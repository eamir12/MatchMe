


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE EXTENSION IF NOT EXISTS "pg_cron" WITH SCHEMA "pg_catalog";






CREATE EXTENSION IF NOT EXISTS "pg_net" WITH SCHEMA "extensions";








ALTER SCHEMA "public" OWNER TO "postgres";


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "http" WITH SCHEMA "public";






CREATE EXTENSION IF NOT EXISTS "hypopg" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "index_advisor" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";






CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."_format_mfa_recovery_code"("p_raw" "text") RETURNS "text"
    LANGUAGE "sql"
    AS $$
  SELECT upper(
    substr(p_raw, 1, 4) || '-' ||
    substr(p_raw, 5, 4) || '-' ||
    substr(p_raw, 9, 4) || '-' ||
    substr(p_raw, 13, 4)
  );
$$;


ALTER FUNCTION "public"."_format_mfa_recovery_code"("p_raw" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."_hash_mfa_recovery_code"("p_user_id" "uuid", "p_normalized_code" "text") RETURNS "text"
    LANGUAGE "sql"
    AS $$
  SELECT encode(extensions.digest(COALESCE(p_normalized_code, '') || ':' || p_user_id::text, 'sha256'), 'hex');
$$;


ALTER FUNCTION "public"."_hash_mfa_recovery_code"("p_user_id" "uuid", "p_normalized_code" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."_normalize_mfa_recovery_code"("p_code" "text") RETURNS "text"
    LANGUAGE "sql"
    AS $$
  SELECT upper(regexp_replace(COALESCE(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
$$;


ALTER FUNCTION "public"."_normalize_mfa_recovery_code"("p_code" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."add_subscription_to_queue"("p_user_id" "uuid", "p_tier" character varying, "p_duration_seconds" integer, "p_payment_provider" character varying DEFAULT 'manual'::character varying, "p_transaction_id" "text" DEFAULT NULL::"text", "p_metadata" "jsonb" DEFAULT '{}'::"jsonb") RETURNS TABLE("queue_entry_id" "uuid", "starts_at" timestamp with time zone, "expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_starts_at timestamptz;
  v_expires_at timestamptz;
  v_current_expires_at timestamptz;
  v_last_queued_expires_at timestamptz;
  v_queue_id uuid;
BEGIN
  v_user_id := COALESCE(p_user_id, auth.uid());

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'missing user_id';
  END IF;

  IF v_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  PERFORM pg_advisory_xact_lock(hashtext(v_user_id::text));

  PERFORM public.normalize_user_subscription_queue(v_user_id);

  SELECT u.subscription_expires_at
  INTO v_current_expires_at
  FROM public.users u
  WHERE u.id = v_user_id;

  SELECT MAX(sq.expires_at)
  INTO v_last_queued_expires_at
  FROM public.user_subscription_queue sq
  WHERE sq.user_id = v_user_id
    AND sq.status IN ('pending', 'active')
    AND sq.expires_at > now();

  v_starts_at := now();
  IF v_current_expires_at IS NOT NULL AND v_current_expires_at > v_starts_at THEN
    v_starts_at := v_current_expires_at;
  END IF;
  IF v_last_queued_expires_at IS NOT NULL AND v_last_queued_expires_at > v_starts_at THEN
    v_starts_at := v_last_queued_expires_at;
  END IF;

  v_expires_at := v_starts_at + (GREATEST(COALESCE(p_duration_seconds, 0), 0) || ' seconds')::interval;

  INSERT INTO public.user_subscription_queue (
    user_id,
    tier,
    status,
    starts_at,
    expires_at,
    payment_provider,
    transaction_id,
    purchase_metadata,
    created_at,
    updated_at
  ) VALUES (
    v_user_id,
    p_tier,
    'pending',
    v_starts_at,
    v_expires_at,
    p_payment_provider,
    p_transaction_id,
    COALESCE(p_metadata, '{}'::jsonb),
    now(),
    now()
  )
  RETURNING id INTO v_queue_id;

  PERFORM public.normalize_user_subscription_queue(v_user_id);

  RETURN QUERY SELECT v_queue_id, v_starts_at, v_expires_at;
END;
$$;


ALTER FUNCTION "public"."add_subscription_to_queue"("p_user_id" "uuid", "p_tier" character varying, "p_duration_seconds" integer, "p_payment_provider" character varying, "p_transaction_id" "text", "p_metadata" "jsonb") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."add_subscription_to_queue"("p_user_id" "uuid", "p_tier" character varying, "p_duration_seconds" integer, "p_payment_provider" character varying, "p_transaction_id" "text", "p_metadata" "jsonb") IS 'Adds a new subscription to the queue, automatically calculating start time based on existing subscriptions';



CREATE OR REPLACE FUNCTION "public"."admin_assert_is_admin"() RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1
    FROM public.users
    WHERE id = auth.uid()
      AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Admin access required'
      USING ERRCODE = '42501';
  END IF;
END;
$$;


ALTER FUNCTION "public"."admin_assert_is_admin"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_bulk_upsert_translations"("p_items" "jsonb") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_count integer := 0;
  v_item jsonb;
  v_locale text;
  v_key text;
  v_value text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_items IS NULL OR jsonb_typeof(p_items) <> 'array' THEN
    RAISE EXCEPTION 'p_items must be a JSON array';
  END IF;

  FOR v_item IN SELECT jsonb_array_elements(p_items)
  LOOP
    v_locale := NULLIF(trim(v_item->>'locale'), '');
    v_key := NULLIF(trim(v_item->>'key'), '');
    v_value := COALESCE(v_item->>'value', '');

    IF v_locale IS NULL OR v_key IS NULL THEN
      CONTINUE;
    END IF;

    IF v_locale NOT IN ('en', 'es', 'he') THEN
      CONTINUE;
    END IF;

    INSERT INTO public.translations (locale, key, value)
    VALUES (v_locale, v_key, v_value)
    ON CONFLICT (locale, key) DO UPDATE
    SET value = EXCLUDED.value;

    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END;
$$;


ALTER FUNCTION "public"."admin_bulk_upsert_translations"("p_items" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_create_promo_code"("p_code" "text", "p_description" "text", "p_code_type" "text", "p_amount" integer DEFAULT NULL::integer, "p_upgrade_tier" "text" DEFAULT NULL::"text", "p_applicable_tiers" "text"[] DEFAULT ARRAY[]::"text"[], "p_campaign_name" "text" DEFAULT NULL::"text", "p_max_uses" integer DEFAULT NULL::integer, "p_max_uses_per_user" integer DEFAULT 1, "p_valid_from" timestamp with time zone DEFAULT "now"(), "p_valid_until" timestamp with time zone DEFAULT ("now"() + '90 days'::interval), "p_min_tier" "text" DEFAULT NULL::"text") RETURNS TABLE("id" "uuid", "code" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    SET "row_security" TO 'off'
    AS $$
DECLARE
  v_user_id UUID;
  v_code_id UUID;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.users AS u
    WHERE u.id = v_user_id
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'Only admins can create promo codes';
  END IF;

  IF p_code IS NULL OR TRIM(p_code) = '' THEN
    RAISE EXCEPTION 'Code is required';
  END IF;

  IF p_code_type NOT IN ('discount_percentage', 'discount_fixed', 'free_days', 'tier_upgrade') THEN
    RAISE EXCEPTION 'Invalid code type';
  END IF;

  IF p_max_uses_per_user IS NULL OR p_max_uses_per_user < 1 THEN
    RAISE EXCEPTION 'Max uses per user must be at least 1';
  END IF;

  IF p_max_uses IS NOT NULL AND p_max_uses < 1 THEN
    RAISE EXCEPTION 'Max uses must be at least 1 when provided';
  END IF;

  IF p_valid_until < p_valid_from THEN
    RAISE EXCEPTION 'Valid until must be on or after valid from';
  END IF;

  INSERT INTO public.promo_codes (
    code,
    description,
    code_type,
    amount,
    upgrade_tier,
    applicable_tiers,
    min_tier,
    campaign_name,
    max_uses,
    max_uses_per_user,
    valid_from,
    valid_until,
    created_by,
    is_active
  )
  VALUES (
    UPPER(TRIM(p_code)),
    NULLIF(TRIM(p_description), ''),
    p_code_type,
    p_amount,
    p_upgrade_tier,
    COALESCE(p_applicable_tiers, ARRAY[]::TEXT[]),
    p_min_tier,
    p_campaign_name,
    p_max_uses,
    p_max_uses_per_user,
    p_valid_from,
    p_valid_until,
    v_user_id,
    true
  )
  RETURNING promo_codes.id INTO v_code_id;

  RETURN QUERY
  SELECT v_code_id, UPPER(TRIM(p_code)), now();
END;
$$;


ALTER FUNCTION "public"."admin_create_promo_code"("p_code" "text", "p_description" "text", "p_code_type" "text", "p_amount" integer, "p_upgrade_tier" "text", "p_applicable_tiers" "text"[], "p_campaign_name" "text", "p_max_uses" integer, "p_max_uses_per_user" integer, "p_valid_from" timestamp with time zone, "p_valid_until" timestamp with time zone, "p_min_tier" "text") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."admin_create_promo_code"("p_code" "text", "p_description" "text", "p_code_type" "text", "p_amount" integer, "p_upgrade_tier" "text", "p_applicable_tiers" "text"[], "p_campaign_name" "text", "p_max_uses" integer, "p_max_uses_per_user" integer, "p_valid_from" timestamp with time zone, "p_valid_until" timestamp with time zone, "p_min_tier" "text") IS 'Creates a new promo code (admin only)';



CREATE OR REPLACE FUNCTION "public"."admin_delete_intent"("p_id" bigint) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_id IS NULL OR p_id = 0 THEN
    RAISE EXCEPTION 'p_id is required';
  END IF;

  IF EXISTS (SELECT 1 FROM public.intents i WHERE i.parent_id = p_id) THEN
    RAISE EXCEPTION 'has children';
  END IF;

  DELETE FROM public.intents WHERE id = p_id;
END;
$$;


ALTER FUNCTION "public"."admin_delete_intent"("p_id" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_delete_interest"("p_id" bigint) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_id IS NULL OR p_id = 0 THEN
    RAISE EXCEPTION 'p_id is required';
  END IF;

  IF EXISTS (SELECT 1 FROM public.interests i WHERE i.parent_id = p_id) THEN
    RAISE EXCEPTION 'has children';
  END IF;

  DELETE FROM public.interests WHERE id = p_id;
END;
$$;


ALTER FUNCTION "public"."admin_delete_interest"("p_id" bigint) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_delete_subscription_plan"("p_id" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_id IS NULL OR btrim(p_id) = '' THEN
    RAISE EXCEPTION 'plan id is required';
  END IF;

  DELETE FROM public.subscription_plans sp
  WHERE sp.id = p_id;
END;
$$;


ALTER FUNCTION "public"."admin_delete_subscription_plan"("p_id" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_delete_subscription_tier"("p_id" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_id IS NULL OR btrim(p_id) = '' THEN
    RAISE EXCEPTION 'tier id is required';
  END IF;

  DELETE FROM public.subscription_tiers st
  WHERE st.id = p_id;
END;
$$;


ALTER FUNCTION "public"."admin_delete_subscription_tier"("p_id" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_delete_translation_key"("p_key" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_trimmed_key text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_trimmed_key := NULLIF(trim(p_key), '');
  IF v_trimmed_key IS NULL THEN
    RAISE EXCEPTION 'p_key is required';
  END IF;

  DELETE FROM public.translations
  WHERE key = v_trimmed_key;
END;
$$;


ALTER FUNCTION "public"."admin_delete_translation_key"("p_key" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_delete_translation_locale_key"("p_locale" "text", "p_key" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_trimmed_locale text;
  v_trimmed_key text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_trimmed_locale := NULLIF(trim(p_locale), '');
  v_trimmed_key := NULLIF(trim(p_key), '');
  IF v_trimmed_locale IS NULL OR v_trimmed_key IS NULL THEN
    RAISE EXCEPTION 'p_locale and p_key are required';
  END IF;

  DELETE FROM public.translations
  WHERE locale = v_trimmed_locale
    AND key = v_trimmed_key;
END;
$$;


ALTER FUNCTION "public"."admin_delete_translation_locale_key"("p_locale" "text", "p_key" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_ai_quota_status"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_updated_at timestamptz;
  v_providers jsonb;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  )
  INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT MAX(updated_at) INTO v_updated_at
  FROM public.ai_quota_status;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'provider', provider,
        'updated_at', CASE
          WHEN provider_updated_at IS NULL THEN NULL
          ELSE to_char(provider_updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
        END,
        'metrics', metrics
      )
      ORDER BY provider
    ),
    '[]'::jsonb
  )
  INTO v_providers
  FROM (
    SELECT
      provider,
      MAX(updated_at) AS provider_updated_at,
      COALESCE(
        jsonb_agg(
          jsonb_build_object(
            'metric', metric,
            'window', window_key,
            'used', used,
            'limit', limit_value,
            'unit', unit,
            'status', status,
            'start_time', CASE
              WHEN start_time IS NULL THEN NULL
              ELSE to_char(start_time AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
            END,
            'end_time', CASE
              WHEN end_time IS NULL THEN NULL
              ELSE to_char(end_time AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
            END,
            'updated_at', to_char(updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
            'details', details
          )
          ORDER BY metric, window_key
        ),
        '[]'::jsonb
      ) AS metrics
    FROM public.ai_quota_status
    GROUP BY provider
  ) s;

  RETURN jsonb_build_object(
    'updated_at', CASE
      WHEN v_updated_at IS NULL THEN NULL
      ELSE to_char(v_updated_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
    END,
    'providers', v_providers
  );
END;
$$;


ALTER FUNCTION "public"."admin_get_ai_quota_status"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_dashboard_drilldown"("p_window" "text" DEFAULT '24h'::"text", "p_metric" "text" DEFAULT NULL::"text", "p_param" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 200, "p_offset" integer DEFAULT 0) RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  v_is_admin boolean;
  v_window text;
  v_metric text;
  v_param text;
  v_p1 text;
  v_p2 text;
  v_p3 text;
  v_start timestamptz;
  v_limit int;
  v_offset int;
  v_fetch int;
  v_result jsonb;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_window := COALESCE(NULLIF(trim(p_window), ''), '24h');
  IF v_window NOT IN ('24h', '7d') THEN
    v_window := '24h';
  END IF;

  v_metric := COALESCE(NULLIF(trim(p_metric), ''), '');
  v_param := NULLIF(trim(COALESCE(p_param, '')), '');
  v_p1 := NULLIF(trim(split_part(COALESCE(v_param, ''), '|', 1)), '');
  v_p2 := NULLIF(trim(split_part(COALESCE(v_param, ''), '|', 2)), '');
  v_p3 := NULLIF(trim(split_part(COALESCE(v_param, ''), '|', 3)), '');

  v_limit := GREATEST(LEAST(COALESCE(p_limit, 200), 500), 1);
  v_offset := GREATEST(COALESCE(p_offset, 0), 0);
  v_fetch := v_limit + 1;

  IF v_window = '24h' THEN
    v_start := date_trunc('hour', now() - interval '23 hours');
  ELSE
    v_start := date_trunc('day', now() - interval '6 days');
  END IF;

  IF v_metric = 'online_users' THEN
    WITH rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        ua.last_activity AS last_activity_at
      FROM public.users u
      JOIN public.user_activity ua ON ua.user_id = u.id
      WHERE ua.is_online = true
        AND ua.last_activity > now() - interval '45 seconds'
      ORDER BY ua.last_activity DESC, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'visible_users' THEN
    WITH rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        ua.last_activity AS last_activity_at
      FROM public.users u
      JOIN public.user_activity ua ON ua.user_id = u.id
      WHERE ua.is_online = true
        AND ua.last_activity > now() - interval '45 seconds'
        AND COALESCE(u.user_visibility_setting, false) = true
        AND COALESCE(u.system_visibility_status, 'visible') = 'visible'
      ORDER BY ua.last_activity DESC, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'new_users' THEN
    WITH rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        u.created_at AS created_at
      FROM public.users u
      WHERE u.created_at >= v_start
      ORDER BY u.created_at DESC, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'messages_sent' THEN
    WITH rows AS (
      SELECT
        cm.sender_id AS user_id,
        u.name AS user_name,
        COUNT(*)::int AS messages
      FROM public.chat_messages cm
      LEFT JOIN public.users u ON u.id = cm.sender_id
      WHERE cm.created_at >= v_start
      GROUP BY cm.sender_id, u.name
      ORDER BY COUNT(*) DESC, cm.sender_id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'matches_created' THEN
    WITH rows AS (
      SELECT
        m.id AS match_id,
        m.user1_id,
        u1.name AS user1_name,
        m.user2_id,
        u2.name AS user2_name,
        m.created_at AS matched_at,
        m.matched_intent,
        to_jsonb(
          ARRAY(
            SELECT x
            FROM unnest(
              ARRAY[
                CASE WHEN m.match_type = 'proximity' THEN 'proximity' END,
                CASE WHEN m.match_type = 'event' THEN 'event' END,
                'shared_intent',
                CASE WHEN m.match_type IN ('proximity', 'event') THEN 'shared_interest' END
              ]::text[]
            ) AS t(x)
            WHERE x IS NOT NULL
          )
        ) AS basis,
        m.event_id,
        e.event_name
      FROM public.matches m
      LEFT JOIN public.users u1 ON u1.id = m.user1_id
      LEFT JOIN public.users u2 ON u2.id = m.user2_id
      LEFT JOIN public.events e ON e.id = m.event_id
      WHERE m.created_at >= v_start
      ORDER BY m.created_at DESC, m.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'active_matches' THEN
    WITH recent_match_ids AS (
      SELECT
        c.match_id,
        MAX(COALESCE(c.last_message_at, c.updated_at)) AS last_activity_at
      FROM public.chats c
      WHERE COALESCE(c.last_message_at, c.updated_at) >= v_start
      GROUP BY c.match_id
    ),
    rows AS (
      SELECT
        m.id AS match_id,
        m.user1_id,
        u1.name AS user1_name,
        m.user2_id,
        u2.name AS user2_name,
        m.created_at AS matched_at,
        r.last_activity_at,
        m.matched_intent,
        to_jsonb(
          ARRAY(
            SELECT x
            FROM unnest(
              ARRAY[
                CASE WHEN m.match_type = 'proximity' THEN 'proximity' END,
                CASE WHEN m.match_type = 'event' THEN 'event' END,
                'shared_intent',
                CASE WHEN m.match_type IN ('proximity', 'event') THEN 'shared_interest' END
              ]::text[]
            ) AS t(x)
            WHERE x IS NOT NULL
          )
        ) AS basis,
        m.event_id,
        e.event_name
      FROM recent_match_ids r
      JOIN public.matches m ON m.id = r.match_id
      LEFT JOIN public.users u1 ON u1.id = m.user1_id
      LEFT JOIN public.users u2 ON u2.id = m.user2_id
      LEFT JOIN public.events e ON e.id = m.event_id
      ORDER BY r.last_activity_at DESC, m.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'verification_pending' THEN
    WITH rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        u.verification_status,
        u.verification_submitted_at
      FROM public.users u
      WHERE u.verification_status = 'pending'
      ORDER BY u.verification_submitted_at DESC NULLS LAST, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'verification_analyzing' THEN
    WITH rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        u.verification_status,
        u.verification_submitted_at
      FROM public.users u
      WHERE u.verification_status = 'analyzing'
      ORDER BY u.verification_submitted_at DESC NULLS LAST, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'profile_edits_pending' THEN
    WITH rows AS (
      SELECT
        r.id AS request_id,
        r.user_id,
        u.name AS user_name,
        r.created_at,
        r.message
      FROM public.profile_edit_requests r
      LEFT JOIN public.users u ON u.id = r.user_id
      WHERE r.status = 'pending'
      ORDER BY r.created_at DESC, r.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'broadcasts_draft' THEN
    WITH rows AS (
      SELECT
        b.id AS broadcast_id,
        b.title,
        b.status,
        b.scheduled_at,
        b.created_at,
        b.target_user_count
      FROM public.admin_broadcasts b
      WHERE b.status = 'draft'
      ORDER BY b.updated_at DESC NULLS LAST, b.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'broadcasts_scheduled' THEN
    WITH rows AS (
      SELECT
        b.id AS broadcast_id,
        b.title,
        b.status,
        b.scheduled_at,
        b.created_at,
        b.target_user_count
      FROM public.admin_broadcasts b
      WHERE b.status = 'scheduled'
      ORDER BY b.scheduled_at DESC NULLS LAST, b.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'notifications_pending' THEN
    WITH rows AS (
      SELECT
        n.id AS notification_id,
        n.user_id,
        u.name AS user_name,
        n.title,
        n.status,
        n.attempts,
        n.scheduled_at,
        n.created_at
      FROM public.notification_queue n
      LEFT JOIN public.users u ON u.id = n.user_id
      WHERE n.status = 'pending'
      ORDER BY n.created_at DESC, n.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'notifications_failed' THEN
    WITH rows AS (
      SELECT
        n.id AS notification_id,
        n.user_id,
        u.name AS user_name,
        n.title,
        n.status,
        n.attempts,
        n.failure_reason,
        n.scheduled_at,
        n.created_at
      FROM public.notification_queue n
      LEFT JOIN public.users u ON u.id = n.user_id
      WHERE n.status = 'failed'
      ORDER BY n.created_at DESC, n.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'paid_active_users' THEN
    WITH earnings_currency AS (
      SELECT
        sq.user_id,
        COALESCE(
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency', ''))), ''),
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency_code', ''))), ''),
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currencyCode', ''))), ''),
          'UNK'
        ) AS currency,
        SUM(
          CASE
            WHEN sq.purchase_metadata ? 'amount_cents'
                 AND (sq.purchase_metadata ->> 'amount_cents') ~ '^-?[0-9]+$'
            THEN (sq.purchase_metadata ->> 'amount_cents')::numeric / 100
            WHEN sq.purchase_metadata ? 'amount'
                 AND (sq.purchase_metadata ->> 'amount') ~ '^-?[0-9]+(\.[0-9]+)?$'
            THEN (sq.purchase_metadata ->> 'amount')::numeric
            ELSE 0
          END
        ) AS total_amount
      FROM public.user_subscription_queue sq
      WHERE COALESCE(NULLIF(btrim(COALESCE(sq.payment_provider, '')), ''), '') <> ''
        AND COALESCE(lower(btrim(COALESCE(sq.status, ''))), '') <> 'cancelled'
      GROUP BY 1, 2
    ),
    earnings_json AS (
      SELECT
        user_id,
        COALESCE(
          jsonb_object_agg(currency, total_amount) FILTER (WHERE total_amount <> 0),
          '{}'::jsonb
        ) AS earnings
      FROM earnings_currency
      GROUP BY user_id
    ),
    rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        u.subscription_tier,
        u.subscription_expires_at,
        COALESCE(ej.earnings, '{}'::jsonb) AS earnings
      FROM public.users u
      LEFT JOIN earnings_json ej ON ej.user_id = u.id
      WHERE COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') <> 'free'
        AND u.subscription_expires_at IS NOT NULL
        AND u.subscription_expires_at > now()
      ORDER BY u.subscription_expires_at ASC, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'paid_expiring_7d' THEN
    WITH earnings_currency AS (
      SELECT
        sq.user_id,
        COALESCE(
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency', ''))), ''),
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency_code', ''))), ''),
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currencyCode', ''))), ''),
          'UNK'
        ) AS currency,
        SUM(
          CASE
            WHEN sq.purchase_metadata ? 'amount_cents'
                 AND (sq.purchase_metadata ->> 'amount_cents') ~ '^-?[0-9]+$'
            THEN (sq.purchase_metadata ->> 'amount_cents')::numeric / 100
            WHEN sq.purchase_metadata ? 'amount'
                 AND (sq.purchase_metadata ->> 'amount') ~ '^-?[0-9]+(\.[0-9]+)?$'
            THEN (sq.purchase_metadata ->> 'amount')::numeric
            ELSE 0
          END
        ) AS total_amount
      FROM public.user_subscription_queue sq
      WHERE COALESCE(NULLIF(btrim(COALESCE(sq.payment_provider, '')), ''), '') <> ''
        AND COALESCE(lower(btrim(COALESCE(sq.status, ''))), '') <> 'cancelled'
      GROUP BY 1, 2
    ),
    earnings_json AS (
      SELECT
        user_id,
        COALESCE(
          jsonb_object_agg(currency, total_amount) FILTER (WHERE total_amount <> 0),
          '{}'::jsonb
        ) AS earnings
      FROM earnings_currency
      GROUP BY user_id
    ),
    rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        u.subscription_tier,
        u.subscription_expires_at,
        COALESCE(ej.earnings, '{}'::jsonb) AS earnings
      FROM public.users u
      LEFT JOIN earnings_json ej ON ej.user_id = u.id
      WHERE COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') <> 'free'
        AND u.subscription_expires_at IS NOT NULL
        AND u.subscription_expires_at > now()
        AND u.subscription_expires_at <= now() + interval '7 days'
      ORDER BY u.subscription_expires_at ASC, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'paid_by_tier' THEN
    WITH earnings_currency AS (
      SELECT
        sq.user_id,
        COALESCE(
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency', ''))), ''),
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency_code', ''))), ''),
          NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currencyCode', ''))), ''),
          'UNK'
        ) AS currency,
        SUM(
          CASE
            WHEN sq.purchase_metadata ? 'amount_cents'
                 AND (sq.purchase_metadata ->> 'amount_cents') ~ '^-?[0-9]+$'
            THEN (sq.purchase_metadata ->> 'amount_cents')::numeric / 100
            WHEN sq.purchase_metadata ? 'amount'
                 AND (sq.purchase_metadata ->> 'amount') ~ '^-?[0-9]+(\.[0-9]+)?$'
            THEN (sq.purchase_metadata ->> 'amount')::numeric
            ELSE 0
          END
        ) AS total_amount
      FROM public.user_subscription_queue sq
      WHERE COALESCE(NULLIF(btrim(COALESCE(sq.payment_provider, '')), ''), '') <> ''
        AND COALESCE(lower(btrim(COALESCE(sq.status, ''))), '') <> 'cancelled'
      GROUP BY 1, 2
    ),
    earnings_json AS (
      SELECT
        user_id,
        COALESCE(
          jsonb_object_agg(currency, total_amount) FILTER (WHERE total_amount <> 0),
          '{}'::jsonb
        ) AS earnings
      FROM earnings_currency
      GROUP BY user_id
    ),
    rows AS (
      SELECT
        u.id AS user_id,
        u.name AS user_name,
        COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') AS subscription_tier,
        u.subscription_expires_at,
        COALESCE(ej.earnings, '{}'::jsonb) AS earnings
      FROM public.users u
      LEFT JOIN earnings_json ej ON ej.user_id = u.id
      WHERE COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') <> 'free'
        AND u.subscription_expires_at IS NOT NULL
        AND u.subscription_expires_at > now()
        AND (v_param IS NULL OR COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') = v_param)
      ORDER BY u.subscription_expires_at ASC, u.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'param', v_param,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'edge_function_usage' THEN
    WITH rows AS (
      SELECT
        e.request_id,
        e.function_name,
        e.invoked_at,
        e.duration_ms,
        e.success,
        e.http_status,
        e.error_type,
        e.error_message,
        e.ai_used,
        e.ai_provider,
        e.ai_model,
        e.ai_task
      FROM public.edge_function_invocations e
      WHERE e.invoked_at >= v_start
        AND (v_param IS NULL OR e.function_name = v_param)
      ORDER BY e.invoked_at DESC, e.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'param', v_param,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSIF v_metric = 'ai_usage' THEN
    WITH rows AS (
      SELECT
        e.request_id,
        e.function_name,
        e.invoked_at,
        e.duration_ms,
        e.success,
        e.http_status,
        e.error_type,
        e.error_message,
        e.ai_provider,
        e.ai_model,
        e.ai_task
      FROM public.edge_function_invocations e
      WHERE e.invoked_at >= v_start
        AND e.ai_used = true
        AND (v_p1 IS NULL OR e.ai_provider = v_p1)
        AND (v_p2 IS NULL OR e.ai_model = v_p2)
        AND (v_p3 IS NULL OR e.ai_task = v_p3)
      ORDER BY e.invoked_at DESC, e.id DESC
      LIMIT v_fetch
      OFFSET v_offset
    ),
    rows_limited AS (
      SELECT * FROM rows LIMIT v_limit
    ),
    stats AS (
      SELECT (COUNT(*) > v_limit) AS has_more FROM rows
    )
    SELECT jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'param', v_param,
      'rows', COALESCE((SELECT jsonb_agg(to_jsonb(rows_limited)) FROM rows_limited), '[]'::jsonb),
      'has_more', COALESCE((SELECT has_more FROM stats), false)
    ) INTO v_result;
  ELSE
    v_result := jsonb_build_object(
      'metric', v_metric,
      'window', v_window,
      'rows', '[]'::jsonb,
      'has_more', false
    );
  END IF;

  RETURN v_result;
END;
$_$;


ALTER FUNCTION "public"."admin_get_dashboard_drilldown"("p_window" "text", "p_metric" "text", "p_param" "text", "p_limit" integer, "p_offset" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_dashboard_stats"("p_window" "text" DEFAULT '24h'::"text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  v_is_admin boolean;
  v_window text := lower(btrim(COALESCE(p_window, '24h')));
  v_start timestamptz;
  v_step interval;
  v_bucket_trunc text;
  v_series jsonb;

  v_online_users int;
  v_visible_users int;

  v_matches_window int;
  v_messages_window int;
  v_signups_window int;
  v_active_matches_window int;

  v_verification_pending int;
  v_verification_analyzing int;
  v_profile_edits_pending int;
  v_broadcasts_draft int;
  v_broadcasts_scheduled int;
  v_notifications_pending int;
  v_notifications_failed int;

  v_paid_active int;
  v_paid_expiring_7d int;
  v_paid_by_tier jsonb;
  v_earnings_by_currency jsonb;

  v_ai_usage_summary jsonb;
  v_ai_recent_errors jsonb;
  v_edge_functions_summary jsonb;
  v_edge_functions_recent_errors jsonb;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  )
  INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF v_window NOT IN ('24h', '7d') THEN
    v_window := '24h';
  END IF;

  IF v_window = '24h' THEN
    v_bucket_trunc := 'hour';
    v_step := interval '1 hour';
    v_start := date_trunc('hour', now() - interval '23 hours');
  ELSE
    v_bucket_trunc := 'day';
    v_step := interval '1 day';
    v_start := date_trunc('day', now() - interval '6 days');
  END IF;

  v_online_users := COALESCE(public.get_online_users_count(auth.uid()), 0);
  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_visible_users
  FROM public.users u
  JOIN public.user_activity ua ON ua.user_id = u.id
  WHERE ua.is_online = true
    AND ua.last_activity > now() - interval '45 seconds'
    AND COALESCE(u.user_visibility_setting, false) = true
    AND COALESCE(u.system_visibility_status, 'visible') = 'visible';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_matches_window
  FROM public.matches m
  WHERE m.created_at >= v_start;

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_messages_window
  FROM public.chat_messages cm
  WHERE cm.created_at >= v_start;

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_signups_window
  FROM public.users u
  WHERE u.created_at >= v_start;

  SELECT COALESCE(COUNT(DISTINCT c.match_id), 0)::int
  INTO v_active_matches_window
  FROM public.chats c
  WHERE COALESCE(c.last_message_at, c.updated_at) >= v_start;

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_verification_pending
  FROM public.users u
  WHERE u.verification_status = 'pending';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_verification_analyzing
  FROM public.users u
  WHERE u.verification_status = 'analyzing';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_profile_edits_pending
  FROM public.profile_edit_requests r
  WHERE r.status = 'pending';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_broadcasts_draft
  FROM public.admin_broadcasts b
  WHERE b.status = 'draft';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_broadcasts_scheduled
  FROM public.admin_broadcasts b
  WHERE b.status = 'scheduled';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_notifications_pending
  FROM public.notification_queue nq
  WHERE nq.status = 'pending';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_notifications_failed
  FROM public.notification_queue nq
  WHERE nq.status = 'failed';

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_paid_active
  FROM public.users u
  WHERE COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') <> 'free'
    AND u.subscription_expires_at IS NOT NULL
    AND u.subscription_expires_at > now();

  SELECT COALESCE(COUNT(*), 0)::int
  INTO v_paid_expiring_7d
  FROM public.users u
  WHERE COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') <> 'free'
    AND u.subscription_expires_at IS NOT NULL
    AND u.subscription_expires_at > now()
    AND u.subscription_expires_at <= now() + interval '7 days';

  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(tier, cnt)
      FROM (
        SELECT
          COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') AS tier,
          COUNT(*)::int AS cnt
        FROM public.users u
        WHERE COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') <> 'free'
          AND u.subscription_expires_at IS NOT NULL
          AND u.subscription_expires_at > now()
        GROUP BY 1
        ORDER BY 1
      ) s
    ),
    '{}'::jsonb
  )
  INTO v_paid_by_tier;

  SELECT COALESCE(
    (
      SELECT jsonb_object_agg(currency, total_amount) FILTER (WHERE total_amount <> 0)
      FROM (
        SELECT
          COALESCE(
            NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency', ''))), ''),
            NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currency_code', ''))), ''),
            NULLIF(upper(btrim(COALESCE(sq.purchase_metadata ->> 'currencyCode', ''))), ''),
            'unknown'
          ) AS currency,
          SUM(
            CASE
              WHEN sq.purchase_metadata ? 'amount_cents'
                   AND (sq.purchase_metadata ->> 'amount_cents') ~ '^-?[0-9]+$'
              THEN (sq.purchase_metadata ->> 'amount_cents')::numeric / 100
              WHEN sq.purchase_metadata ? 'amount'
                   AND (sq.purchase_metadata ->> 'amount') ~ '^-?[0-9]+(\.[0-9]+)?$'
              THEN (sq.purchase_metadata ->> 'amount')::numeric
              ELSE 0
            END
          ) AS total_amount
        FROM public.user_subscription_queue sq
        WHERE sq.created_at >= (
          CASE
            WHEN v_window = '7d' THEN date_trunc('day', now() - interval '7 days')
            ELSE v_start
          END
        )
          AND COALESCE(NULLIF(btrim(COALESCE(sq.payment_provider, '')), ''), '') <> ''
          AND COALESCE(lower(btrim(COALESCE(sq.status, ''))), '') <> 'cancelled'
        GROUP BY 1
        ORDER BY 1
      ) s
    ),
    '{}'::jsonb
  )
  INTO v_earnings_by_currency;

  WITH buckets AS (
    SELECT generate_series(
      v_start,
      date_trunc(v_bucket_trunc, now()),
      v_step
    ) AS bucket
  ),
  match_counts AS (
    SELECT date_trunc(v_bucket_trunc, m.created_at) AS bucket, COUNT(*)::int AS c
    FROM public.matches m
    WHERE m.created_at >= v_start
    GROUP BY 1
  ),
  message_counts AS (
    SELECT date_trunc(v_bucket_trunc, cm.created_at) AS bucket, COUNT(*)::int AS c
    FROM public.chat_messages cm
    WHERE cm.created_at >= v_start
    GROUP BY 1
  ),
  signup_counts AS (
    SELECT date_trunc(v_bucket_trunc, u.created_at) AS bucket, COUNT(*)::int AS c
    FROM public.users u
    WHERE u.created_at >= v_start
    GROUP BY 1
  ),
  active_match_counts AS (
    SELECT date_trunc(v_bucket_trunc, COALESCE(c.last_message_at, c.updated_at)) AS bucket, COUNT(DISTINCT c.match_id)::int AS c
    FROM public.chats c
    WHERE COALESCE(c.last_message_at, c.updated_at) >= v_start
    GROUP BY 1
  )
  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        't', to_char(b.bucket AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
        'matches', COALESCE(mc.c, 0),
        'messages', COALESCE(msg.c, 0),
        'signups', COALESCE(sc.c, 0),
        'active_matches', COALESCE(amc.c, 0)
      )
      ORDER BY b.bucket
    ),
    '[]'::jsonb
  )
  INTO v_series
  FROM buckets b
  LEFT JOIN match_counts mc ON mc.bucket = b.bucket
  LEFT JOIN message_counts msg ON msg.bucket = b.bucket
  LEFT JOIN signup_counts sc ON sc.bucket = b.bucket
  LEFT JOIN active_match_counts amc ON amc.bucket = b.bucket;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'provider', provider,
        'model', model,
        'task', task,
        'calls', calls,
        'failures', failures
      )
      ORDER BY calls DESC
    ),
    '[]'::jsonb
  )
  INTO v_ai_usage_summary
  FROM (
    SELECT
      COALESCE(NULLIF(btrim(COALESCE(efi.ai_provider, '')), ''), 'unknown') AS provider,
      COALESCE(NULLIF(btrim(COALESCE(efi.ai_model, '')), ''), 'unknown') AS model,
      COALESCE(NULLIF(btrim(COALESCE(efi.ai_task, '')), ''), 'unknown') AS task,
      COUNT(*)::int AS calls,
      COUNT(*) FILTER (WHERE efi.success = false)::int AS failures
    FROM public.edge_function_invocations efi
    WHERE efi.invoked_at >= v_start
      AND efi.ai_used = true
    GROUP BY 1, 2, 3
    ORDER BY COUNT(*) DESC
    LIMIT 20
  ) s;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        't', to_char(invoked_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
        'function', function_name,
        'provider', COALESCE(NULLIF(btrim(COALESCE(ai_provider, '')), ''), 'unknown'),
        'model', COALESCE(NULLIF(btrim(COALESCE(ai_model, '')), ''), 'unknown'),
        'task', COALESCE(NULLIF(btrim(COALESCE(ai_task, '')), ''), 'unknown'),
        'request_id', request_id::text,
        'error_type', error_type,
        'error_message', error_message,
        'http_status', http_status
      )
      ORDER BY invoked_at DESC
    ),
    '[]'::jsonb
  )
  INTO v_ai_recent_errors
  FROM (
    SELECT invoked_at, function_name, ai_provider, ai_model, ai_task, request_id, error_type, error_message, http_status
    FROM public.edge_function_invocations
    WHERE invoked_at >= v_start
      AND ai_used = true
      AND success = false
    ORDER BY invoked_at DESC
    LIMIT 25
  ) e;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'function', function_name,
        'calls', calls,
        'failures', failures,
        'last_error_at', CASE
          WHEN last_error_at IS NULL THEN NULL
          ELSE to_char(last_error_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"')
        END
      )
      ORDER BY calls DESC
    ),
    '[]'::jsonb
  )
  INTO v_edge_functions_summary
  FROM (
    SELECT
      efi.function_name,
      COUNT(*)::int AS calls,
      COUNT(*) FILTER (WHERE efi.success = false)::int AS failures,
      MAX(efi.invoked_at) FILTER (WHERE efi.success = false) AS last_error_at
    FROM public.edge_function_invocations efi
    WHERE efi.invoked_at >= v_start
    GROUP BY 1
    ORDER BY COUNT(*) DESC
    LIMIT 20
  ) s;

  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        't', to_char(invoked_at AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
        'function', function_name,
        'request_id', request_id::text,
        'error_type', error_type,
        'error_message', error_message,
        'http_status', http_status
      )
      ORDER BY invoked_at DESC
    ),
    '[]'::jsonb
  )
  INTO v_edge_functions_recent_errors
  FROM (
    SELECT invoked_at, function_name, request_id, error_type, error_message, http_status
    FROM public.edge_function_invocations
    WHERE invoked_at >= v_start
      AND success = false
    ORDER BY invoked_at DESC
    LIMIT 25
  ) e;

  RETURN jsonb_build_object(
    'generated_at', to_char(now() AT TIME ZONE 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"'),
    'window', v_window,
    'engagement', jsonb_build_object(
      'online_users', v_online_users,
      'visible_users', v_visible_users,
      'matches_created', v_matches_window,
      'messages_sent', v_messages_window,
      'new_users', v_signups_window,
      'active_matches', v_active_matches_window
    ),
    'engagement_series', v_series,
    'operations', jsonb_build_object(
      'verification_pending', v_verification_pending,
      'verification_analyzing', v_verification_analyzing,
      'profile_edits_pending', v_profile_edits_pending,
      'broadcasts_draft', v_broadcasts_draft,
      'broadcasts_scheduled', v_broadcasts_scheduled,
      'notifications_pending', v_notifications_pending,
      'notifications_failed', v_notifications_failed
    ),
    'revenue', jsonb_build_object(
      'paid_active_users', v_paid_active,
      'paid_expiring_7d', v_paid_expiring_7d,
      'paid_by_tier', v_paid_by_tier,
      'earnings_by_currency', v_earnings_by_currency
    ),
    'safety', jsonb_build_object(
      'available', false
    ),
    'ai', jsonb_build_object(
      'usage', v_ai_usage_summary,
      'recent_errors', v_ai_recent_errors,
      'quota_status', public.admin_get_ai_quota_status()
    ),
    'edge_functions', jsonb_build_object(
      'usage', v_edge_functions_summary,
      'recent_errors', v_edge_functions_recent_errors
    )
  );
END;
$_$;


ALTER FUNCTION "public"."admin_get_dashboard_stats"("p_window" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_promo_discount_by_date"() RETURNS TABLE("date" "text", "total_discount_cents" bigint, "total_uses" integer, "unique_users" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Permission denied: user is not an admin';
  END IF;

  RETURN QUERY
  SELECT
    TO_CHAR(pcu.redeemed_at, 'YYYY-MM-DD') AS date,
    COALESCE(SUM(pcu.discount_value_cents), 0)::BIGINT AS total_discount_cents,
    COUNT(pcu.id)::INT AS total_uses,
    COUNT(DISTINCT pcu.user_id)::INT AS unique_users
  FROM public.promo_code_usages AS pcu
  WHERE pcu.redeemed_at >= NOW() - INTERVAL '90 days'
  GROUP BY TO_CHAR(pcu.redeemed_at, 'YYYY-MM-DD')
  ORDER BY date DESC;
END;
$$;


ALTER FUNCTION "public"."admin_get_promo_discount_by_date"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_promo_usage_by_code"() RETURNS TABLE("promo_code_id" "uuid", "promo_code" "text", "code_type" "text", "amount" integer, "total_uses" integer, "unique_users" integer, "total_discount_cents" bigint, "is_active" boolean, "valid_until" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Permission denied: user is not an admin';
  END IF;

  RETURN QUERY
  SELECT
    pc.id AS promo_code_id,
    pc.code AS promo_code,
    pc.code_type,
    pc.amount,
    COUNT(pcu.id)::INT AS total_uses,
    COUNT(DISTINCT pcu.user_id)::INT AS unique_users,
    COALESCE(SUM(pcu.discount_value_cents), 0)::BIGINT AS total_discount_cents,
    pc.is_active,
    pc.valid_until
  FROM public.promo_codes AS pc
  INNER JOIN public.promo_code_usages AS pcu ON pcu.promo_code_id = pc.id
  GROUP BY pc.id, pc.code, pc.code_type, pc.amount, pc.is_active, pc.valid_until
  HAVING COUNT(pcu.id) > 0
  ORDER BY total_uses DESC, total_discount_cents DESC;
END;
$$;


ALTER FUNCTION "public"."admin_get_promo_usage_by_code"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_promo_usage_by_user"() RETURNS TABLE("user_id" "uuid", "user_name" "text", "total_uses" integer, "total_discount_cents" bigint, "first_use" timestamp with time zone, "last_use" timestamp with time zone, "unique_promos" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Permission denied: user is not an admin';
  END IF;

  RETURN QUERY
  SELECT
    pcu.user_id,
    COALESCE(NULLIF(BTRIM(u.name), ''), u.email) AS user_name,
    COUNT(pcu.id)::INT AS total_uses,
    COALESCE(SUM(pcu.discount_value_cents), 0)::BIGINT AS total_discount_cents,
    MIN(pcu.redeemed_at) AS first_use,
    MAX(pcu.redeemed_at) AS last_use,
    COUNT(DISTINCT pcu.promo_code_id)::INT AS unique_promos
  FROM public.promo_code_usages AS pcu
  INNER JOIN public.users AS u ON u.id = pcu.user_id
  GROUP BY pcu.user_id, u.name, u.email
  ORDER BY total_uses DESC, total_discount_cents DESC;
END;
$$;


ALTER FUNCTION "public"."admin_get_promo_usage_by_user"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_promo_usage_stats"("p_promo_code_id" "uuid") RETURNS TABLE("code" "text", "total_uses" integer, "unique_users" integer, "total_discount_cents" bigint, "created_at" timestamp with time zone, "valid_until" timestamp with time zone, "is_active" boolean)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id UUID;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.users AS u
    WHERE u.id = v_user_id
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'Only admins can view promo stats';
  END IF;

  RETURN QUERY
  SELECT
    pc.code,
    COUNT(pcu.id)::INT AS total_uses,
    COUNT(DISTINCT pcu.user_id)::INT AS unique_users,
    COALESCE(SUM(pcu.discount_value_cents), 0)::BIGINT AS total_discount_cents,
    pc.created_at,
    pc.valid_until,
    pc.is_active
  FROM public.promo_codes AS pc
  LEFT JOIN public.promo_code_usages AS pcu
    ON pcu.promo_code_id = pc.id
  WHERE pc.id = p_promo_code_id
  GROUP BY pc.id;
END;
$$;


ALTER FUNCTION "public"."admin_get_promo_usage_stats"("p_promo_code_id" "uuid") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."admin_get_promo_usage_stats"("p_promo_code_id" "uuid") IS 'Gets usage statistics for a promo code (admin only)';



CREATE OR REPLACE FUNCTION "public"."admin_get_promo_usage_user_details"("p_user_id" "uuid") RETURNS TABLE("promo_code_id" "uuid", "promo_code" "text", "code_type" "text", "amount" integer, "redeemed_at" timestamp with time zone, "discount_value_cents" integer, "applied_tier" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Permission denied: user is not an admin';
  END IF;

  RETURN QUERY
  SELECT
    pc.id AS promo_code_id,
    pc.code AS promo_code,
    pc.code_type,
    pc.amount,
    pcu.redeemed_at,
    pcu.discount_value_cents,
    pcu.applied_tier
  FROM public.promo_code_usages AS pcu
  INNER JOIN public.promo_codes AS pc ON pc.id = pcu.promo_code_id
  WHERE pcu.user_id = p_user_id
  ORDER BY pcu.redeemed_at DESC;
END;
$$;


ALTER FUNCTION "public"."admin_get_promo_usage_user_details"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_get_user_ui_languages"("p_user_ids" "uuid"[]) RETURNS TABLE("user_id" "uuid", "ui_language" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  RETURN QUERY
  SELECT
    u.id AS user_id,
    CASE lower(btrim(COALESCE(u.preferred_language, '')))
      WHEN 'es' THEN 'es'
      WHEN 'he' THEN 'he'
      ELSE 'en'
    END AS ui_language
  FROM public.users u
  WHERE p_user_ids IS NOT NULL
    AND u.id = ANY(p_user_ids);
END;
$$;


ALTER FUNCTION "public"."admin_get_user_ui_languages"("p_user_ids" "uuid"[]) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_external_ad_analytics_by_network"("p_start_date" timestamp with time zone DEFAULT ("now"() - '30 days'::interval), "p_end_date" timestamp with time zone DEFAULT "now"()) RETURNS TABLE("network_id" "uuid", "network_name" "text", "impressions" bigint, "clicks" bigint, "revenue_usd" numeric, "ctr_percent" numeric, "cpm" numeric)
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT
    n.id AS network_id,
    n.display_name AS network_name,
    COUNT(e.id)::bigint AS impressions,
    COALESCE(SUM(e.click_count), 0)::bigint AS clicks,
    COALESCE(SUM(e.revenue_usd), 0)::numeric AS revenue_usd,
    CASE 
      WHEN COUNT(e.id) > 0
      THEN (COALESCE(SUM(e.click_count), 0)::numeric / COUNT(e.id)::numeric * 100)
      ELSE 0
    END::numeric AS ctr_percent,
    CASE 
      WHEN COUNT(e.id) > 0
      THEN (COALESCE(SUM(e.revenue_usd), 0)::numeric / COUNT(e.id)::numeric * 1000)
      ELSE 0
    END::numeric AS cpm
  FROM public.ad_networks n
  LEFT JOIN public.ad_revenue_events e ON e.network_id = n.id
    AND e.event_type = 'impression'
    AND e.created_at >= p_start_date
    AND e.created_at <= p_end_date
  GROUP BY n.id, n.display_name
  ORDER BY COUNT(e.id) DESC;
$$;


ALTER FUNCTION "public"."admin_list_external_ad_analytics_by_network"("p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_external_ad_analytics_by_placement"("p_start_date" timestamp with time zone DEFAULT ("now"() - '30 days'::interval), "p_end_date" timestamp with time zone DEFAULT "now"()) RETURNS TABLE("placement" "text", "impressions" bigint, "clicks" bigint, "revenue_usd" numeric, "ctr_percent" numeric, "cpm" numeric)
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT
    COALESCE(e.placement, 'unknown') as placement,
    COUNT(*)::bigint AS impressions,
    COALESCE(SUM(e.click_count), 0)::bigint AS clicks,
    COALESCE(SUM(e.revenue_usd), 0)::numeric AS revenue_usd,
    CASE 
      WHEN COUNT(*) > 0
      THEN (COALESCE(SUM(e.click_count), 0)::numeric / COUNT(*)::numeric * 100)
      ELSE 0
    END::numeric AS ctr_percent,
    CASE 
      WHEN COUNT(*) > 0
      THEN (COALESCE(SUM(e.revenue_usd), 0)::numeric / COUNT(*)::numeric * 1000)
      ELSE 0
    END::numeric AS cpm
  FROM public.ad_revenue_events e
  WHERE e.event_type = 'impression'
    AND e.created_at >= p_start_date
    AND e.created_at <= p_end_date
  GROUP BY e.placement
  ORDER BY COUNT(*) DESC;
$$;


ALTER FUNCTION "public"."admin_list_external_ad_analytics_by_placement"("p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_external_ad_analytics_by_platform"("p_start_date" timestamp with time zone DEFAULT ("now"() - '30 days'::interval), "p_end_date" timestamp with time zone DEFAULT "now"()) RETURNS TABLE("platform" "text", "impressions" bigint, "clicks" bigint, "revenue_usd" numeric, "ctr_percent" numeric, "cpm" numeric)
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  SELECT
    COALESCE(e.platform, 'unknown') as platform,
    COUNT(*)::bigint AS impressions,
    COALESCE(SUM(e.click_count), 0)::bigint AS clicks,
    COALESCE(SUM(e.revenue_usd), 0)::numeric AS revenue_usd,
    CASE 
      WHEN COUNT(*) > 0
      THEN (COALESCE(SUM(e.click_count), 0)::numeric / COUNT(*)::numeric * 100)
      ELSE 0
    END::numeric AS ctr_percent,
    CASE 
      WHEN COUNT(*) > 0
      THEN (COALESCE(SUM(e.revenue_usd), 0)::numeric / COUNT(*)::numeric * 1000)
      ELSE 0
    END::numeric AS cpm
  FROM public.ad_revenue_events e
  WHERE e.event_type = 'impression'
    AND e.created_at >= p_start_date
    AND e.created_at <= p_end_date
  GROUP BY e.platform
  ORDER BY COUNT(*) DESC;
$$;


ALTER FUNCTION "public"."admin_list_external_ad_analytics_by_platform"("p_start_date" timestamp with time zone, "p_end_date" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_external_ad_event_details"("p_filter_type" "text" DEFAULT 'all'::"text", "p_filter_value" "text" DEFAULT NULL::"text", "p_start_date" "date" DEFAULT (CURRENT_DATE - '30 days'::interval), "p_end_date" "date" DEFAULT CURRENT_DATE, "p_limit" integer DEFAULT 200) RETURNS TABLE("event_id" "uuid", "event_type" "text", "network_id" "uuid", "network_name" "text", "user_id" "uuid", "user_name" "text", "placement" "text", "platform" "text", "ad_format" "text", "revenue_usd" numeric, "created_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.admin_assert_is_admin();

  RETURN QUERY
  SELECT
    e.id AS event_id,
    e.event_type,
    e.network_id,
    n.display_name AS network_name,
    e.user_id,
    COALESCE(NULLIF(BTRIM(u.name), ''), e.user_id::text) AS user_name,
    e.placement,
    e.platform,
    e.ad_format,
    e.revenue_usd,
    e.created_at
  FROM public.ad_revenue_events e
  LEFT JOIN public.ad_networks n ON n.id = e.network_id
  LEFT JOIN public.users u ON u.id = e.user_id
  WHERE DATE(e.created_at) >= p_start_date
    AND DATE(e.created_at) <= p_end_date
    AND (
      p_filter_type = 'all'
      OR (p_filter_type = 'network' AND e.network_id::text = p_filter_value)
      OR (p_filter_type = 'placement' AND e.placement = p_filter_value)
      OR (p_filter_type = 'platform' AND e.platform = p_filter_value)
    )
  ORDER BY e.created_at DESC, e.id DESC
  LIMIT GREATEST(COALESCE(p_limit, 200), 1);
END;
$$;


ALTER FUNCTION "public"."admin_list_external_ad_event_details"("p_filter_type" "text", "p_filter_value" "text", "p_start_date" "date", "p_end_date" "date", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_external_ad_events"("p_network_id" "uuid" DEFAULT NULL::"uuid", "p_placement" "text" DEFAULT NULL::"text", "p_platform" "text" DEFAULT NULL::"text", "p_start_date" "date" DEFAULT NULL::"date", "p_end_date" "date" DEFAULT NULL::"date", "p_limit" integer DEFAULT 100) RETURNS TABLE("event_id" "uuid", "network_id" "uuid", "placement" "text", "platform" "text", "impression_date" "date", "impressions" integer, "clicks" integer, "conversions" integer, "revenue_usd" numeric, "updated_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.admin_assert_is_admin();
  
  RETURN QUERY
  SELECT
    a.id AS event_id,
    a.network_id,
    a.placement,
    a.platform,
    a.date AS impression_date,
    a.impressions,
    a.clicks,
    a.conversions,
    a.revenue_usd,
    a.updated_at
  FROM public.ad_network_analytics a
  WHERE (p_network_id IS NULL OR a.network_id = p_network_id)
    AND (p_placement IS NULL OR a.placement = p_placement)
    AND (p_platform IS NULL OR a.platform = p_platform)
    AND (p_start_date IS NULL OR a.date >= p_start_date)
    AND (p_end_date IS NULL OR a.date <= p_end_date)
  ORDER BY a.date DESC, a.network_id, a.placement, a.platform
  LIMIT GREATEST(p_limit, 1);
END;
$$;


ALTER FUNCTION "public"."admin_list_external_ad_events"("p_network_id" "uuid", "p_placement" "text", "p_platform" "text", "p_start_date" "date", "p_end_date" "date", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_intents"() RETURNS TABLE("id" bigint, "key" "text", "parent_id" bigint, "translation_key" "text", "sort_order" integer, "is_social" boolean, "is_business" boolean, "created_at" timestamp with time zone, "updated_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  RETURN QUERY
  SELECT
    i.id,
    i.key,
    i.parent_id,
    i.translation_key,
    i.sort_order,
    i.is_social,
    i.is_business,
    i.created_at,
    i.updated_at
  FROM public.intents i
  ORDER BY i.sort_order ASC, i.key ASC;
END;
$$;


ALTER FUNCTION "public"."admin_list_intents"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_interests"() RETURNS TABLE("id" bigint, "key" "text", "parent_id" bigint, "translation_key" "text", "sort_order" integer, "is_social" boolean, "is_business" boolean, "created_at" timestamp with time zone, "updated_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  RETURN QUERY
  SELECT
    i.id,
    i.key,
    i.parent_id,
    i.translation_key,
    i.sort_order,
    i.is_social,
    i.is_business,
    i.created_at,
    i.updated_at
  FROM public.interests i
  ORDER BY i.sort_order ASC, i.key ASC;
END;
$$;


ALTER FUNCTION "public"."admin_list_interests"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_profile_edit_requests"("p_status" "text" DEFAULT NULL::"text", "p_query" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 100, "p_offset" integer DEFAULT 0) RETURNS TABLE("id" "uuid", "user_id" "uuid", "user_name" "text", "requested_fields" "text"[], "message" "text", "attachments" "jsonb", "status" "text", "change_complete" boolean, "created_at" timestamp with time zone, "updated_at" timestamp with time zone, "reviewed_at" timestamp with time zone, "reviewed_by" "uuid", "reviewer_note" "text", "reviewer_name" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_status text;
  v_query text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_status := NULLIF(trim(p_status), '');
  v_query := NULLIF(trim(p_query), '');

  RETURN QUERY
  SELECT
    r.id,
    r.user_id,
    u.name AS user_name,
    r.requested_fields,
    r.message,
    r.attachments,
    r.status,
    CASE
      WHEN r.status <> 'approved' THEN false
      WHEN COALESCE(array_length(r.requested_fields, 1), 0) = 0 THEN false
      ELSE NOT EXISTS (
        SELECT 1
        FROM unnest(COALESCE(r.requested_fields, '{}'::text[])) AS rf(field_key)
        WHERE NULLIF(trim(rf.field_key), '') IS NOT NULL
          AND rf.field_key = ANY(COALESCE(u.editable_profile_fields, '{}'::text[]))
      )
    END AS change_complete,
    r.created_at,
    r.updated_at,
    r.reviewed_at,
    r.reviewed_by,
    r.reviewer_note,
    COALESCE(ru.name, '') AS reviewer_name
  FROM public.profile_edit_requests r
  JOIN public.users u ON u.id = r.user_id
  LEFT JOIN public.users ru ON ru.id = r.reviewed_by
  WHERE (v_status IS NULL OR r.status = v_status)
    AND (
      v_query IS NULL OR
      r.user_id::text ILIKE '%' || v_query || '%' OR
      COALESCE(u.name, '') ILIKE '%' || v_query || '%' OR
      COALESCE(ru.name, '') ILIKE '%' || v_query || '%' OR
      COALESCE(r.message, '') ILIKE '%' || v_query || '%' OR
      array_to_string(COALESCE(r.requested_fields, '{}'::text[]), ',') ILIKE '%' || v_query || '%'
    )
  ORDER BY r.created_at DESC NULLS LAST, r.id DESC
  LIMIT GREATEST(LEAST(COALESCE(p_limit, 100), 500), 1)
  OFFSET GREATEST(COALESCE(p_offset, 0), 0);
END;
$$;


ALTER FUNCTION "public"."admin_list_profile_edit_requests"("p_status" "text", "p_query" "text", "p_limit" integer, "p_offset" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_recent_sponsored_ad_reports"("p_limit" integer DEFAULT 25) RETURNS TABLE("report_id" "uuid", "campaign_id" "uuid", "creative_id" "uuid", "internal_name" "text", "advertiser_name" "text", "placement" "text", "reason" "text", "details" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.admin_assert_is_admin();

  RETURN QUERY
  SELECT
    r.id AS report_id,
    r.campaign_id,
    r.creative_id,
    c.internal_name,
    c.advertiser_name,
    r.placement,
    r.reason,
    r.details,
    r.created_at
  FROM public.ad_reports r
  INNER JOIN public.ad_campaigns c
    ON c.id = r.campaign_id
  ORDER BY r.created_at DESC
  LIMIT GREATEST(COALESCE(p_limit, 25), 1);
END;
$$;


ALTER FUNCTION "public"."admin_list_recent_sponsored_ad_reports"("p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_sponsored_campaign_event_details"("p_campaign_id" "uuid", "p_event_type" "text", "p_limit" integer DEFAULT 200) RETURNS TABLE("event_id" "uuid", "event_type" "text", "campaign_id" "uuid", "creative_id" "uuid", "user_id" "uuid", "user_name" "text", "placement" "text", "platform" "text", "locale" "text", "destination_url" "text", "reason" "text", "details" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_event_type text := lower(trim(coalesce(p_event_type, '')));
BEGIN
  PERFORM public.admin_assert_is_admin();
  
  IF v_event_type = 'impression' THEN
    RETURN QUERY
    SELECT
      d.id AS event_id,
      'impression'::text AS event_type,
      d.campaign_id,
      d.creative_id,
      d.user_id,
      COALESCE(NULLIF(BTRIM(u.name), ''), d.user_id::text) AS user_name,
      d.placement,
      d.platform,
      d.locale,
      NULL::text AS destination_url,
      NULL::text AS reason,
      ('Impressions: ' || d.impression_count::text)::text AS details,
      d.last_impression_at AS created_at
    FROM public.ad_impressions_daily d
    LEFT JOIN public.users u
      ON u.id = d.user_id
    WHERE d.campaign_id = p_campaign_id
    ORDER BY d.last_impression_at DESC, d.id DESC
    LIMIT GREATEST(COALESCE(p_limit, 200), 1);
    RETURN;
  END IF;
  
  IF v_event_type = 'click' THEN
    RETURN QUERY
    SELECT
      c.id AS event_id,
      'click'::text AS event_type,
      c.campaign_id,
      c.creative_id,
      c.user_id,
      COALESCE(NULLIF(BTRIM(u.name), ''), c.user_id::text) AS user_name,
      c.placement,
      c.platform,
      c.locale,
      c.destination_url,
      NULL::text AS reason,
      NULL::text AS details,
      c.created_at
    FROM public.ad_clicks c
    LEFT JOIN public.users u
      ON u.id = c.user_id
    WHERE c.campaign_id = p_campaign_id
    ORDER BY c.created_at DESC, c.id DESC
    LIMIT GREATEST(COALESCE(p_limit, 200), 1);
    RETURN;
  END IF;
  
  RAISE EXCEPTION 'Unsupported sponsored ad event type: %', p_event_type
    USING ERRCODE = '22023';
END;
$$;


ALTER FUNCTION "public"."admin_list_sponsored_campaign_event_details"("p_campaign_id" "uuid", "p_event_type" "text", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_sponsored_campaign_metrics"() RETURNS TABLE("campaign_id" "uuid", "impressions" bigint, "clicks" bigint, "reports" bigint, "ctr_percent" numeric, "last_impression_at" timestamp with time zone, "last_click_at" timestamp with time zone, "last_report_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Check if caller is admin
  IF auth.uid() IS NULL OR NOT EXISTS (
    SELECT 1
    FROM public.users
    WHERE id = auth.uid()
      AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Admin access required'
      USING ERRCODE = '42501';
  END IF;

  RETURN QUERY
  WITH impression_stats AS (
    SELECT
      ad_impressions.campaign_id,
      COUNT(*)::bigint AS impressions,
      MAX(ad_impressions.created_at) AS last_impression_at
    FROM public.ad_impressions
    GROUP BY ad_impressions.campaign_id
  ),
  click_stats AS (
    SELECT
      ad_clicks.campaign_id,
      COUNT(*)::bigint AS clicks,
      MAX(ad_clicks.created_at) AS last_click_at
    FROM public.ad_clicks
    GROUP BY ad_clicks.campaign_id
  ),
  report_stats AS (
    SELECT
      ad_reports.campaign_id,
      COUNT(*)::bigint AS reports,
      MAX(ad_reports.created_at) AS last_report_at
    FROM public.ad_reports
    GROUP BY ad_reports.campaign_id
  )
  SELECT
    c.id AS campaign_id,
    COALESCE(i.impressions, 0)::bigint AS impressions,
    COALESCE(k.clicks, 0)::bigint AS clicks,
    COALESCE(r.reports, 0)::bigint AS reports,
    CASE
      WHEN COALESCE(i.impressions, 0) = 0 THEN 0::numeric
      ELSE ROUND((COALESCE(k.clicks, 0)::numeric / i.impressions::numeric) * 100, 2)
    END AS ctr_percent,
    i.last_impression_at,
    k.last_click_at,
    r.last_report_at
  FROM public.ad_campaigns c
  LEFT JOIN impression_stats i ON i.campaign_id = c.id
  LEFT JOIN click_stats k ON k.campaign_id = c.id
  LEFT JOIN report_stats r ON r.campaign_id = c.id
  ORDER BY c.updated_at DESC, c.id;
END;
$$;


ALTER FUNCTION "public"."admin_list_sponsored_campaign_metrics"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_sponsored_campaign_report_details"("p_campaign_id" "uuid", "p_limit" integer DEFAULT 200) RETURNS TABLE("report_id" "uuid", "campaign_id" "uuid", "creative_id" "uuid", "reporter_user_id" "uuid", "reporter_name" "text", "placement" "text", "reason" "text", "details" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.admin_assert_is_admin();

  RETURN QUERY
  SELECT
    r.id AS report_id,
    r.campaign_id,
    r.creative_id,
    r.user_id AS reporter_user_id,
    COALESCE(NULLIF(BTRIM(u.name), ''), r.user_id::text) AS reporter_name,
    r.placement,
    r.reason,
    r.details,
    r.created_at
  FROM public.ad_reports r
  LEFT JOIN public.users u
    ON u.id = r.user_id
  WHERE r.campaign_id = p_campaign_id
  ORDER BY r.created_at DESC, r.id DESC
  LIMIT GREATEST(COALESCE(p_limit, 200), 1);
END;
$$;


ALTER FUNCTION "public"."admin_list_sponsored_campaign_report_details"("p_campaign_id" "uuid", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_sponsored_campaign_report_summaries"() RETURNS TABLE("campaign_id" "uuid", "report_count" bigint, "unique_reporter_count" bigint, "last_reported_at" timestamp with time zone, "latest_reason" "text", "latest_details" "text", "latest_placement" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.admin_assert_is_admin();

  RETURN QUERY
  WITH report_aggregates AS (
    SELECT
      r.campaign_id,
      COUNT(*)::bigint AS report_count,
      COUNT(DISTINCT r.user_id)::bigint AS unique_reporter_count,
      MAX(r.created_at) AS last_reported_at
    FROM public.ad_reports r
    GROUP BY r.campaign_id
  ),
  ranked_reports AS (
    SELECT
      r.campaign_id,
      r.reason,
      r.details,
      r.placement,
      ROW_NUMBER() OVER (
        PARTITION BY r.campaign_id
        ORDER BY r.created_at DESC, r.id DESC
      ) AS row_num
    FROM public.ad_reports r
  )
  SELECT
    aggregates.campaign_id,
    aggregates.report_count,
    aggregates.unique_reporter_count,
    aggregates.last_reported_at,
    latest.reason AS latest_reason,
    latest.details AS latest_details,
    latest.placement AS latest_placement
  FROM report_aggregates aggregates
  LEFT JOIN ranked_reports latest
    ON latest.campaign_id = aggregates.campaign_id
   AND latest.row_num = 1
  ORDER BY aggregates.last_reported_at DESC, aggregates.campaign_id;
END;
$$;


ALTER FUNCTION "public"."admin_list_sponsored_campaign_report_summaries"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_target_users_for_broadcast"("filter_criteria" "jsonb", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("user_id" "uuid", "name" "text", "platform" "text", "last_active_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
  v_limit integer;
  v_offset integer;
  c jsonb;
  v_status text;
  v_tiers text[];
  v_user_ids uuid[];
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_limit := GREATEST(LEAST(COALESCE(p_limit, 50), 500), 1);
  v_offset := GREATEST(COALESCE(p_offset, 0), 0);

  c := public.normalize_broadcast_filter_criteria(filter_criteria);
  v_status := lower(btrim(COALESCE(c->>'status', '')));
  IF c ? 'subscription_tiers' THEN
    SELECT array_agg(lower(btrim(value))) INTO v_tiers
    FROM jsonb_array_elements_text(c->'subscription_tiers') AS t(value);
  END IF;

  IF c ? 'user_ids' THEN
    SELECT array_agg(DISTINCT value::uuid) INTO v_user_ids
    FROM jsonb_array_elements_text(c->'user_ids') AS t(value);
  END IF;

  RETURN QUERY
  SELECT *
  FROM (
    SELECT DISTINCT ON (u.id)
      u.id AS user_id,
      u.name,
      us.platform,
      us.last_active_at
    FROM public.users u
    JOIN public.user_session us ON u.id = us.user_id
    WHERE us.revoked = false
      AND NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), '') IS NOT NULL
      AND COALESCE((u.notification_preferences->'global_methods'->>'push')::boolean, true) = true
      AND COALESCE(
        (u.notification_preferences->'matrix'->'admin_announcements'->>'push')::boolean,
        (u.notification_preferences->>'enable_admin_notifications')::boolean,
        true
      ) = true
      AND (
        (v_user_ids IS NOT NULL AND u.id = ANY(v_user_ids)) OR
        (
          COALESCE((c->>'all_users')::boolean, false) = true OR
          (
            (c->'gender' IS NULL OR
              u.gender = ANY(ARRAY(SELECT jsonb_array_elements_text(c->'gender')))) AND
            (c->'age_range' IS NULL OR
              (EXTRACT(YEAR FROM AGE(CURRENT_DATE, u.date_of_birth)) >= (c->'age_range'->>'min')::int AND
              EXTRACT(YEAR FROM AGE(CURRENT_DATE, u.date_of_birth)) <= (c->'age_range'->>'max')::int)) AND
            (
              v_tiers IS NULL OR
              COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') = ANY(v_tiers)
            ) AND
            (c->'verification_status' IS NULL OR
              u.verification_status = ANY(ARRAY(SELECT jsonb_array_elements_text(c->'verification_status')))) AND
            (c->'platform' IS NULL OR
              us.platform = ANY(ARRAY(SELECT jsonb_array_elements_text(c->'platform')))) AND
            (c->'last_active_days' IS NULL OR
              us.last_active_at >= NOW() - INTERVAL '1 day' * (c->>'last_active_days')::int) AND
            (
              v_status = '' OR v_status = 'all' OR
              (v_status = 'visible' AND public.is_user_truly_visible(u.id) = TRUE) OR
              (v_status = 'invisible' AND public.is_user_online(u.id) = TRUE AND public.is_user_truly_visible(u.id) = FALSE) OR
              (v_status = 'offline' AND public.is_user_online(u.id) = FALSE)
            ) AND
            (
              c->'ui_language' IS NULL OR
              lower(coalesce(u.preferred_language, '')) = lower(c->>'ui_language')
            ) AND
            (
              c->'ui_languages' IS NULL OR
              lower(coalesce(u.preferred_language, '')) = ANY(
                ARRAY(
                  SELECT lower(jsonb_array_elements_text(c->'ui_languages'))
                )
              )
            )
          )
        )
      )
    ORDER BY u.id, us.last_active_at DESC NULLS LAST
  ) t
  ORDER BY t.last_active_at DESC NULLS LAST, t.user_id DESC
  LIMIT v_limit
  OFFSET v_offset;
END;
$$;


ALTER FUNCTION "public"."admin_list_target_users_for_broadcast"("filter_criteria" "jsonb", "p_limit" integer, "p_offset" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_list_verification_users"("p_status" "text" DEFAULT NULL::"text", "p_query" "text" DEFAULT NULL::"text", "p_limit" integer DEFAULT 100, "p_offset" integer DEFAULT 0) RETURNS TABLE("id" "uuid", "name" "text", "verification_status" "text", "is_verified" boolean, "profile_photo_path" "text", "verification_photo_path" "text", "verification_submitted_at" timestamp with time zone, "verification_reviewed_at" timestamp with time zone, "verification_reviewer_id" "uuid", "verification_reviewer_name" "text", "verification_similarity_score" numeric, "verification_ai_analysis" "jsonb", "verification_auto_rejected" boolean)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_status text;
  v_query text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_status := NULLIF(trim(p_status), '');
  v_query := NULLIF(trim(p_query), '');

  RETURN QUERY
  SELECT
    u.id,
    u.name,
    u.verification_status,
    u.is_verified,
    (
      SELECT p
      FROM unnest(u.photos) AS p
      WHERE NULLIF(btrim(p), '') IS NOT NULL
      LIMIT 1
    ) AS profile_photo_path,
    u.verification_photo_path,
    u.verification_submitted_at,
    u.verification_reviewed_at,
    u.verification_reviewer_id,
    ru.name AS verification_reviewer_name,
    u.verification_similarity_score,
    u.verification_ai_analysis,
    u.verification_auto_rejected
  FROM public.users u
  LEFT JOIN public.users ru
    ON ru.id = u.verification_reviewer_id
  WHERE (v_status IS NULL OR u.verification_status = v_status)
    AND (
      v_query IS NULL OR
      u.id::text ILIKE '%' || v_query || '%' OR
      COALESCE(u.name, '') ILIKE '%' || v_query || '%' OR
      COALESCE(u.verification_status, '') ILIKE '%' || v_query || '%'
    )
  ORDER BY u.verification_submitted_at DESC NULLS LAST, u.id DESC
  LIMIT GREATEST(LEAST(COALESCE(p_limit, 100), 500), 1)
  OFFSET GREATEST(COALESCE(p_offset, 0), 0);
END;
$$;


ALTER FUNCTION "public"."admin_list_verification_users"("p_status" "text", "p_query" "text", "p_limit" integer, "p_offset" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_reschedule_broadcast"("p_broadcast_id" "uuid", "p_scheduled_at" timestamp with time zone) RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
  v_new_broadcast_id uuid;
  v_src public.admin_broadcasts%ROWTYPE;
  v_scheduled timestamptz;
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_scheduled := p_scheduled_at;
  IF v_scheduled IS NULL THEN
    RAISE EXCEPTION 'p_scheduled_at is required';
  END IF;
  IF v_scheduled <= now() THEN
    RAISE EXCEPTION 'p_scheduled_at must be in the future';
  END IF;

  SELECT *
  INTO v_src
  FROM public.admin_broadcasts b
  WHERE b.id = p_broadcast_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Broadcast not found';
  END IF;

  IF COALESCE(v_src.status, '') <> 'sent' THEN
    RAISE EXCEPTION 'broadcast must be sent';
  END IF;

  INSERT INTO public.admin_broadcasts (
    title,
    message,
    message_type,
    action_url,
    action_url_text,
    scheduled_at,
    sent_at,
    status,
    filter_criteria,
    target_user_count,
    actual_sent_count,
    created_by,
    created_at,
    updated_at
  ) VALUES (
    v_src.title,
    v_src.message,
    v_src.message_type,
    v_src.action_url,
    v_src.action_url_text,
    v_scheduled,
    NULL,
    'scheduled',
    v_src.filter_criteria,
    NULL,
    0,
    auth.uid(),
    now(),
    now()
  )
  RETURNING id INTO v_new_broadcast_id;

  RETURN v_new_broadcast_id;
END;
$$;


ALTER FUNCTION "public"."admin_reschedule_broadcast"("p_broadcast_id" "uuid", "p_scheduled_at" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_resend_broadcast_now"("p_broadcast_id" "uuid") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
  v_new_broadcast_id uuid;
  v_src public.admin_broadcasts%ROWTYPE;
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT *
  INTO v_src
  FROM public.admin_broadcasts b
  WHERE b.id = p_broadcast_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Broadcast not found';
  END IF;

  IF COALESCE(v_src.status, '') <> 'sent' THEN
    RAISE EXCEPTION 'broadcast must be sent';
  END IF;

  INSERT INTO public.admin_broadcasts (
    title,
    message,
    message_type,
    action_url,
    action_url_text,
    scheduled_at,
    sent_at,
    status,
    filter_criteria,
    target_user_count,
    actual_sent_count,
    created_by,
    created_at,
    updated_at
  ) VALUES (
    v_src.title,
    v_src.message,
    v_src.message_type,
    v_src.action_url,
    v_src.action_url_text,
    NULL,
    NULL,
    'draft',
    v_src.filter_criteria,
    NULL,
    0,
    auth.uid(),
    now(),
    now()
  )
  RETURNING id INTO v_new_broadcast_id;

  BEGIN
    PERFORM public.send_admin_broadcast(v_new_broadcast_id);
  EXCEPTION WHEN OTHERS THEN
    UPDATE public.admin_broadcasts
    SET status = 'failed',
        updated_at = now()
    WHERE id = v_new_broadcast_id;
    RAISE;
  END;

  RETURN v_new_broadcast_id;
END;
$$;


ALTER FUNCTION "public"."admin_resend_broadcast_now"("p_broadcast_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_review_profile_edit_request"("p_request_id" "uuid", "p_decision" "text", "p_reviewer_note" "text" DEFAULT NULL::"text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_decision text;
  v_req record;
  v_cur_fields text[];
  v_req_fields text[];
  v_new_fields text[];
  v_keep_fields text[];
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_decision := NULLIF(trim(p_decision), '');
  IF v_decision IS NULL THEN
    RAISE EXCEPTION 'p_decision is required';
  END IF;

  IF v_decision NOT IN ('approved', 'rejected') THEN
    RAISE EXCEPTION 'invalid decision';
  END IF;

  SELECT r.* INTO v_req
  FROM public.profile_edit_requests r
  WHERE r.id = p_request_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'request not found';
  END IF;

  UPDATE public.profile_edit_requests
  SET
    status = v_decision,
    reviewed_at = now(),
    reviewed_by = auth.uid(),
    reviewer_note = NULLIF(trim(p_reviewer_note), '')
  WHERE id = p_request_id;

  v_req_fields := COALESCE(v_req.requested_fields, '{}'::text[]);

  SELECT COALESCE(u.editable_profile_fields, '{}'::text[]) INTO v_cur_fields
  FROM public.users u
  WHERE u.id = v_req.user_id;

  SELECT COALESCE(array_agg(DISTINCT f), '{}'::text[]) INTO v_keep_fields
  FROM public.profile_edit_requests r2
  CROSS JOIN LATERAL unnest(COALESCE(r2.requested_fields, '{}'::text[])) AS t(f)
  WHERE r2.user_id = v_req.user_id
    AND r2.status = 'approved'
    AND r2.id <> p_request_id
    AND NULLIF(trim(f), '') IS NOT NULL;

  IF v_decision = 'approved' THEN
    SELECT COALESCE(array_agg(DISTINCT f), '{}'::text[]) INTO v_new_fields
    FROM unnest(COALESCE(v_cur_fields, '{}'::text[]) || COALESCE(v_req_fields, '{}'::text[])) AS t(f)
    WHERE NULLIF(trim(f), '') IS NOT NULL;
  ELSE
    SELECT COALESCE(array_agg(DISTINCT f), '{}'::text[]) INTO v_new_fields
    FROM unnest(COALESCE(v_cur_fields, '{}'::text[])) AS t(f)
    WHERE NULLIF(trim(f), '') IS NOT NULL
      AND (
        NOT (f = ANY(COALESCE(v_req_fields, '{}'::text[])))
        OR f = ANY(COALESCE(v_keep_fields, '{}'::text[]))
      );
  END IF;

  UPDATE public.users
  SET editable_profile_fields =
    CASE
      WHEN COALESCE(array_length(v_new_fields, 1), 0) = 0 THEN NULL
      ELSE v_new_fields
    END
  WHERE id = v_req.user_id;
END;
$$;


ALTER FUNCTION "public"."admin_review_profile_edit_request"("p_request_id" "uuid", "p_decision" "text", "p_reviewer_note" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_search_users"("p_query" "text", "p_limit" integer DEFAULT 50, "p_offset" integer DEFAULT 0) RETURNS TABLE("user_id" "uuid", "name" "text", "platform" "text", "last_active_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
  v_limit integer;
  v_offset integer;
  q text;
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_limit := GREATEST(LEAST(COALESCE(p_limit, 50), 200), 1);
  v_offset := GREATEST(COALESCE(p_offset, 0), 0);
  q := btrim(COALESCE(p_query, ''));

  RETURN QUERY
  SELECT *
  FROM (
    SELECT DISTINCT ON (u.id)
      u.id AS user_id,
      u.name,
      us.platform,
      us.last_active_at
    FROM public.users u
    JOIN public.user_session us ON u.id = us.user_id
    WHERE us.revoked = false
      AND NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), '') IS NOT NULL
      AND COALESCE((u.notification_preferences->'global_methods'->>'push')::boolean, true) = true
      AND COALESCE(
        (u.notification_preferences->'matrix'->'admin_announcements'->>'push')::boolean,
        (u.notification_preferences->>'enable_admin_notifications')::boolean,
        true
      ) = true
      AND (
        q = '' OR
        u.id::text ILIKE ('%' || q || '%') OR
        COALESCE(u.name, '') ILIKE ('%' || q || '%')
      )
    ORDER BY u.id, us.last_active_at DESC NULLS LAST
  ) t
  ORDER BY t.last_active_at DESC NULLS LAST, t.user_id DESC
  LIMIT v_limit
  OFFSET v_offset;
END;
$$;


ALTER FUNCTION "public"."admin_search_users"("p_query" "text", "p_limit" integer, "p_offset" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_set_user_verification_status"("p_user_id" "uuid", "p_status" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_status text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_status := NULLIF(trim(p_status), '');
  IF v_status IS NULL THEN
    RAISE EXCEPTION 'p_status is required';
  END IF;

  IF v_status NOT IN ('unverified', 'analyzing', 'pending', 'approved', 'rejected') THEN
    RAISE EXCEPTION 'invalid status';
  END IF;

  PERFORM set_config('request.jwt.claim.role', 'service_role', true);

  UPDATE public.users u
  SET
    verification_status = v_status,
    is_verified = (v_status = 'approved'),
    verification_reviewed_at = CASE WHEN v_status IN ('approved', 'rejected') THEN now() ELSE NULL END,
    verification_reviewer_id = CASE WHEN v_status IN ('approved', 'rejected') THEN auth.uid() ELSE NULL END,
    verification_photo_retention_until = CASE
      WHEN v_status = 'approved' THEN now() + interval '30 days'
      WHEN v_status = 'pending' THEN now() + interval '14 days'
      WHEN v_status = 'rejected' THEN now() + interval '7 days'
      ELSE NULL
    END
  WHERE u.id = p_user_id;
END;
$$;


ALTER FUNCTION "public"."admin_set_user_verification_status"("p_user_id" "uuid", "p_status" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_update_app_config"("p_config_key" "text", "p_config_value" "jsonb", "p_config_type" "text", "p_category" "text", "p_description" "text", "p_is_user_configurable" boolean, "p_min_value" numeric DEFAULT NULL::numeric, "p_max_value" numeric DEFAULT NULL::numeric, "p_allowed_values" "jsonb" DEFAULT NULL::"jsonb") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Check if user is admin
  IF NOT EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RAISE EXCEPTION 'Permission denied: user is not an admin';
  END IF;

  INSERT INTO app_config (
    config_key,
    config_value,
    config_type,
    category,
    description,
    is_user_configurable,
    min_value,
    max_value,
    allowed_values
  ) VALUES (
    p_config_key,
    p_config_value,
    p_config_type,
    p_category,
    p_description,
    p_is_user_configurable,
    p_min_value,
    p_max_value,
    p_allowed_values
  )
  ON CONFLICT (config_key) DO UPDATE SET
    config_value = EXCLUDED.config_value,
    config_type = EXCLUDED.config_type,
    category = EXCLUDED.category,
    description = EXCLUDED.description,
    is_user_configurable = EXCLUDED.is_user_configurable,
    min_value = EXCLUDED.min_value,
    max_value = EXCLUDED.max_value,
    allowed_values = EXCLUDED.allowed_values,
    updated_at = NOW();
END;
$$;


ALTER FUNCTION "public"."admin_update_app_config"("p_config_key" "text", "p_config_value" "jsonb", "p_config_type" "text", "p_category" "text", "p_description" "text", "p_is_user_configurable" boolean, "p_min_value" numeric, "p_max_value" numeric, "p_allowed_values" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_update_promo_code"("p_id" "uuid", "p_code" "text" DEFAULT NULL::"text", "p_is_active" boolean DEFAULT NULL::boolean, "p_valid_until" timestamp with time zone DEFAULT NULL::timestamp with time zone, "p_valid_from" timestamp with time zone DEFAULT NULL::timestamp with time zone, "p_max_uses" integer DEFAULT NULL::integer, "p_description" "text" DEFAULT NULL::"text", "p_code_type" "text" DEFAULT NULL::"text", "p_amount" integer DEFAULT NULL::integer, "p_upgrade_tier" "text" DEFAULT NULL::"text", "p_max_uses_per_user" integer DEFAULT NULL::integer, "p_applicable_tiers" "text"[] DEFAULT NULL::"text"[], "p_campaign_name" "text" DEFAULT NULL::"text", "p_min_tier" "text" DEFAULT NULL::"text") RETURNS TABLE("id" "uuid", "code" "text", "is_active" boolean)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    SET "row_security" TO 'off'
    AS $$
DECLARE
  v_user_id UUID;
BEGIN
  v_user_id := auth.uid();

  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.users AS u
    WHERE u.id = v_user_id
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'Only admins can update promo codes';
  END IF;

  IF p_code_type IS NOT NULL
     AND p_code_type NOT IN ('discount_percentage', 'discount_fixed', 'free_days', 'tier_upgrade') THEN
    RAISE EXCEPTION 'Invalid code type';
  END IF;

  IF p_max_uses_per_user IS NOT NULL AND p_max_uses_per_user < 1 THEN
    RAISE EXCEPTION 'Max uses per user must be at least 1';
  END IF;

  IF p_max_uses IS NOT NULL AND p_max_uses < 1 THEN
    RAISE EXCEPTION 'Max uses must be at least 1 when provided';
  END IF;

  UPDATE public.promo_codes AS pc
  SET
    code = COALESCE(NULLIF(UPPER(TRIM(p_code)), ''), pc.code),
    is_active = COALESCE(p_is_active, pc.is_active),
    valid_until = COALESCE(p_valid_until, pc.valid_until),
    valid_from = COALESCE(p_valid_from, pc.valid_from),
    max_uses = COALESCE(p_max_uses, pc.max_uses),
    description = COALESCE(NULLIF(TRIM(p_description), ''), pc.description),
    code_type = COALESCE(p_code_type, pc.code_type),
    amount = COALESCE(p_amount, pc.amount),
    upgrade_tier = COALESCE(p_upgrade_tier, pc.upgrade_tier),
    max_uses_per_user = COALESCE(p_max_uses_per_user, pc.max_uses_per_user),
    applicable_tiers = COALESCE(p_applicable_tiers, pc.applicable_tiers),
    campaign_name = COALESCE(NULLIF(TRIM(p_campaign_name), ''), pc.campaign_name),
    min_tier = COALESCE(NULLIF(TRIM(p_min_tier), ''), pc.min_tier),
    updated_at = now()
  WHERE pc.id = p_id;

  RETURN QUERY
  SELECT pc.id, pc.code, pc.is_active
  FROM public.promo_codes AS pc
  WHERE pc.id = p_id;
END;
$$;


ALTER FUNCTION "public"."admin_update_promo_code"("p_id" "uuid", "p_code" "text", "p_is_active" boolean, "p_valid_until" timestamp with time zone, "p_valid_from" timestamp with time zone, "p_max_uses" integer, "p_description" "text", "p_code_type" "text", "p_amount" integer, "p_upgrade_tier" "text", "p_max_uses_per_user" integer, "p_applicable_tiers" "text"[], "p_campaign_name" "text", "p_min_tier" "text") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."admin_update_promo_code"("p_id" "uuid", "p_code" "text", "p_is_active" boolean, "p_valid_until" timestamp with time zone, "p_valid_from" timestamp with time zone, "p_max_uses" integer, "p_description" "text", "p_code_type" "text", "p_amount" integer, "p_upgrade_tier" "text", "p_max_uses_per_user" integer, "p_applicable_tiers" "text"[], "p_campaign_name" "text", "p_min_tier" "text") IS 'Updates an existing promo code (admin only)';



CREATE OR REPLACE FUNCTION "public"."admin_update_promo_codes_config"("p_enabled" boolean) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    UPDATE app_config
    SET config_value = p_enabled::text::jsonb,
        updated_at = NOW()
    WHERE config_key = 'promo_codes_enabled';
END;
$$;


ALTER FUNCTION "public"."admin_update_promo_codes_config"("p_enabled" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_upsert_intent"("p_id" bigint DEFAULT NULL::bigint, "p_key" "text" DEFAULT NULL::"text", "p_parent_id" bigint DEFAULT NULL::bigint, "p_translation_key" "text" DEFAULT NULL::"text", "p_sort_order" integer DEFAULT 0, "p_is_social" boolean DEFAULT false, "p_is_business" boolean DEFAULT false) RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_id bigint;
  v_key text;
  v_translation_key text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_key := NULLIF(trim(p_key), '');
  v_translation_key := NULLIF(trim(p_translation_key), '');

  IF v_key IS NULL THEN
    RAISE EXCEPTION 'p_key is required';
  END IF;

  IF v_translation_key IS NULL THEN
    RAISE EXCEPTION 'p_translation_key is required';
  END IF;

  IF p_id IS NULL OR p_id = 0 THEN
    INSERT INTO public.intents (
      key,
      parent_id,
      translation_key,
      sort_order,
      is_social,
      is_business
    )
    VALUES (
      v_key,
      p_parent_id,
      v_translation_key,
      COALESCE(p_sort_order, 0),
      COALESCE(p_is_social, false),
      COALESCE(p_is_business, false)
    )
    RETURNING id INTO v_id;
    RETURN v_id;
  END IF;

  UPDATE public.intents
  SET
    parent_id = p_parent_id,
    translation_key = v_translation_key,
    sort_order = COALESCE(p_sort_order, 0),
    is_social = COALESCE(p_is_social, false),
    is_business = COALESCE(p_is_business, false),
    updated_at = now()
  WHERE id = p_id
  RETURNING id INTO v_id;

  RETURN COALESCE(v_id, 0);
END;
$$;


ALTER FUNCTION "public"."admin_upsert_intent"("p_id" bigint, "p_key" "text", "p_parent_id" bigint, "p_translation_key" "text", "p_sort_order" integer, "p_is_social" boolean, "p_is_business" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_upsert_interest"("p_id" bigint DEFAULT NULL::bigint, "p_key" "text" DEFAULT NULL::"text", "p_parent_id" bigint DEFAULT NULL::bigint, "p_translation_key" "text" DEFAULT NULL::"text", "p_sort_order" integer DEFAULT 0, "p_is_social" boolean DEFAULT false, "p_is_business" boolean DEFAULT false) RETURNS bigint
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_admin boolean;
  v_id bigint;
  v_key text;
  v_translation_key text;
BEGIN
  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF NOT COALESCE(v_is_admin, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_key := NULLIF(trim(p_key), '');
  v_translation_key := NULLIF(trim(p_translation_key), '');

  IF v_key IS NULL THEN
    RAISE EXCEPTION 'p_key is required';
  END IF;

  IF v_translation_key IS NULL THEN
    RAISE EXCEPTION 'p_translation_key is required';
  END IF;

  IF p_id IS NULL OR p_id = 0 THEN
    INSERT INTO public.interests (
      key,
      parent_id,
      translation_key,
      sort_order,
      is_social,
      is_business
    )
    VALUES (
      v_key,
      p_parent_id,
      v_translation_key,
      COALESCE(p_sort_order, 0),
      COALESCE(p_is_social, false),
      COALESCE(p_is_business, false)
    )
    RETURNING id INTO v_id;
    RETURN v_id;
  END IF;

  UPDATE public.interests
  SET
    parent_id = p_parent_id,
    translation_key = v_translation_key,
    sort_order = COALESCE(p_sort_order, 0),
    is_social = COALESCE(p_is_social, false),
    is_business = COALESCE(p_is_business, false),
    updated_at = now()
  WHERE id = p_id
  RETURNING id INTO v_id;

  RETURN COALESCE(v_id, 0);
END;
$$;


ALTER FUNCTION "public"."admin_upsert_interest"("p_id" bigint, "p_key" "text", "p_parent_id" bigint, "p_translation_key" "text", "p_sort_order" integer, "p_is_social" boolean, "p_is_business" boolean) OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."subscription_plans" (
    "id" "text" NOT NULL,
    "tier_id" "text" NOT NULL,
    "duration" "text" NOT NULL,
    "price_display" "text" NOT NULL,
    "savings_text" "text",
    "revenue_cat_package_identifier" "text",
    "sort_order" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "public"."subscription_plans" OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_upsert_subscription_plan"("p_id" "text", "p_tier_id" "text", "p_duration" "text", "p_price_display" "text", "p_savings_text" "text", "p_revenue_cat_package_identifier" "text", "p_sort_order" integer) RETURNS "public"."subscription_plans"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_row public.subscription_plans;
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_id IS NULL OR btrim(p_id) = '' THEN
    RAISE EXCEPTION 'plan id is required';
  END IF;

  IF p_tier_id IS NULL OR btrim(p_tier_id) = '' THEN
    RAISE EXCEPTION 'tier_id is required';
  END IF;

  IF p_duration IS NULL OR btrim(p_duration) = '' THEN
    RAISE EXCEPTION 'duration is required';
  END IF;

  IF p_price_display IS NULL OR btrim(p_price_display) = '' THEN
    RAISE EXCEPTION 'price_display is required';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.subscription_tiers st WHERE st.id = p_tier_id) THEN
    RAISE EXCEPTION 'unknown tier_id';
  END IF;

  INSERT INTO public.subscription_plans (
    id,
    tier_id,
    duration,
    price_display,
    savings_text,
    revenue_cat_package_identifier,
    sort_order
  ) VALUES (
    p_id,
    p_tier_id,
    p_duration,
    p_price_display,
    NULLIF(btrim(COALESCE(p_savings_text, '')), ''),
    NULLIF(btrim(COALESCE(p_revenue_cat_package_identifier, '')), ''),
    COALESCE(p_sort_order, 0)
  )
  ON CONFLICT (id) DO UPDATE SET
    tier_id = EXCLUDED.tier_id,
    duration = EXCLUDED.duration,
    price_display = EXCLUDED.price_display,
    savings_text = EXCLUDED.savings_text,
    revenue_cat_package_identifier = EXCLUDED.revenue_cat_package_identifier,
    sort_order = EXCLUDED.sort_order;

  SELECT *
  INTO v_row
  FROM public.subscription_plans sp
  WHERE sp.id = p_id;

  RETURN v_row;
END;
$$;


ALTER FUNCTION "public"."admin_upsert_subscription_plan"("p_id" "text", "p_tier_id" "text", "p_duration" "text", "p_price_display" "text", "p_savings_text" "text", "p_revenue_cat_package_identifier" "text", "p_sort_order" integer) OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."subscription_tiers" (
    "id" "text" NOT NULL,
    "revenue_cat_package_identifier" "text" NOT NULL,
    "title_key" "text" NOT NULL,
    "subtitle_key" "text",
    "features_key" "text" NOT NULL,
    "badge_key" "text",
    "sort_order" integer DEFAULT 0,
    "is_active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL
);


ALTER TABLE "public"."subscription_tiers" OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."admin_upsert_subscription_tier"("p_id" "text", "p_revenue_cat_package_identifier" "text", "p_title_key" "text", "p_subtitle_key" "text", "p_features_key" "text", "p_badge_key" "text", "p_sort_order" integer, "p_is_active" boolean) RETURNS "public"."subscription_tiers"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_row public.subscription_tiers;
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_id IS NULL OR btrim(p_id) = '' THEN
    RAISE EXCEPTION 'tier id is required';
  END IF;

  IF p_revenue_cat_package_identifier IS NULL OR btrim(p_revenue_cat_package_identifier) = '' THEN
    RAISE EXCEPTION 'revenue_cat_package_identifier is required';
  END IF;

  IF p_title_key IS NULL OR btrim(p_title_key) = '' THEN
    RAISE EXCEPTION 'title_key is required';
  END IF;

  IF p_features_key IS NULL OR btrim(p_features_key) = '' THEN
    RAISE EXCEPTION 'features_key is required';
  END IF;

  INSERT INTO public.subscription_tiers (
    id,
    revenue_cat_package_identifier,
    title_key,
    subtitle_key,
    features_key,
    badge_key,
    sort_order,
    is_active
  ) VALUES (
    p_id,
    p_revenue_cat_package_identifier,
    p_title_key,
    NULLIF(btrim(COALESCE(p_subtitle_key, '')), ''),
    p_features_key,
    NULLIF(btrim(COALESCE(p_badge_key, '')), ''),
    COALESCE(p_sort_order, 0),
    COALESCE(p_is_active, true)
  )
  ON CONFLICT (id) DO UPDATE SET
    revenue_cat_package_identifier = EXCLUDED.revenue_cat_package_identifier,
    title_key = EXCLUDED.title_key,
    subtitle_key = EXCLUDED.subtitle_key,
    features_key = EXCLUDED.features_key,
    badge_key = EXCLUDED.badge_key,
    sort_order = EXCLUDED.sort_order,
    is_active = EXCLUDED.is_active;

  SELECT *
  INTO v_row
  FROM public.subscription_tiers st
  WHERE st.id = p_id;

  RETURN v_row;
END;
$$;


ALTER FUNCTION "public"."admin_upsert_subscription_tier"("p_id" "text", "p_revenue_cat_package_identifier" "text", "p_title_key" "text", "p_subtitle_key" "text", "p_features_key" "text", "p_badge_key" "text", "p_sort_order" integer, "p_is_active" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."aggregate_ad_revenue_daily"("p_date" "date" DEFAULT CURRENT_DATE) RETURNS TABLE("date" "date", "network_id" "uuid", "ad_unit_id" "uuid", "placement" "text", "platform" "text", "ad_format" "text", "impressions" bigint, "clicks" bigint, "conversions" bigint, "revenue" numeric)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  INSERT INTO public.ad_revenue_daily_stats (
    date,
    network_id,
    ad_unit_id,
    placement,
    platform,
    ad_format,
    impressions,
    clicks,
    conversions,
    revenue
  )
  SELECT
    p_date,
    network_id,
    ad_unit_id,
    placement,
    platform,
    ad_format,
    COUNT(*) FILTER (WHERE event_type = 'impression')::BIGINT,
    COUNT(*) FILTER (WHERE event_type = 'click')::BIGINT,
    COUNT(*) FILTER (WHERE event_type = 'conversion')::BIGINT,
    COALESCE(SUM(revenue), 0.00)
  FROM public.ad_revenue_events
  WHERE DATE(created_at) = p_date
  GROUP BY
    p_date,
    network_id,
    ad_unit_id,
    placement,
    platform,
    ad_format
  ON CONFLICT (date, network_id, ad_unit_id, placement, platform, ad_format)
  DO UPDATE SET
    impressions = EXCLUDED.impressions,
    clicks = EXCLUDED.clicks,
    conversions = EXCLUDED.conversions,
    revenue = EXCLUDED.revenue,
    updated_at = NOW()
  RETURNING
    date,
    network_id,
    ad_unit_id,
    placement,
    platform,
    ad_format,
    impressions,
    clicks,
    conversions,
    revenue;
END;
$$;


ALTER FUNCTION "public"."aggregate_ad_revenue_daily"("p_date" "date") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."aggregate_ad_revenue_last_n_days"("p_days" integer DEFAULT 7) RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_count INTEGER := 0;
  v_current_date DATE;
BEGIN
  v_current_date := CURRENT_DATE;
  
  FOR i IN 0..p_days-1 LOOP
    INSERT INTO public.ad_revenue_daily_stats (
      date,
      network_id,
      ad_unit_id,
      placement,
      platform,
      ad_format,
      impressions,
      clicks,
      conversions,
      revenue
    )
    SELECT
      v_current_date - i,
      network_id,
      ad_unit_id,
      placement,
      platform,
      ad_format,
      COUNT(*) FILTER (WHERE event_type = 'impression')::BIGINT,
      COUNT(*) FILTER (WHERE event_type = 'click')::BIGINT,
      COUNT(*) FILTER (WHERE event_type = 'conversion')::BIGINT,
      COALESCE(SUM(revenue), 0.00)
    FROM public.ad_revenue_events
    WHERE DATE(created_at) = v_current_date - i
    GROUP BY
      v_current_date - i,
      network_id,
      ad_unit_id,
      placement,
      platform,
      ad_format
    ON CONFLICT (date, network_id, ad_unit_id, placement, platform, ad_format)
    DO UPDATE SET
      impressions = EXCLUDED.impressions,
      clicks = EXCLUDED.clicks,
      conversions = EXCLUDED.conversions,
      revenue = EXCLUDED.revenue,
      updated_at = NOW();
    
    v_count := v_count + 1;
  END LOOP;
  
  RETURN v_count;
END;
$$;


ALTER FUNCTION "public"."aggregate_ad_revenue_last_n_days"("p_days" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."app_config_bool"("p_key" "text", "p_default" boolean) RETURNS boolean
    LANGUAGE "sql"
    SET "search_path" TO 'public'
    AS $$
  SELECT COALESCE(
    (
      SELECT CASE
        WHEN jsonb_typeof(config_value) = 'boolean' THEN (config_value #>> '{}')::boolean
        WHEN jsonb_typeof(config_value) = 'string'
          THEN lower(trim(both '"' FROM config_value::text)) = 'true'
        ELSE NULL
      END
      FROM public.app_config
      WHERE config_key = p_key
      LIMIT 1
    ),
    p_default
  );
$$;


ALTER FUNCTION "public"."app_config_bool"("p_key" "text", "p_default" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."app_config_jsonb"("p_key" "text", "p_default" "jsonb" DEFAULT '{}'::"jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_value jsonb;
BEGIN
  SELECT config_value::jsonb INTO v_value
  FROM public.app_config
  WHERE config_key = p_key
  LIMIT 1;
  
  IF v_value IS NULL THEN
    RETURN p_default;
  END IF;
  
  RETURN v_value;
END;
$$;


ALTER FUNCTION "public"."app_config_jsonb"("p_key" "text", "p_default" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."apply_manual_subscription_purchase"("p_tier" "text", "p_duration_seconds" integer, "p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("subscription_tier" "text", "subscription_expires_at" timestamp with time zone, "subscription_next_tier" "text", "subscription_next_starts_at" timestamp with time zone, "subscription_next_expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_tier text;
  v_exp timestamptz;
  v_next_tier text;
  v_next_start timestamptz;
  v_next_exp timestamptz;
  v_now timestamptz := now();
  v_add interval;
BEGIN
  IF p_user_id IS NULL THEN
    p_user_id := auth.uid();
  END IF;

  IF p_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_tier IS NULL OR btrim(p_tier) = '' OR p_tier = 'free' THEN
    RETURN QUERY SELECT * FROM public.clear_user_subscription(p_user_id);
    RETURN;
  END IF;

  v_add := make_interval(secs => GREATEST(COALESCE(p_duration_seconds, 0), 0));

  SELECT u.subscription_tier, u.subscription_expires_at, u.subscription_next_tier, u.subscription_next_starts_at, u.subscription_next_expires_at
  INTO v_tier, v_exp, v_next_tier, v_next_start, v_next_exp
  FROM public.users u
  WHERE u.id = p_user_id
  FOR UPDATE;

  IF v_tier IS NULL OR v_tier = '' THEN
    v_tier := 'free';
  END IF;

  IF v_tier <> 'free' AND v_exp IS NOT NULL AND v_exp > v_now THEN
    IF v_tier = p_tier THEN
      v_exp := v_exp + v_add;
      v_next_tier := NULL;
      v_next_start := NULL;
      v_next_exp := NULL;
    ELSE
      v_next_tier := p_tier;
      v_next_start := v_exp;
      v_next_exp := v_exp + v_add;
    END IF;
  ELSE
    v_tier := p_tier;
    v_exp := v_now + v_add;
    v_next_tier := NULL;
    v_next_start := NULL;
    v_next_exp := NULL;
  END IF;

  UPDATE public.users
  SET subscription_tier = v_tier,
      subscription_expires_at = v_exp,
      subscription_next_tier = v_next_tier,
      subscription_next_starts_at = v_next_start,
      subscription_next_expires_at = v_next_exp
  WHERE id = p_user_id;

  RETURN QUERY SELECT v_tier, v_exp, v_next_tier, v_next_start, v_next_exp;
END $$;


ALTER FUNCTION "public"."apply_manual_subscription_purchase"("p_tier" "text", "p_duration_seconds" integer, "p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."apply_revenuecat_subscription"("p_tier" "text", "p_expires_at" timestamp with time zone, "p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("subscription_tier" "text", "subscription_expires_at" timestamp with time zone, "subscription_next_tier" "text", "subscription_next_starts_at" timestamp with time zone, "subscription_next_expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_tier text;
  v_exp timestamptz;
BEGIN
  IF p_user_id IS NULL THEN
    p_user_id := auth.uid();
  END IF;

  IF p_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  IF p_tier IS NULL OR btrim(p_tier) = '' OR p_tier = 'free' OR p_expires_at IS NULL OR p_expires_at <= now() THEN
    v_tier := 'free';
    v_exp := NULL;
  ELSE
    v_tier := p_tier;
    v_exp := p_expires_at;
  END IF;

  UPDATE public.users
  SET subscription_tier = v_tier,
      subscription_expires_at = v_exp,
      subscription_next_tier = NULL,
      subscription_next_starts_at = NULL,
      subscription_next_expires_at = NULL
  WHERE id = p_user_id;

  RETURN QUERY
  SELECT u.subscription_tier, u.subscription_expires_at, u.subscription_next_tier, u.subscription_next_starts_at, u.subscription_next_expires_at
  FROM public.users u
  WHERE u.id = p_user_id;
END $$;


ALTER FUNCTION "public"."apply_revenuecat_subscription"("p_tier" "text", "p_expires_at" timestamp with time zone, "p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."apply_verification_decision"("p_user_id" "uuid") RETURNS TABLE("user_id" "uuid", "verification_status" "text", "is_verified" boolean, "similarity_score" numeric, "is_match" boolean)
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_similarity numeric;
  v_is_match boolean;
  v_ai jsonb;
BEGIN
  SET search_path = 'public';

  IF auth.role() <> 'service_role' THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;

  SELECT
    u.verification_similarity_score,
    u.verification_ai_analysis
  INTO
    v_similarity,
    v_ai
  FROM public.users u
  WHERE u.id = p_user_id
  FOR UPDATE;

  IF v_ai IS NULL THEN
    v_is_match := NULL;
  ELSE
    v_is_match := NULLIF(v_ai->>'isMatch', '')::boolean;
  END IF;

  IF v_similarity IS NULL OR v_is_match IS NULL THEN
    UPDATE public.users
    SET verification_status = 'pending'
    WHERE id = p_user_id;
  ELSIF v_is_match = false THEN
    UPDATE public.users
    SET
      is_verified = false,
      verification_status = 'rejected',
      verification_auto_rejected = true,
      verification_reviewed_at = now(),
      verification_reviewer_id = NULL
    WHERE id = p_user_id;
  ELSIF v_similarity >= 0.85 THEN
    UPDATE public.users
    SET
      is_verified = true,
      verification_status = 'approved',
      verification_auto_rejected = false,
      verification_reviewed_at = now(),
      verification_reviewer_id = NULL
    WHERE id = p_user_id;
  ELSE
    UPDATE public.users
    SET
      is_verified = false,
      verification_status = 'pending',
      verification_auto_rejected = false,
      verification_reviewed_at = NULL,
      verification_reviewer_id = NULL
    WHERE id = p_user_id;
  END IF;

  RETURN QUERY
  SELECT
    u.id,
    u.verification_status,
    u.is_verified,
    u.verification_similarity_score,
    NULLIF(u.verification_ai_analysis->>'isMatch', '')::boolean
  FROM public.users u
  WHERE u.id = p_user_id;
END;
$$;


ALTER FUNCTION "public"."apply_verification_decision"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."approve_primary_photo"("p_user_id" "uuid", "p_photo_path" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_clean_path text;
  v_current jsonb;
  v_new jsonb;
BEGIN
  SET search_path = 'public';

  -- Authorization is enforced by GRANT EXECUTE TO service_role only
  -- The REVOKE ALL FROM PUBLIC ensures no other roles can execute

  v_clean_path := btrim(COALESCE(p_photo_path, ''));
  IF v_clean_path = '' THEN
    RAISE EXCEPTION 'photo path required';
  END IF;

  SELECT COALESCE(u.approved_primary_photos, '[]'::jsonb)
  INTO v_current
  FROM public.users u
  WHERE u.id = p_user_id
  FOR UPDATE;

  v_new := to_jsonb(ARRAY(
    SELECT DISTINCT x
    FROM (
      SELECT jsonb_array_elements_text(v_current) AS x
      UNION ALL
      SELECT v_clean_path AS x
    ) t
    WHERE x IS NOT NULL AND x <> ''
  ));

  UPDATE public.users
  SET approved_primary_photos = v_new
  WHERE id = p_user_id;

  RETURN jsonb_build_object(
    'user_id', p_user_id,
    'photo_path', v_clean_path,
    'approved_primary_photos', v_new
  );
END;
$$;


ALTER FUNCTION "public"."approve_primary_photo"("p_user_id" "uuid", "p_photo_path" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."batch_translate_chat_messages"("p_user_id" "uuid", "p_match_id" "uuid", "p_target_language" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_message record;
  v_source_norm text;
  v_target_norm text;
BEGIN
  v_target_norm := public.normalize_language_code(p_target_language);
  IF v_target_norm IS NULL THEN
    RETURN;
  END IF;

  FOR v_message IN
    SELECT cm.id as message_id, cm.content_original, cm.detected_source_language,
           cm.translated_target_language, cm.content_translated, cm.sender_id
    FROM public.chat_messages cm
    WHERE cm.match_id = p_match_id
      AND cm.sender_id <> p_user_id
      AND cm.content_original IS NOT NULL
      AND length(trim(cm.content_original)) >= 2
      AND (
        cm.content_translated IS NULL 
        OR cm.translated_target_language IS NULL
        OR trim(cm.content_translated) = ''
        OR cm.content_translated = 'null'
        OR public.normalize_language_code(cm.translated_target_language) <> v_target_norm
      )
    ORDER BY cm.created_at ASC
    LIMIT 50
  LOOP
    v_source_norm := public.normalize_language_code(v_message.detected_source_language);
    
    IF v_source_norm IS NOT NULL AND v_source_norm = v_target_norm THEN
      UPDATE public.chat_messages
      SET detected_source_language = COALESCE(detected_source_language, v_source_norm)
      WHERE id = v_message.message_id AND detected_source_language IS NULL;
      CONTINUE;
    END IF;

    IF public.normalize_language_code(v_message.translated_target_language) = v_target_norm
       AND v_message.content_translated IS NOT NULL
       AND trim(v_message.content_translated) != ''
       AND v_message.content_translated != 'null' THEN
      CONTINUE;
    END IF;

    PERFORM public.translate_message_for_user(v_message.message_id, p_user_id, v_target_norm);
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."batch_translate_chat_messages"("p_user_id" "uuid", "p_match_id" "uuid", "p_target_language" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."bio_texts_too_similar"("p_left" "text", "p_right" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
  v_left text;
  v_right text;
  v_shorter text;
  v_longer text;
  v_shorter_len integer;
  v_longer_len integer;
  v_i integer := 1;
  v_j integer := 1;
  v_mismatches integer := 0;
BEGIN
  v_left := public.normalize_profile_bio_text(p_left);
  v_right := public.normalize_profile_bio_text(p_right);

  IF v_left IS NULL OR v_right IS NULL THEN
    RETURN false;
  END IF;

  IF v_left = v_right THEN
    RETURN true;
  END IF;

  IF abs(char_length(v_left) - char_length(v_right)) > 1 THEN
    RETURN false;
  END IF;

  IF char_length(v_left) = char_length(v_right) THEN
    FOR v_i IN 1..char_length(v_left) LOOP
      IF substr(v_left, v_i, 1) <> substr(v_right, v_i, 1) THEN
        v_mismatches := v_mismatches + 1;
        IF v_mismatches > 1 THEN
          RETURN false;
        END IF;
      END IF;
    END LOOP;

    RETURN true;
  END IF;

  IF char_length(v_left) < char_length(v_right) THEN
    v_shorter := v_left;
    v_longer := v_right;
  ELSE
    v_shorter := v_right;
    v_longer := v_left;
  END IF;

  v_shorter_len := char_length(v_shorter);
  v_longer_len := char_length(v_longer);

  WHILE v_i <= v_shorter_len AND v_j <= v_longer_len LOOP
    IF substr(v_shorter, v_i, 1) = substr(v_longer, v_j, 1) THEN
      v_i := v_i + 1;
      v_j := v_j + 1;
    ELSE
      v_mismatches := v_mismatches + 1;
      IF v_mismatches > 1 THEN
        RETURN false;
      END IF;
      v_j := v_j + 1;
    END IF;
  END LOOP;

  RETURN true;
END;
$$;


ALTER FUNCTION "public"."bio_texts_too_similar"("p_left" "text", "p_right" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."block_protected_user_fields_update"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  jwt_role text;
  v_is_admin boolean;
BEGIN
  jwt_role := current_setting('request.jwt.claim.role', true);

  IF jwt_role IS NULL THEN
    RETURN NEW;
  END IF;

  IF jwt_role = 'service_role' THEN
    RETURN NEW;
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF COALESCE(v_is_admin, false) THEN
    RETURN NEW;
  END IF;

  IF (
    NEW.is_verified IS DISTINCT FROM OLD.is_verified OR
    NEW.verification_status IS DISTINCT FROM OLD.verification_status OR
    NEW.verification_photo_path IS DISTINCT FROM OLD.verification_photo_path OR
    NEW.verification_submitted_at IS DISTINCT FROM OLD.verification_submitted_at OR
    NEW.verification_reviewed_at IS DISTINCT FROM OLD.verification_reviewed_at OR
    NEW.verification_reviewer_id IS DISTINCT FROM OLD.verification_reviewer_id OR
    NEW.verification_similarity_score IS DISTINCT FROM OLD.verification_similarity_score OR
    NEW.verification_ai_analysis IS DISTINCT FROM OLD.verification_ai_analysis OR
    NEW.verification_auto_rejected IS DISTINCT FROM OLD.verification_auto_rejected OR
    NEW.verification_reference_artifact IS DISTINCT FROM OLD.verification_reference_artifact OR
    NEW.verification_reference_generated_at IS DISTINCT FROM OLD.verification_reference_generated_at OR
    NEW.verification_photo_retention_until IS DISTINCT FROM OLD.verification_photo_retention_until OR
    NEW.approved_primary_photos IS DISTINCT FROM OLD.approved_primary_photos
  ) THEN
    RAISE EXCEPTION 'protected_user_fields_update_not_allowed';
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."block_protected_user_fields_update"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."broadcast_user_online_event"("p_user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
    -- Only insert if we haven't broadcasted recently (throttle to every 5 seconds)
    IF NOT EXISTS (
        SELECT 1 FROM public.presence_events pe
        WHERE pe.user_id = p_user_id
          AND pe.event_type = 'online'
          AND pe.created_at > NOW() - INTERVAL '5 seconds'
    ) THEN
        INSERT INTO public.presence_events (user_id, event_type, created_at, expires_at)
        VALUES (p_user_id, 'online', NOW(), NOW() + INTERVAL '1 minute');
    END IF;
END;
$$;


ALTER FUNCTION "public"."broadcast_user_online_event"("p_user_id" "uuid") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."broadcast_user_online_event"("p_user_id" "uuid") IS 'Broadcasts a user online event, throttled to once per 5 seconds per user.';



CREATE OR REPLACE FUNCTION "public"."call_translate_proxy_edge_function"("p_content" "text", "p_target_lang" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'extensions'
    AS $$
DECLARE
    v_url text;
    v_anon_key text;
    v_response_status int;
    v_response_body text;
    v_result jsonb;
BEGIN
    -- Get config (hardcoded for now to avoid app_config dependency)
    v_url := 'https://vazkmvrbshxwyodentng.supabase.co';
    v_anon_key := 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZhemttdnJic2h4d3lvZGVudG5nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA2ODgyOTIsImV4cCI6MjA3NjI2NDI5Mn0.z4b2Mh_sTYjHAmqcvh14FBOfDJ-NmEC8iAirKitleUU';

    -- Fallback to env vars if not set (though we just set them)
    IF v_url IS NULL THEN
        v_url := current_setting('app.settings.supabase_url', true);
    END IF;
    IF v_anon_key IS NULL THEN
        v_anon_key := current_setting('app.settings.supabase_anon_key', true);
    END IF;

    IF v_url IS NULL OR v_anon_key IS NULL THEN
        RAISE EXCEPTION 'Missing Supabase configuration in app_config or env vars';
    END IF;

    -- Ensure URL ends with /functions/v1/translate-proxy
    -- Use trim to remove potential trailing slash from base URL
    v_url := trim(trailing '/' from v_url) || '/functions/v1/translate-proxy';

    -- Make the HTTP request
    SELECT
        status,
        content::text
    INTO
        v_response_status,
        v_response_body
    FROM
        http((
            'POST',
            v_url,
            ARRAY[
                http_header('Content-Type', 'application/json'),
                http_header('Authorization', 'Bearer ' || v_anon_key)
            ],
            'application/json',
            jsonb_build_object(
                'text', p_content,
                'target_lang', p_target_lang
            )::text
        )::http_request);

    IF v_response_status != 200 THEN
        -- Log error or raise exception
        RAISE WARNING 'Edge function failed with status %: %', v_response_status, v_response_body;
        RETURN NULL;
    END IF;

    BEGIN
        v_result := v_response_body::jsonb;
    EXCEPTION WHEN OTHERS THEN
        RAISE WARNING 'Failed to parse edge function response: %', v_response_body;
        RETURN NULL;
    END;

    RETURN v_result;
END;
$$;


ALTER FUNCTION "public"."call_translate_proxy_edge_function"("p_content" "text", "p_target_lang" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."call_translate_proxy_edge_function"("p_message_id" "uuid", "p_user_id" "uuid", "p_target_language" "text", "p_content" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public', 'extensions'
    AS $$
DECLARE
  v_url text;
  v_payload jsonb;
BEGIN
  -- Hardcoded Supabase URL as requested to avoid app_config dependency
  -- Note: The project ref part 'dprmvqkctvjvoikrcjwl' should be correct for the project.
  v_url := 'https://dprmvqkctvjvoikrcjwl.supabase.co/functions/v1/translate-proxy';
  
  -- Construct payload with keys matching translate-proxy/index.ts expectations
  -- index.ts expects: text, target_lang, source_lang (optional), message_id (optional but needed for update)
  v_payload := jsonb_build_object(
    'message_id', p_message_id,
    'user_id', p_user_id,
    'target_lang', p_target_language, -- Corrected key from target_language
    'text', p_content,               -- Corrected key from content
    'source_lang', 'auto'
  );

  -- Call Edge Function using http extension
  -- We use perform to discard result as this is fire-and-forget for the trigger/RPC
  -- However, for RPC we might want to know if it failed, but void return is fine.
  
  PERFORM
    extensions.http_post(
      v_url,
      jsonb_build_object(
        'Content-Type', 'application/json',
        'Authorization', 'Bearer ' || (SELECT coalesce(current_setting('request.jwt.claim.sub', true), 'anon')) 
        -- Pass auth header. If called from trigger, jwt might be null, so fallback to anon or similar if needed.
        -- But ideally we should pass a valid token. For now, assuming anon key is handled in edge function or it's public.
        -- Actually, we should probably use the service_role key if we want to bypass RLS in the edge function, 
        -- but we don't have it here without config.
        -- The edge function seems to use supabase-js with env vars, so it has service role key internally.
        -- The request itself needs to be authorized.
      )::http_header[], -- Corrected cast (removed extensions. prefix)
      'application/json',
      v_payload::text
    );
    
EXCEPTION WHEN OTHERS THEN
  -- Log error but don't fail the transaction
  RAISE WARNING 'Failed to call translate-proxy: %', SQLERRM;
END;
$$;


ALTER FUNCTION "public"."call_translate_proxy_edge_function"("p_message_id" "uuid", "p_user_id" "uuid", "p_target_language" "text", "p_content" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."call_translate_proxy_edge_function"("p_text" "text", "p_target_lang" "text", "p_source_lang" "text" DEFAULT 'auto'::"text", "p_message_id" "uuid" DEFAULT NULL::"uuid", "p_match_id" "uuid" DEFAULT NULL::"uuid", "p_recipient_gender" "text" DEFAULT NULL::"text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_supabase_url text;
  v_anon_key text;
  v_edge_function_url text;
  v_http_response record;
  v_response_json jsonb;
  v_auth_header text;
BEGIN
  -- Get Supabase configuration from environment variables
  v_supabase_url := current_setting('app.supabase_url', true);
  v_anon_key := current_setting('app.supabase_anon_key', true);
  
  IF v_supabase_url IS NULL OR v_supabase_url = '' OR
     v_anon_key IS NULL OR v_anon_key = '' THEN
    RAISE NOTICE '[EDGE_FUNCTION] Missing Supabase environment configuration';
    RETURN NULL;
  END IF;
  
  v_edge_function_url := v_supabase_url || '/functions/v1/translate-proxy';
  v_auth_header := 'Bearer ' || v_anon_key;
  
  v_response_json := jsonb_build_object(
    'text', p_text,
    'target_language', p_target_lang,
    'source_language', p_source_lang
  );
  
  IF p_message_id IS NOT NULL THEN
    v_response_json := v_response_json || jsonb_build_object('message_id', p_message_id::text);
  END IF;
  
  IF p_match_id IS NOT NULL THEN
    v_response_json := v_response_json || jsonb_build_object('match_id', p_match_id::text);
  END IF;
  
  IF p_recipient_gender IS NOT NULL THEN
    v_response_json := v_response_json || jsonb_build_object('recipient_gender', p_recipient_gender);
  END IF;
  
  SELECT * INTO v_http_response
  FROM http_post(
    v_edge_function_url,
    v_response_json::text,
    'application/json',
    ARRAY[
      http_header('Authorization', v_auth_header),
      http_header('Content-Type', 'application/json')
    ]
  );
  
  IF v_http_response.status = 200 THEN
    BEGIN
      RETURN v_http_response.content::jsonb;
    EXCEPTION WHEN OTHERS THEN
      RETURN NULL;
    END;
  ELSE
    RETURN NULL;
  END IF;
  
EXCEPTION WHEN OTHERS THEN
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."call_translate_proxy_edge_function"("p_text" "text", "p_target_lang" "text", "p_source_lang" "text", "p_message_id" "uuid", "p_match_id" "uuid", "p_recipient_gender" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cancel_queued_subscription"("p_queue_id" "uuid", "p_reason" "text" DEFAULT NULL::"text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
BEGIN
  SELECT user_id INTO v_user_id
  FROM public.user_subscription_queue
  WHERE id = p_queue_id;

  IF v_user_id IS NULL THEN
    RETURN FALSE;
  END IF;

  IF v_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  UPDATE public.user_subscription_queue
  SET status = 'cancelled',
      cancelled_at = now(),
      cancellation_reason = p_reason,
      updated_at = now()
  WHERE id = p_queue_id
    AND status = 'pending';

  RETURN FOUND;
END;
$$;


ALTER FUNCTION "public"."cancel_queued_subscription"("p_queue_id" "uuid", "p_reason" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."check_and_normalize_user_subscription"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("previous_tier" character varying, "new_tier" character varying, "normalized" boolean)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_before text;
  v_after text;
  v_before_exp timestamptz;
  v_after_exp timestamptz;
BEGIN
  v_user_id := COALESCE(p_user_id, auth.uid());

  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  IF v_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT subscription_tier, subscription_expires_at
  INTO v_before, v_before_exp
  FROM public.users
  WHERE id = v_user_id;

  PERFORM public.normalize_user_subscription_queue(v_user_id);

  SELECT subscription_tier, subscription_expires_at
  INTO v_after, v_after_exp
  FROM public.users
  WHERE id = v_user_id;

  RETURN QUERY SELECT
    v_before::varchar,
    v_after::varchar,
    (v_before IS DISTINCT FROM v_after) OR (v_before_exp IS DISTINCT FROM v_after_exp);
END;
$$;


ALTER FUNCTION "public"."check_and_normalize_user_subscription"("p_user_id" "uuid") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."check_and_normalize_user_subscription"("p_user_id" "uuid") IS 'Client-callable function to check and normalize a specific user subscription immediately';



CREATE OR REPLACE FUNCTION "public"."check_email_availability"("p_email" "text", "p_exclude_user_id" "uuid" DEFAULT NULL::"uuid") RETURNS TABLE("available" boolean, "message" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_existing_user_id uuid;
BEGIN
  -- Check if email exists in auth.users
  SELECT id INTO v_existing_user_id
  FROM auth.users
  WHERE email = LOWER(p_email)
    AND (p_exclude_user_id IS NULL OR id != p_exclude_user_id)
  LIMIT 1;
  
  IF v_existing_user_id IS NOT NULL THEN
    RETURN QUERY SELECT false, 'This email address is already in use'::text;
  ELSE
    RETURN QUERY SELECT true, 'Email is available'::text;
  END IF;
END;
$$;


ALTER FUNCTION "public"."check_email_availability"("p_email" "text", "p_exclude_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."check_event_start_not_past"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  -- If an event starts in the past, reject the insert/update
  IF NEW.start_time < now() THEN
    RAISE EXCEPTION 'Event start_time (% ) must not be in the past', NEW.start_time;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."check_event_start_not_past"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."check_profile_bio_uniqueness"("p_user_id" "uuid", "p_bio" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_normalized_bio text;
BEGIN
  v_normalized_bio := public.normalize_profile_bio_text(p_bio);

  IF v_normalized_bio IS NULL THEN
    RETURN true;
  END IF;

  RETURN NOT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id <> p_user_id
      AND public.bio_texts_too_similar(u.bio, p_bio)
  );
END;
$$;


ALTER FUNCTION "public"."check_profile_bio_uniqueness"("p_user_id" "uuid", "p_bio" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."check_unread_notifications"("p_user_id" "uuid", "p_message_id" "uuid" DEFAULT NULL::"uuid") RETURNS TABLE("unread_matches_count" integer, "unread_messages_count" integer, "latest_match_name" "text", "latest_message_sender" "text", "latest_message_content" "text", "latest_message_id" "uuid", "latest_match_id" "uuid", "latest_message_sender_id" "uuid", "translation_enabled" boolean, "translation_language" "text", "translation_available" boolean)
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    v_unread_matches INTEGER := 0;
    v_unread_messages INTEGER := 0;
    v_latest_match_name TEXT;
    v_latest_message_sender TEXT;
    v_latest_message_content TEXT;
    v_latest_message_id UUID;
    v_latest_match_id UUID;
    v_latest_sender_id UUID;
    v_translation_enabled BOOLEAN;
    v_translation_language TEXT;
    v_translation_available BOOLEAN;
BEGIN
    SET search_path = 'public';

    -- If a specific message ID is provided (from Realtime), fetch it directly
    IF p_message_id IS NOT NULL THEN
        SELECT 
            public.mask_full_name(
                COALESCE(up.profile_data->>'fullName', u.name)
            ),
            CASE 
                WHEN cm.content_translated IS NOT NULL AND cm.content_translated != '' AND cm.content_translated != 'null' THEN cm.content_translated
                ELSE cm.content_original
            END,
            cm.id,
            cm.match_id,
            cm.sender_id,
            COALESCE(c.translation_enabled, false),
            c.translation_language,
            (cm.content_translated IS NOT NULL AND cm.content_translated != '' AND cm.content_translated != 'null')
        INTO v_latest_message_sender, v_latest_message_content, v_latest_message_id, v_latest_match_id, v_latest_sender_id, v_translation_enabled, v_translation_language, v_translation_available
        FROM chat_messages cm
        LEFT JOIN user_profiles up ON up.user_id = cm.sender_id
        LEFT JOIN users u ON u.id = cm.sender_id
        LEFT JOIN chats c ON c.match_id = cm.match_id AND c.user_id = p_user_id
        WHERE cm.id = p_message_id;

        IF FOUND THEN
            v_unread_messages := 1;
            RETURN QUERY SELECT 
                0, 
                1, 
                NULL::TEXT, 
                v_latest_message_sender, 
                v_latest_message_content,
                v_latest_message_id,
                v_latest_match_id,
                v_latest_sender_id,
                v_translation_enabled,
                v_translation_language,
                v_translation_available;
            RETURN;
        END IF;
    END IF;

    -- Fallback to polling logic (check recent unread)
    
    -- 1. Count unread matches (last 2 minutes)
    SELECT COUNT(*)::INTEGER
    INTO v_unread_matches
    FROM matches m
    WHERE (m.user1_id = p_user_id OR m.user2_id = p_user_id)
      AND m.created_at > (NOW() - INTERVAL '2 minutes');

    -- Get the name of the most recent match
    IF v_unread_matches > 0 THEN
        SELECT 
            public.mask_full_name(
                COALESCE(up.profile_data->>'fullName', u.name)
            ),
            m.id
        INTO v_latest_match_name, v_latest_match_id
        FROM matches m
        LEFT JOIN user_profiles up ON up.user_id = CASE 
            WHEN m.user1_id = p_user_id THEN m.user2_id 
            ELSE m.user1_id 
        END
        LEFT JOIN public.users u ON u.id = CASE 
            WHEN m.user1_id = p_user_id THEN m.user2_id 
            ELSE m.user1_id 
        END
        WHERE (m.user1_id = p_user_id OR m.user2_id = p_user_id)
          AND m.created_at > (NOW() - INTERVAL '2 minutes')
        ORDER BY m.created_at DESC
        LIMIT 1;
    END IF;

    -- 2. Count unread messages (received in last 2 minutes and unread)
    -- Using read_at IS NULL to determine unread status
    SELECT COUNT(*)::INTEGER
    INTO v_unread_messages
    FROM chat_messages cm
    JOIN matches m ON cm.match_id = m.id
    WHERE (m.user1_id = p_user_id OR m.user2_id = p_user_id)
      AND cm.sender_id != p_user_id
      AND cm.read_at IS NULL
      AND cm.created_at > (NOW() - INTERVAL '2 minutes');

    -- Get latest message details with translation info
    IF v_unread_messages > 0 THEN
        SELECT 
            public.mask_full_name(
                COALESCE(up.profile_data->>'fullName', u.name)
            ),
            CASE 
                WHEN cm.content_translated IS NOT NULL AND cm.content_translated != '' AND cm.content_translated != 'null' THEN cm.content_translated
                ELSE cm.content_original
            END,
            cm.id,
            cm.match_id,
            cm.sender_id,
            COALESCE(c.translation_enabled, false),
            c.translation_language,
            (cm.content_translated IS NOT NULL AND cm.content_translated != '' AND cm.content_translated != 'null')
        INTO v_latest_message_sender, v_latest_message_content, v_latest_message_id, v_latest_match_id, v_latest_sender_id, v_translation_enabled, v_translation_language, v_translation_available
        FROM chat_messages cm
        JOIN matches m ON cm.match_id = m.id
        LEFT JOIN user_profiles up ON up.user_id = cm.sender_id
        LEFT JOIN users u ON u.id = cm.sender_id
        LEFT JOIN chats c ON c.match_id = cm.match_id AND c.user_id = p_user_id
        WHERE (m.user1_id = p_user_id OR m.user2_id = p_user_id)
          AND cm.sender_id != p_user_id
          AND cm.read_at IS NULL
          AND cm.created_at > (NOW() - INTERVAL '2 minutes')
        ORDER BY cm.created_at DESC
        LIMIT 1;
    END IF;

    RETURN QUERY SELECT 
        COALESCE(v_unread_matches, 0), 
        COALESCE(v_unread_messages, 0), 
        v_latest_match_name, 
        v_latest_message_sender, 
        v_latest_message_content, 
        v_latest_message_id,
        v_latest_match_id,
        v_latest_sender_id, -- Matches latest_message_sender_id in table definition order
        v_translation_enabled,
        v_translation_language,
        v_translation_available;
END;
$$;


ALTER FUNCTION "public"."check_unread_notifications"("p_user_id" "uuid", "p_message_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."claim_referral"("p_referral_code" "text", "p_device_id" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    v_user_id UUID;
    v_user_created_at TIMESTAMPTZ;
    v_referrer_id UUID;
    v_existing_referral_id UUID;
    v_device_check_id UUID;
BEGIN
    -- 1. Get Current User ID (from Auth context)
    v_user_id := auth.uid();
    IF v_user_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'Not authenticated');
    END IF;

    -- 2. Get User Creation Time
    SELECT created_at INTO v_user_created_at FROM users WHERE id = v_user_id;
    
    -- CHECK: Account Age (Must be < 1 hour old)
    -- Allow a small buffer, but strictly block older accounts
    IF v_user_created_at < (NOW() - INTERVAL '1 hour') THEN
        RETURN jsonb_build_object('success', false, 'error', 'Account is not new (created > 1 hour ago)');
    END IF;

    -- 3. Validate Referral Code & Get Referrer
    SELECT id INTO v_referrer_id FROM users WHERE referral_code = p_referral_code;
    
    IF v_referrer_id IS NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'Invalid referral code');
    END IF;

    -- CHECK: Self-Referral
    IF v_referrer_id = v_user_id THEN
        RETURN jsonb_build_object('success', false, 'error', 'Cannot refer yourself');
    END IF;

    -- 4. Check for Existing Referral (User Level)
    SELECT id INTO v_existing_referral_id FROM referrals WHERE referee_id = v_user_id;
    IF v_existing_referral_id IS NOT NULL THEN
        RETURN jsonb_build_object('success', false, 'error', 'User already referred');
    END IF;

    -- 5. Check for Device Abuse (Device Level)
    -- If p_device_id is provided and valid, check if it has been used before
    IF p_device_id IS NOT NULL AND p_device_id != 'unknown' AND p_device_id != '' THEN
        SELECT id INTO v_device_check_id FROM referrals WHERE device_id = p_device_id LIMIT 1;
        
        IF v_device_check_id IS NOT NULL THEN
             RETURN jsonb_build_object('success', false, 'error', 'Device already used for referral');
        END IF;
    END IF;

    -- 6. Execute Claim (Insert)
    INSERT INTO referrals (referrer_id, referee_id, status, device_id)
    VALUES (v_referrer_id, v_user_id, 'pending', p_device_id);

    RETURN jsonb_build_object('success', true, 'message', 'Referral claimed successfully');

EXCEPTION WHEN OTHERS THEN
    RETURN jsonb_build_object('success', false, 'error', SQLERRM);
END;
$$;


ALTER FUNCTION "public"."claim_referral"("p_referral_code" "text", "p_device_id" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_expired_email_codes"() RETURNS TABLE("deleted_count" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_deleted_count int;
BEGIN
  -- Delete codes that have expired (15 minutes after creation)
  DELETE FROM public.sensitive_action_email_codes
  WHERE created_at < now() - interval '15 minutes';
  
  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
  
  RETURN QUERY SELECT v_deleted_count;
END;
$$;


ALTER FUNCTION "public"."cleanup_expired_email_codes"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_expired_matches"("p_cutoff" timestamp with time zone, "p_limit" integer DEFAULT 500) RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_deleted int := 0;
BEGIN
  WITH locked AS (
    SELECT m.id, m.user1_id, m.user2_id, m.match_type
    FROM public.matches m
    WHERE m.created_at < p_cutoff
      AND m.match_type IN ('proximity','event','co_motion')
    ORDER BY m.created_at
    LIMIT COALESCE(p_limit, 500)
    FOR UPDATE
  ),
  eligible AS (
    SELECT l.*
    FROM locked l
    WHERE NOT EXISTS (
      SELECT 1 FROM public.chat_messages cm
      WHERE cm.match_id = l.id
      LIMIT 1
    )
  ),
  upsert_pairs AS (
    INSERT INTO public.unmatched_pairs (user1_id, user2_id, created_by, created_at, match_type, match_id)
    SELECT
      LEAST(e.user1_id, e.user2_id),
      GREATEST(e.user1_id, e.user2_id),
      '00000000-0000-0000-0000-000000000000'::uuid,
      now(),
      e.match_type,
      e.id
    FROM eligible e
    ON CONFLICT (user1_id, user2_id) DO UPDATE
    SET
      created_by = EXCLUDED.created_by,
      created_at = GREATEST(unmatched_pairs.created_at, EXCLUDED.created_at),
      match_type = COALESCE(unmatched_pairs.match_type, EXCLUDED.match_type),
      match_id = COALESCE(unmatched_pairs.match_id, EXCLUDED.match_id)
    RETURNING 1
  ),
  del_chats AS (
    DELETE FROM public.chats c
    WHERE c.match_id IN (SELECT id FROM eligible)
    RETURNING 1
  ),
  del_user_recent_matches AS (
    DELETE FROM public.user_recent_matches urm
    WHERE urm.match_id IN (SELECT id FROM eligible)
    RETURNING 1
  ),
  del_messages AS (
    DELETE FROM public.chat_messages cm
    WHERE cm.match_id IN (SELECT id FROM eligible)
    RETURNING 1
  ),
  del_matches AS (
    DELETE FROM public.matches m
    WHERE m.id IN (SELECT id FROM eligible)
    RETURNING 1
  )
  SELECT COUNT(*) INTO v_deleted FROM del_matches;

  RETURN COALESCE(v_deleted, 0);
END;
$$;


ALTER FUNCTION "public"."cleanup_expired_matches"("p_cutoff" timestamp with time zone, "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_expired_verification_photos"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_deleted_count integer := 0;
  v_storage_path text;
  v_row record;
BEGIN
  PERFORM set_config('request.jwt.claim.role', 'service_role', true);

  FOR v_row IN
    SELECT u.id, u.verification_photo_path
    FROM public.users u
    WHERE u.verification_photo_path IS NOT NULL
      AND u.verification_photo_retention_until IS NOT NULL
      AND u.verification_photo_retention_until <= now()
  LOOP
    v_storage_path := btrim(COALESCE(v_row.verification_photo_path, ''));
    v_storage_path := regexp_replace(v_storage_path, '^https?://[^/]+/storage/v1/object/(?:public|authenticated|sign)/verification-photos/', '');
    v_storage_path := regexp_replace(v_storage_path, '^/?verification-photos/', '');

    IF v_storage_path <> '' THEN
      DELETE FROM storage.objects
      WHERE bucket_id = 'verification-photos'
        AND name = v_storage_path;
    END IF;

    UPDATE public.users u
    SET verification_photo_path = NULL
    WHERE u.id = v_row.id;

    v_deleted_count := v_deleted_count + 1;
  END LOOP;

  RETURN v_deleted_count;
END;
$$;


ALTER FUNCTION "public"."cleanup_expired_verification_photos"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_notification_queue"() RETURNS TABLE("action_taken" "text", "records_affected" integer)
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    rows_deleted INTEGER;
    rows_updated INTEGER;
    rows_reset INTEGER;
BEGIN
    -- Clean up NULL user_id records
    DELETE FROM notification_queue 
    WHERE user_id IS NULL;
    
    GET DIAGNOSTICS rows_deleted = ROW_COUNT;
    
    action_taken := 'Deleted records with NULL user_id';
    records_affected := rows_deleted;
    RETURN NEXT;
    
    -- Fix invalid status values
    UPDATE notification_queue 
    SET status = 'pending' 
    WHERE status NOT IN ('pending', 'processing', 'sent', 'failed');
    
    GET DIAGNOSTICS rows_updated = ROW_COUNT;
    
    action_taken := 'Fixed invalid status values';
    records_affected := rows_updated;
    RETURN NEXT;
    
    -- Reset stuck 'processing' records back to 'pending'
    UPDATE notification_queue 
    SET status = 'pending',
        updated_at = NOW()
    WHERE status = 'processing' 
    AND updated_at < NOW() - INTERVAL '1 hour'; -- Assume stuck if processing for more than 1 hour
    
    GET DIAGNOSTICS rows_reset = ROW_COUNT;
    
    action_taken := 'Reset stuck processing records';
    records_affected := rows_reset;
    RETURN NEXT;
END;
$$;


ALTER FUNCTION "public"."cleanup_notification_queue"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_old_presence_events"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    DELETE FROM public.presence_events
    WHERE expires_at < NOW();
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    RETURN deleted_count;
END;
$$;


ALTER FUNCTION "public"."cleanup_old_presence_events"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_orphan_profile_photos"("p_min_age_minutes" integer DEFAULT 1440) RETURNS TABLE("deleted_count" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_threshold timestamptz;
  v_deleted int := 0;
BEGIN
  IF p_min_age_minutes IS NULL OR p_min_age_minutes < 0 THEN
    RAISE EXCEPTION 'p_min_age_minutes must be >= 0';
  END IF;

  v_threshold := now() - make_interval(mins => p_min_age_minutes);

  WITH referenced AS (
    SELECT DISTINCT value AS name
    FROM public.users u
    CROSS JOIN LATERAL jsonb_array_elements_text(to_jsonb(u.photos)) AS value
    WHERE u.photos IS NOT NULL
      AND value IS NOT NULL
      AND btrim(value) <> ''
    UNION
    SELECT DISTINCT value AS name
    FROM public.users u
    CROSS JOIN LATERAL jsonb_array_elements_text(COALESCE(u.approved_primary_photos, '[]'::jsonb)) AS value
    WHERE value IS NOT NULL
      AND btrim(value) <> ''
  )
  DELETE FROM storage.objects o
  WHERE o.bucket_id = 'profile-photos'
    AND o.created_at < v_threshold
    AND NOT EXISTS (
      SELECT 1
      FROM referenced r
      WHERE r.name = o.name
    );

  GET DIAGNOSTICS v_deleted = ROW_COUNT;
  deleted_count := v_deleted;
  RETURN NEXT;
END;
$$;


ALTER FUNCTION "public"."cleanup_orphan_profile_photos"("p_min_age_minutes" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_orphaned_chat_messages"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  deleted_count integer;
BEGIN
  -- Delete messages for matches that no longer exist
  DELETE FROM public.chat_messages
  WHERE match_id NOT IN (SELECT id FROM public.matches);

  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$;


ALTER FUNCTION "public"."cleanup_orphaned_chat_messages"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_profile_edit_attachments_on_decision"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public', 'storage'
    AS $$
DECLARE
  v_paths text[];
BEGIN
  IF TG_OP <> 'UPDATE' THEN
    RETURN NEW;
  END IF;

  IF NEW.status NOT IN ('approved', 'rejected') THEN
    RETURN NEW;
  END IF;

  IF COALESCE(OLD.status, '') IN ('approved', 'rejected') THEN
    RETURN NEW;
  END IF;

  IF NEW.attachments IS NULL OR jsonb_typeof(NEW.attachments) <> 'array' THEN
    RETURN NEW;
  END IF;

  BEGIN
    SELECT array_agg(DISTINCT cleaned_path)
    INTO v_paths
    FROM (
      SELECT
        NULLIF(
          regexp_replace(
            regexp_replace(
              regexp_replace(
                regexp_replace(
                  regexp_replace(
                    COALESCE(a.value->>'url', a.value->>'path', a.value->>'objectPath', ''),
                    '^https?://[^/]+',
                    ''
                  ),
                  '^/storage/v1/object/(sign|public)/profile-edit-attachments/',
                  ''
                ),
                '^storage/v1/object/(sign|public)/profile-edit-attachments/',
                ''
              ),
              '^profile-edit-attachments/',
              ''
            ),
            '^/+',
            ''
          ),
          ''
        ) AS cleaned_path,
        NULLIF(btrim(COALESCE(a.value->>'bucket', '')), '') AS bucket_name
      FROM jsonb_array_elements(NEW.attachments) AS a(value)
    ) s
    WHERE cleaned_path IS NOT NULL
      AND (bucket_name IS NULL OR bucket_name = 'profile-edit-attachments');

    IF v_paths IS NOT NULL AND COALESCE(array_length(v_paths, 1), 0) > 0 THEN
      DELETE FROM storage.objects
      WHERE bucket_id = 'profile-edit-attachments'
        AND name = ANY(v_paths);
    END IF;
  EXCEPTION WHEN OTHERS THEN
    NULL;
  END;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."cleanup_profile_edit_attachments_on_decision"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."cleanup_stale_presence"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    cleaned_count INTEGER := 0;
BEGIN
    -- Mark users offline if they haven't been seen in presence for more than 5 seconds
    -- This provides fast detection of app kills while avoiding false positives
    UPDATE public.user_presence
    SET is_online = FALSE, updated_at = NOW()
    WHERE is_online = TRUE
      AND updated_at < NOW() - INTERVAL '5 seconds';

    GET DIAGNOSTICS cleaned_count = ROW_COUNT;
    RETURN cleaned_count;
END;
$$;


ALTER FUNCTION "public"."cleanup_stale_presence"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."clear_mfa_recovery_codes"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_deleted_count integer;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  DELETE FROM public.user_mfa_recovery_codes
  WHERE user_id = v_user_id;

  GET DIAGNOSTICS v_deleted_count = ROW_COUNT;
  RETURN COALESCE(v_deleted_count, 0);
END;
$$;


ALTER FUNCTION "public"."clear_mfa_recovery_codes"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."clear_user_session_fcm_token"("p_fcm_token" "text") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_token text;
  v_count integer := 0;
BEGIN
  IF auth.role() <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_token := NULLIF(btrim(COALESCE(p_fcm_token, '')), '');
  IF v_token IS NULL THEN
    RETURN 0;
  END IF;

  UPDATE public.user_session
  SET metadata = (COALESCE(metadata, '{}'::jsonb) - 'fcm_token' - 'fcm_token_updated_at')
  WHERE NULLIF(btrim(COALESCE(metadata->>'fcm_token', '')), '') = v_token;

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;


ALTER FUNCTION "public"."clear_user_session_fcm_token"("p_fcm_token" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."clear_user_subscription"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("subscription_tier" "text", "subscription_expires_at" timestamp with time zone, "subscription_next_tier" "text", "subscription_next_starts_at" timestamp with time zone, "subscription_next_expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF p_user_id IS NULL THEN
    p_user_id := auth.uid();
  END IF;

  IF p_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  UPDATE public.users
  SET subscription_tier = 'free',
      subscription_expires_at = NULL,
      subscription_next_tier = NULL,
      subscription_next_starts_at = NULL,
      subscription_next_expires_at = NULL
  WHERE id = p_user_id;

  RETURN QUERY
  SELECT u.subscription_tier, u.subscription_expires_at, u.subscription_next_tier, u.subscription_next_starts_at, u.subscription_next_expires_at
  FROM public.users u
  WHERE u.id = p_user_id;
END $$;


ALTER FUNCTION "public"."clear_user_subscription"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."complete_email_change"("p_user_id" "uuid", "p_code" "text") RETURNS TABLE("success" boolean, "message" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  UPDATE public.pending_email_changes
  SET completed_at = now()
  WHERE user_id = p_user_id
    AND verification_code = p_code
    AND verified_at IS NOT NULL
    AND completed_at IS NULL;

  IF FOUND THEN
    RETURN QUERY SELECT true, 'Email change completed'::text;
  ELSE
    RETURN QUERY SELECT false, 'Could not complete email change'::text;
  END IF;
END;
$$;


ALTER FUNCTION "public"."complete_email_change"("p_user_id" "uuid", "p_code" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."consume_mfa_recovery_code"("p_code" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_normalized_code text;
  v_code_hash text;
  v_recovery_code_id uuid;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  v_normalized_code := public._normalize_mfa_recovery_code(p_code);
  IF length(v_normalized_code) <> 16 THEN
    RETURN false;
  END IF;

  v_code_hash := public._hash_mfa_recovery_code(v_user_id, v_normalized_code);

  SELECT id
  INTO v_recovery_code_id
  FROM public.user_mfa_recovery_codes
  WHERE user_id = v_user_id
    AND code_hash = v_code_hash
    AND used_at IS NULL
  LIMIT 1;

  IF v_recovery_code_id IS NULL THEN
    RETURN false;
  END IF;

  UPDATE public.user_mfa_recovery_codes
  SET used_at = now()
  WHERE id = v_recovery_code_id
    AND used_at IS NULL;

  RETURN FOUND;
END;
$$;


ALTER FUNCTION "public"."consume_mfa_recovery_code"("p_code" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."count_event_attendees"("event_id_param" "uuid") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    attendee_count INTEGER;
BEGIN
    SET search_path = 'public';
    SELECT COUNT(*)
    INTO attendee_count
    FROM event_attendees
    WHERE event_id = event_id_param;
    RETURN COALESCE(attendee_count, 0);
END;
$$;


ALTER FUNCTION "public"."count_event_attendees"("event_id_param" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."count_target_users"("filter_criteria" "jsonb") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
  user_count integer;
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT COUNT(DISTINCT gufb.user_id)
  INTO user_count
  FROM public.get_users_for_broadcast(filter_criteria) AS gufb;

  RETURN COALESCE(user_count, 0);
END;
$$;


ALTER FUNCTION "public"."count_target_users"("filter_criteria" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."debug_get_external_ad_for_placement"("p_placement" "text", "p_platform" "text") RETURNS TABLE("debug_step" "text", "debug_value" "text", "ad_id" "uuid", "network_id" "uuid", "ad_placement" "text", "platform" "text", "ad_format" "text", "ad_unit_id" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_platform text := lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web'));
  v_user_tier text;
  v_allowed_placements jsonb;
  v_allowed_tiers jsonb;
  v_allowed_platforms jsonb;
  v_ad_enabled boolean;
  v_placement_allowed boolean;
  v_tier_allowed boolean;
  v_platform_allowed boolean;
BEGIN
  -- Step 1: Check auth
  IF v_user_id IS NULL THEN
    RETURN QUERY SELECT 
      'Step 1: Auth Check'::text,
      'FAIL: auth.uid() is NULL'::text,
      null::uuid, null::uuid, null::text, null::text, null::text, null::text;
    RETURN;
  END IF;
  
  RETURN QUERY SELECT 
    'Step 1: Auth Check'::text,
    'PASS: User ID = ' || v_user_id::text,
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 2: Check if external ads are enabled
  v_ad_enabled := public.app_config_bool('ads.external.enabled', false);
  IF NOT v_ad_enabled THEN
    RETURN QUERY SELECT 
      'Step 2: Ads Enabled Check'::text,
      'FAIL: ads.external.enabled = false'::text,
      null::uuid, null::uuid, null::text, null::text, null::text, null::text;
    RETURN;
  END IF;
  
  RETURN QUERY SELECT 
    'Step 2: Ads Enabled Check'::text,
    'PASS: ads.external.enabled = true'::text,
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 3: Get user's subscription tier
  SELECT COALESCE(NULLIF(btrim(subscription_tier), ''), 'free')
  INTO v_user_tier
  FROM public.users
  WHERE id = v_user_id;
  
  RETURN QUERY SELECT 
    'Step 3: User Tier'::text,
    'User tier = ' || COALESCE(v_user_tier, 'NULL'),
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 4: Get config values
  v_allowed_placements := public.app_config_jsonb('ads.external.allowed_placements', '["home_inline", "matches_inline", "chats_inline", "events_inline"]'::jsonb);
  v_allowed_tiers := public.app_config_jsonb('ads.external.allowed_tiers', '["free"]'::jsonb);
  v_allowed_platforms := public.app_config_jsonb('ads.external.allowed_platforms', '["android", "ios", "web"]'::jsonb);
  
  RETURN QUERY SELECT 
    'Step 4: Config Values'::text,
    'placements=' || v_allowed_placements::text || ', tiers=' || v_allowed_tiers::text || ', platforms=' || v_allowed_platforms::text,
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 5: Check placement
  v_placement_allowed := v_allowed_placements @> to_jsonb(p_placement);
  IF NOT v_placement_allowed THEN
    RETURN QUERY SELECT 
      'Step 5: Placement Check'::text,
      'FAIL: ' || p_placement || ' not in ' || v_allowed_placements::text,
      null::uuid, null::uuid, null::text, null::text, null::text, null::text;
    RETURN;
  END IF;
  
  RETURN QUERY SELECT 
    'Step 5: Placement Check'::text,
    'PASS: ' || p_placement || ' allowed'::text,
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 6: Check tier
  v_tier_allowed := v_allowed_tiers @> to_jsonb(v_user_tier);
  IF NOT v_tier_allowed THEN
    RETURN QUERY SELECT 
      'Step 6: Tier Check'::text,
      'FAIL: tier ' || v_user_tier || ' not in ' || v_allowed_tiers::text,
      null::uuid, null::uuid, null::text, null::text, null::text, null::text;
    RETURN;
  END IF;
  
  RETURN QUERY SELECT 
    'Step 6: Tier Check'::text,
    'PASS: tier ' || v_user_tier || ' allowed'::text,
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 7: Check platform
  v_platform_allowed := v_allowed_platforms @> to_jsonb(v_platform);
  IF NOT v_platform_allowed THEN
    RETURN QUERY SELECT 
      'Step 7: Platform Check'::text,
      'FAIL: platform ' || v_platform || ' not in ' || v_allowed_platforms::text,
      null::uuid, null::uuid, null::text, null::text, null::text, null::text;
    RETURN;
  END IF;
  
  RETURN QUERY SELECT 
    'Step 7: Platform Check'::text,
    'PASS: platform ' || v_platform || ' allowed'::text,
    null::uuid, null::uuid, null::text, null::text, null::text, null::text;

  -- Step 8: Query for ad
  RETURN QUERY
  SELECT
    'Step 8: Ad Query'::text,
    'Found ad'::text,
    u.id,
    u.network_id,
    u.placement,
    u.platform,
    u.ad_format,
    u.ad_unit_id
  FROM public.ad_networks n
  INNER JOIN public.ad_units u ON u.network_id = n.id
  WHERE n.is_enabled = true
    AND u.is_active = true
    AND u.placement = p_placement
    AND u.platform IN ('web', v_platform)
  ORDER BY n.priority ASC, u.priority ASC
  LIMIT 1;
  
  -- If no rows returned from above, show that
  IF NOT FOUND THEN
    RETURN QUERY SELECT 
      'Step 8: Ad Query'::text,
      'FAIL: No matching ad units found'::text,
      null::uuid, null::uuid, null::text, null::text, null::text, null::text;
  END IF;
END;
$$;


ALTER FUNCTION "public"."debug_get_external_ad_for_placement"("p_placement" "text", "p_platform" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."detect_and_broadcast_offline_users"() RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    offline_user RECORD;
    inserted_count INTEGER := 0;
BEGIN
    -- Find users who just went offline (last activity between 10-20 seconds ago)
    -- We use a window to avoid duplicate broadcasts
    FOR offline_user IN 
        SELECT ua.user_id, ua.last_activity
        FROM public.user_activity ua
        WHERE ua.is_online = TRUE
          AND ua.last_activity < NOW() - INTERVAL '10 seconds'
          AND ua.last_activity > NOW() - INTERVAL '20 seconds'
          AND NOT EXISTS (
              -- Don't broadcast if we already have a recent offline event
              SELECT 1 FROM public.presence_events pe
              WHERE pe.user_id = ua.user_id
                AND pe.event_type = 'offline'
                AND pe.created_at > NOW() - INTERVAL '30 seconds'
          )
    LOOP
        INSERT INTO public.presence_events (user_id, event_type, created_at, expires_at)
        VALUES (offline_user.user_id, 'offline', NOW(), NOW() + INTERVAL '1 minute');
        
        inserted_count := inserted_count + 1;
    END LOOP;
    
    RETURN inserted_count;
END;
$$;


ALTER FUNCTION "public"."detect_and_broadcast_offline_users"() OWNER TO "postgres";


COMMENT ON FUNCTION "public"."detect_and_broadcast_offline_users"() IS 'Detects users who have gone offline and inserts records into presence_events for real-time broadcast.';



CREATE OR REPLACE FUNCTION "public"."edge_require_internal_secret"() RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  v_headers jsonb;
  v_provided text;
  v_expected text;
  v_config_value_type text;
BEGIN
  v_headers := COALESCE(current_setting('request.headers', true), '{}'::text)::jsonb;
  v_provided := COALESCE(
    v_headers ->> 'x-edge-internal-secret',
    v_headers ->> 'X-Edge-Internal-Secret'
  );

  SELECT c.data_type
  INTO v_config_value_type
  FROM information_schema.columns c
  WHERE c.table_schema = 'public'
    AND c.table_name = 'app_config'
    AND c.column_name = 'config_value'
  LIMIT 1;

  IF v_config_value_type IN ('json', 'jsonb') THEN
    EXECUTE
      'SELECT (config_value #>> ''{}'') FROM public.app_config WHERE config_key = $1 LIMIT 1'
    INTO v_expected
    USING 'edge_internal_secret';
  ELSE
    EXECUTE
      'SELECT config_value::text FROM public.app_config WHERE config_key = $1 LIMIT 1'
    INTO v_expected
    USING 'edge_internal_secret';
  END IF;

  IF v_expected IS NULL OR btrim(v_expected) = '' THEN
    RAISE EXCEPTION 'edge_internal_secret_not_configured';
  END IF;

  IF v_provided IS NULL OR v_provided <> v_expected THEN
    RAISE EXCEPTION 'edge_internal_secret_invalid';
  END IF;
END;
$_$;


ALTER FUNCTION "public"."edge_require_internal_secret"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."edge_update_verification"("p_user_id" "uuid", "p_patch" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_patch jsonb := COALESCE(p_patch, '{}'::jsonb);
  v_status text;
BEGIN
  PERFORM public.edge_require_internal_secret();

  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'user_id_required';
  END IF;

  IF jsonb_typeof(v_patch) IS DISTINCT FROM 'object' THEN
    RAISE EXCEPTION 'invalid_patch';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM jsonb_object_keys(v_patch) k
    WHERE k NOT IN (
      'verification_photo_path',
      'verification_status',
      'verification_submitted_at',
      'verification_reviewed_at',
      'verification_similarity_score',
      'verification_ai_analysis',
      'verification_auto_rejected',
      'verification_reference_artifact',
      'verification_reference_generated_at',
      'verification_photo_retention_until',
      'is_verified'
    )
  ) THEN
    RAISE EXCEPTION 'patch_has_disallowed_keys';
  END IF;

  v_status := NULLIF(btrim(COALESCE(v_patch ->> 'verification_status', '')), '');
  IF v_status IS NOT NULL AND v_status NOT IN ('pending', 'analyzing', 'approved', 'rejected') THEN
    RAISE EXCEPTION 'invalid_verification_status';
  END IF;

  PERFORM set_config('request.jwt.claim.role', 'service_role', true);

  UPDATE public.users u
  SET
    verification_photo_path = CASE
      WHEN v_patch ? 'verification_photo_path' THEN NULLIF(btrim(COALESCE(v_patch ->> 'verification_photo_path', '')), '')
      ELSE u.verification_photo_path
    END,
    verification_status = CASE
      WHEN v_patch ? 'verification_status' THEN v_status
      ELSE u.verification_status
    END,
    verification_submitted_at = CASE
      WHEN v_patch ? 'verification_submitted_at' THEN NULLIF(v_patch ->> 'verification_submitted_at', '')::timestamptz
      ELSE u.verification_submitted_at
    END,
    verification_reviewed_at = CASE
      WHEN v_patch ? 'verification_reviewed_at' THEN NULLIF(v_patch ->> 'verification_reviewed_at', '')::timestamptz
      ELSE u.verification_reviewed_at
    END,
    verification_similarity_score = CASE
      WHEN v_patch ? 'verification_similarity_score' THEN NULLIF(v_patch ->> 'verification_similarity_score', '')::numeric
      ELSE u.verification_similarity_score
    END,
    verification_ai_analysis = CASE
      WHEN v_patch ? 'verification_ai_analysis' THEN COALESCE(v_patch -> 'verification_ai_analysis', 'null'::jsonb)
      ELSE u.verification_ai_analysis
    END,
    verification_auto_rejected = CASE
      WHEN v_patch ? 'verification_auto_rejected' THEN COALESCE((v_patch ->> 'verification_auto_rejected')::boolean, false)
      ELSE u.verification_auto_rejected
    END,
    verification_reference_artifact = CASE
      WHEN v_patch ? 'verification_reference_artifact' THEN COALESCE(v_patch -> 'verification_reference_artifact', 'null'::jsonb)
      ELSE u.verification_reference_artifact
    END,
    verification_reference_generated_at = CASE
      WHEN v_patch ? 'verification_reference_generated_at' THEN NULLIF(v_patch ->> 'verification_reference_generated_at', '')::timestamptz
      ELSE u.verification_reference_generated_at
    END,
    verification_photo_retention_until = CASE
      WHEN v_patch ? 'verification_photo_retention_until' THEN NULLIF(v_patch ->> 'verification_photo_retention_until', '')::timestamptz
      ELSE u.verification_photo_retention_until
    END,
    is_verified = CASE
      WHEN v_patch ? 'is_verified' THEN COALESCE((v_patch ->> 'is_verified')::boolean, false)
      ELSE u.is_verified
    END
  WHERE u.id = p_user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'user_not_found';
  END IF;
END;
$$;


ALTER FUNCTION "public"."edge_update_verification"("p_user_id" "uuid", "p_patch" "jsonb") OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."chat_messages" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "match_id" "uuid",
    "sender_id" "uuid",
    "content_original" "text" NOT NULL,
    "content_translated" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "read_at" timestamp with time zone,
    "edited_at" timestamp with time zone,
    "reaction_summary" "jsonb" DEFAULT '{}'::"jsonb",
    "reply_to_message_id" "uuid",
    "delivered_at" timestamp with time zone,
    "ciphertext" "text",
    "encrypted_key_for_server" "text",
    "encrypted_key_for_recipient" "text",
    "iv" "text",
    "translation_ciphertext" "text",
    "encryption_version" integer DEFAULT 0,
    "detected_source_language" "text",
    "translated_target_language" "text"
);


ALTER TABLE "public"."chat_messages" OWNER TO "postgres";


COMMENT ON TABLE "public"."chat_messages" IS 'Chat messages with optional E2EE. encryption_version: 0=plaintext (legacy), 2=ephemeral key delegation with server translation';



COMMENT ON COLUMN "public"."chat_messages"."ciphertext" IS 'AES-256-GCM encrypted message content';



COMMENT ON COLUMN "public"."chat_messages"."encrypted_key_for_server" IS 'Message key encrypted with server RSA public key (temporary access for translation)';



COMMENT ON COLUMN "public"."chat_messages"."encrypted_key_for_recipient" IS 'Message key encrypted with recipient RSA public key (recipient can decrypt)';



COMMENT ON COLUMN "public"."chat_messages"."translation_ciphertext" IS 'AES encrypted translated message (encrypted with same ephemeral key)';



CREATE OR REPLACE FUNCTION "public"."edit_chat_message"("p_message_id" "uuid", "p_new_content" "text") RETURNS SETOF "public"."chat_messages"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  UPDATE public.chat_messages
  SET content_original = p_new_content,
      edited_at = now()
  WHERE id = p_message_id
    AND sender_id = auth.uid()
  RETURNING *;
$$;


ALTER FUNCTION "public"."edit_chat_message"("p_message_id" "uuid", "p_new_content" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."edit_message"("p_message_id" "uuid", "p_user_id" "uuid", "p_new_content" "text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    message_sender_id UUID;
BEGIN
    -- Get the sender_id of the message to verify ownership
    SELECT sender_id INTO message_sender_id
    FROM chat_messages
    WHERE id = p_message_id;

    -- Check if message exists and belongs to the user
    IF message_sender_id IS NULL THEN
        RAISE EXCEPTION 'Message not found';
    END IF;

    IF message_sender_id != p_user_id THEN
        RAISE EXCEPTION 'You can only edit your own messages';
    END IF;

    -- Update the message
    UPDATE chat_messages
    SET
        content_original = p_new_content,
        edited_at = NOW()
    WHERE id = p_message_id;

    RETURN TRUE;
END;
$$;


ALTER FUNCTION "public"."edit_message"("p_message_id" "uuid", "p_user_id" "uuid", "p_new_content" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."enforce_basic_details_one_time_edit"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_role text;
  v_is_admin boolean;
  v_used_fields text[] := '{}'::text[];
  v_old_fields text[] := '{}'::text[];
BEGIN
  v_role := auth.role();

  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  IF v_role = 'service_role' THEN
    RETURN NEW;
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM public.users u
    WHERE u.id = auth.uid()
      AND u.is_admin = true
  ) INTO v_is_admin;

  IF COALESCE(v_is_admin, false) THEN
    RETURN NEW;
  END IF;

  v_old_fields := COALESCE(OLD.editable_profile_fields, '{}'::text[]);

  -- While a profile is still incomplete, basic details remain editable.
  -- When the user completes their profile, strip any temporary unlocks for
  -- these fields so future edits require an admin-approved unlock.
  IF COALESCE(NEW.is_profile_complete, false)
     AND NOT COALESCE(OLD.is_profile_complete, false) THEN
    SELECT COALESCE(array_agg(f), '{}'::text[])
    INTO NEW.editable_profile_fields
    FROM unnest(v_old_fields) AS t(f)
    WHERE f <> ALL (ARRAY['name', 'gender', 'date_of_birth']);

    IF COALESCE(array_length(NEW.editable_profile_fields, 1), 0) = 0 THEN
      NEW.editable_profile_fields := NULL;
    END IF;
  END IF;

  IF NOT COALESCE(OLD.is_profile_complete, false) THEN
    RETURN NEW;
  END IF;

  IF NEW.name IS DISTINCT FROM OLD.name THEN
    IF NOT ('name' = ANY(v_old_fields)) THEN
      RAISE EXCEPTION 'basic_details_update_not_allowed';
    END IF;
    v_used_fields := v_used_fields || ARRAY['name'];
  END IF;

  IF NEW.gender IS DISTINCT FROM OLD.gender THEN
    IF NOT ('gender' = ANY(v_old_fields)) THEN
      RAISE EXCEPTION 'basic_details_update_not_allowed';
    END IF;
    v_used_fields := v_used_fields || ARRAY['gender'];
  END IF;

  IF NEW.date_of_birth IS DISTINCT FROM OLD.date_of_birth THEN
    IF NOT ('date_of_birth' = ANY(v_old_fields)) THEN
      RAISE EXCEPTION 'basic_details_update_not_allowed';
    END IF;
    v_used_fields := v_used_fields || ARRAY['date_of_birth'];
  END IF;

  IF COALESCE(array_length(v_used_fields, 1), 0) > 0 THEN
    SELECT COALESCE(array_agg(f), '{}'::text[])
    INTO NEW.editable_profile_fields
    FROM unnest(v_old_fields) AS t(f)
    WHERE NOT (f = ANY(v_used_fields));

    IF COALESCE(array_length(NEW.editable_profile_fields, 1), 0) = 0 THEN
      NEW.editable_profile_fields := NULL;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."enforce_basic_details_one_time_edit"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."enforce_unique_profile_bio"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  v_old_normalized text;
  v_new_normalized text;
BEGIN
  v_new_normalized := public.normalize_profile_bio_text(NEW.bio);

  IF TG_OP = 'UPDATE' THEN
    v_old_normalized := public.normalize_profile_bio_text(OLD.bio);
    IF v_new_normalized IS NOT DISTINCT FROM v_old_normalized THEN
      RETURN NEW;
    END IF;
  END IF;

  IF v_new_normalized IS NULL THEN
    RETURN NEW;
  END IF;

  IF NOT public.check_profile_bio_uniqueness(NEW.id, NEW.bio) THEN
    RAISE EXCEPTION 'bio_already_in_use'
      USING ERRCODE = 'P0001',
            DETAIL = 'This bio is already being used by another profile.';
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."enforce_unique_profile_bio"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."enqueue_profile_edit_request_review_fcm"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_allowed boolean;
  v_locale text;
  v_fields text[];
  v_title_key text;
  v_body_key text;
  v_title text;
  v_body_template text;
  v_body text;
  v_note text;
  v_note_line_template text;
  v_note_line text;
  v_token text;
  v_platform text;
  v_field text;
  v_label_key text;
  v_label text;
  v_labels text[] := '{}'::text[];
  v_fields_text text := '';
BEGIN
  IF TG_OP <> 'UPDATE' THEN
    RETURN NEW;
  END IF;

  IF NEW.status IS NULL OR OLD.status IS NULL OR NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;

  IF NEW.status NOT IN ('approved', 'rejected') THEN
    RETURN NEW;
  END IF;

  v_fields := ARRAY(
    SELECT f
    FROM unnest(COALESCE(NEW.requested_fields, '{}'::text[])) AS t(f)
    WHERE f IN ('name', 'gender', 'date_of_birth')
  );

  IF COALESCE(array_length(v_fields, 1), 0) = 0 THEN
    RETURN NEW;
  END IF;

  SELECT (
    COALESCE((u.notification_preferences->'global_methods'->>'push')::boolean, true) = true
    AND COALESCE(
      (u.notification_preferences->'matrix'->'admin_announcements'->>'push')::boolean,
      (u.notification_preferences->>'enable_admin_notifications')::boolean,
      true
    ) = true
  )
  , lower(btrim(COALESCE(u.preferred_language, 'en')))
  INTO v_allowed, v_locale
  FROM public.users u
  WHERE u.id = NEW.user_id;

  IF NOT COALESCE(v_allowed, false) THEN
    RETURN NEW;
  END IF;

  IF v_locale NOT IN ('en', 'es', 'he') THEN
    v_locale := 'en';
  END IF;

  FOREACH v_field IN ARRAY v_fields
  LOOP
    v_label_key := CASE v_field
      WHEN 'name' THEN 'profileEditFieldLabelName'
      WHEN 'gender' THEN 'profileEditFieldLabelGender'
      WHEN 'date_of_birth' THEN 'profileEditFieldLabelDateOfBirth'
      ELSE NULL
    END;

    v_label := NULL;
    IF v_label_key IS NOT NULL THEN
      SELECT t.value INTO v_label
      FROM public.translations t
      WHERE t.locale = v_locale
        AND t.key = v_label_key;

      IF v_label IS NULL THEN
        SELECT t.value INTO v_label
        FROM public.translations t
        WHERE t.locale = 'en'
          AND t.key = v_label_key;
      END IF;
    END IF;

    IF v_label IS NULL THEN
      v_label := v_field;
    END IF;

    v_labels := array_append(v_labels, v_label);
  END LOOP;

  v_fields_text := array_to_string(v_labels, ', ');

  v_title_key := CASE
    WHEN NEW.status = 'approved' THEN 'profileEditRequestApprovedNotifTitle'
    ELSE 'profileEditRequestRejectedNotifTitle'
  END;

  v_body_key := CASE
    WHEN NEW.status = 'approved' THEN 'profileEditRequestApprovedNotifBody'
    ELSE 'profileEditRequestRejectedNotifBody'
  END;

  SELECT t.value
  INTO v_title
  FROM public.translations t
  WHERE t.locale = v_locale
    AND t.key = v_title_key;

  IF v_title IS NULL THEN
    SELECT t.value
    INTO v_title
    FROM public.translations t
    WHERE t.locale = 'en'
      AND t.key = v_title_key;
  END IF;

  SELECT t.value
  INTO v_body_template
  FROM public.translations t
  WHERE t.locale = v_locale
    AND t.key = v_body_key;

  IF v_body_template IS NULL THEN
    SELECT t.value
    INTO v_body_template
    FROM public.translations t
    WHERE t.locale = 'en'
      AND t.key = v_body_key;
  END IF;

  IF v_title IS NULL THEN
    v_title := CASE
      WHEN NEW.status = 'approved' THEN 'Profile edit request approved'
      ELSE 'Profile edit request rejected'
    END;
  END IF;

  IF v_body_template IS NULL THEN
    v_body_template := CASE
      WHEN NEW.status = 'approved' THEN 'An admin approved your profile edit request for {fields}.'
      ELSE 'An admin rejected your profile edit request for {fields}.'
    END;
  END IF;

  v_body := replace(v_body_template, '{fields}', v_fields_text);

  v_note := NULLIF(btrim(COALESCE(NEW.reviewer_note, '')), '');
  IF v_note IS NOT NULL THEN
    SELECT t.value
    INTO v_note_line_template
    FROM public.translations t
    WHERE t.locale = v_locale
      AND t.key = 'profileEditRequestReviewerNoteLine';

    IF v_note_line_template IS NULL THEN
      SELECT t.value
      INTO v_note_line_template
      FROM public.translations t
      WHERE t.locale = 'en'
        AND t.key = 'profileEditRequestReviewerNoteLine';
    END IF;

    IF v_note_line_template IS NULL THEN
      v_note_line_template := 'Admin note: {note}';
    END IF;

    v_note_line := replace(v_note_line_template, '{note}', v_note);
    v_body := v_body || ' ' || v_note_line;
  END IF;

  FOR v_token, v_platform IN
    SELECT DISTINCT ON (NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), ''))
      NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), '') AS fcm_token,
      us.platform
    FROM public.user_session us
    WHERE us.user_id = NEW.user_id
      AND us.revoked = false
      AND NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), '') IS NOT NULL
    ORDER BY NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), ''), us.last_active_at DESC NULLS LAST
  LOOP
    INSERT INTO public.notification_queue (
      user_id,
      fcm_token,
      title,
      body,
      data,
      platform
    )
    VALUES (
      NEW.user_id,
      v_token,
      v_title,
      v_body,
      jsonb_build_object(
        'type', 'profile_edit_review',
        'request_id', NEW.id::text,
        'decision', NEW.status,
        'fields', v_fields,
        'reviewer_note', v_note
      ),
      COALESCE(NULLIF(btrim(v_platform), ''), 'unknown')
    );
  END LOOP;

  RETURN NEW;
EXCEPTION WHEN others THEN
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."enqueue_profile_edit_request_review_fcm"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."extract_source_language_from_edge_response"("p_response" "jsonb") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
BEGIN
  IF p_response IS NULL THEN
    RETURN NULL;
  END IF;
  
  IF p_response ? 'detectedSourceLanguage' THEN
    RETURN p_response ->> 'detectedSourceLanguage';
  ELSIF p_response ? 'source_language' THEN
    RETURN p_response ->> 'source_language';
  ELSIF p_response ? 'translations' AND jsonb_typeof(p_response -> 'translations') = 'array' THEN
    RETURN p_response -> 'translations' -> 0 ->> 'detected_source_language';
  ELSE
    RETURN NULL;
  END IF;
END;
$$;


ALTER FUNCTION "public"."extract_source_language_from_edge_response"("p_response" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."extract_translation_from_edge_response"("p_response" "jsonb") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
BEGIN
  IF p_response IS NULL THEN
    RETURN NULL;
  END IF;
  
  IF p_response ? 'translatedText' THEN
    RETURN p_response ->> 'translatedText';
  ELSIF p_response ? 'text' THEN
    RETURN p_response ->> 'text';
  ELSIF p_response ? 'translations' AND jsonb_typeof(p_response -> 'translations') = 'array' THEN
    RETURN p_response -> 'translations' -> 0 ->> 'text';
  ELSE
    RETURN NULL;
  END IF;
END;
$$;


ALTER FUNCTION "public"."extract_translation_from_edge_response"("p_response" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."find_nearby_users"("current_user_id" "uuid", "current_lat" double precision, "current_lng" double precision, "radius_km" double precision) RETURNS TABLE("user_id" "uuid", "latitude" double precision, "longitude" double precision, "distance_km" double precision, "updated_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  earth_km CONSTANT DOUBLE PRECISION := 6371.0;
BEGIN
  RETURN QUERY
  SELECT
    ul.user_id,
    ul.latitude,
    ul.longitude,
    (earth_km * acos(
      cos(radians(current_lat)) * cos(radians(ul.latitude)) * cos(radians(ul.longitude) - radians(current_lng))
      + sin(radians(current_lat)) * sin(radians(ul.latitude))
    ))::DOUBLE PRECISION AS distance_km,
    ul.updated_at
  FROM public.user_locations ul
  JOIN public.users u ON u.id = ul.user_id
  WHERE ul.user_id IS NOT NULL
    AND ul.user_id <> current_user_id
    AND COALESCE(u.user_visibility_setting, FALSE) = TRUE
    AND COALESCE(u.system_visibility_status, 'visible') = 'visible'
    AND EXISTS (SELECT 1 FROM user_activity ua WHERE ua.user_id = u.id AND ua.is_online = TRUE)
    AND (earth_km * acos(
      cos(radians(current_lat)) * cos(radians(ul.latitude)) * cos(radians(ul.longitude) - radians(current_lng))
      + sin(radians(current_lat)) * sin(radians(ul.latitude))
    )) <= radius_km
  ORDER BY distance_km ASC;
END;
$$;


ALTER FUNCTION "public"."find_nearby_users"("current_user_id" "uuid", "current_lat" double precision, "current_lng" double precision, "radius_km" double precision) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."find_shared_events"("user1_id" "uuid", "user2_id" "uuid") RETURNS TABLE("event_id" "uuid", "event_name" "text", "start_time" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    SET search_path = 'public';
    RETURN QUERY
    SELECT
        e.id,
        e.event_name,
        e.start_time
    FROM events e
    WHERE EXISTS (
        SELECT 1 FROM event_attendees ea1
        WHERE ea1.event_id = e.id AND ea1.user_id = user1_id
    )
    AND EXISTS (
        SELECT 1 FROM event_attendees ea2
        WHERE ea2.event_id = e.id AND ea2.user_id = user2_id
    )
    ORDER BY e.start_time DESC
    LIMIT 1; -- Return the most recent shared event
END;
$$;


ALTER FUNCTION "public"."find_shared_events"("user1_id" "uuid", "user2_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."generate_email_change_code"("p_user_id" "uuid", "p_new_email" "text") RETURNS TABLE("code" "text", "expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_code text;
  v_expires_at timestamp with time zone;
BEGIN
  -- Generate 6-digit code
  v_code := LPAD((random() * 999999)::integer::text, 6, '0');
  v_expires_at := now() + interval '15 minutes';

  -- Insert the pending email change
  INSERT INTO public.pending_email_changes (user_id, new_email, verification_code, expires_at)
  VALUES (p_user_id, p_new_email, v_code, v_expires_at)
  ON CONFLICT DO NOTHING;

  RETURN QUERY SELECT v_code, v_expires_at;
END;
$$;


ALTER FUNCTION "public"."generate_email_change_code"("p_user_id" "uuid", "p_new_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."generate_mfa_recovery_codes"("p_replace_existing" boolean DEFAULT true) RETURNS TABLE("code" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_raw_code text;
  v_normalized_code text;
  v_code_hash text;
  v_inserted_count integer := 0;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF COALESCE(p_replace_existing, true) THEN
    DELETE FROM public.user_mfa_recovery_codes
    WHERE user_id = v_user_id;
  END IF;

  WHILE v_inserted_count < 10 LOOP
    v_raw_code := upper(encode(extensions.gen_random_bytes(8), 'hex'));
    v_normalized_code := public._normalize_mfa_recovery_code(v_raw_code);
    v_code_hash := public._hash_mfa_recovery_code(v_user_id, v_normalized_code);

    BEGIN
      INSERT INTO public.user_mfa_recovery_codes (
        user_id,
        code_hash
      )
      VALUES (
        v_user_id,
        v_code_hash
      );

      code := public._format_mfa_recovery_code(v_normalized_code);
      v_inserted_count := v_inserted_count + 1;
      RETURN NEXT;
    EXCEPTION
      WHEN unique_violation THEN
        CONTINUE;
    END;
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."generate_mfa_recovery_codes"("p_replace_existing" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."generate_sensitive_action_email_code"("p_user_id" "uuid", "p_email" "text") RETURNS TABLE("code" "text", "expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_code text;
  v_expires_at timestamp with time zone;
BEGIN
  -- Generate a random 6-digit code
  v_code := LPAD((random() * 999999)::int::text, 6, '0');
  v_expires_at := now() + interval '10 minutes';
  
  -- Insert the code with encryption using MATCHME_INTERNAL_SECRET
  INSERT INTO public.sensitive_action_email_codes (user_id, email, encrypted_code, expires_at)
  VALUES (
    p_user_id, 
    p_email, 
    pgp_sym_encrypt(v_code, 'MATCHME_INTERNAL_SECRET'),
    v_expires_at
  );
  
  RETURN QUERY SELECT v_code, v_expires_at;
END;
$$;


ALTER FUNCTION "public"."generate_sensitive_action_email_code"("p_user_id" "uuid", "p_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_active_sensitive_action_email_code"("p_user_id" "uuid", "p_email" "text") RETURNS TABLE("code" "text", "created_at" timestamp with time zone, "expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  -- Find the most recent unused code for this user and email that hasn't expired
  RETURN QUERY
  SELECT 
    pgp_sym_decrypt(encrypted_code, 'MATCHME_INTERNAL_SECRET')::text as code,
    sensitive_action_email_codes.created_at,
    sensitive_action_email_codes.expires_at
  FROM public.sensitive_action_email_codes
  WHERE sensitive_action_email_codes.user_id = p_user_id 
    AND sensitive_action_email_codes.email = LOWER(p_email)
    AND sensitive_action_email_codes.used_at IS NULL
    AND sensitive_action_email_codes.expires_at > now()
  ORDER BY sensitive_action_email_codes.created_at DESC
  LIMIT 1;
END;
$$;


ALTER FUNCTION "public"."get_active_sensitive_action_email_code"("p_user_id" "uuid", "p_email" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_ad_network_analytics"("p_network_id" "uuid", "p_start_date" "date", "p_end_date" "date") RETURNS TABLE("date" "date", "placement" "text", "platform" "text", "impressions" integer, "clicks" integer, "conversions" integer, "revenue_usd" numeric)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.users
    WHERE id = auth.uid() AND is_admin = true
  ) THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT
    DATE(e.created_at) AS date,
    e.placement,
    e.platform,
    COUNT(CASE WHEN e.event_type = 'impression' THEN 1 END)::integer AS impressions,
    COALESCE(SUM(e.click_count), 0)::integer AS clicks,
    COUNT(CASE WHEN e.event_type = 'conversion' THEN 1 END)::integer AS conversions,
    COALESCE(SUM(e.revenue_usd), 0)::numeric AS revenue_usd
  FROM public.ad_revenue_events e
  WHERE e.network_id = p_network_id
    AND DATE(e.created_at) >= p_start_date
    AND DATE(e.created_at) <= p_end_date
  GROUP BY DATE(e.created_at), e.placement, e.platform
  ORDER BY DATE(e.created_at) DESC;
END;
$$;


ALTER FUNCTION "public"."get_ad_network_analytics"("p_network_id" "uuid", "p_start_date" "date", "p_end_date" "date") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_app_config_text"("p_key" "text") RETURNS "text"
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  v_has_new boolean;
  v_has_old boolean;
  v_config_value_type text;
  v_out text;
BEGIN
  IF p_key IS NULL OR btrim(p_key) = '' THEN
    RETURN NULL;
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns c
    WHERE c.table_schema = 'public'
      AND c.table_name = 'app_config'
      AND c.column_name = 'config_key'
  ) AND EXISTS (
    SELECT 1
    FROM information_schema.columns c
    WHERE c.table_schema = 'public'
      AND c.table_name = 'app_config'
      AND c.column_name = 'config_value'
  )
  INTO v_has_new;

  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns c
    WHERE c.table_schema = 'public'
      AND c.table_name = 'app_config'
      AND c.column_name = 'key'
  ) AND EXISTS (
    SELECT 1
    FROM information_schema.columns c
    WHERE c.table_schema = 'public'
      AND c.table_name = 'app_config'
      AND c.column_name = 'value'
  )
  INTO v_has_old;

  IF v_has_new THEN
    SELECT c.data_type
    INTO v_config_value_type
    FROM information_schema.columns c
    WHERE c.table_schema = 'public'
      AND c.table_name = 'app_config'
      AND c.column_name = 'config_value'
    LIMIT 1;

    IF v_config_value_type IN ('json', 'jsonb') THEN
      EXECUTE
        'SELECT (config_value #>> ''{}'') FROM public.app_config WHERE config_key = $1 LIMIT 1'
      INTO v_out
      USING p_key;
    ELSE
      EXECUTE
        'SELECT config_value::text FROM public.app_config WHERE config_key = $1 LIMIT 1'
      INTO v_out
      USING p_key;
    END IF;

    RETURN NULLIF(btrim(v_out), '');
  END IF;

  IF v_has_old THEN
    EXECUTE
      'SELECT value::text FROM public.app_config WHERE key = $1 LIMIT 1'
    INTO v_out
    USING p_key;
    RETURN NULLIF(btrim(v_out), '');
  END IF;

  RETURN NULL;
END;
$_$;


ALTER FUNCTION "public"."get_app_config_text"("p_key" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_broadcast_stats"("p_broadcast_id" "uuid") RETURNS TABLE("total_target" integer, "sent_count" integer, "delivered_count" integer, "failed_count" integer, "delivery_rate" numeric)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
    IF auth.uid() IS NULL OR NOT EXISTS (
        SELECT 1
        FROM public.users u
        WHERE u.id = auth.uid()
          AND u.is_admin = true
    ) THEN
        RAISE EXCEPTION 'Admin access required'
            USING ERRCODE = '42501';
    END IF;

    RETURN QUERY
    SELECT
        COUNT(*)::integer AS total_target,
        COUNT(*) FILTER (WHERE abd.delivery_status = 'sent')::integer AS sent_count,
        COUNT(*) FILTER (WHERE abd.delivery_status = 'delivered')::integer AS delivered_count,
        COUNT(*) FILTER (WHERE abd.delivery_status = 'failed')::integer AS failed_count,
        ROUND(
            (
                COUNT(*) FILTER (WHERE abd.delivery_status = 'delivered')::numeric /
                NULLIF(COUNT(*), 0) * 100
            ),
            2
        ) AS delivery_rate
    FROM public.admin_broadcast_deliveries abd
    WHERE abd.broadcast_id = p_broadcast_id;
END;
$$;


ALTER FUNCTION "public"."get_broadcast_stats"("p_broadcast_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_current_timestamp"() RETURNS timestamp with time zone
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
    SELECT now();
$$;


ALTER FUNCTION "public"."get_current_timestamp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_due_match_rating_prompts"("p_user_id" "uuid", "p_initial_delay_seconds" integer, "p_limit" integer DEFAULT 1) RETURNS TABLE("match_id" "uuid", "other_user_id" "uuid", "other_name" "text", "match_created_at" timestamp with time zone, "other_user_met_confirmed" boolean, "self_met_confirmed" boolean, "next_prompt_at" timestamp with time zone)
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
WITH user_matches AS (
  SELECT m.id AS match_id,
         m.created_at AS created_at,
         CASE WHEN m.user1_id = p_user_id THEN m.user2_id ELSE m.user1_id END AS other_user_id
  FROM public.matches m
  WHERE (m.user1_id = p_user_id OR m.user2_id = p_user_id)
),
due_missing_rows AS (
  SELECT um.match_id, p_user_id AS user_id,
         (um.created_at + make_interval(secs => p_initial_delay_seconds)) AS next_prompt_at
  FROM user_matches um
  LEFT JOIN public.match_rating_prompts mrp
    ON mrp.match_id = um.match_id AND mrp.user_id = p_user_id
  WHERE mrp.match_id IS NULL
    AND (um.created_at + make_interval(secs => p_initial_delay_seconds)) <= now()
),
inserted AS (
  INSERT INTO public.match_rating_prompts (match_id, user_id, next_prompt_at)
  SELECT match_id, user_id, next_prompt_at
  FROM due_missing_rows
  ON CONFLICT (match_id, user_id) DO NOTHING
  RETURNING match_id
),
due_prompts AS (
  SELECT mrp.match_id,
         mrp.user_id,
         mrp.next_prompt_at,
         mrp.met_confirmed AS self_met_confirmed
  FROM public.match_rating_prompts mrp
  WHERE mrp.user_id = p_user_id
    AND mrp.rating_submitted_at IS NULL
    AND mrp.next_prompt_at IS NOT NULL
    AND mrp.next_prompt_at <= now()
)
SELECT dp.match_id,
       um.other_user_id,
       public.mask_full_name(u.name) AS other_name,
       um.created_at AS match_created_at,
       COALESCE(otherp.met_confirmed, false) AS other_user_met_confirmed,
       dp.self_met_confirmed,
       dp.next_prompt_at
FROM due_prompts dp
JOIN user_matches um ON um.match_id = dp.match_id
LEFT JOIN public.users u ON u.id = um.other_user_id
LEFT JOIN public.match_rating_prompts otherp
  ON otherp.match_id = dp.match_id AND otherp.user_id = um.other_user_id
ORDER BY dp.next_prompt_at ASC
LIMIT p_limit;
$$;


ALTER FUNCTION "public"."get_due_match_rating_prompts"("p_user_id" "uuid", "p_initial_delay_seconds" integer, "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_external_ad_for_placement"("p_placement" "text", "p_platform" "text") RETURNS TABLE("ad_unit_id" "uuid", "network_id" "uuid", "placement" "text", "platform" "text", "ad_format" "text", "external_ad_unit_id" "text", "is_active" boolean, "priority" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_platform text := lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web'));
  v_user_tier text;
  v_allowed_placements jsonb;
  v_allowed_tiers jsonb;
  v_allowed_platforms jsonb;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  -- Check if external ads are enabled
  IF NOT public.app_config_bool('ads.external.enabled', false) THEN
    RETURN;
  END IF;

  -- Get user's subscription tier
  SELECT COALESCE(NULLIF(btrim(subscription_tier), ''), 'free')
  INTO v_user_tier
  FROM public.users
  WHERE id = v_user_id;

  -- Get allowed placements, tiers, and platforms from config
  v_allowed_placements := public.app_config_jsonb('ads.external.allowed_placements', '["home_inline", "matches_inline", "chats_inline", "events_inline", "profile_inline"]'::jsonb);
  v_allowed_tiers := public.app_config_jsonb('ads.external.allowed_tiers', '["free"]'::jsonb);
  v_allowed_platforms := public.app_config_jsonb('ads.external.allowed_platforms', '["android", "ios", "web"]'::jsonb);

  -- Check if placement is allowed
  IF NOT (v_allowed_placements @> to_jsonb(p_placement)) THEN
    RETURN;
  END IF;

  -- Check if user tier is allowed
  IF NOT (v_allowed_tiers @> to_jsonb(v_user_tier)) THEN
    RETURN;
  END IF;

  -- Check if platform is allowed
  IF NOT (v_allowed_platforms @> to_jsonb(v_platform)) THEN
    RETURN;
  END IF;

  -- Return ad unit with the REQUESTED platform
  RETURN QUERY
  SELECT
    au.id as ad_unit_id,
    au.network_id,
    au.placement,
    v_platform as platform,
    au.ad_format,
    au.ad_unit_id as external_ad_unit_id,
    au.is_active,
    au.priority
  FROM public.ad_networks an
  INNER JOIN public.ad_units au ON au.network_id = an.id
  WHERE an.is_enabled = true
    AND au.is_active = true
    AND au.placement = p_placement
    AND au.platform IN ('web', v_platform)
  ORDER BY
    CASE WHEN au.platform = v_platform THEN 0 ELSE 1 END,
    an.priority ASC,
    au.priority ASC
  LIMIT 1;
END;
$$;


ALTER FUNCTION "public"."get_external_ad_for_placement"("p_placement" "text", "p_platform" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_message_details"("p_message_id" "uuid") RETURNS TABLE("sender_name" "text", "content" "text", "sender_id" "uuid", "match_id" "uuid")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    SET search_path = 'public';
    
    RETURN QUERY
    SELECT 
        public.mask_full_name(up.profile_data->>'fullName') as sender_name,
        COALESCE(cm.content_translated, cm.content_original) as content,
        cm.sender_id,
        cm.match_id
    FROM chat_messages cm
    JOIN user_profiles up ON up.user_id = cm.sender_id
    WHERE cm.id = p_message_id;
END;
$$;


ALTER FUNCTION "public"."get_message_details"("p_message_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_message_reactors"("message_id" "uuid", "reaction" "text") RETURNS TABLE("user_id" "uuid", "display_name" "text", "photo" "text")
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $_$
  SELECT
    mr.user_id::uuid AS user_id,
    public.mask_full_name(u.name) AS display_name,
    u.photos[1] AS photo
  FROM public.message_reactions mr
  LEFT JOIN public.users u ON u.id = mr.user_id
  WHERE mr.message_id = $1 AND mr.reaction = $2;
$_$;


ALTER FUNCTION "public"."get_message_reactors"("message_id" "uuid", "reaction" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_mfa_recovery_code_status"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_available_count integer;
  v_last_generated_at timestamptz;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  SELECT COUNT(*)::integer, MAX(created_at)
  INTO v_available_count, v_last_generated_at
  FROM public.user_mfa_recovery_codes
  WHERE user_id = v_user_id
    AND used_at IS NULL;

  RETURN jsonb_build_object(
    'available_count', COALESCE(v_available_count, 0),
    'has_codes', COALESCE(v_available_count, 0) > 0,
    'last_generated_at', v_last_generated_at
  );
END;
$$;


ALTER FUNCTION "public"."get_mfa_recovery_code_status"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_nearby_users_count"("p_user_id" "uuid", "p_radius_km" integer DEFAULT 50) RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    nearby_count INTEGER;
    user_lat DOUBLE PRECISION;
    user_lon DOUBLE PRECISION;
BEGIN
    -- Get current user's location
    SELECT latitude, longitude
    INTO user_lat, user_lon
    FROM user_locations
    WHERE user_id = p_user_id
    ORDER BY updated_at DESC
    LIMIT 1;

    -- If user has no location, return 0
    IF user_lat IS NULL OR user_lon IS NULL THEN
        RETURN 0;
    END IF;

    -- Count nearby users who are both online and visible
    SELECT COUNT(DISTINCT ul.user_id)
    INTO nearby_count
    FROM user_locations ul
    JOIN user_activity ua ON ul.user_id = ua.user_id
    JOIN users u ON ul.user_id = u.id
    WHERE ul.user_id != p_user_id
    AND ua.is_online = true
    AND ua.last_activity > NOW() - INTERVAL '10 seconds'
    AND COALESCE(u.user_visibility_setting, false) = true
    AND COALESCE(u.system_visibility_status, 'visible') = 'visible'
    -- Simple bounding box filter for performance
    AND ul.latitude BETWEEN user_lat - (p_radius_km / 111.0) AND user_lat + (p_radius_km / 111.0)
    AND ul.longitude BETWEEN user_lon - (p_radius_km / (111.0 * COS(RADIANS(user_lat)))) 
                         AND user_lon + (p_radius_km / (111.0 * COS(RADIANS(user_lat))))
    AND ul.updated_at > NOW() - INTERVAL '24 hours'; -- Only consider recent locations

    RETURN COALESCE(nearby_count, 0);
END;
$$;


ALTER FUNCTION "public"."get_nearby_users_count"("p_user_id" "uuid", "p_radius_km" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_next_queued_subscription"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("queue_id" "uuid", "tier" character varying, "starts_at" timestamp with time zone, "expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
BEGIN
  v_user_id := COALESCE(p_user_id, auth.uid());

  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  IF v_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  RETURN QUERY
  SELECT sq.id, sq.tier, sq.starts_at, sq.expires_at
  FROM public.user_subscription_queue sq
  WHERE sq.user_id = v_user_id
    AND sq.status = 'pending'
    AND sq.starts_at > now()
  ORDER BY sq.starts_at ASC
  LIMIT 1;
END;
$$;


ALTER FUNCTION "public"."get_next_queued_subscription"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_online_user_counts_by_country"("p_recent_seconds" integer DEFAULT 30) RETURNS TABLE("country" "text", "user_count" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_seconds integer;
BEGIN
  IF auth.uid() IS NULL AND auth.role() <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  v_seconds := GREATEST(LEAST(COALESCE(p_recent_seconds, 30), 3600), 5);

  RETURN QUERY
  WITH online AS (
    SELECT DISTINCT ua.user_id
    FROM public.user_activity ua
    WHERE ua.is_online = true
      AND ua.last_activity > NOW() - make_interval(secs => v_seconds)
  ),
  latest_session AS (
    SELECT DISTINCT ON (us.user_id)
      us.user_id,
      NULLIF(btrim(COALESCE(us.country, '')), '') AS country
    FROM public.user_session us
    WHERE us.revoked = false
    ORDER BY
      us.user_id,
      us.last_active_at DESC NULLS LAST,
      us.created_at DESC NULLS LAST,
      us.id DESC
  )
  SELECT
    ls.country AS country,
    COUNT(*)::integer AS user_count
  FROM online o
  LEFT JOIN latest_session ls ON ls.user_id = o.user_id
  WHERE ls.country IS NOT NULL
  GROUP BY ls.country
  ORDER BY user_count DESC, ls.country ASC;
END;
$$;


ALTER FUNCTION "public"."get_online_user_counts_by_country"("p_recent_seconds" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_online_users_count"("p_user_id" "uuid") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  online_count integer;
BEGIN
  SELECT COUNT(*)
  INTO online_count
  FROM public.user_activity ua
  WHERE ua.is_online = true
    AND ua.last_activity > NOW() - INTERVAL '2 minutes';

  RETURN COALESCE(online_count, 0);
END;
$$;


ALTER FUNCTION "public"."get_online_users_count"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_online_users_count_excluding_self"("p_user_id" "uuid") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  online_count integer;
BEGIN
  SELECT COUNT(*)
  INTO online_count
  FROM public.user_activity ua
  INNER JOIN public.users u ON ua.user_id = u.id
  WHERE ua.is_online = true
    AND ua.last_activity > NOW() - INTERVAL '2 minutes'
    AND ua.user_id != p_user_id
    AND COALESCE(u.user_visibility_setting, false) = true
    AND COALESCE(u.system_visibility_status, 'visible') = 'visible';

  RETURN COALESCE(online_count, 0);
END;
$$;


ALTER FUNCTION "public"."get_online_users_count_excluding_self"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_potential_event_matches"("p_event_id" "uuid", "p_user_id" "uuid") RETURNS TABLE("suggested_user_id" "uuid", "suggested_user_name" "text", "shared_intents" "text"[])
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    current_user_data RECORD;
    current_user_interests JSONB;
    other_attendee RECORD;
    other_user_data RECORD;
    other_user_interests JSONB;
    shared_intents_list TEXT[];
    has_shared_interest BOOLEAN := FALSE;
    shared_interest_category TEXT;
    existing_match_count INTEGER;
BEGIN
    SET search_path = 'public';

    SELECT active_modes, user_visibility_setting, shared_event_matching_enabled
    INTO current_user_data
    FROM users
    WHERE id = p_user_id;

    IF current_user_data IS NULL OR NOT current_user_data.shared_event_matching_enabled THEN
        RETURN;
    END IF;

    SELECT COALESCE(jsonb_object_agg(category, interests), '{}'::jsonb)
    INTO current_user_interests
    FROM (
        SELECT
            jsonb_object_keys(profile_data->'interests') as category,
            profile_data->'interests'->jsonb_object_keys(profile_data->'interests') as interests
        FROM user_profiles
        WHERE user_id = p_user_id
        AND profile_data ? 'interests'
    ) interests_data;

    FOR other_attendee IN
        SELECT DISTINCT ea.user_id, public.mask_full_name(up.profile_data->>'fullName') as user_name
        FROM event_attendees ea
        LEFT JOIN user_profiles up ON ea.user_id = up.user_id
        WHERE ea.event_id = p_event_id
        AND ea.user_id != p_user_id
    LOOP
        SELECT active_modes, user_visibility_setting, shared_event_matching_enabled
        INTO other_user_data
        FROM users
        WHERE id = other_attendee.user_id;

        IF other_user_data IS NULL OR NOT other_user_data.shared_event_matching_enabled THEN
            CONTINUE;
        END IF;

        SELECT ARRAY(
            SELECT intent
            FROM unnest(current_user_data.active_modes) AS t(intent)
            WHERE intent = ANY(other_user_data.active_modes)
        ) INTO shared_intents_list;

        IF shared_intents_list IS NULL OR array_length(shared_intents_list, 1) IS NULL THEN
            CONTINUE;
        END IF;

        SELECT COALESCE(jsonb_object_agg(category, interests), '{}'::jsonb)
        INTO other_user_interests
        FROM (
            SELECT
                jsonb_object_keys(profile_data->'interests') as category,
                profile_data->'interests'->jsonb_object_keys(profile_data->'interests') as interests
            FROM user_profiles
            WHERE user_id = other_attendee.user_id
            AND profile_data ? 'interests'
        ) interests_data;

        has_shared_interest := FALSE;
        FOR shared_interest_category IN
            SELECT jsonb_object_keys(current_user_interests)
        LOOP
            IF current_user_interests ? shared_interest_category AND other_user_interests ? shared_interest_category THEN
                IF EXISTS (
                    SELECT 1
                    FROM jsonb_array_elements_text(current_user_interests->shared_interest_category) as current_user_interest
                    WHERE current_user_interest = ANY(
                        SELECT jsonb_array_elements_text(other_user_interests->shared_interest_category)
                    )
                ) THEN
                    has_shared_interest := TRUE;
                    EXIT;
                END IF;
            END IF;
        END LOOP;

        IF NOT has_shared_interest THEN
            CONTINUE;
        END IF;

        SELECT COUNT(*) INTO existing_match_count
        FROM matches
        WHERE (user1_id = p_user_id AND user2_id = other_attendee.user_id)
           OR (user1_id = other_attendee.user_id AND user2_id = p_user_id);

        IF existing_match_count > 0 THEN
            CONTINUE;
        END IF;

        RETURN QUERY SELECT
            other_attendee.user_id,
            COALESCE(other_attendee.user_name, 'Unknown User'),
            shared_intents_list;
    END LOOP;

    RETURN;
END;
$$;


ALTER FUNCTION "public"."get_potential_event_matches"("p_event_id" "uuid", "p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_promo_code_details"("p_code" "text") RETURNS TABLE("code" "text", "description" "text", "code_type" "text", "amount" integer, "upgrade_tier" "text", "campaign_name" "text", "valid_until" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  RETURN QUERY
  SELECT
    pc.code,
    pc.description,
    pc.code_type,
    pc.amount,
    pc.upgrade_tier,
    pc.campaign_name,
    pc.valid_until
  FROM public.promo_codes AS pc
  WHERE UPPER(pc.code) = UPPER(TRIM(p_code))
    AND pc.is_active = true
    AND pc.valid_from <= now()
    AND pc.valid_until > now();
END;
$$;


ALTER FUNCTION "public"."get_promo_code_details"("p_code" "text") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."get_promo_code_details"("p_code" "text") IS 'Returns details about a specific promo code';



CREATE OR REPLACE FUNCTION "public"."get_recent_chats"("p_user_id" "uuid") RETURNS TABLE("match_id" "uuid", "other_user_id" "uuid", "other_user_name" "text", "last_message_content" "text", "last_message_id" "uuid", "last_message_at" timestamp with time zone, "unread_count" integer, "match_created_at" timestamp with time zone, "event_id" "uuid", "event_name" "text", "event_link" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    SET search_path = 'public';
    RETURN QUERY
    SELECT DISTINCT
        m.id AS match_id,
        CASE
            WHEN m.user1_id = p_user_id THEN m.user2_id
            ELSE m.user1_id
        END AS other_user_id,
        -- Use DB function to mask names so last names are never returned
        public.mask_full_name(up.profile_data->>'fullName') AS other_user_name,
        COALESCE(cm.content_translated, cm.content_original) AS last_message_content,
        cm.id AS last_message_id,
        cm.created_at AS last_message_at,
        -- Count messages from the other user that are unread (read_at IS NULL)
        (SELECT COUNT(*)::integer
         FROM chat_messages cm_unread
         WHERE cm_unread.match_id = m.id
         AND cm_unread.sender_id != p_user_id
         AND cm_unread.read_at IS NULL) AS unread_count,
        m.created_at AS match_created_at,
        m.event_id,
        e.event_name,
        e.event_link
    FROM matches m
    -- Join with user_profiles to get the other user's name
    LEFT JOIN user_profiles up ON up.user_id = CASE
        WHEN m.user1_id = p_user_id THEN m.user2_id
        ELSE m.user1_id
    END
    -- Join with events to get event details
    LEFT JOIN events e ON e.id = m.event_id
    -- Join with chat_messages to get the last message
    INNER JOIN chat_messages cm ON cm.match_id = m.id
    -- Ensure we only include matches that have messages
    WHERE (m.user1_id = p_user_id OR m.user2_id = p_user_id)
    -- Get only the most recent message per match
    AND cm.id = (
        SELECT cm_sub.id
        FROM chat_messages cm_sub
        WHERE cm_sub.match_id = m.id
        ORDER BY cm_sub.created_at DESC
        LIMIT 1
    )
    ORDER BY cm.created_at DESC;

    RETURN;
END;
$$;


ALTER FUNCTION "public"."get_recent_chats"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_sponsored_ad_for_placement"("p_placement" "text", "p_locale" "text", "p_platform" "text") RETURNS TABLE("campaign_id" "uuid", "creative_id" "uuid", "placement" "text", "platform" "text", "destination_url" "text", "image_url" "text", "sponsor_name" "text", "headline" "text", "body" "text", "cta_label" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_locale text := lower(COALESCE(NULLIF(btrim(p_locale), ''), 'en'));
  v_platform text := lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web'));
  v_allowed_placements jsonb;
  v_allowed_platforms jsonb;
BEGIN
  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  IF NOT public.app_config_bool('ads.internal.enabled', false) THEN
    RETURN;
  END IF;

  IF NOT public.app_config_bool('ads.internal.sponsored_cards_enabled', true) THEN
    RETURN;
  END IF;

  IF NOT public.user_can_receive_ads(v_user_id) THEN
    RETURN;
  END IF;

  -- Load master controls
  v_allowed_placements := public.app_config_jsonb('ads.internal.allowed_placements', '["home_inline", "matches_inline", "chats_inline", "events_inline", "profile_inline"]'::jsonb);
  v_allowed_platforms := public.app_config_jsonb('ads.internal.allowed_platforms', '["android", "ios", "web", "windows", "macos", "linux"]'::jsonb);

  -- Check if requested placement is allowed at master level
  IF NOT (v_allowed_placements ? p_placement) THEN
    RETURN;
  END IF;

  -- Check if requested platform is allowed at master level
  IF NOT (v_allowed_platforms ? v_platform) THEN
    RETURN;
  END IF;

  RETURN QUERY
  WITH eligible AS (
    SELECT
      c.id AS campaign_id,
      cr.id AS creative_id,
      cr.placement,
      cr.platform,
      c.destination_url,
      cr.image_url,
      COALESCE(sponsor_locale.value, sponsor_en.value, c.advertiser_name) AS sponsor_name,
      COALESCE(headline_locale.value, headline_en.value) AS headline,
      COALESCE(body_locale.value, body_en.value, '') AS body,
      COALESCE(cta_locale.value, cta_en.value, '') AS cta_label,
      c.daily_impression_cap,
      c.total_impression_cap,
      c.sort_priority AS campaign_sort_priority,
      cr.sort_priority AS creative_sort_priority,
      (
        SELECT COUNT(*)
        FROM public.ad_impressions i
        WHERE i.campaign_id = c.id
          AND i.created_at >= date_trunc('day', NOW())
      ) AS impressions_today,
      (
        SELECT COUNT(*)
        FROM public.ad_impressions i
        WHERE i.campaign_id = c.id
      ) AS impressions_total
    FROM public.ad_campaigns c
    INNER JOIN public.ad_creatives cr
      ON cr.campaign_id = c.id
    LEFT JOIN public.translations headline_locale
      ON headline_locale.locale = v_locale
     AND headline_locale.key = cr.headline_key
    LEFT JOIN public.translations headline_en
      ON headline_en.locale = 'en'
     AND headline_en.key = cr.headline_key
    LEFT JOIN public.translations body_locale
      ON body_locale.locale = v_locale
     AND body_locale.key = cr.body_key
    LEFT JOIN public.translations body_en
      ON body_en.locale = 'en'
     AND body_en.key = cr.body_key
    LEFT JOIN public.translations cta_locale
      ON cta_locale.locale = v_locale
     AND cta_locale.key = cr.cta_key
    LEFT JOIN public.translations cta_en
      ON cta_en.locale = 'en'
     AND cta_en.key = cr.cta_key
    LEFT JOIN public.translations sponsor_locale
      ON sponsor_locale.locale = v_locale
     AND sponsor_locale.key = cr.sponsor_name_key
    LEFT JOIN public.translations sponsor_en
      ON sponsor_en.locale = 'en'
     AND sponsor_en.key = cr.sponsor_name_key
    WHERE c.is_active = true
      AND cr.is_active = true
      AND c.family_safe = true
      AND c.moderation_status = 'approved'
      AND c.starts_at <= NOW()
      AND (c.ends_at IS NULL OR c.ends_at > NOW())
      AND cr.placement = p_placement
      AND cr.platform IN ('all', v_platform)
  )
  SELECT
    eligible.campaign_id,
    eligible.creative_id,
    eligible.placement,
    eligible.platform,
    eligible.destination_url,
    eligible.image_url,
    eligible.sponsor_name,
    eligible.headline,
    eligible.body,
    eligible.cta_label
  FROM eligible
  WHERE eligible.headline IS NOT NULL
    AND (eligible.daily_impression_cap IS NULL OR eligible.impressions_today < eligible.daily_impression_cap)
    AND (eligible.total_impression_cap IS NULL OR eligible.impressions_total < eligible.total_impression_cap)
  ORDER BY eligible.creative_sort_priority ASC, eligible.campaign_sort_priority ASC, eligible.campaign_id
  LIMIT 1;
END;
$$;


ALTER FUNCTION "public"."get_sponsored_ad_for_placement"("p_placement" "text", "p_locale" "text", "p_platform" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_sponsored_ad_for_placement"("p_user_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text" DEFAULT 'en'::"text") RETURNS TABLE("campaign_id" "uuid", "creative_id" "uuid", "internal_name" "text", "advertiser_name" "text", "headline" "text", "body" "text", "cta_label" "text", "destination_url" "text", "image_url" "text", "impression_count" bigint)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_locale text := lower(COALESCE(NULLIF(btrim(p_locale), ''), 'en'));
  v_platform text := lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web'));
BEGIN
  RETURN QUERY
  WITH eligible AS (
    SELECT
      c.id AS campaign_id,
      cr.id AS creative_id,
      c.internal_name,
      c.advertiser_name,
      c.daily_impression_cap,
      c.total_impression_cap,
      c.sort_priority AS campaign_sort_priority,
      cr.sort_priority AS creative_sort_priority,
      cr.destination_url,
      cr.image_url,
      COALESCE(sponsor_locale.value, sponsor_en.value, c.advertiser_name) AS sponsor_name,
      COALESCE(headline_locale.value, headline_en.value) AS headline,
      COALESCE(body_locale.value, body_en.value, '') AS body,
      COALESCE(cta_locale.value, cta_en.value, '') AS cta_label,
      (
        SELECT COALESCE(SUM(impression_count), 0)::bigint
        FROM public.ad_impressions_daily i
        WHERE i.campaign_id = c.id
          AND i.created_at >= date_trunc('day', NOW())
      ) AS impressions_today,
      (
        SELECT COALESCE(SUM(impression_count), 0)::bigint
        FROM public.ad_impressions_daily i
        WHERE i.campaign_id = c.id
      ) AS impressions_total
    FROM public.ad_campaigns c
    INNER JOIN public.ad_creatives cr
      ON cr.campaign_id = c.id
    LEFT JOIN public.translations headline_locale
      ON headline_locale.locale = v_locale
      AND headline_locale.key = cr.headline_key
    LEFT JOIN public.translations headline_en
      ON headline_en.locale = 'en'
      AND headline_en.key = cr.headline_key
    LEFT JOIN public.translations body_locale
      ON body_locale.locale = v_locale
      AND body_locale.key = cr.body_key
    LEFT JOIN public.translations body_en
      ON body_en.locale = 'en'
      AND body_en.key = cr.body_key
    LEFT JOIN public.translations cta_locale
      ON cta_locale.locale = v_locale
      AND cta_locale.key = cr.cta_key
    LEFT JOIN public.translations cta_en
      ON cta_en.locale = 'en'
      AND cta_en.key = cr.cta_key
    LEFT JOIN public.translations sponsor_locale
      ON sponsor_locale.locale = v_locale
      AND sponsor_locale.key = cr.sponsor_name_key
    LEFT JOIN public.translations sponsor_en
      ON sponsor_en.locale = 'en'
      AND sponsor_en.key = cr.sponsor_name_key
    WHERE c.is_active = true
      AND c.moderation_status = 'approved'
      AND (NOT c.family_safe OR public.user_is_mature(p_user_id))
      AND NOW() BETWEEN c.starts_at AND c.ends_at
      AND cr.is_active = true
      AND cr.placement = p_placement
      AND (cr.platform = 'all' OR cr.platform = v_platform)
      AND (NOT public.user_has_dismissed_ad(p_user_id, cr.id))
    ORDER BY c.sort_priority, cr.sort_priority
  )
  SELECT
    eligible.campaign_id,
    eligible.creative_id,
    eligible.internal_name,
    eligible.advertiser_name,
    eligible.headline,
    eligible.body,
    eligible.cta_label,
    eligible.destination_url,
    eligible.image_url,
    eligible.impressions_today AS impression_count
  FROM eligible
  WHERE (eligible.daily_impression_cap IS NULL OR eligible.impressions_today < eligible.daily_impression_cap)
    AND (eligible.total_impression_cap IS NULL OR eligible.impressions_total < eligible.total_impression_cap)
  LIMIT 1;
END;
$$;


ALTER FUNCTION "public"."get_sponsored_ad_for_placement"("p_user_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_subscription_cron_status"() RETURNS TABLE("job_name" "text", "schedule" "text", "active" boolean, "last_run" timestamp with time zone, "next_run" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        j.jobname::TEXT,
        j.schedule::TEXT,
        j.active,
        j.last_run,
        j.next_run
    FROM cron.job j
    WHERE j.jobname = 'subscription-normalization';
END;
$$;


ALTER FUNCTION "public"."get_subscription_cron_status"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_ad_consent"("p_user_id" "uuid") RETURNS TABLE("user_id" "uuid", "personalized_ads" boolean, "non_personalized_ads" boolean, "consent_given_at" timestamp with time zone, "consent_version" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RETURN;
  END IF;

  RETURN QUERY
  SELECT
    ac.user_id,
    ac.personalized_ads,
    ac.non_personalized_ads,
    ac.consent_given_at,
    ac.consent_version
  FROM public.ad_consent ac
  WHERE ac.user_id = p_user_id;
END;
$$;


ALTER FUNCTION "public"."get_user_ad_consent"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_chats"("p_user_id" "uuid", "p_limit" integer DEFAULT 5) RETURNS TABLE("match_id" "uuid", "other_user_id" "uuid", "other_name" "text", "other_photos" "text"[], "last_message_id" "uuid", "last_message_preview" "text", "last_message_at" timestamp with time zone, "unread_count" integer, "updated_at" timestamp with time zone)
    LANGUAGE "sql" STABLE
    AS $$
  SELECT c.match_id,
         c.other_user_id,
         public.mask_full_name(u.name) as other_name,
         u.photos::text[] as other_photos,
         c.last_message_id,
         c.last_message_preview,
         c.last_message_at,
         c.unread_count,
         c.updated_at
  FROM public.chats c
  LEFT JOIN public.users u ON u.id = c.other_user_id
  WHERE c.user_id = p_user_id
  ORDER BY COALESCE(c.last_message_at, c.updated_at) DESC
  LIMIT p_limit;
$$;


ALTER FUNCTION "public"."get_user_chats"("p_user_id" "uuid", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_profiles"("p_user_id" "uuid") RETURNS TABLE("intent_type" "text", "profile_data" "jsonb", "created_at" timestamp with time zone, "updated_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
    RETURN QUERY
    SELECT up.intent_type, up.profile_data, up.created_at, up.updated_at
    FROM user_profiles up
    WHERE up.user_id = p_user_id;
END;
$$;


ALTER FUNCTION "public"."get_user_profiles"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_rating_summary"("p_user_id" "uuid", "p_min_count" integer DEFAULT 0, "p_last_n" integer DEFAULT NULL::integer) RETURNS TABLE("rated_by_count" integer, "q1_avg" double precision, "q2_avg" double precision, "q3_avg" double precision, "q4_avg" double precision, "q5_avg" double precision, "overall_avg" double precision)
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
WITH base AS (
  SELECT *
  FROM public.match_ratings mr
  WHERE mr.ratee_id = p_user_id
  ORDER BY mr.created_at DESC
  LIMIT COALESCE(p_last_n, 2147483647)
),
agg AS (
  SELECT
    COUNT(*)::int AS rated_by_count,
    AVG(q1::double precision) AS q1_avg,
    AVG(q2::double precision) AS q2_avg,
    AVG(q3::double precision) AS q3_avg,
    AVG(q4::double precision) AS q4_avg,
    AVG(q5::double precision) AS q5_avg,
    AVG(((q1 + q2 + q3 + q4 + q5)::double precision) / 5.0) AS overall_avg
  FROM base
)
SELECT
  a.rated_by_count,
  CASE WHEN a.rated_by_count < p_min_count THEN NULL ELSE a.q1_avg END,
  CASE WHEN a.rated_by_count < p_min_count THEN NULL ELSE a.q2_avg END,
  CASE WHEN a.rated_by_count < p_min_count THEN NULL ELSE a.q3_avg END,
  CASE WHEN a.rated_by_count < p_min_count THEN NULL ELSE a.q4_avg END,
  CASE WHEN a.rated_by_count < p_min_count THEN NULL ELSE a.q5_avg END,
  CASE WHEN a.rated_by_count < p_min_count THEN NULL ELSE a.overall_avg END
FROM agg a;
$$;


ALTER FUNCTION "public"."get_user_rating_summary"("p_user_id" "uuid", "p_min_count" integer, "p_last_n" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_recent_chats"("p_user_id" "uuid", "p_limit" integer DEFAULT 5) RETURNS TABLE("match_id" "uuid", "other_user_id" "uuid", "other_name" "text", "other_photos" "text"[], "last_message_preview" "text", "last_message_at" timestamp with time zone, "unread_count" integer, "updated_at" timestamp with time zone, "translation_enabled" boolean, "translation_language" "text", "last_message_id" "uuid", "last_message_sender_id" "uuid", "last_message_translated" "text")
    LANGUAGE "sql" STABLE
    AS $$
  SELECT c.match_id, c.other_user_id,
         public.mask_full_name(u.name) as other_name,
         u.photos::text[] as other_photos,
         c.last_message_preview, c.last_message_at,
         c.unread_count, c.updated_at,
         c.translation_enabled, c.translation_language,
         c.last_message_id,
         COALESCE(cm.sender_id, c.other_user_id) as last_message_sender_id,
         CASE 
             WHEN cm.content_translated IS NOT NULL AND cm.content_translated != '' AND cm.content_translated != 'null' THEN cm.content_translated
             ELSE NULL
         END as last_message_translated
  FROM public.chats c
  LEFT JOIN public.users u ON c.other_user_id = u.id
  LEFT JOIN public.chat_messages cm ON cm.id = c.last_message_id
  WHERE c.user_id = p_user_id
  ORDER BY c.updated_at DESC
  LIMIT p_limit;
$$;


ALTER FUNCTION "public"."get_user_recent_chats"("p_user_id" "uuid", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_recent_matches"("p_user_id" "uuid", "p_limit" integer DEFAULT 5) RETURNS TABLE("id" "uuid", "user1_id" "uuid", "user2_id" "uuid", "matched_intent" "text", "created_at" timestamp with time zone, "event_id" "uuid", "event_name" "text", "event_link" "text")
    LANGUAGE "sql" STABLE
    AS $$
  SELECT m.id, m.user1_id, m.user2_id, m.matched_intent, m.created_at,
         m.event_id, e.event_name, e.event_link
  FROM public.matches m
  LEFT JOIN public.events e ON m.event_id = e.id
  WHERE m.user1_id = p_user_id OR m.user2_id = p_user_id
  ORDER BY m.created_at DESC
  LIMIT p_limit;
$$;


ALTER FUNCTION "public"."get_user_recent_matches"("p_user_id" "uuid", "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_user_subscription_timeline"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("entry_type" character varying, "tier" character varying, "status" character varying, "starts_at" timestamp with time zone, "expires_at" timestamp with time zone, "payment_provider" character varying)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_current_tier text;
  v_current_expires_at timestamptz;
BEGIN
  v_user_id := COALESCE(p_user_id, auth.uid());

  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  IF v_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT subscription_tier, subscription_expires_at
  INTO v_current_tier, v_current_expires_at
  FROM public.users
  WHERE id = v_user_id;

  IF v_current_tier IS NOT NULL AND v_current_tier <> 'free' AND v_current_expires_at IS NOT NULL THEN
    RETURN QUERY
    SELECT
      'current'::varchar,
      v_current_tier::varchar,
      'active'::varchar,
      now()::timestamptz,
      v_current_expires_at::timestamptz,
      NULL::varchar;
  END IF;

  RETURN QUERY
  SELECT
    'queued'::varchar,
    sq.tier,
    sq.status,
    sq.starts_at,
    sq.expires_at,
    sq.payment_provider
  FROM public.user_subscription_queue sq
  WHERE sq.user_id = v_user_id
    AND sq.status IN ('pending', 'active')
  ORDER BY sq.starts_at ASC;
END;
$$;


ALTER FUNCTION "public"."get_user_subscription_timeline"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_users_for_broadcast"("filter_criteria" "jsonb") RETURNS TABLE("user_id" "uuid", "fcm_token" "text", "platform" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_is_allowed boolean;
  c jsonb;
  v_status text;
  v_tiers text[];
  v_user_ids uuid[];
BEGIN
  IF auth.role() = 'service_role' THEN
    v_is_allowed := true;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM public.users u
      WHERE u.id = auth.uid()
        AND u.is_admin = true
    ) INTO v_is_allowed;
  END IF;

  IF NOT COALESCE(v_is_allowed, false) THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  c := public.normalize_broadcast_filter_criteria(filter_criteria);
  v_status := lower(btrim(COALESCE(c->>'status', '')));

  IF c ? 'subscription_tiers' THEN
    SELECT array_agg(lower(btrim(value))) INTO v_tiers
    FROM jsonb_array_elements_text(c->'subscription_tiers') AS t(value);
  END IF;

  IF c ? 'user_ids' THEN
    SELECT array_agg(DISTINCT value::uuid) INTO v_user_ids
    FROM jsonb_array_elements_text(c->'user_ids') AS t(value);
  END IF;

  RETURN QUERY
  SELECT DISTINCT u.id, us.metadata->>'fcm_token', us.platform
  FROM public.users u
  JOIN public.user_session us ON u.id = us.user_id
  WHERE us.revoked = false
    AND NULLIF(btrim(COALESCE(us.metadata->>'fcm_token', '')), '') IS NOT NULL
    AND COALESCE((u.notification_preferences->'global_methods'->>'push')::boolean, true) = true
    AND COALESCE(
      (u.notification_preferences->'matrix'->'admin_announcements'->>'push')::boolean,
      (u.notification_preferences->>'enable_admin_notifications')::boolean,
      true
    ) = true
    AND (
      (v_user_ids IS NOT NULL AND u.id = ANY(v_user_ids)) OR
      (
        COALESCE((c->>'all_users')::boolean, false) = true OR
        (
          (c->'gender' IS NULL OR
            u.gender = ANY(ARRAY(SELECT jsonb_array_elements_text(c->'gender')))) AND
          (c->'age_range' IS NULL OR
            (EXTRACT(YEAR FROM AGE(CURRENT_DATE, u.date_of_birth)) >= (c->'age_range'->>'min')::int AND
            EXTRACT(YEAR FROM AGE(CURRENT_DATE, u.date_of_birth)) <= (c->'age_range'->>'max')::int)) AND
          (
            v_tiers IS NULL OR
            COALESCE(NULLIF(btrim(COALESCE(u.subscription_tier, '')), ''), 'free') = ANY(v_tiers)
          ) AND
          (c->'verification_status' IS NULL OR
            u.verification_status = ANY(ARRAY(SELECT jsonb_array_elements_text(c->'verification_status')))) AND
          (c->'platform' IS NULL OR
            us.platform = ANY(ARRAY(SELECT jsonb_array_elements_text(c->'platform')))) AND
          (c->'last_active_days' IS NULL OR
            us.last_active_at >= NOW() - INTERVAL '1 day' * (c->>'last_active_days')::int) AND
          (
            v_status = '' OR v_status = 'all' OR
            (v_status = 'visible' AND public.is_user_truly_visible(u.id) = TRUE) OR
            (v_status = 'invisible' AND public.is_user_online(u.id) = TRUE AND public.is_user_truly_visible(u.id) = FALSE) OR
            (v_status = 'offline' AND public.is_user_online(u.id) = FALSE)
          ) AND
          (
            c->'ui_language' IS NULL OR
            lower(coalesce(u.preferred_language, '')) = lower(c->>'ui_language')
          ) AND
          (
            c->'ui_languages' IS NULL OR
            lower(coalesce(u.preferred_language, '')) = ANY(
              ARRAY(
                SELECT lower(jsonb_array_elements_text(c->'ui_languages'))
              )
            )
          )
        )
      )
    );
END;
$$;


ALTER FUNCTION "public"."get_users_for_broadcast"("filter_criteria" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_visible_online_user_map_cells"("p_requesting_user_id" "uuid", "p_center_lat" double precision, "p_center_lng" double precision, "p_radius_km" double precision, "p_cell_meters" integer DEFAULT 2000, "p_recent_minutes" integer DEFAULT 30) RETURNS TABLE("cell_center_lat" double precision, "cell_center_lng" double precision, "user_count" integer)
    LANGUAGE "plpgsql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  earth_km CONSTANT double precision := 6371.0;
  lat_step double precision;
  lng_step double precision;
BEGIN
  IF p_center_lat IS NULL OR p_center_lng IS NULL OR p_radius_km IS NULL OR p_radius_km <= 0 THEN
    RETURN;
  END IF;

  lat_step := GREATEST((p_cell_meters::double precision / 111000.0), 0.0001);
  lng_step := GREATEST((p_cell_meters::double precision / (111000.0 * GREATEST(ABS(COS(RADIANS(p_center_lat))), 0.15))), 0.0001);

  RETURN QUERY
  WITH latest_locations AS (
    SELECT DISTINCT ON (ul.user_id)
      ul.user_id,
      ul.latitude,
      ul.longitude,
      ul.updated_at
    FROM public.user_locations ul
    WHERE ul.user_id IS NOT NULL
      AND ul.user_id <> p_requesting_user_id
      AND ul.updated_at >= NOW() - make_interval(mins => GREATEST(p_recent_minutes, 1))
    ORDER BY ul.user_id, ul.updated_at DESC
  ),
  nearby AS (
    SELECT
      ll.user_id,
      ll.latitude,
      ll.longitude
    FROM latest_locations ll
    WHERE public.is_user_truly_visible(ll.user_id) = TRUE
      AND (earth_km * acos(
        cos(radians(p_center_lat)) * cos(radians(ll.latitude)) * cos(radians(ll.longitude) - radians(p_center_lng))
        + sin(radians(p_center_lat)) * sin(radians(ll.latitude))
      )) <= p_radius_km
  ),
  keyed AS (
    SELECT
      FLOOR(nearby.latitude / lat_step)::bigint AS lat_bucket,
      FLOOR(nearby.longitude / lng_step)::bigint AS lng_bucket,
      nearby.user_id
    FROM nearby
  )
  SELECT
    ((lat_bucket + 0.5) * lat_step)::double precision AS cell_center_lat,
    ((lng_bucket + 0.5) * lng_step)::double precision AS cell_center_lng,
    COUNT(DISTINCT user_id)::integer AS user_count
  FROM keyed
  GROUP BY lat_bucket, lng_bucket
  ORDER BY user_count DESC;
END;
$$;


ALTER FUNCTION "public"."get_visible_online_user_map_cells"("p_requesting_user_id" "uuid", "p_center_lat" double precision, "p_center_lng" double precision, "p_radius_km" double precision, "p_cell_meters" integer, "p_recent_minutes" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_chat_deletion_check_messages"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  -- Check if this was the last chat entry for this match
  IF public.should_delete_match_messages(OLD.match_id) THEN
    -- No more users have this chat, safe to delete messages
    DELETE FROM public.chat_messages WHERE match_id = OLD.match_id;
  END IF;

  RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chat_deletion_check_messages"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_chat_message_delete_for_chats"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  m_record RECORD;
  sender uuid;
  other uuid;
  latest_msg RECORD;
  preview text;
  was_unread boolean;
BEGIN
  IF (TG_OP = 'DELETE') THEN
    -- Resolve participants
    SELECT user1_id, user2_id INTO m_record FROM public.matches WHERE id = OLD.match_id;
    IF NOT FOUND THEN
      RETURN OLD;
    END IF;

    sender := OLD.sender_id;
    IF m_record.user1_id = sender THEN
      other := m_record.user2_id;
    ELSE
      other := m_record.user1_id;
    END IF;

    -- Check if the deleted message was unread
    was_unread := (OLD.read_at IS NULL);

    -- Find the new latest message for this match after deletion
    SELECT id, content_original, created_at INTO latest_msg
    FROM public.chat_messages
    WHERE match_id = OLD.match_id
    ORDER BY created_at DESC
    LIMIT 1;

    -- Update the chats table for both participants
    IF latest_msg.id IS NOT NULL THEN
      -- New message exists, update chats to point to it
      preview := substring(regexp_replace(coalesce(latest_msg.content_original, ''), E'\n+', ' ', 'g') FROM 1 FOR 400);
      UPDATE public.chats 
      SET last_message_id = latest_msg.id, 
          last_message_preview = preview, 
          last_message_at = latest_msg.created_at,
          unread_count = CASE 
            WHEN user_id = other AND was_unread AND unread_count > 0 THEN unread_count - 1
            ELSE unread_count 
          END,
          updated_at = now()
      WHERE match_id = OLD.match_id AND user_id IN (sender, other);
    ELSE
      -- No messages left, clear the chat preview and reset unread count
      UPDATE public.chats 
      SET last_message_id = NULL, 
          last_message_preview = '', 
          last_message_at = NULL,
          unread_count = 0,
          updated_at = now()
      WHERE match_id = OLD.match_id AND user_id IN (sender, other);
    END IF;
  END IF;
  RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chat_message_delete_for_chats"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_chat_message_for_chats"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  m_record RECORD;
  sender uuid;
  other uuid;
  preview text;
BEGIN
  -- Resolve participants for the match
  SELECT user1_id, user2_id INTO m_record FROM public.matches WHERE id = NEW.match_id;
  IF NOT FOUND THEN
    RETURN NEW;
  END IF;

  sender := NEW.sender_id;
  IF m_record.user1_id = sender THEN
    other := m_record.user2_id;
  ELSE
    other := m_record.user1_id;
  END IF;

  preview := substring(regexp_replace(coalesce(NEW.content_original, ''), E'\n+', ' ', 'g') FROM 1 FOR 400);

  -- Upsert for sender with unread increment 0
  PERFORM public.upsert_chat_row(sender, NEW.match_id, other, NEW.id, preview, COALESCE(NEW.created_at, now()), 0, COALESCE(NEW.created_at, now()));

  -- Upsert for recipient with unread increment 1
  PERFORM public.upsert_chat_row(other, NEW.match_id, sender, NEW.id, preview, COALESCE(NEW.created_at, now()), 1, COALESCE(NEW.created_at, now()));

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_chat_message_for_chats"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_chat_message_update_for_chats"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  m_record RECORD;
  sender uuid;
  other uuid;
  latest_msg RECORD;
  preview text;
BEGIN
  IF (TG_OP = 'UPDATE') THEN
    -- Only process if the content was actually changed
    IF (OLD.content_original != NEW.content_original) THEN
      -- Resolve participants
      SELECT user1_id, user2_id INTO m_record FROM public.matches WHERE id = NEW.match_id;
      IF NOT FOUND THEN
        RETURN NEW;
      END IF;

      sender := NEW.sender_id;
      IF m_record.user1_id = sender THEN
        other := m_record.user2_id;
      ELSE
        other := m_record.user1_id;
      END IF;

      -- Check if this message is the latest for the match
      SELECT id, content_original, created_at INTO latest_msg
      FROM public.chat_messages
      WHERE match_id = NEW.match_id
      ORDER BY created_at DESC
      LIMIT 1;

      -- If this is the latest message, update the chats table
      IF latest_msg.id = NEW.id THEN
        preview := substring(regexp_replace(coalesce(NEW.content_original, ''), E'\n+', ' ', 'g') FROM 1 FOR 400);
        
        -- Update both users' chat entries
        UPDATE public.chats 
        SET last_message_preview = preview, updated_at = now()
        WHERE match_id = NEW.match_id AND user_id IN (sender, other);
      END IF;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_chat_message_update_for_chats"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_message_reactions_change"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  affected_id uuid;
BEGIN
  IF (TG_OP = 'INSERT') THEN
    affected_id := NEW.message_id;
  ELSIF (TG_OP = 'UPDATE') THEN
    affected_id := NEW.message_id;
    -- In case message_id changed (unlikely), update old one too
    IF OLD.message_id IS DISTINCT FROM NEW.message_id THEN
      PERFORM public.recompute_reaction_summary(OLD.message_id);
    END IF;
  ELSIF (TG_OP = 'DELETE') THEN
    affected_id := OLD.message_id;
  END IF;

  PERFORM public.recompute_reaction_summary(affected_id);
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_message_reactions_change"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_message_read_for_chats"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  matchid uuid;
  reader uuid;
BEGIN
  IF (TG_OP = 'UPDATE') THEN
    IF (OLD.read_at IS NULL AND NEW.read_at IS NOT NULL) THEN
      matchid := NEW.match_id;
      -- Try to use auth.uid() as the reader (who marked messages read). If not available, derive from match participants.
      reader := auth.uid();
      IF reader IS NULL THEN
        SELECT CASE WHEN m.user1_id = NEW.sender_id THEN m.user2_id ELSE m.user1_id END INTO reader
        FROM public.matches m WHERE m.id = NEW.match_id;
      END IF;
      UPDATE public.chats SET unread_count = 0, updated_at = now() WHERE user_id = reader AND match_id = matchid;
    END IF;
  END IF; 
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_message_read_for_chats"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_new_match"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  -- Upsert for both participants
  PERFORM public.upsert_user_recent_match(NEW.user1_id, NEW.id, NEW.user2_id, NEW.match_type, NEW.matched_intent, COALESCE(NEW.created_at, now()), COALESCE(NEW.created_at, now()));
  PERFORM public.upsert_user_recent_match(NEW.user2_id, NEW.id, NEW.user1_id, NEW.match_type, NEW.matched_intent, COALESCE(NEW.created_at, now()), COALESCE(NEW.created_at, now()));
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_new_match"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."handle_user_preferred_language_change"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_new_lang text;
  v_chat record;
BEGIN
  IF TG_OP <> 'UPDATE' THEN
    RETURN NEW;
  END IF;

  IF OLD.preferred_language IS NOT DISTINCT FROM NEW.preferred_language THEN
    RETURN NEW;
  END IF;

  v_new_lang := public.normalize_language_code(NEW.preferred_language);
  IF v_new_lang IS NULL THEN
    RETURN NEW;
  END IF;

  UPDATE public.chats
  SET translation_language = v_new_lang,
      updated_at = GREATEST(updated_at, now())
  WHERE user_id = NEW.id
    AND translation_enabled = true;

  FOR v_chat IN
    SELECT c.match_id, c.last_message_id
    FROM public.chats c
    WHERE c.user_id = NEW.id
      AND c.translation_enabled = true
      AND c.last_message_id IS NOT NULL
  LOOP
    BEGIN
      PERFORM public.translate_message_for_user(v_chat.last_message_id, NEW.id, v_new_lang);
    EXCEPTION WHEN OTHERS THEN
      -- Best-effort: ignore per-chat translation failures.
      NULL;
    END;
  END LOOP;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."handle_user_preferred_language_change"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."health_check"() RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  PERFORM 1 FROM users LIMIT 1;
  RETURN jsonb_build_object('ok', true, 'checked_at', now());
EXCEPTION WHEN OTHERS THEN
  RETURN jsonb_build_object('ok', false, 'error', SQLERRM, 'checked_at', now());
END;
$$;


ALTER FUNCTION "public"."health_check"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_user_online"("p_user_id" "uuid") RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
SELECT COALESCE((
  SELECT
    EXISTS (
      SELECT 1
      FROM public.user_activity ua
      WHERE ua.user_id = p_user_id
        AND ua.is_online = TRUE
        AND ua.last_activity > NOW() - INTERVAL '2 minutes'
    )
), FALSE);
$$;


ALTER FUNCTION "public"."is_user_online"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_user_online_realtime"("p_user_id" "uuid") RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
SELECT COALESCE((
  SELECT is_online
  FROM public.user_presence
  WHERE user_id = p_user_id
), FALSE);
$$;


ALTER FUNCTION "public"."is_user_online_realtime"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_user_truly_visible"("p_user_id" "uuid") RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
SELECT COALESCE((
  SELECT
    (
      EXISTS (
        SELECT 1
        FROM public.user_activity ua
        WHERE ua.user_id = p_user_id
          AND ua.is_online = TRUE
          AND ua.last_activity > NOW() - INTERVAL '2 minutes'
      )
      AND COALESCE(u.user_visibility_setting, false) = TRUE
      AND COALESCE(u.system_visibility_status, 'visible') = 'visible'
    )
  FROM public.users u
  WHERE u.id = p_user_id
), FALSE);
$$;


ALTER FUNCTION "public"."is_user_truly_visible"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_user_truly_visible_realtime"("p_user_id" "uuid") RETURNS boolean
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
SELECT COALESCE((
  SELECT
    (is_online = TRUE
     AND COALESCE(u.user_visibility_setting, false) = TRUE
     AND COALESCE(u.system_visibility_status, 'visible') = 'visible')
  FROM public.user_presence up
  INNER JOIN public.users u ON up.user_id = u.id
  WHERE up.user_id = p_user_id
), FALSE);
$$;


ALTER FUNCTION "public"."is_user_truly_visible_realtime"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_valid_currency_code_array"("p_codes" "text"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $_$
  SELECT
    p_codes IS NOT NULL
    AND NOT EXISTS (
      SELECT 1
      FROM unnest(p_codes) AS item
      WHERE item IS NULL
         OR item !~ '^[A-Z]{3}$'
    );
$_$;


ALTER FUNCTION "public"."is_valid_currency_code_array"("p_codes" "text"[]) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."list_orphan_profile_photos"("p_min_age_minutes" integer DEFAULT 1440, "p_limit" integer DEFAULT 500) RETURNS TABLE("name" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_threshold timestamptz;
  v_limit int;
BEGIN
  IF p_min_age_minutes IS NULL OR p_min_age_minutes < 0 THEN
    RAISE EXCEPTION 'p_min_age_minutes must be >= 0';
  END IF;

  v_limit := COALESCE(p_limit, 500);
  IF v_limit < 1 THEN v_limit := 1; END IF;
  IF v_limit > 1000 THEN v_limit := 1000; END IF;

  v_threshold := now() - make_interval(mins => p_min_age_minutes);

  RETURN QUERY
  WITH referenced AS (
    SELECT DISTINCT value AS name
    FROM public.users u
    CROSS JOIN LATERAL jsonb_array_elements_text(to_jsonb(u.photos)) AS value
    WHERE u.photos IS NOT NULL
      AND value IS NOT NULL
      AND btrim(value) <> ''
  )
  SELECT o.name
  FROM storage.objects o
  WHERE o.bucket_id = 'profile-photos'
    AND o.created_at < v_threshold
    AND NOT EXISTS (
      SELECT 1
      FROM referenced r
      WHERE r.name = o.name
    )
  ORDER BY o.created_at ASC
  LIMIT v_limit;
END;
$$;


ALTER FUNCTION "public"."list_orphan_profile_photos"("p_min_age_minutes" integer, "p_limit" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."log_edge_function_invocation"("p_request_id" "uuid", "p_function_name" "text", "p_duration_ms" integer DEFAULT NULL::integer, "p_success" boolean DEFAULT true, "p_http_status" integer DEFAULT NULL::integer, "p_error_type" "text" DEFAULT NULL::"text", "p_error_message" "text" DEFAULT NULL::"text", "p_user_id" "uuid" DEFAULT NULL::"uuid", "p_ai_used" boolean DEFAULT false, "p_ai_provider" "text" DEFAULT NULL::"text", "p_ai_model" "text" DEFAULT NULL::"text", "p_ai_task" "text" DEFAULT NULL::"text", "p_meta" "jsonb" DEFAULT '{}'::"jsonb") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_headers jsonb;
  v_authz text;
  v_apikey text;
BEGIN
  v_headers := COALESCE(current_setting('request.headers', true), '{}'::text)::jsonb;
  v_authz := COALESCE(v_headers ->> 'authorization', v_headers ->> 'Authorization');
  v_apikey := COALESCE(v_headers ->> 'apikey', v_headers ->> 'x-api-key', v_headers ->> 'X-Api-Key');

  IF (v_authz IS NULL OR btrim(v_authz) = '')
     AND (v_apikey IS NULL OR btrim(v_apikey) = '') THEN
    RAISE EXCEPTION 'missing_auth';
  END IF;

  INSERT INTO public.edge_function_invocations (
    request_id,
    function_name,
    duration_ms,
    success,
    http_status,
    error_type,
    error_message,
    user_id,
    ai_used,
    ai_provider,
    ai_model,
    ai_task,
    meta
  ) VALUES (
    p_request_id,
    COALESCE(NULLIF(btrim(COALESCE(p_function_name, '')), ''), 'unknown'),
    p_duration_ms,
    COALESCE(p_success, true),
    p_http_status,
    NULLIF(btrim(COALESCE(p_error_type, '')), ''),
    NULLIF(btrim(COALESCE(p_error_message, '')), ''),
    p_user_id,
    COALESCE(p_ai_used, false),
    NULLIF(btrim(COALESCE(p_ai_provider, '')), ''),
    NULLIF(btrim(COALESCE(p_ai_model, '')), ''),
    NULLIF(btrim(COALESCE(p_ai_task, '')), ''),
    COALESCE(p_meta, '{}'::jsonb)
  );
END;
$$;


ALTER FUNCTION "public"."log_edge_function_invocation"("p_request_id" "uuid", "p_function_name" "text", "p_duration_ms" integer, "p_success" boolean, "p_http_status" integer, "p_error_type" "text", "p_error_message" "text", "p_user_id" "uuid", "p_ai_used" boolean, "p_ai_provider" "text", "p_ai_model" "text", "p_ai_task" "text", "p_meta" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."mark_broadcast_failed"("p_broadcast_id" "uuid", "p_failure_reason" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    UPDATE admin_broadcasts
    SET status = 'failed', updated_at = NOW()
    WHERE id = p_broadcast_id;

    UPDATE admin_broadcast_deliveries
    SET delivery_status = 'failed', failure_reason = p_failure_reason
    WHERE broadcast_id = p_broadcast_id AND delivery_status = 'pending';
END;
$$;


ALTER FUNCTION "public"."mark_broadcast_failed"("p_broadcast_id" "uuid", "p_failure_reason" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."mark_message_delivered"("p_message_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  UPDATE public.chat_messages
  SET delivered_at = CASE 
    WHEN delivered_at IS NULL THEN NOW()
    ELSE delivered_at
  END
  WHERE id = p_message_id
    AND delivered_at IS NULL; -- Only update if not already marked as delivered
END;
$$;


ALTER FUNCTION "public"."mark_message_delivered"("p_message_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."mark_messages_as_read"("p_match_id" "uuid") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    rows_affected INTEGER;
BEGIN
    SET search_path = 'public';
    
    UPDATE chat_messages
    SET read_at = NOW()
    WHERE match_id = p_match_id
    AND sender_id != auth.uid()
    AND read_at IS NULL;  -- Only update messages that haven't been read yet
    
    GET DIAGNOSTICS rows_affected = ROW_COUNT;
    
    RETURN rows_affected;
END;
$$;


ALTER FUNCTION "public"."mark_messages_as_read"("p_match_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."mask_full_name"("full_name" "text") RETURNS "text"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  parts TEXT[];
  first_part TEXT;
  last_part TEXT;
BEGIN
  IF full_name IS NULL OR trim(full_name) = '' THEN
    RETURN 'Unknown User';
  END IF;

  parts := regexp_split_to_array(trim(full_name), '\s+');
  first_part := parts[1];

  IF array_length(parts, 1) > 1 THEN
    last_part := parts[array_length(parts, 1)];
    IF last_part IS NOT NULL AND last_part <> first_part THEN
      RETURN first_part || ' ' || upper(left(last_part, 1)) || '.';
    END IF;
  END IF;

  RETURN first_part;
END;
$$;


ALTER FUNCTION "public"."mask_full_name"("full_name" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."normalize_broadcast_filter_criteria"("p_criteria" "jsonb") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  c jsonb := COALESCE(p_criteria, '{}'::jsonb);
  out jsonb := '{}'::jsonb;

  v_bool boolean;
  v_int integer;
  v_min integer;
  v_max integer;
  v_text text;
  v_status text;
  arr text[];
BEGIN
  IF jsonb_typeof(c) IS DISTINCT FROM 'object' THEN
    c := '{}'::jsonb;
  END IF;

  BEGIN
    v_bool := COALESCE((c->>'all_users')::boolean, false);
  EXCEPTION WHEN OTHERS THEN
    v_bool := false;
  END;

  IF v_bool THEN
    RETURN jsonb_build_object('all_users', true);
  END IF;

  IF c ? 'user_ids' AND jsonb_typeof(c->'user_ids') = 'array' THEN
    SELECT array_agg(DISTINCT value) INTO arr
    FROM (
      SELECT lower(btrim(value)) AS value
      FROM jsonb_array_elements_text(c->'user_ids') AS t(value)
      WHERE lower(btrim(value)) ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      LIMIT 500
    ) s
    WHERE value <> '';

    IF arr IS NOT NULL AND array_length(arr, 1) > 0 THEN
      RETURN jsonb_build_object('user_ids', to_jsonb(arr));
    END IF;
  END IF;

  v_status := lower(btrim(COALESCE(c->>'status', '')));
  IF v_status = '' THEN
    v_status := lower(btrim(COALESCE(c->>'visibility', '')));
  END IF;
  IF v_status = '' THEN
    BEGIN
      IF COALESCE((c->>'visible_only')::boolean, false) THEN
        v_status := 'visible';
      END IF;
    EXCEPTION WHEN OTHERS THEN
    END;
  END IF;

  IF v_status IN ('visible', 'invisible', 'offline') THEN
    out := out || jsonb_build_object('status', v_status);
  END IF;

  IF c ? 'gender' AND jsonb_typeof(c->'gender') = 'array' THEN
    SELECT array_agg(DISTINCT lower(btrim(value))) INTO arr
    FROM jsonb_array_elements_text(c->'gender') AS t(value)
    WHERE btrim(value) <> '';
    IF arr IS NOT NULL AND array_length(arr, 1) > 0 THEN
      out := out || jsonb_build_object('gender', to_jsonb(arr));
    END IF;
  END IF;

  IF c ? 'age_range' AND jsonb_typeof(c->'age_range') = 'object' THEN
    BEGIN
      v_min := (c->'age_range'->>'min')::int;
      v_max := (c->'age_range'->>'max')::int;
    EXCEPTION WHEN OTHERS THEN
      v_min := NULL;
      v_max := NULL;
    END;
    IF v_min IS NOT NULL AND v_max IS NOT NULL THEN
      v_min := GREATEST(18, LEAST(v_min, 80));
      v_max := GREATEST(18, LEAST(v_max, 80));
      IF v_min > v_max THEN
        v_int := v_min;
        v_min := v_max;
        v_max := v_int;
      END IF;
      out := out || jsonb_build_object('age_range', jsonb_build_object('min', v_min, 'max', v_max));
    END IF;
  END IF;

  IF c ? 'subscription_tiers' AND jsonb_typeof(c->'subscription_tiers') = 'array' THEN
    SELECT array_agg(DISTINCT lower(btrim(value))) INTO arr
    FROM jsonb_array_elements_text(c->'subscription_tiers') AS t(value)
    WHERE btrim(value) <> '';
    IF arr IS NOT NULL AND array_length(arr, 1) > 0 THEN
      out := out || jsonb_build_object('subscription_tiers', to_jsonb(arr));
    END IF;
  END IF;

  IF c ? 'verification_status' AND jsonb_typeof(c->'verification_status') = 'array' THEN
    SELECT array_agg(DISTINCT lower(btrim(value))) INTO arr
    FROM jsonb_array_elements_text(c->'verification_status') AS t(value)
    WHERE lower(btrim(value)) = ANY(ARRAY['unverified','analyzing','pending','approved','rejected']);
    IF arr IS NOT NULL AND array_length(arr, 1) > 0 THEN
      out := out || jsonb_build_object('verification_status', to_jsonb(arr));
    END IF;
  END IF;

  IF c ? 'platform' AND jsonb_typeof(c->'platform') = 'array' THEN
    SELECT array_agg(DISTINCT lower(btrim(value))) INTO arr
    FROM jsonb_array_elements_text(c->'platform') AS t(value)
    WHERE lower(btrim(value)) = ANY(ARRAY['android','ios','web','macos','windows','linux','unknown']);
    IF arr IS NOT NULL AND array_length(arr, 1) > 0 THEN
      out := out || jsonb_build_object('platform', to_jsonb(arr));
    END IF;
  END IF;

  IF c ? 'last_active_days' THEN
    BEGIN
      v_int := (c->>'last_active_days')::int;
    EXCEPTION WHEN OTHERS THEN
      v_int := NULL;
    END;
    IF v_int IS NOT NULL AND v_int > 0 AND v_int <= 3650 THEN
      out := out || jsonb_build_object('last_active_days', v_int);
    END IF;
  END IF;

  v_text := lower(btrim(COALESCE(c->>'ui_language', '')));
  IF v_text IN ('en','es','he') THEN
    out := out || jsonb_build_object('ui_language', v_text);
  END IF;

  IF c ? 'ui_languages' AND jsonb_typeof(c->'ui_languages') = 'array' THEN
    SELECT array_agg(DISTINCT lower(btrim(value))) INTO arr
    FROM jsonb_array_elements_text(c->'ui_languages') AS t(value)
    WHERE lower(btrim(value)) = ANY(ARRAY['en','es','he']);
    IF arr IS NOT NULL AND array_length(arr, 1) > 0 THEN
      out := out || jsonb_build_object('ui_languages', to_jsonb(arr));
    END IF;
  END IF;

  RETURN out;
END;
$_$;


ALTER FUNCTION "public"."normalize_broadcast_filter_criteria"("p_criteria" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."normalize_language_code"("p_lang" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
BEGIN
  IF p_lang IS NULL OR trim(p_lang) = '' THEN
    RETURN NULL;
  END IF;
  
  -- Normalize to lowercase
  p_lang := lower(trim(p_lang));
  
  -- Handle special cases
  CASE p_lang
    WHEN 'en', 'eng', 'english' THEN RETURN 'en';
    WHEN 'es', 'spa', 'spanish' THEN RETURN 'es';
    WHEN 'fr', 'fre', 'french' THEN RETURN 'fr';
    WHEN 'de', 'ger', 'german' THEN RETURN 'de';
    WHEN 'it', 'ita', 'italian' THEN RETURN 'it';
    WHEN 'pt', 'por', 'portuguese' THEN RETURN 'pt';
    WHEN 'ru', 'rus', 'russian' THEN RETURN 'ru';
    WHEN 'zh', 'chi', 'chinese' THEN RETURN 'zh';
    WHEN 'ja', 'jpn', 'japanese' THEN RETURN 'ja';
    WHEN 'ko', 'kor', 'korean' THEN RETURN 'ko';
    WHEN 'ar', 'ara', 'arabic' THEN RETURN 'ar';
    WHEN 'he', 'heb', 'hebrew' THEN RETURN 'he';
    WHEN 'hi', 'hin', 'hindi' THEN RETURN 'hi';
    WHEN 'tr', 'tur', 'turkish' THEN RETURN 'tr';
    WHEN 'pl', 'pol', 'polish' THEN RETURN 'pl';
    WHEN 'nl', 'dut', 'dutch' THEN RETURN 'nl';
    WHEN 'sv', 'swe', 'swedish' THEN RETURN 'sv';
    WHEN 'el', 'gre', 'greek' THEN RETURN 'el';
    WHEN 'th', 'tha', 'thai' THEN RETURN 'th';
    WHEN 'vi', 'vie', 'vietnamese' THEN RETURN 'vi';
    WHEN 'id', 'ind', 'indonesian' THEN RETURN 'id';
    WHEN 'uk', 'ukr', 'ukrainian' THEN RETURN 'uk';
    WHEN 'cs', 'cze', 'czech' THEN RETURN 'cs';
    WHEN 'ro', 'rum', 'romanian' THEN RETURN 'ro';
    WHEN 'hu', 'hun', 'hungarian' THEN RETURN 'hu';
    ELSE RETURN p_lang;
  END CASE;
END;
$$;


ALTER FUNCTION "public"."normalize_language_code"("p_lang" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."normalize_profile_bio_text"("p_bio" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
  SELECT NULLIF(
    trim(
      regexp_replace(
        lower(
          replace(
            replace(
              replace(
                replace(COALESCE(p_bio, ''), chr(8203), ''),
                chr(8204),
                ''
              ),
              chr(8205),
              ''
            ),
            chr(65279),
            ''
          )
        ),
        '\s+',
        ' ',
        'g'
      )
    ),
    ''
  );
$$;


ALTER FUNCTION "public"."normalize_profile_bio_text"("p_bio" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."normalize_user_subscription"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS TABLE("subscription_tier" "text", "subscription_expires_at" timestamp with time zone, "subscription_next_tier" "text", "subscription_next_starts_at" timestamp with time zone, "subscription_next_expires_at" timestamp with time zone)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_tier text;
  v_exp timestamptz;
  v_next_tier text;
  v_next_start timestamptz;
  v_next_exp timestamptz;
  v_now timestamptz := now();
BEGIN
  IF p_user_id IS NULL THEN
    p_user_id := auth.uid();
  END IF;

  IF p_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  SELECT u.subscription_tier, u.subscription_expires_at, u.subscription_next_tier, u.subscription_next_starts_at, u.subscription_next_expires_at
  INTO v_tier, v_exp, v_next_tier, v_next_start, v_next_exp
  FROM public.users u
  WHERE u.id = p_user_id
  FOR UPDATE;

  IF v_tier IS NULL OR v_tier = '' THEN
    v_tier := 'free';
  END IF;

  IF v_tier <> 'free' AND v_exp IS NOT NULL AND v_exp <= v_now THEN
    IF v_next_tier IS NOT NULL AND v_next_exp IS NOT NULL AND (v_next_start IS NULL OR v_next_start <= v_now) THEN
      v_tier := v_next_tier;
      v_exp := v_next_exp;
      v_next_tier := NULL;
      v_next_start := NULL;
      v_next_exp := NULL;
    ELSE
      v_tier := 'free';
      v_exp := NULL;
      v_next_tier := NULL;
      v_next_start := NULL;
      v_next_exp := NULL;
    END IF;

    UPDATE public.users
    SET subscription_tier = v_tier,
        subscription_expires_at = v_exp,
        subscription_next_tier = v_next_tier,
        subscription_next_starts_at = v_next_start,
        subscription_next_expires_at = v_next_exp
    WHERE id = p_user_id;
  END IF;

  RETURN QUERY SELECT v_tier, v_exp, v_next_tier, v_next_start, v_next_exp;
END $$;


ALTER FUNCTION "public"."normalize_user_subscription"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."normalize_user_subscription_queue"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_now timestamptz := now();
  v_current_tier text;
  v_current_expires_at timestamptz;
  v_next record;
BEGIN
  v_user_id := COALESCE(p_user_id, auth.uid());

  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  IF v_user_id IS DISTINCT FROM auth.uid()
     AND COALESCE(auth.jwt() ->> 'role', '') <> 'service_role' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;

  UPDATE public.user_subscription_queue
  SET status = 'completed',
      updated_at = v_now
  WHERE user_id = v_user_id
    AND status = 'active'
    AND expires_at <= v_now;

  SELECT u.subscription_tier, u.subscription_expires_at
  INTO v_current_tier, v_current_expires_at
  FROM public.users u
  WHERE u.id = v_user_id
  FOR UPDATE;

  IF v_current_tier IS NULL OR btrim(v_current_tier) = '' THEN
    v_current_tier := 'free';
  END IF;

  IF v_current_tier <> 'free'
     AND v_current_expires_at IS NOT NULL
     AND v_current_expires_at > v_now THEN
    RETURN;
  END IF;

  SELECT sq.*
  INTO v_next
  FROM public.user_subscription_queue sq
  WHERE sq.user_id = v_user_id
    AND sq.status = 'pending'
    AND sq.starts_at <= v_now
  ORDER BY sq.starts_at ASC
  LIMIT 1;

  IF FOUND THEN
    UPDATE public.user_subscription_queue
    SET status = 'active',
        activated_at = COALESCE(activated_at, v_now),
        updated_at = v_now
    WHERE id = v_next.id;

    UPDATE public.users
    SET subscription_tier = v_next.tier,
        subscription_expires_at = v_next.expires_at,
        updated_at = v_now
    WHERE id = v_user_id;
  ELSE
    UPDATE public.users
    SET subscription_tier = 'free',
        subscription_expires_at = NULL,
        updated_at = v_now
    WHERE id = v_user_id;
  END IF;
END;
$$;


ALTER FUNCTION "public"."normalize_user_subscription_queue"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."normalize_user_subscription_v2"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    v_next_subscription RECORD;
BEGIN
    -- Only run if the current subscription has expired
    IF NEW.subscription_tier IS NOT NULL 
       AND NEW.subscription_tier != 'free'
       AND NEW.subscription_expires_at IS NOT NULL
       AND NEW.subscription_expires_at <= NOW() THEN
        
        -- Find the next pending subscription
        SELECT * INTO v_next_subscription
        FROM user_subscription_queue
        WHERE user_id = NEW.id
        AND status = 'pending'
        AND starts_at <= NOW()
        ORDER BY starts_at ASC
        LIMIT 1;
        
        IF FOUND THEN
            -- Activate the queued subscription
            UPDATE user_subscription_queue
            SET status = 'active',
                activated_at = NOW(),
                updated_at = NOW()
            WHERE id = v_next_subscription.id;
            
            -- Update user's current subscription
            NEW.subscription_tier := v_next_subscription.tier;
            NEW.subscription_expires_at := v_next_subscription.expires_at;
            NEW.updated_at := NOW();
        ELSE
            -- No queued subscription, set to free
            NEW.subscription_tier := 'free';
            NEW.subscription_expires_at := NULL;
            NEW.updated_at := NOW();
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."normalize_user_subscription_v2"() OWNER TO "postgres";


COMMENT ON FUNCTION "public"."normalize_user_subscription_v2"() IS 'Automatically activates the next queued subscription when current expires (trigger-based)';



CREATE OR REPLACE FUNCTION "public"."on_chat_open"("p_match_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_target_lang text;
  v_last_message_id uuid;
  v_msg record;
  v_recipient_gender text;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  SELECT public.normalize_language_code(u.preferred_language)
  INTO v_target_lang
  FROM public.users u
  WHERE u.id = v_user_id
  LIMIT 1;

  IF v_target_lang IS NULL THEN
    RETURN;
  END IF;

  -- Get recipient gender for better translation quality
  SELECT gender INTO v_recipient_gender
  FROM public.users
  WHERE id = v_user_id
  LIMIT 1;

  SELECT c.last_message_id
  INTO v_last_message_id
  FROM public.chats c
  WHERE c.user_id = v_user_id
    AND c.match_id = p_match_id
    AND c.translation_enabled = true
  LIMIT 1;

  IF v_last_message_id IS NULL THEN
    RETURN;
  END IF;

  -- Batch translate remaining incoming messages using edge function
  FOR v_msg IN
    SELECT cm.id, cm.match_id, cm.content_original
    FROM public.chat_messages cm
    WHERE cm.match_id = p_match_id
      AND cm.sender_id <> v_user_id
      AND cm.id <> v_last_message_id
      AND cm.content_original IS NOT NULL
      AND length(trim(cm.content_original)) >= 2
      AND (
        cm.content_translated IS NULL
        OR cm.content_translated = ''
        OR cm.content_translated = 'null'
        OR public.normalize_language_code(cm.translated_target_language) IS DISTINCT FROM v_target_lang
      )
    ORDER BY cm.created_at DESC
    LIMIT 50
  LOOP
    BEGIN
      -- Call translate-proxy edge function for batch translation
      PERFORM public.translate_message_for_user(v_msg.id, v_user_id, v_target_lang);
    EXCEPTION WHEN OTHERS THEN
      NULL;
    END;
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."on_chat_open"("p_match_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."perform_continuous_event_matching"() RETURNS TABLE("event_processed" "uuid", "attendees_found" integer, "matches_created" integer, "status" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    event_record RECORD;
    attendee_count INTEGER := 0;
    match_count INTEGER := 0;
    total_matches INTEGER := 0;
BEGIN
    SET search_path = 'public';

    RAISE NOTICE 'Starting continuous event matching at %', NOW();

    -- Loop through all events that have attendees
    FOR event_record IN
        SELECT DISTINCT e.id, e.event_name, e.start_time
        FROM events e
        INNER JOIN event_attendees ea ON e.id = ea.event_id
        WHERE e.start_time >= CURRENT_DATE  -- Only future or current events
        ORDER BY e.start_time ASC
    LOOP
        RAISE NOTICE 'Processing event: % (ID: %)', event_record.event_name, event_record.id;

        -- Count attendees for this event
        SELECT COUNT(*) INTO attendee_count
        FROM event_attendees
        WHERE event_id = event_record.id;

        RAISE NOTICE 'Event % has % attendees', event_record.id, attendee_count;

        -- Only process if there are at least 2 attendees
        IF attendee_count >= 2 THEN
            -- Perform matching for this event
            BEGIN
                PERFORM perform_event_matching(event_record.id);
                RAISE NOTICE 'Successfully processed matching for event %', event_record.id;

                -- Count new matches created for this event (rough estimate)
                SELECT COUNT(*) INTO match_count
                FROM matches
                WHERE event_id = event_record.id
                AND created_at >= NOW() - INTERVAL '1 minute';

                total_matches := total_matches + match_count;

                RETURN QUERY SELECT
                    event_record.id,
                    attendee_count,
                    match_count,
                    'processed'::TEXT;

            EXCEPTION WHEN OTHERS THEN
                RAISE WARNING 'Error processing event %: %', event_record.id, SQLERRM;
                RETURN QUERY SELECT
                    event_record.id,
                    attendee_count,
                    0,
                    'error: ' || SQLERRM;
            END;
        ELSE
            RAISE NOTICE 'Skipping event % - not enough attendees (% < 2)', event_record.id, attendee_count;
            RETURN QUERY SELECT
                event_record.id,
                attendee_count,
                0,
                'skipped: insufficient attendees'::TEXT;
        END IF;
    END LOOP;

    RAISE NOTICE 'Continuous event matching completed. Total matches created: %', total_matches;

    -- Return summary if no events were processed
    IF NOT FOUND THEN
        RETURN QUERY SELECT
            NULL::UUID,
            0,
            total_matches,
            'no events to process'::TEXT;
    END IF;
END;
$$;


ALTER FUNCTION "public"."perform_continuous_event_matching"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."perform_continuous_user_matching"() RETURNS TABLE("users_processed" integer, "matches_created" integer, "status" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    user_record RECORD;
    nearby_user_record RECORD;
    current_user_intents TEXT[];
    current_user_interests JSONB;
    other_user_interests JSONB;
    shared_intents TEXT[];
    has_shared_interest BOOLEAN := FALSE;
    interest_category TEXT;
    total_users_processed INTEGER := 0;
    total_matches_created INTEGER := 0;
    current_user_profile RECORD;
    other_user_profile RECORD;
    current_user_age INTEGER;
    other_user_age INTEGER;
    loop_intent TEXT;
    intent_gender_match BOOLEAN;
    intent_age_match BOOLEAN;
    overall_gender_match BOOLEAN;
    overall_age_match BOOLEAN;
    strict_enforcement BOOLEAN;
    v_a uuid;
    v_b uuid;
BEGIN
    SET search_path = 'public';

    FOR user_record IN
        SELECT
            ul.user_id,
            ul.latitude,
            ul.longitude,
            u.active_modes,
            u.match_radius_default
        FROM user_locations ul
        INNER JOIN users u ON ul.user_id = u.id
        WHERE (EXISTS (SELECT 1 FROM user_activity ua WHERE ua.user_id = u.id AND ua.is_online = TRUE)
          AND COALESCE(u.user_visibility_setting,false) = TRUE
          AND COALESCE(u.system_visibility_status,'visible') = 'visible')
        AND ul.updated_at >= NOW() - INTERVAL '5 minutes'
        ORDER BY ul.updated_at DESC
    LOOP
        total_users_processed := total_users_processed + 1;

        SELECT
            gender,
            date_of_birth,
            gender_preferences,
            age_preferences,
            strict_gender_age_enforcement
        INTO current_user_profile
        FROM users
        WHERE id = user_record.user_id;

        IF current_user_profile.date_of_birth IS NOT NULL THEN
            current_user_age := EXTRACT(YEAR FROM AGE(current_user_profile.date_of_birth));
        END IF;

        SELECT profile_data->'interests' INTO current_user_interests
        FROM user_profiles
        WHERE user_id = user_record.user_id AND profile_data ? 'interests'
        LIMIT 1;

        current_user_intents := user_record.active_modes;

        FOR nearby_user_record IN
            SELECT * FROM find_nearby_users(
                user_record.user_id,
                user_record.latitude,
                user_record.longitude,
                (user_record.match_radius_default / 1000.0)::DOUBLE PRECISION
            )
        LOOP
            v_a := LEAST(user_record.user_id, nearby_user_record.user_id);
            v_b := GREATEST(user_record.user_id, nearby_user_record.user_id);

            IF EXISTS (
                SELECT 1 FROM public.unmatched_pairs up
                WHERE up.user1_id = v_a AND up.user2_id = v_b
            ) THEN
                CONTINUE;
            END IF;

            IF EXISTS (
                SELECT 1 FROM matches
                WHERE (user1_id = user_record.user_id AND user2_id = nearby_user_record.user_id)
                   OR (user1_id = nearby_user_record.user_id AND user2_id = user_record.user_id)
            ) THEN
                CONTINUE;
            END IF;

            SELECT
                gender,
                date_of_birth,
                gender_preferences,
                age_preferences,
                strict_gender_age_enforcement,
                active_modes
            INTO other_user_profile
            FROM users
            WHERE id = nearby_user_record.user_id AND (EXISTS (SELECT 1 FROM user_activity ua WHERE ua.user_id = users.id AND ua.is_online = TRUE)
              AND COALESCE(user_visibility_setting,false) = TRUE
              AND COALESCE(system_visibility_status,'visible') = 'visible');

            IF other_user_profile.active_modes IS NULL OR array_length(other_user_profile.active_modes, 1) = 0 THEN
                CONTINUE;
            END IF;

            IF other_user_profile.date_of_birth IS NOT NULL THEN
                other_user_age := EXTRACT(YEAR FROM AGE(other_user_profile.date_of_birth));
            END IF;

            SELECT ARRAY(
                SELECT intent_item
                FROM unnest(current_user_intents) as t(intent_item)
                WHERE intent_item = ANY(other_user_profile.active_modes)
            ) INTO shared_intents;

            IF array_length(shared_intents, 1) IS NULL OR array_length(shared_intents, 1) = 0 THEN
                CONTINUE;
            END IF;

            has_shared_interest := FALSE;
            IF current_user_interests IS NOT NULL THEN
                SELECT profile_data->'interests' INTO other_user_interests
                FROM user_profiles WHERE user_id = nearby_user_record.user_id AND profile_data ? 'interests' LIMIT 1;

                IF other_user_interests IS NOT NULL THEN
                    FOR interest_category IN SELECT jsonb_object_keys(current_user_interests) INTERSECT SELECT jsonb_object_keys(other_user_interests) LOOP
                        IF jsonb_array_length(current_user_interests->interest_category) > 0 AND jsonb_array_length(other_user_interests->interest_category) > 0 THEN
                            IF EXISTS (
                                SELECT 1
                                FROM jsonb_array_elements_text(current_user_interests->interest_category) as i1
                                WHERE i1 IN (SELECT jsonb_array_elements_text(other_user_interests->interest_category))
                            ) THEN
                                has_shared_interest := TRUE;
                                EXIT;
                            END IF;
                        END IF;
                    END LOOP;
                END IF;
            END IF;

            IF has_shared_interest THEN
                INSERT INTO matches (
                    user1_id, user2_id, matched_intent, match_type, created_at
                ) VALUES (
                    v_a,
                    v_b,
                    shared_intents[1],
                    'proximity',
                    NOW()
                );

                total_matches_created := total_matches_created + 1;
            END IF;
        END LOOP;
    END LOOP;

    RETURN QUERY SELECT total_users_processed, total_matches_created, 'completed'::TEXT;
END;
$$;


ALTER FUNCTION "public"."perform_continuous_user_matching"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."perform_event_matching"("p_event_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
    event_attendee RECORD;
    other_attendee RECORD;
    attendee_a_id uuid;
    attendee_b_id uuid;
    user_a_data RECORD;
    user_b_data RECORD;
    user_a_interests JSONB;
    user_b_interests JSONB;
    shared_intents TEXT[];
    has_shared_interest BOOLEAN := FALSE;
    shared_interest_category TEXT;
    existing_match_id UUID;
BEGIN
    SET search_path = 'public';

    FOR event_attendee IN
        SELECT DISTINCT ea.user_id FROM event_attendees ea WHERE ea.event_id = p_event_id
    LOOP
        attendee_a_id := event_attendee.user_id;

        SELECT active_modes, COALESCE(user_visibility_setting,false) as user_visibility_setting, shared_event_matching_enabled
        INTO user_a_data
        FROM users
        WHERE id = attendee_a_id;

        IF user_a_data IS NULL
           OR NOT user_a_data.shared_event_matching_enabled
           OR user_a_data.active_modes IS NULL
           OR array_length(user_a_data.active_modes, 1) IS NULL THEN
            CONTINUE;
        END IF;

        SELECT COALESCE(jsonb_object_agg(category, interests), '{}'::jsonb)
        INTO user_a_interests
        FROM (
            SELECT
                interest_entry.key AS category,
                interest_entry.value AS interests
            FROM user_profiles up
            CROSS JOIN LATERAL jsonb_each(up.profile_data->'interests') AS interest_entry(key, value)
            WHERE up.user_id = attendee_a_id
              AND up.profile_data ? 'interests'
              AND jsonb_typeof(up.profile_data->'interests') = 'object'
              AND jsonb_typeof(interest_entry.value) = 'array'
        ) interests_data;

        FOR other_attendee IN
            SELECT DISTINCT ea2.user_id FROM event_attendees ea2 WHERE ea2.event_id = p_event_id AND ea2.user_id != attendee_a_id
        LOOP
            attendee_b_id := other_attendee.user_id;

            IF attendee_a_id >= attendee_b_id THEN
                CONTINUE;
            END IF;

            IF EXISTS (
                SELECT 1 FROM public.unmatched_pairs up
                WHERE up.user1_id = attendee_a_id AND up.user2_id = attendee_b_id
            ) THEN
                CONTINUE;
            END IF;

            SELECT id INTO existing_match_id
            FROM matches
            WHERE (user1_id = attendee_a_id AND user2_id = attendee_b_id)
               OR (user1_id = attendee_b_id AND user2_id = attendee_a_id)
            LIMIT 1;

            IF existing_match_id IS NOT NULL THEN
                CONTINUE;
            END IF;

            SELECT active_modes, COALESCE(user_visibility_setting,false) as user_visibility_setting, shared_event_matching_enabled
            INTO user_b_data
            FROM users
            WHERE id = attendee_b_id;

            IF user_b_data IS NULL
               OR NOT user_b_data.shared_event_matching_enabled
               OR user_b_data.active_modes IS NULL
               OR array_length(user_b_data.active_modes, 1) IS NULL THEN
                CONTINUE;
            END IF;

            SELECT ARRAY(
                SELECT intent
                FROM unnest(user_a_data.active_modes) AS t(intent)
                WHERE intent = ANY(user_b_data.active_modes)
            ) INTO shared_intents;

            IF shared_intents IS NULL OR array_length(shared_intents, 1) IS NULL THEN
                CONTINUE;
            END IF;

            SELECT COALESCE(jsonb_object_agg(category, interests), '{}'::jsonb)
            INTO user_b_interests
            FROM (
                SELECT
                    interest_entry.key AS category,
                    interest_entry.value AS interests
                FROM user_profiles up
                CROSS JOIN LATERAL jsonb_each(up.profile_data->'interests') AS interest_entry(key, value)
                WHERE up.user_id = attendee_b_id
                  AND up.profile_data ? 'interests'
                  AND jsonb_typeof(up.profile_data->'interests') = 'object'
                  AND jsonb_typeof(interest_entry.value) = 'array'
            ) interests_data;

            has_shared_interest := FALSE;
            FOR shared_interest_category IN SELECT jsonb_object_keys(user_a_interests) LOOP
                IF user_a_interests ? shared_interest_category AND user_b_interests ? shared_interest_category THEN
                    IF EXISTS (
                        SELECT 1
                        FROM jsonb_array_elements_text(user_a_interests->shared_interest_category) AS user_a_interest
                        WHERE user_a_interest = ANY(SELECT jsonb_array_elements_text(user_b_interests->shared_interest_category))
                    ) THEN
                        has_shared_interest := TRUE;
                        EXIT;
                    END IF;
                END IF;
            END LOOP;

            IF NOT has_shared_interest THEN
                CONTINUE;
            END IF;

            INSERT INTO matches (user1_id, user2_id, match_type, matched_intent, event_id, created_at)
            VALUES (
                attendee_a_id,
                attendee_b_id,
                'event',
                shared_intents[1],
                p_event_id,
                NOW()
            );
        END LOOP;
    END LOOP;
END;
$$;


ALTER FUNCTION "public"."perform_event_matching"("p_event_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."perform_event_matching_debug"("p_event_id" "uuid") RETURNS TABLE("debug_message" "text", "debug_data" "jsonb")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    event_attendee RECORD;
    other_attendee RECORD;
    v_user1_id UUID;
    v_user2_id UUID;
    user_a_data RECORD;
    user_b_data RECORD;
    user_a_interests JSONB;
    user_b_interests JSONB;
    shared_intents TEXT[];
    has_shared_interest BOOLEAN := FALSE;
    shared_interest_category TEXT;
    existing_match_count INTEGER;
BEGIN
    SET search_path = 'public';
    -- Log start
    RETURN QUERY SELECT 'START: Checking event ' || p_event_id::TEXT, jsonb_build_object('event_id', p_event_id);

    -- Get all attendees for this event
    FOR event_attendee IN
        SELECT DISTINCT ea.user_id
        FROM event_attendees ea
        WHERE ea.event_id = p_event_id
    LOOP
        v_user1_id := event_attendee.user_id;
        
        -- Get user A data
        SELECT * INTO user_a_data
        FROM users 
        WHERE id = v_user1_id;

        IF user_a_data IS NULL THEN
            RETURN QUERY SELECT 'SKIP: User A not found', jsonb_build_object('user_id', v_user1_id);
            CONTINUE;
        END IF;

        IF NOT user_a_data.shared_event_matching_enabled THEN
            RETURN QUERY SELECT 'SKIP: User A has event matching disabled', jsonb_build_object('user_id', v_user1_id, 'enabled', user_a_data.shared_event_matching_enabled);
            CONTINUE;
        END IF;

        -- Get first user's interests
        SELECT COALESCE(jsonb_object_agg(category, interests), '{}'::jsonb)
        INTO user_a_interests
        FROM (
            SELECT
                jsonb_object_keys(profile_data->'interests') as category,
                profile_data->'interests'->jsonb_object_keys(profile_data->'interests') as interests
            FROM user_profiles
            WHERE user_id = v_user1_id
            AND profile_data ? 'interests'
        ) interests_data;

        RETURN QUERY SELECT 'USER A data', jsonb_build_object(
            'user_id', v_user1_id,
            'active_modes', user_a_data.active_modes,
            'event_matching_enabled', user_a_data.shared_event_matching_enabled,
            'interests', user_a_interests
        );

        -- Compare with other attendees
        FOR other_attendee IN
            SELECT DISTINCT ea2.user_id
            FROM event_attendees ea2
            WHERE ea2.event_id = p_event_id
            AND ea2.user_id != v_user1_id
        LOOP
            v_user2_id := other_attendee.user_id;

            -- Skip if users are in wrong order
            IF v_user1_id >= v_user2_id THEN
                CONTINUE;
            END IF;

            -- Check if match already exists
            SELECT COUNT(*) INTO existing_match_count
            FROM matches m
            WHERE m.user1_id = v_user1_id AND m.user2_id = v_user2_id;

            IF existing_match_count > 0 THEN
                RETURN QUERY SELECT 'SKIP: Match already exists', jsonb_build_object('user_a', v_user1_id, 'user_b', v_user2_id);
                CONTINUE;
            END IF;

            -- Get second user's data
            SELECT active_modes, shared_event_matching_enabled
            INTO user_b_data
            FROM users
            WHERE id = v_user2_id;

            IF user_b_data IS NULL THEN
                RETURN QUERY SELECT 'SKIP: User B not found', jsonb_build_object('user_id', v_user2_id);
                CONTINUE;
            END IF;

            IF NOT user_b_data.shared_event_matching_enabled THEN
                RETURN QUERY SELECT 'SKIP: User B has event matching disabled', jsonb_build_object('user_id', v_user2_id, 'enabled', user_b_data.shared_event_matching_enabled);
                CONTINUE;
            END IF;

            -- Check shared intents
            SELECT ARRAY(
                SELECT intent
                FROM unnest(user_a_data.active_modes) AS t(intent)
                WHERE intent = ANY(user_b_data.active_modes)
            ) INTO shared_intents;

            IF shared_intents IS NULL OR array_length(shared_intents, 1) IS NULL THEN
                RETURN QUERY SELECT 'SKIP: No shared intents', jsonb_build_object(
                    'user_a_intents', user_a_data.active_modes,
                    'user_b_intents', user_b_data.active_modes
                );
                CONTINUE;
            END IF;

            -- Get second user's interests
            SELECT COALESCE(jsonb_object_agg(category, interests), '{}'::jsonb)
            INTO user_b_interests
            FROM (
                SELECT
                    jsonb_object_keys(profile_data->'interests') as category,
                    profile_data->'interests'->jsonb_object_keys(profile_data->'interests') as interests
                FROM user_profiles
                WHERE user_id = user2_id
                AND profile_data ? 'interests'
            ) interests_data;

            RETURN QUERY SELECT 'USER B data', jsonb_build_object(
                'user_id', user2_id,
                'active_modes', user_b_data.active_modes,
                'event_matching_enabled', user_b_data.shared_event_matching_enabled,
                'interests', user_b_interests
            );

            -- Check for shared interests
            has_shared_interest := FALSE;
            FOR shared_interest_category IN
                SELECT jsonb_object_keys(user_a_interests)
            LOOP
                IF user_a_interests ? shared_interest_category AND user_b_interests ? shared_interest_category THEN
                    IF EXISTS (
                        SELECT 1
                        FROM jsonb_array_elements_text(user_a_interests->shared_interest_category) AS user_a_interest
                        WHERE user_a_interest = ANY(
                            SELECT jsonb_array_elements_text(user_b_interests->shared_interest_category)
                        )
                    ) THEN
                        has_shared_interest := TRUE;
                        RETURN QUERY SELECT 'SHARED INTEREST FOUND', jsonb_build_object(
                            'category', shared_interest_category,
                            'user_a_interests', user_a_interests->shared_interest_category,
                            'user_b_interests', user_b_interests->shared_interest_category
                        );
                        EXIT;
                    END IF;
                END IF;
            END LOOP;

            IF NOT has_shared_interest THEN
                RETURN QUERY SELECT 'SKIP: No shared interests', jsonb_build_object(
                    'user_a_interests', user_a_interests,
                    'user_b_interests', user_b_interests
                );
                CONTINUE;
            END IF;

            -- Create match!
            INSERT INTO matches (user1_id, user2_id, match_type, matched_intent, event_id, created_at)
            VALUES (
                user1_id,
                user2_id,
                'event',
                shared_intents[1],
                p_event_id,
                NOW()
            );

            RETURN QUERY SELECT 'MATCH CREATED!', jsonb_build_object(
                'user_a', user1_id,
                'user_b', user2_id,
                'matched_intent', shared_intents[1],
                'event_id', p_event_id
            );
        END LOOP;
    END LOOP;

    RETURN QUERY SELECT 'END: Function completed', jsonb_build_object('event_id', p_event_id);
END;
$$;


ALTER FUNCTION "public"."perform_event_matching_debug"("p_event_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prevent_duplicate_pending_profile_edit_requests"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  f text;
BEGIN
  IF NEW.status <> 'pending' THEN
    RETURN NEW;
  END IF;

  FOREACH f IN ARRAY COALESCE(NEW.requested_fields, '{}'::text[])
  LOOP
    f := NULLIF(trim(f), '');
    IF f IS NULL THEN
      CONTINUE;
    END IF;

    IF EXISTS (
      SELECT 1
      FROM public.profile_edit_requests r
      WHERE r.user_id = NEW.user_id
        AND r.status = 'pending'
        AND r.requested_fields @> ARRAY[f]
    ) THEN
      RAISE EXCEPTION 'profile_edit_request_already_pending';
    END IF;
  END LOOP;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."prevent_duplicate_pending_profile_edit_requests"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prevent_sensitive_user_field_updates"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF auth.role() = 'service_role' THEN
    RETURN NEW;
  END IF;

  IF NEW.is_admin IS DISTINCT FROM OLD.is_admin THEN
    IF NEW.is_admin IS DISTINCT FROM false THEN
      RAISE EXCEPTION 'Not allowed to set is_admin';
    END IF;
  END IF;

  IF NEW.is_verified IS DISTINCT FROM OLD.is_verified THEN
    IF NEW.is_verified IS DISTINCT FROM false THEN
      RAISE EXCEPTION 'Not allowed to set is_verified';
    END IF;
  END IF;

  IF NEW.verification_similarity_score IS DISTINCT FROM OLD.verification_similarity_score THEN
    IF NEW.verification_similarity_score IS NOT NULL THEN
      RAISE EXCEPTION 'Not allowed to set verification_similarity_score';
    END IF;
  END IF;

  IF NEW.verification_ai_analysis IS DISTINCT FROM OLD.verification_ai_analysis THEN
    IF NEW.verification_ai_analysis IS NOT NULL THEN
      RAISE EXCEPTION 'Not allowed to set verification_ai_analysis';
    END IF;
  END IF;

  IF NEW.verification_auto_rejected IS DISTINCT FROM OLD.verification_auto_rejected THEN
    IF COALESCE(NEW.verification_auto_rejected, false) IS DISTINCT FROM false THEN
      RAISE EXCEPTION 'Not allowed to set verification_auto_rejected';
    END IF;
  END IF;

  IF NEW.verification_reviewed_at IS DISTINCT FROM OLD.verification_reviewed_at THEN
    IF NEW.verification_reviewed_at IS NOT NULL THEN
      RAISE EXCEPTION 'Not allowed to set verification_reviewed_at';
    END IF;
  END IF;

  IF NEW.verification_reviewer_id IS DISTINCT FROM OLD.verification_reviewer_id THEN
    IF NEW.verification_reviewer_id IS NOT NULL THEN
      RAISE EXCEPTION 'Not allowed to set verification_reviewer_id';
    END IF;
  END IF;

  IF NEW.approved_primary_photos IS DISTINCT FROM OLD.approved_primary_photos THEN
    RAISE EXCEPTION 'Not allowed to change approved_primary_photos';
  END IF;

  IF NEW.verification_status IS DISTINCT FROM OLD.verification_status THEN
    IF NEW.verification_status IN ('approved', 'rejected') THEN
      RAISE EXCEPTION 'Not allowed to set verification_status to %', NEW.verification_status;
    END IF;
  END IF;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."prevent_sensitive_user_field_updates"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."process_notification_queue"() RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    notification_record RECORD;
    processed_count INTEGER := 0;
    success BOOLEAN;
BEGIN
    -- Process all pending notifications
    FOR notification_record IN 
        SELECT * FROM notification_queue 
        WHERE status = 'pending' 
        ORDER BY created_at ASC
        LIMIT 100 -- Process up to 100 notifications at a time
    LOOP
        -- Update status to processing
        UPDATE notification_queue 
        SET status = 'processing',
            updated_at = NOW()
        WHERE id = notification_record.id;
        
        -- Simulate FCM notification sending (in production, this would call FCM API)
        -- For now, we'll assume success since the actual FCM integration happens on the client side
        success := TRUE;
        
        IF success THEN
            -- Mark as sent successfully
            UPDATE notification_queue 
            SET status = 'sent', 
                sent_at = NOW(),
                updated_at = NOW()
            WHERE id = notification_record.id;
            
            processed_count := processed_count + 1;
        ELSE
            -- Mark as failed
            UPDATE notification_queue 
            SET status = 'failed', 
                failure_reason = 'FCM API error',
                updated_at = NOW()
            WHERE id = notification_record.id;
        END IF;
    END LOOP;
    
    RETURN processed_count;
END;
$$;


ALTER FUNCTION "public"."process_notification_queue"() OWNER TO "postgres";


COMMENT ON FUNCTION "public"."process_notification_queue"() IS 'Processes pending notifications from the notification queue and updates their status';



CREATE OR REPLACE FUNCTION "public"."profile_edit_requests_set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."profile_edit_requests_set_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."prune_expired_sessions"("p_older_than" interval DEFAULT '30 days'::interval) RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  deleted_count INTEGER := 0;
BEGIN
  SET search_path = 'public';

  DELETE FROM user_session
  WHERE (expires_at IS NOT NULL AND expires_at < NOW() - p_older_than)
  OR (last_active_at < NOW() - p_older_than)
  RETURNING 1 INTO deleted_count;

  RETURN COALESCE(deleted_count, 0);
END;
$$;


ALTER FUNCTION "public"."prune_expired_sessions"("p_older_than" interval) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."queue_fcm_notification"("p_fcm_token" "text", "p_title" "text", "p_body" "text", "p_data" "jsonb" DEFAULT '{}'::"jsonb", "p_platform" "text" DEFAULT 'unknown'::"text") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    notification_id UUID;
BEGIN
    INSERT INTO notification_queue (
        fcm_token, title, body, data, platform
    ) VALUES (
        p_fcm_token, p_title, p_body, p_data, p_platform
    ) RETURNING id INTO notification_id;
    
    RETURN notification_id;
END;
$$;


ALTER FUNCTION "public"."queue_fcm_notification"("p_fcm_token" "text", "p_title" "text", "p_body" "text", "p_data" "jsonb", "p_platform" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."queue_fcm_notification"("p_user_id" "uuid", "p_fcm_token" "text", "p_title" "text", "p_body" "text", "p_data" "jsonb" DEFAULT '{}'::"jsonb", "p_platform" "text" DEFAULT 'unknown'::"text") RETURNS "uuid"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    notification_id UUID;
BEGIN
    INSERT INTO notification_queue (
        user_id, fcm_token, title, body, data, platform
    ) VALUES (
        p_user_id, p_fcm_token, p_title, p_body, p_data, p_platform
    ) RETURNING id INTO notification_id;
    
    RETURN notification_id;
END;
$$;


ALTER FUNCTION "public"."queue_fcm_notification"("p_user_id" "uuid", "p_fcm_token" "text", "p_title" "text", "p_body" "text", "p_data" "jsonb", "p_platform" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."recompute_reaction_summary"("p_message_id" "uuid") RETURNS "jsonb"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  summary jsonb;
BEGIN
  SELECT jsonb_object_agg(reaction, cnt) INTO summary
  FROM (
    SELECT reaction, count(*)::int AS cnt
    FROM public.message_reactions
    WHERE message_id = p_message_id
    GROUP BY reaction
  ) t;

  IF summary IS NULL THEN
    summary := '{}'::jsonb;
  END IF;

  UPDATE public.chat_messages SET reaction_summary = summary WHERE id = p_message_id;
  RETURN summary;
END;
$$;


ALTER FUNCTION "public"."recompute_reaction_summary"("p_message_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."record_ad_click"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text", "p_destination_url" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_id uuid := gen_random_uuid();
BEGIN
  IF v_user_id IS NULL THEN
    RETURN NULL;
  END IF;

  INSERT INTO public.ad_clicks (
    id,
    campaign_id,
    creative_id,
    user_id,
    placement,
    platform,
    locale,
    destination_url
  )
  VALUES (
    v_id,
    p_campaign_id,
    p_creative_id,
    v_user_id,
    p_placement,
    lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web')),
    lower(COALESCE(NULLIF(btrim(p_locale), ''), 'en')),
    p_destination_url
  );

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."record_ad_click"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text", "p_destination_url" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."record_ad_impression"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_id uuid := gen_random_uuid();
BEGIN
  -- Only check that user is authenticated, not whether they "can receive ads"
  -- The user_can_receive_ads check should be done when deciding to SHOW the ad,
  -- not when recording that an impression occurred
  IF v_user_id IS NULL THEN
    RETURN NULL;
  END IF;

  INSERT INTO public.ad_impressions (
    id,
    campaign_id,
    creative_id,
    user_id,
    placement,
    platform,
    locale
  )
  VALUES (
    v_id,
    p_campaign_id,
    p_creative_id,
    v_user_id,
    p_placement,
    lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web')),
    lower(COALESCE(NULLIF(btrim(p_locale), ''), 'en'))
  );

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."record_ad_impression"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."record_ad_revenue"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_user_id" "uuid", "p_placement" "text", "p_platform" "text", "p_revenue_usd" numeric, "p_ad_format" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_id uuid;
BEGIN
  -- Upsert into ad_network_analytics (add revenue)
  INSERT INTO public.ad_network_analytics (
    network_id,
    date,
    placement,
    platform,
    impressions,
    clicks,
    conversions,
    revenue_usd
  )
  VALUES (
    p_network_id,
    CURRENT_DATE,
    p_placement,
    lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web')),
    0,
    0,
    1,
    p_revenue_usd
  )
  ON CONFLICT (network_id, date, placement, platform)
  DO UPDATE SET
    conversions = ad_network_analytics.conversions + 1,
    revenue_usd = ad_network_analytics.revenue_usd + p_revenue_usd,
    updated_at = NOW()
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."record_ad_revenue"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_user_id" "uuid", "p_placement" "text", "p_platform" "text", "p_revenue_usd" numeric, "p_ad_format" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."record_ad_revenue"("p_user_id" "uuid", "p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_event_type" "text", "p_revenue_usd" numeric, "p_ad_format" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_id uuid := gen_random_uuid();
BEGIN
  -- Only service role or admins can record revenue
  IF auth.uid() IS NULL THEN
    RETURN NULL;
  END IF;

  INSERT INTO public.ad_revenue_events (
    id,
    user_id,
    network_id,
    ad_unit_id,
    placement,
    platform,
    event_type,
    revenue_usd,
    ad_format
  )
  VALUES (
    v_id,
    p_user_id,
    p_network_id,
    p_ad_unit_id,
    p_placement,
    lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web')),
    p_event_type,
    p_revenue_usd,
    p_ad_format
  );

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."record_ad_revenue"("p_user_id" "uuid", "p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_event_type" "text", "p_revenue_usd" numeric, "p_ad_format" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."record_external_ad_click"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_impression_id uuid;
  v_platform text := lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web'));
BEGIN
  IF v_user_id IS NULL THEN
    RETURN NULL;
  END IF;

  -- Find the most recent impression for this user/network/placement
  -- and increment its click_count, update last_clicked_at
  UPDATE public.ad_revenue_events
  SET 
    click_count = click_count + 1,
    last_clicked_at = NOW()
  WHERE id = (
    SELECT id
    FROM public.ad_revenue_events
    WHERE user_id = v_user_id
      AND network_id = p_network_id
      AND ad_unit_id = p_ad_unit_id
      AND placement = p_placement
      AND platform = v_platform
      AND event_type = 'impression'
    ORDER BY created_at DESC
    LIMIT 1
  )
  RETURNING id INTO v_impression_id;

  -- If no impression found, create one with click_count = 1
  IF v_impression_id IS NULL THEN
    INSERT INTO public.ad_revenue_events (
      id,
      user_id,
      network_id,
      ad_unit_id,
      placement,
      platform,
      event_type,
      ad_format,
      click_count,
      last_clicked_at
    )
    VALUES (
      gen_random_uuid(),
      v_user_id,
      p_network_id,
      p_ad_unit_id,
      p_placement,
      v_platform,
      'impression',
      p_ad_format,
      1,
      NOW()
    )
    RETURNING id INTO v_impression_id;
  END IF;

  RETURN v_impression_id;
END;
$$;


ALTER FUNCTION "public"."record_external_ad_click"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."record_external_ad_impression"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_id uuid := gen_random_uuid();
BEGIN
  IF v_user_id IS NULL THEN
    RETURN NULL;
  END IF;

  INSERT INTO public.ad_revenue_events (
    id,
    user_id,
    network_id,
    ad_unit_id,
    placement,
    platform,
    event_type,
    ad_format
  )
  VALUES (
    v_id,
    v_user_id,
    p_network_id,
    p_ad_unit_id,
    p_placement,
    lower(COALESCE(NULLIF(btrim(p_platform), ''), 'web')),
    'impression',
    p_ad_format
  );

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."record_external_ad_impression"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."redeem_promo_code"("p_code" "text", "p_user_id" "uuid" DEFAULT "auth"."uid"(), "p_subscription_queue_id" "uuid" DEFAULT NULL::"uuid", "p_discount_value_cents" integer DEFAULT NULL::integer) RETURNS TABLE("success" boolean, "error_message" "text", "usage_id" "uuid", "message" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    SET "row_security" TO 'off'
    AS $$
DECLARE
  v_code_id UUID;
  v_user_id UUID;
  v_usage_id UUID;
  v_max_uses_per_user INT;
  v_user_uses INT := 0;
  v_max_uses INT;
  v_total_uses INT := 0;
BEGIN
  v_user_id := COALESCE(p_user_id, auth.uid());

  IF v_user_id IS NULL THEN
    RETURN QUERY
    SELECT false, 'Not authenticated'::TEXT, NULL::UUID, 'User not authenticated'::TEXT;
    RETURN;
  END IF;

  p_code := UPPER(TRIM(p_code));

  SELECT
    pc.id,
    pc.max_uses_per_user,
    pc.max_uses
  INTO
    v_code_id,
    v_max_uses_per_user,
    v_max_uses
  FROM public.promo_codes AS pc
  WHERE UPPER(pc.code) = p_code
    AND pc.is_active = true;

  IF v_code_id IS NULL THEN
    RETURN QUERY
    SELECT false, 'Invalid or inactive promo code'::TEXT, NULL::UUID, 'The promo code could not be found'::TEXT;
    RETURN;
  END IF;

  SELECT COUNT(*)::INT
  INTO v_user_uses
  FROM public.promo_code_usages AS pcu
  WHERE pcu.promo_code_id = v_code_id
    AND pcu.user_id = v_user_id;

  IF v_user_uses >= v_max_uses_per_user THEN
    RETURN QUERY
    SELECT false, 'Usage limit exceeded'::TEXT, NULL::UUID, 'You have already used this code the maximum number of times'::TEXT;
    RETURN;
  END IF;

  SELECT COUNT(*)::INT
  INTO v_total_uses
  FROM public.promo_code_usages AS pcu
  WHERE pcu.promo_code_id = v_code_id;

  IF v_max_uses IS NOT NULL AND v_total_uses >= v_max_uses THEN
    RETURN QUERY
    SELECT false, 'Code limit reached'::TEXT, NULL::UUID, 'This promo code has reached its usage limit'::TEXT;
    RETURN;
  END IF;

  INSERT INTO public.promo_code_usages (
    promo_code_id,
    user_id,
    subscription_queue_id,
    discount_value_cents,
    applied_tier
  )
  VALUES (
    v_code_id,
    v_user_id,
    p_subscription_queue_id,
    p_discount_value_cents,
    (
      SELECT u.subscription_tier
      FROM public.users AS u
      WHERE u.id = v_user_id
    )
  )
  RETURNING id INTO v_usage_id;

  RETURN QUERY
  SELECT true, NULL::TEXT, v_usage_id, 'Promo code redeemed successfully'::TEXT;
END;
$$;


ALTER FUNCTION "public"."redeem_promo_code"("p_code" "text", "p_user_id" "uuid", "p_subscription_queue_id" "uuid", "p_discount_value_cents" integer) OWNER TO "postgres";


COMMENT ON FUNCTION "public"."redeem_promo_code"("p_code" "text", "p_user_id" "uuid", "p_subscription_queue_id" "uuid", "p_discount_value_cents" integer) IS 'Records a promo code redemption';



CREATE OR REPLACE FUNCTION "public"."report_ad"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_reason" "text", "p_details" "text" DEFAULT NULL::"text") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
  v_id uuid := gen_random_uuid();
BEGIN
  IF v_user_id IS NULL THEN
    RETURN NULL;
  END IF;

  INSERT INTO public.ad_reports (
    id,
    campaign_id,
    creative_id,
    user_id,
    placement,
    reason,
    details
  )
  VALUES (
    v_id,
    p_campaign_id,
    p_creative_id,
    v_user_id,
    p_placement,
    COALESCE(NULLIF(btrim(p_reason), ''), 'user_reported'),
    NULLIF(btrim(COALESCE(p_details, '')), '')
  );

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."report_ad"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_reason" "text", "p_details" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."retranslate_last_messages_for_user"("p_user_id" "uuid", "p_target_language" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_chat record;
  v_source_norm text;
  v_target_norm text;
BEGIN
  v_target_norm := public.normalize_language_code(p_target_language);
  IF v_target_norm IS NULL THEN
    RETURN;
  END IF;

  FOR v_chat IN
    SELECT DISTINCT ON (c.match_id)
      c.match_id, c.last_message_id, cm.content_original,
      cm.detected_source_language, cm.translated_target_language,
      cm.content_translated, cm.sender_id
    FROM public.chats c
    LEFT JOIN public.chat_messages cm ON cm.id = c.last_message_id
    WHERE c.user_id = p_user_id
      AND c.translation_enabled = true
      AND c.last_message_id IS NOT NULL
      AND cm.content_original IS NOT NULL
      AND length(trim(cm.content_original)) >= 2
      AND cm.sender_id <> p_user_id
    ORDER BY c.match_id, cm.created_at DESC
  LOOP
    v_source_norm := public.normalize_language_code(v_chat.detected_source_language);
    
    IF v_source_norm IS NOT NULL AND v_source_norm = v_target_norm THEN
      UPDATE public.chat_messages
      SET detected_source_language = COALESCE(detected_source_language, v_source_norm)
      WHERE id = v_chat.last_message_id AND detected_source_language IS NULL;
      CONTINUE;
    END IF;

    IF public.normalize_language_code(v_chat.translated_target_language) = v_target_norm
       AND v_chat.content_translated IS NOT NULL
       AND trim(v_chat.content_translated) != ''
       AND v_chat.content_translated != 'null' THEN
      CONTINUE;
    END IF;

    PERFORM public.translate_message_for_user(v_chat.last_message_id, p_user_id, v_target_norm);
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."retranslate_last_messages_for_user"("p_user_id" "uuid", "p_target_language" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."revoke_all_passkeys"("p_user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Verify user is authenticated and removing their own passkeys
  IF auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Not authorized to revoke passkeys for other users';
  END IF;

  -- Delete all passkey credentials for this user
  -- NOTE: Using passkey_credentials table (not webauthn_credentials)
  DELETE FROM public.passkey_credentials 
  WHERE user_id = p_user_id;

  -- Log the revocation event if audit_log table exists
  BEGIN
    INSERT INTO public.audit_log (user_id, action, timestamp)
    VALUES (p_user_id, 'passkey_revocation', NOW());
  EXCEPTION WHEN OTHERS THEN
    -- Fail silently if audit_log doesn't exist or insert fails
    NULL;
  END;
END;
$$;


ALTER FUNCTION "public"."revoke_all_passkeys"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."revoke_all_user_sessions"("p_user_id" "uuid", "p_terminated_by" "text" DEFAULT 'user'::"text") RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  updated_count INTEGER := 0;
BEGIN
  SET search_path = 'public';

  -- Ensure caller is either service_role or the same user
  IF auth.jwt() ->> 'role' <> 'service_role' THEN
    IF auth.uid() IS NULL OR auth.uid()::uuid <> p_user_id THEN
      RAISE EXCEPTION 'Not authorized to revoke sessions for other users';
    END IF;
  END IF;

  UPDATE user_session
  SET revoked = true, revoked_at = NOW(), terminated_by = p_terminated_by
  WHERE user_id = p_user_id AND revoked = false;

  GET DIAGNOSTICS updated_count = ROW_COUNT;
  RETURN COALESCE(updated_count, 0);
END;
$$;


ALTER FUNCTION "public"."revoke_all_user_sessions"("p_user_id" "uuid", "p_terminated_by" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."revoke_user_session"("p_session_id" "uuid", "p_terminated_by" "text" DEFAULT 'user'::"text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  SET search_path = 'public';

  -- Only allow revoking if caller is service_role or owns the session
  UPDATE user_session
  SET revoked = true, revoked_at = NOW(), terminated_by = p_terminated_by
  WHERE id = p_session_id
    AND (
      auth.jwt() ->> 'role' = 'service_role'
      OR user_id = auth.uid()::uuid
    );
END;
$$;


ALTER FUNCTION "public"."revoke_user_session"("p_session_id" "uuid", "p_terminated_by" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."scheduled_subscription_normalization"() RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.trigger_subscription_normalization();
END;
$$;


ALTER FUNCTION "public"."scheduled_subscription_normalization"() OWNER TO "postgres";


COMMENT ON FUNCTION "public"."scheduled_subscription_normalization"() IS 'Scheduled job that runs every 5 minutes to normalize all expired subscriptions';



CREATE OR REPLACE FUNCTION "public"."scheduled_verification_photo_cleanup"() RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.cleanup_expired_verification_photos();
END;
$$;


ALTER FUNCTION "public"."scheduled_verification_photo_cleanup"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."send_admin_broadcast"("broadcast_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  broadcast_record public.admin_broadcasts%ROWTYPE;
  target_user RECORD;
  notification_count integer := 0;
  c jsonb;
BEGIN
  SELECT * INTO broadcast_record FROM public.admin_broadcasts WHERE id = broadcast_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Broadcast not found';
  END IF;

  c := public.normalize_broadcast_filter_criteria(broadcast_record.filter_criteria);

  UPDATE public.admin_broadcasts
  SET status = 'sending',
      sent_at = NOW(),
      filter_criteria = c
  WHERE id = broadcast_id;

  FOR target_user IN SELECT * FROM public.get_users_for_broadcast(c)
  LOOP
    INSERT INTO public.admin_broadcast_deliveries (broadcast_id, user_id, fcm_token)
    VALUES (broadcast_id, target_user.user_id, target_user.fcm_token);

    PERFORM public.queue_fcm_notification(
      target_user.user_id,
      target_user.fcm_token,
      broadcast_record.title,
      broadcast_record.message,
      jsonb_build_object(
        'type', 'admin_broadcast',
        'broadcast_id', broadcast_id,
        'action_url', broadcast_record.action_url,
        'action_url_text', broadcast_record.action_url_text
      ),
      target_user.platform
    );

    notification_count := notification_count + 1;
  END LOOP;

  UPDATE public.admin_broadcasts
  SET target_user_count = notification_count,
      actual_sent_count = notification_count,
      status = 'sent'
  WHERE id = broadcast_id;

  DELETE FROM public.notification_queue
  WHERE created_at < NOW() - INTERVAL '7 days'
    AND status IN ('sent', 'failed');
END;
$$;


ALTER FUNCTION "public"."send_admin_broadcast"("broadcast_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."send_chat_message"("p_match_id" "uuid", "p_content_original" "text", "p_reply_to_message_id" "uuid" DEFAULT NULL::"uuid") RETURNS "public"."chat_messages"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid;
  v_row public.chat_messages;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF p_match_id IS NULL THEN
    RAISE EXCEPTION 'match_id required';
  END IF;

  IF p_content_original IS NULL OR length(trim(p_content_original)) < 1 THEN
    RAISE EXCEPTION 'content_original required';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.matches m
    WHERE m.id = p_match_id
      AND (m.user1_id = v_user_id OR m.user2_id = v_user_id)
  ) THEN
    RAISE EXCEPTION 'Not a participant in match';
  END IF;

  INSERT INTO public.chat_messages (
    match_id,
    sender_id,
    content_original,
    reply_to_message_id
  )
  VALUES (
    p_match_id,
    v_user_id,
    p_content_original,
    p_reply_to_message_id
  )
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$$;


ALTER FUNCTION "public"."send_chat_message"("p_match_id" "uuid", "p_content_original" "text", "p_reply_to_message_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_chat_translation"("p_user_id" "uuid", "p_match_id" "uuid", "p_enabled" boolean, "p_language" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  other uuid;
BEGIN
  -- Derive the other participant for this match
  SELECT CASE WHEN m.user1_id = p_user_id THEN m.user2_id ELSE m.user1_id END INTO other
  FROM public.matches m WHERE m.id = p_match_id;

  IF other IS NULL THEN
    RAISE EXCEPTION 'match % not found for user %', p_match_id, p_user_id;
  END IF;

  -- Ensure an upsert exists for this user+match
  INSERT INTO public.chats (user_id, match_id, other_user_id, last_message_id, last_message_preview, last_message_at, unread_count, created_at, updated_at, translation_enabled, translation_language)
  VALUES (p_user_id, p_match_id, other, NULL, NULL, NULL, 0, now(), now(), p_enabled, p_language)
  ON CONFLICT (user_id, match_id) DO UPDATE
  SET translation_enabled = COALESCE(EXCLUDED.translation_enabled, chats.translation_enabled),
      translation_language = EXCLUDED.translation_language,
      updated_at = GREATEST(chats.updated_at, EXCLUDED.updated_at);
END;
$$;


ALTER FUNCTION "public"."set_chat_translation"("p_user_id" "uuid", "p_match_id" "uuid", "p_enabled" boolean, "p_language" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_currency_exchange_rates_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_currency_exchange_rates_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_match_met_answer"("p_match_id" "uuid", "p_met" boolean, "p_repeat_delay_seconds" integer) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM public.matches m
    WHERE m.id = p_match_id AND (m.user1_id = auth.uid() OR m.user2_id = auth.uid())
  ) THEN
    RAISE EXCEPTION 'not_a_match_participant';
  END IF;

  INSERT INTO public.match_rating_prompts (match_id, user_id, met_answer, met_confirmed, met_answered_at, next_prompt_at)
  VALUES (
    p_match_id,
    auth.uid(),
    p_met,
    p_met,
    now(),
    CASE WHEN p_met THEN NULL ELSE now() + make_interval(secs => p_repeat_delay_seconds) END
  )
  ON CONFLICT (match_id, user_id) DO UPDATE SET
    met_answer = EXCLUDED.met_answer,
    met_confirmed = EXCLUDED.met_confirmed,
    met_answered_at = EXCLUDED.met_answered_at,
    next_prompt_at = EXCLUDED.next_prompt_at;
END;
$$;


ALTER FUNCTION "public"."set_match_met_answer"("p_match_id" "uuid", "p_met" boolean, "p_repeat_delay_seconds" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_message_reaction"("p_message_id" "uuid", "p_reaction" "text") RETURNS "jsonb"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  my_user uuid := auth.uid();
  new_summary jsonb;
BEGIN
  IF my_user IS NULL THEN
    RAISE EXCEPTION 'unauthenticated';
  END IF;

  IF p_reaction IS NULL THEN
    DELETE FROM public.message_reactions WHERE message_id = p_message_id AND user_id = my_user;
  ELSE
    INSERT INTO public.message_reactions (message_id, user_id, reaction)
    VALUES (p_message_id, my_user, p_reaction)
    ON CONFLICT (message_id, user_id) DO UPDATE SET reaction = EXCLUDED.reaction, created_at = now();
  END IF;

  SELECT public.recompute_reaction_summary(p_message_id) INTO new_summary;
  RETURN new_summary;
END;
$$;


ALTER FUNCTION "public"."set_message_reaction"("p_message_id" "uuid", "p_reaction" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_promo_codes_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_promo_codes_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_row_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."set_row_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_user_offline"("p_user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    user_exists BOOLEAN;
BEGIN
    SET search_path = 'public';
    
    -- Check if user exists before attempting update
    SELECT EXISTS(SELECT 1 FROM users WHERE id = p_user_id)
    INTO user_exists;
    
    IF NOT user_exists THEN
        -- User has been deleted; silently return
        RETURN;
    END IF;
    
    -- Update existing record if exists
    UPDATE user_activity 
    SET is_online = false, 
        updated_at = NOW() 
    WHERE user_id = p_user_id;
    
    -- Insert if no record exists
    INSERT INTO user_activity (
        user_id, 
        last_activity, 
        is_online, 
        is_visible,
        updated_at
    )
    SELECT 
        p_user_id, 
        NOW(), 
        false, 
        COALESCE(u.user_visibility_setting, false),
        NOW()
    FROM users u
    WHERE u.id = p_user_id
    ON CONFLICT (user_id)
    DO UPDATE SET
        is_online = false,
        updated_at = NOW();
END;
$$;


ALTER FUNCTION "public"."set_user_offline"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."should_delete_match_messages"("p_match_id" "uuid") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  -- Return true if no users have this chat in their chats table
  RETURN NOT EXISTS (
    SELECT 1 FROM public.chats
    WHERE match_id = p_match_id
  );
END;
$$;


ALTER FUNCTION "public"."should_delete_match_messages"("p_match_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."should_translate_message"("p_message_language" "text", "p_ui_language" "text", "p_translation_enabled" boolean, "p_existing_translation_language" "text" DEFAULT NULL::"text") RETURNS boolean
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- If translation is disabled, never translate
  IF p_translation_enabled IS NOT TRUE THEN
    RETURN FALSE;
  END IF;

  -- Normalize languages (handle 'iw' -> 'he')
  p_message_language := CASE WHEN p_message_language = 'iw' THEN 'he' ELSE p_message_language END;
  p_ui_language := CASE WHEN p_ui_language = 'iw' THEN 'he' ELSE p_ui_language END;
  p_existing_translation_language := CASE WHEN p_existing_translation_language = 'iw' THEN 'he' ELSE p_existing_translation_language END;

  -- If UI language matches source language, show original (don't translate)
  IF p_message_language = p_ui_language THEN
    RETURN FALSE;
  END IF;

  -- If existing translation matches UI language, reuse it (don't re-translate)
  IF p_existing_translation_language IS NOT NULL AND p_existing_translation_language = p_ui_language THEN
    RETURN FALSE;
  END IF;

  -- Otherwise, translation is needed
  RETURN TRUE;
END;
$$;


ALTER FUNCTION "public"."should_translate_message"("p_message_language" "text", "p_ui_language" "text", "p_translation_enabled" boolean, "p_existing_translation_language" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."should_translate_message"("p_source_lang" "text", "p_target_lang" "text", "p_existing_target_lang" "text", "p_existing_content" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
  v_source_norm text;
  v_target_norm text;
  v_existing_target_norm text;
BEGIN
  v_target_norm := public.normalize_language_code(p_target_lang);
  IF v_target_norm IS NULL THEN
    RETURN false;
  END IF;

  v_source_norm := public.normalize_language_code(p_source_lang);
  
  -- If source is same as target, we don't need translation (we need to clear it, which is handled separately)
  IF v_source_norm IS NOT NULL AND v_source_norm = v_target_norm THEN
    RETURN false;
  END IF;

  v_existing_target_norm := public.normalize_language_code(p_existing_target_lang);
  
  -- If already translated to target, and content is present, no need to translate
  IF v_existing_target_norm = v_target_norm 
     AND p_existing_content IS NOT NULL 
     AND length(trim(p_existing_content)) > 0 
     AND p_existing_content != 'null' THEN
    RETURN false;
  END IF;

  RETURN true;
END;
$$;


ALTER FUNCTION "public"."should_translate_message"("p_source_lang" "text", "p_target_lang" "text", "p_existing_target_lang" "text", "p_existing_content" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."submit_match_rating"("p_match_id" "uuid", "p_q1" integer, "p_q2" integer, "p_q3" integer, "p_q4" integer, "p_q5" integer) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_other uuid;
BEGIN
  SELECT CASE WHEN m.user1_id = auth.uid() THEN m.user2_id ELSE m.user1_id END
    INTO v_other
  FROM public.matches m
  WHERE m.id = p_match_id AND (m.user1_id = auth.uid() OR m.user2_id = auth.uid());

  IF v_other IS NULL THEN
    RAISE EXCEPTION 'not_a_match_participant';
  END IF;

  INSERT INTO public.match_ratings (match_id, rater_id, ratee_id, q1, q2, q3, q4, q5)
  VALUES (p_match_id, auth.uid(), v_other, p_q1, p_q2, p_q3, p_q4, p_q5);

  INSERT INTO public.match_rating_prompts (match_id, user_id, met_answer, met_confirmed, met_answered_at, rating_submitted_at, next_prompt_at)
  VALUES (p_match_id, auth.uid(), true, true, now(), now(), NULL)
  ON CONFLICT (match_id, user_id) DO UPDATE SET
    met_answer = true,
    met_confirmed = true,
    met_answered_at = COALESCE(public.match_rating_prompts.met_answered_at, now()),
    rating_submitted_at = now(),
    next_prompt_at = NULL;
END;
$$;


ALTER FUNCTION "public"."submit_match_rating"("p_match_id" "uuid", "p_q1" integer, "p_q2" integer, "p_q3" integer, "p_q4" integer, "p_q5" integer) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."sync_users_on_auth_change"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.users (id, email, created_at, updated_at)
    VALUES (NEW.id, NEW.email, NEW.created_at, NEW.updated_at)
    ON CONFLICT (id) DO NOTHING;
    RETURN NEW;
  ELSIF TG_OP = 'UPDATE' THEN
    UPDATE public.users SET
      email = NEW.email,
      updated_at = NEW.updated_at
    WHERE id = NEW.id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    DELETE FROM public.users WHERE id = OLD.id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."sync_users_on_auth_change"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."test_get_external_ad"() RETURNS TABLE("id" "uuid", "network_id" "uuid", "placement" "text", "platform" "text", "ad_format" "text", "ad_unit_id" "text", "is_active" boolean, "priority" integer)
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  -- Same logic but without auth.uid() check
  SELECT
    u.id,
    u.network_id,
    u.placement,
    u.platform,
    u.ad_format,
    u.ad_unit_id,
    u.is_active,
    u.priority
  FROM public.ad_networks n
  INNER JOIN public.ad_units u ON u.network_id = n.id
  WHERE n.is_enabled = true
    AND u.is_active = true
    AND u.placement = 'home_inline'
    AND u.platform = 'web'
  ORDER BY n.priority ASC, u.priority ASC
  LIMIT 1;
$$;


ALTER FUNCTION "public"."test_get_external_ad"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."touch_admin_dashboard_tick"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  UPDATE public.admin_dashboard_tick
  SET
    updated_at = now(),
    last_table = TG_TABLE_NAME,
    last_op = TG_OP
  WHERE id = 1;

  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."touch_admin_dashboard_tick"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."touch_user_session"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.last_active_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."touch_user_session"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."translate_message_for_user"("p_message_id" "uuid", "p_user_id" "uuid", "p_target_language" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_target_norm text;
  v_msg record;
  v_edge_response jsonb;
  v_translated_text text;
  v_detected_source text;
  v_source_norm text;
  v_recipient_gender text;
  v_match_id uuid;
  v_sender_id uuid;
BEGIN
  RAISE NOTICE '=== translate_message_for_user START ===';
  
  -- Normalize target language
  v_target_norm := public.normalize_language_code(p_target_language);
  RAISE NOTICE 'Target normalized to: %', v_target_norm;
  
  IF v_target_norm IS NULL THEN
    RAISE NOTICE 'Target normalization failed';
    RETURN;
  END IF;

  -- Get message
  SELECT id, match_id, sender_id, content_original,
         content_translated, detected_source_language,
         translated_target_language
  INTO v_msg
  FROM public.chat_messages 
  WHERE id = p_message_id;

  IF NOT FOUND THEN
    RAISE NOTICE 'Message not found: %', p_message_id;
    RETURN;
  END IF;

  RAISE NOTICE 'Message found: sender=%, content=%, source_lang=%, target_lang=%', 
    v_msg.sender_id, v_msg.content_original, v_msg.detected_source_language, v_msg.translated_target_language;

  IF v_msg.content_original IS NULL OR length(trim(v_msg.content_original)) < 2 THEN
    RAISE NOTICE 'Message too short';
    RETURN;
  END IF;

  -- Check if sender is user (skip own messages)
  IF v_msg.sender_id = p_user_id THEN
    RAISE NOTICE 'Skipping own message';
    RETURN;
  END IF;

  v_match_id := v_msg.match_id;
  v_sender_id := v_msg.sender_id;

  -- Check if user is in match
  IF NOT EXISTS (
    SELECT 1 FROM public.matches m
    WHERE m.id = v_match_id
      AND (m.user1_id = p_user_id OR m.user2_id = p_user_id)
  ) THEN
    RAISE NOTICE 'User not in match';
    RETURN;
  END IF;
  RAISE NOTICE 'User in match - OK';

  -- Check translation enabled
  IF NOT EXISTS (
    SELECT 1 FROM public.chats c
    WHERE c.user_id = p_user_id
      AND c.match_id = v_match_id
      AND c.translation_enabled = true
  ) THEN
    RAISE NOTICE 'Translation not enabled';
    RETURN;
  END IF;
  RAISE NOTICE 'Translation enabled - OK';

  -- Normalize source
  v_source_norm := public.normalize_language_code(v_msg.detected_source_language);
  RAISE NOTICE 'Source: %, Target: %', v_source_norm, v_target_norm;
  
  -- Case B: Source = Target
  IF v_source_norm IS NOT NULL AND v_source_norm = v_target_norm THEN
    RAISE NOTICE 'Case B: Source = Target, showing original';
    UPDATE public.chat_messages
    SET detected_source_language = COALESCE(detected_source_language, v_source_norm)
    WHERE id = p_message_id AND detected_source_language IS NULL;
    RETURN;
  END IF;

  -- Case C: Already translated to target
  IF public.normalize_language_code(v_msg.translated_target_language) = v_target_norm
     AND v_msg.content_translated IS NOT NULL
     AND trim(v_msg.content_translated) != ''
     AND v_msg.content_translated != 'null' THEN
    RAISE NOTICE 'Case C: Already translated to target, reusing';
    UPDATE public.chat_messages
    SET detected_source_language = COALESCE(detected_source_language, v_source_norm)
    WHERE id = p_message_id AND detected_source_language IS NULL;
    RETURN;
  END IF;

  -- Case A: Need translation
  RAISE NOTICE 'Case A: Need translation from % to %', v_source_norm, v_target_norm;
  
  -- Get recipient gender
  SELECT gender INTO v_recipient_gender FROM public.users WHERE id = p_user_id LIMIT 1;

  -- Call edge function
  RAISE NOTICE 'Calling edge function...';
  v_edge_response := public.call_translate_proxy_edge_function(
    v_msg.content_original,
    v_target_norm,
    'auto'::text,
    v_msg.id,
    v_match_id,
    v_recipient_gender
  );
  
  RAISE NOTICE 'Edge response: %', v_edge_response;

  IF v_edge_response IS NOT NULL THEN
    v_translated_text := public.extract_translation_from_edge_response(v_edge_response);
    v_detected_source := public.extract_source_language_from_edge_response(v_edge_response);
    RAISE NOTICE 'Extracted translation: %, detected source: %', v_translated_text, v_detected_source;

    UPDATE public.chat_messages
    SET content_translated = CASE
          WHEN v_translated_text IS NOT NULL AND v_translated_text != '' THEN v_translated_text
          ELSE NULL
        END,
        translated_target_language = CASE
          WHEN v_translated_text IS NOT NULL AND v_translated_text != '' THEN v_target_norm
          ELSE NULL
        END,
        detected_source_language = COALESCE(public.normalize_language_code(v_detected_source), detected_source_language)
    WHERE id = p_message_id;
    
    RAISE NOTICE 'Translation updated in database';
  ELSE
    RAISE NOTICE 'Edge function returned NULL';
  END IF;
  
  RAISE NOTICE '=== translate_message_for_user END ===';
END;
$$;


ALTER FUNCTION "public"."translate_message_for_user"("p_message_id" "uuid", "p_user_id" "uuid", "p_target_language" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."translate_recent_messages_on_chat_translation_change"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_target_norm text;
  v_msg_id uuid;
BEGIN
  IF TG_OP <> 'UPDATE' THEN
    RETURN NEW;
  END IF;

  IF NOT COALESCE(NEW.translation_enabled, false) THEN
    RETURN NEW;
  END IF;

  IF NEW.translation_language IS NULL OR trim(NEW.translation_language) = '' THEN
    RETURN NEW;
  END IF;

  IF COALESCE(OLD.translation_enabled, false) = COALESCE(NEW.translation_enabled, false)
     AND COALESCE(OLD.translation_language, '') = COALESCE(NEW.translation_language, '') THEN
    RETURN NEW;
  END IF;

  v_target_norm := public.normalize_language_code(NEW.translation_language);
  IF v_target_norm IS NULL THEN
    RETURN NEW;
  END IF;

  FOR v_msg_id IN
    SELECT cm.id
    FROM public.chat_messages cm
    WHERE cm.match_id = NEW.match_id
      AND cm.sender_id <> NEW.user_id
      AND (
        cm.content_translated IS NULL OR trim(cm.content_translated) = '' OR cm.content_translated = 'null'
        OR public.normalize_language_code(cm.translated_target_language) IS DISTINCT FROM v_target_norm
      )
    ORDER BY cm.created_at DESC
    LIMIT 50
  LOOP
    PERFORM public.translate_message_for_user(v_msg_id, NEW.user_id, v_target_norm);
  END LOOP;

  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."translate_recent_messages_on_chat_translation_change"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_lazy_translation"("p_user_id" "uuid", "p_match_id" "uuid", "p_target_language" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  PERFORM public.batch_translate_chat_messages(p_user_id, p_match_id, p_target_language);
END;
$$;


ALTER FUNCTION "public"."trigger_lazy_translation"("p_user_id" "uuid", "p_match_id" "uuid", "p_target_language" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_perform_event_matching"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    SET search_path = 'public';
    IF TG_OP = 'INSERT' THEN
        PERFORM public.perform_event_matching(NEW.event_id);
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_perform_event_matching"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_perform_user_location_matching"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    SET search_path = 'public';
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        PERFORM public.perform_continuous_user_matching();
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_perform_user_location_matching"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_set_timestamp"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    SET search_path = 'public';
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_set_timestamp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_subscription_normalization"() RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT DISTINCT u.id AS user_id
    FROM public.users u
    LEFT JOIN public.user_subscription_queue sq
      ON sq.user_id = u.id
      AND sq.status = 'pending'
      AND sq.starts_at <= now()
    WHERE (u.subscription_tier IS NOT NULL AND u.subscription_tier <> 'free' AND u.subscription_expires_at IS NOT NULL AND u.subscription_expires_at <= now())
       OR sq.id IS NOT NULL
  LOOP
    PERFORM public.normalize_user_subscription_queue(r.user_id);
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."trigger_subscription_normalization"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_update_user_visibility"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
    -- Only trigger on visibility or ban status changes
    IF (OLD.user_visibility_setting IS DISTINCT FROM NEW.user_visibility_setting) OR
       (OLD.system_visibility_status IS DISTINCT FROM NEW.system_visibility_status) THEN
        PERFORM public.update_user_visibility(NEW.id);
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_update_user_visibility"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."trigger_user_proximity_matching"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    current_user_id UUID;
    current_lat DOUBLE PRECISION;
    current_lng DOUBLE PRECISION;
    user_intents TEXT[];
    user_radius INTEGER;
    user_interests JSONB;
    nearby_user RECORD;
    other_user_intents TEXT[];
    other_user_interests JSONB;
    shared_intents TEXT[];
    has_shared_interest BOOLEAN := FALSE;
    interest_category TEXT;
    interest_value TEXT;
    match_reason TEXT := '';
BEGIN
    SET search_path = 'public';

    -- Get the user who just updated their location
    current_user_id := NEW.user_id;
    current_lat := NEW.latitude;
    current_lng := NEW.longitude;

    -- Get current user's profile data
    SELECT
        COALESCE(u.active_modes, '{}'),
        COALESCE(u.match_radius_default, 50)
    INTO user_intents, user_radius
    FROM users u
    WHERE u.id = current_user_id AND u.is_visible = true;

    -- Skip if user is not visible or has no intents
    IF user_intents IS NULL OR array_length(user_intents, 1) = 0 THEN
        RETURN NEW;
    END IF;

    -- Get user's interests
    SELECT jsonb_object_agg(up.intent_type, up.profile_data->'interests')
    INTO user_interests
    FROM user_profiles up
    WHERE up.user_id = current_user_id;

    -- Find nearby users
    FOR nearby_user IN
        SELECT * FROM find_nearby_users(current_user_id, current_lat, current_lng, (user_radius::float / 1000))
    LOOP
        -- Check if match already exists
        IF EXISTS (
            SELECT 1 FROM matches
            WHERE (user1_id = current_user_id AND user2_id = nearby_user.user_id)
               OR (user1_id = nearby_user.user_id AND user2_id = current_user_id)
        ) THEN
            CONTINUE;
        END IF;

        -- Get other user's data
        SELECT
            COALESCE(u.active_modes, '{}')
        INTO other_user_intents
        FROM users u
        WHERE u.id = nearby_user.user_id AND u.is_visible = true;

        -- Skip if other user not visible or has no intents
        IF other_user_intents IS NULL OR array_length(other_user_intents, 1) = 0 THEN
            CONTINUE;
        END IF;

        -- Check for shared intents
        SELECT array_agg(intent)
        INTO shared_intents
        FROM unnest(user_intents) AS u(intent)
        WHERE intent = ANY(other_user_intents);

        -- Check for shared interests if no shared intents
        IF shared_intents IS NULL OR array_length(shared_intents, 1) = 0 THEN
            -- Get other user's interests
            SELECT jsonb_object_agg(up.intent_type, up.profile_data->'interests')
            INTO other_user_interests
            FROM user_profiles up
            WHERE up.user_id = nearby_user.user_id;

            -- Check for shared interests
            has_shared_interest := FALSE;
            IF user_interests IS NOT NULL AND other_user_interests IS NOT NULL THEN
                FOR interest_category IN SELECT jsonb_object_keys(user_interests)
                LOOP
                    IF other_user_interests ? interest_category THEN
                        -- Check if they share any interests in this category
                        FOR interest_value IN SELECT jsonb_array_elements_text(user_interests->interest_category)
                        LOOP
                            IF other_user_interests->interest_category ? interest_value THEN
                                has_shared_interest := TRUE;
                                EXIT;
                            END IF;
                        END LOOP;
                        IF has_shared_interest THEN EXIT; END IF;
                    END IF;
                END LOOP;
            END IF;

            IF NOT has_shared_interest THEN
                CONTINUE;
            END IF;

            match_reason := 'shared_interests';
        ELSE
            match_reason := 'shared_intents';
        END IF;

        -- Create the match
        INSERT INTO matches (
            user1_id,
            user2_id,
            matched_intent,
            match_type,
            created_at
        ) VALUES (
            current_user_id,
            nearby_user.user_id,
            shared_intents[1], -- Use first shared intent as primary
            'proximity',
            NOW()
        );

        -- Log successful match
        RAISE NOTICE 'Created proximity match between % and % via %',
            current_user_id, nearby_user.user_id, match_reason;
    END LOOP;

    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."trigger_user_proximity_matching"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."unmatch_from_system_match"("p_match_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  v_user_id uuid;
  v_user1_id uuid;
  v_user2_id uuid;
  v_match_type text;
  v_a uuid;
  v_b uuid;
BEGIN
  v_user_id := auth.uid();
  IF v_user_id IS NULL THEN
    RAISE EXCEPTION 'Unauthorized';
  END IF;

  SELECT m.user1_id, m.user2_id, m.match_type
  INTO v_user1_id, v_user2_id, v_match_type
  FROM public.matches m
  WHERE m.id = p_match_id;

  IF v_user1_id IS NULL OR v_user2_id IS NULL THEN
    RAISE EXCEPTION 'Match not found';
  END IF;

  IF v_user_id <> v_user1_id AND v_user_id <> v_user2_id THEN
    RAISE EXCEPTION 'Forbidden';
  END IF;

  IF v_match_type NOT IN ('proximity','event','co_motion') THEN
    RAISE EXCEPTION 'Match type not allowed';
  END IF;

  v_a := LEAST(v_user1_id, v_user2_id);
  v_b := GREATEST(v_user1_id, v_user2_id);

  INSERT INTO public.unmatched_pairs (user1_id, user2_id, created_by, created_at, match_type, match_id)
  VALUES (v_a, v_b, v_user_id, now(), v_match_type, p_match_id)
  ON CONFLICT (user1_id, user2_id) DO UPDATE
  SET
    created_by = EXCLUDED.created_by,
    created_at = GREATEST(unmatched_pairs.created_at, EXCLUDED.created_at),
    match_type = COALESCE(unmatched_pairs.match_type, EXCLUDED.match_type),
    match_id = COALESCE(unmatched_pairs.match_id, EXCLUDED.match_id);

  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='chats') THEN
    EXECUTE 'DELETE FROM public.chats WHERE match_id = $1' USING p_match_id;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='user_recent_matches') THEN
    EXECUTE 'DELETE FROM public.user_recent_matches WHERE match_id = $1' USING p_match_id;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='user_recent_chats') THEN
    EXECUTE 'DELETE FROM public.user_recent_chats WHERE match_id = $1' USING p_match_id;
  END IF;
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema='public' AND table_name='chat_messages') THEN
    EXECUTE 'DELETE FROM public.chat_messages WHERE match_id = $1' USING p_match_id;
  END IF;
  EXECUTE 'DELETE FROM public.matches WHERE id = $1' USING p_match_id;
END;
$_$;


ALTER FUNCTION "public"."unmatch_from_system_match"("p_match_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_admin_broadcasts_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_admin_broadcasts_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_app_config_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_app_config_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_match_rating_prompts_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_match_rating_prompts_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_notification_queue_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_notification_queue_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_subscription_tier"("p_tier" "text") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
BEGIN
  UPDATE public.users
  SET subscription_tier = p_tier
  WHERE id = auth.uid();
END;
$$;


ALTER FUNCTION "public"."update_subscription_tier"("p_tier" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_updated_at_column"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_user_activity"("p_user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    is_visible BOOLEAN;
    is_banned BOOLEAN;
    user_exists BOOLEAN;
BEGIN
    SET search_path = 'public';
    
    -- Check if user exists in the users table
    SELECT EXISTS(SELECT 1 FROM users WHERE id = p_user_id)
    INTO user_exists;
    
    -- If user doesn't exist (has been deleted), return early silently
    -- This prevents NULL constraint violations on is_visible
    IF NOT user_exists THEN
        RETURN;
    END IF;
    
    -- Get current visibility and ban status
    SELECT 
        COALESCE(user_visibility_setting, false),
        COALESCE(system_visibility_status, 'visible') = 'banned'
    INTO is_visible, is_banned
    FROM users
    WHERE id = p_user_id;
    
    -- If user is banned, force offline
    IF is_banned THEN
        UPDATE user_activity 
        SET is_online = false, 
            last_activity = NOW(), 
            updated_at = NOW() 
        WHERE user_id = p_user_id;
    ELSE
        -- Update activity with current visibility status
        INSERT INTO user_activity (
            user_id, 
            last_activity, 
            is_online, 
            is_visible,
            updated_at
        )
        VALUES (
            p_user_id, 
            NOW(), 
            true, 
            is_visible,
            NOW()
        )
        ON CONFLICT (user_id) 
        DO UPDATE SET 
            last_activity = NOW(), 
            is_online = true,
            is_visible = EXCLUDED.is_visible,
            updated_at = NOW();
    END IF;
END;
$$;


ALTER FUNCTION "public"."update_user_activity"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_user_ad_consent"("p_personalized_ads" boolean, "p_non_personalized_ads" boolean) RETURNS TABLE("user_id" "uuid", "personalized_ads" boolean, "non_personalized_ads" boolean, "consent_given_at" timestamp with time zone, "consent_version" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_user_id uuid := auth.uid();
BEGIN
  IF v_user_id IS NULL THEN
    RETURN;
  END IF;

  INSERT INTO public.ad_consent (
    user_id,
    personalized_ads,
    non_personalized_ads,
    consent_version
  )
  VALUES (
    v_user_id,
    p_personalized_ads,
    p_non_personalized_ads,
    '1.0'
  )
  ON CONFLICT (user_id) DO UPDATE SET
    personalized_ads = EXCLUDED.personalized_ads,
    non_personalized_ads = EXCLUDED.non_personalized_ads,
    updated_at = NOW();

  RETURN QUERY
  SELECT
    ac.user_id,
    ac.personalized_ads,
    ac.non_personalized_ads,
    ac.consent_given_at,
    ac.consent_version
  FROM public.ad_consent ac
  WHERE ac.user_id = v_user_id;
END;
$$;


ALTER FUNCTION "public"."update_user_ad_consent"("p_personalized_ads" boolean, "p_non_personalized_ads" boolean) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_user_location"("p_user_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_speed" double precision DEFAULT NULL::double precision, "p_heading" double precision DEFAULT NULL::double precision) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    user_exists BOOLEAN;
BEGIN
    SET search_path = 'public';

    -- Check if user still exists before attempting any updates
    -- This prevents foreign key constraint violations on deleted users
    SELECT EXISTS(SELECT 1 FROM users WHERE id = p_user_id)
    INTO user_exists;
    
    IF NOT user_exists THEN
        -- User has been deleted; silently return to avoid errors
        -- The user_locations record will be cascade-deleted when user was deleted
        RETURN;
    END IF;

    INSERT INTO user_locations (user_id, latitude, longitude, speed, heading, updated_at)
    VALUES (p_user_id, p_latitude, p_longitude, p_speed, p_heading, NOW())
    ON CONFLICT (user_id)
    DO UPDATE SET
        latitude = EXCLUDED.latitude,
        longitude = EXCLUDED.longitude,
        speed = EXCLUDED.speed,
        heading = EXCLUDED.heading,
        updated_at = NOW();

    -- Also update user activity to keep them online
    PERFORM update_user_activity(p_user_id);
END;
$$;


ALTER FUNCTION "public"."update_user_location"("p_user_id" "uuid", "p_latitude" double precision, "p_longitude" double precision, "p_speed" double precision, "p_heading" double precision) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_user_presence_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_user_presence_updated_at"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_user_rating_stats"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    target_user_id UUID;
    stats RECORD;
BEGIN
    IF (TG_OP = 'DELETE') THEN
        target_user_id := OLD.rated_id;
    ELSE
        target_user_id := NEW.rated_id;
    END IF;

    -- Calculate new aggregates
    SELECT
        COUNT(*) as total,
        ROUND(AVG(q1), 2) as q1,
        ROUND(AVG(q2), 2) as q2,
        ROUND(AVG(q3), 2) as q3,
        ROUND(AVG(q4), 2) as q4,
        ROUND(AVG(q5), 2) as q5,
        ROUND(AVG(average), 2) as cumulative
    INTO stats
    FROM public.match_ratings
    WHERE rated_id = target_user_id;

    -- Update or Insert stats
    INSERT INTO public.user_rating_stats (
        user_id,
        total_ratings_count,
        q1_avg,
        q2_avg,
        q3_avg,
        q4_avg,
        q5_avg,
        cumulative_avg,
        updated_at
    ) VALUES (
        target_user_id,
        COALESCE(stats.total, 0),
        COALESCE(stats.q1, 0),
        COALESCE(stats.q2, 0),
        COALESCE(stats.q3, 0),
        COALESCE(stats.q4, 0),
        COALESCE(stats.q5, 0),
        COALESCE(stats.cumulative, 0),
        NOW()
    )
    ON CONFLICT (user_id) DO UPDATE SET
        total_ratings_count = EXCLUDED.total_ratings_count,
        q1_avg = EXCLUDED.q1_avg,
        q2_avg = EXCLUDED.q2_avg,
        q3_avg = EXCLUDED.q3_avg,
        q4_avg = EXCLUDED.q4_avg,
        q5_avg = EXCLUDED.q5_avg,
        cumulative_avg = EXCLUDED.cumulative_avg,
        updated_at = NOW();

    RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_user_rating_stats"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."update_user_visibility"("p_user_id" "uuid") RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
    visibility_value BOOLEAN;
BEGIN
    SET search_path = 'public';
    
    -- Get current visibility setting
    SELECT COALESCE(u.user_visibility_setting, false)
    INTO visibility_value
    FROM users u
    WHERE u.id = p_user_id;
    
    -- Update visibility in user_activity
    UPDATE user_activity
    SET is_visible = visibility_value,
        updated_at = NOW()
    WHERE user_id = p_user_id;
    
    -- If no activity record exists, create one
    IF NOT FOUND THEN
        INSERT INTO user_activity (
            user_id,
            last_activity,
            is_online,
            is_visible,
            updated_at
        )
        VALUES (
            p_user_id,
            NOW(),
            false,  -- Not setting online status here
            visibility_value,
            NOW()
        );
    END IF;
END;
$$;


ALTER FUNCTION "public"."update_user_visibility"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_chat_row"("p_user_id" "uuid", "p_match_id" "uuid", "p_other_user_id" "uuid", "p_last_message_id" "uuid" DEFAULT NULL::"uuid", "p_last_message_preview" "text" DEFAULT ''::"text", "p_last_message_at" timestamp with time zone DEFAULT "now"(), "p_unread_increment" integer DEFAULT 0, "p_ts" timestamp with time zone DEFAULT "now"()) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO public.chats (user_id, match_id, other_user_id, last_message_id, last_message_preview, last_message_at, unread_count, created_at, updated_at)
  VALUES (p_user_id, p_match_id, p_other_user_id, p_last_message_id, p_last_message_preview, p_last_message_at, GREATEST(p_unread_increment,0), COALESCE(p_ts, now()), COALESCE(p_ts, now()))
  ON CONFLICT (user_id, match_id) DO UPDATE
  SET
    other_user_id = EXCLUDED.other_user_id,
    last_message_id = COALESCE(EXCLUDED.last_message_id, chats.last_message_id),
    last_message_preview = COALESCE(EXCLUDED.last_message_preview, chats.last_message_preview),
    last_message_at = GREATEST(COALESCE(chats.last_message_at, EXCLUDED.last_message_at), COALESCE(EXCLUDED.last_message_at, chats.last_message_at)),
    -- FIX: Use proper increment instead of broken CASE logic
    unread_count = chats.unread_count + EXCLUDED.unread_count,
    updated_at = GREATEST(chats.updated_at, EXCLUDED.updated_at);
END;
$$;


ALTER FUNCTION "public"."upsert_chat_row"("p_user_id" "uuid", "p_match_id" "uuid", "p_other_user_id" "uuid", "p_last_message_id" "uuid", "p_last_message_preview" "text", "p_last_message_at" timestamp with time zone, "p_unread_increment" integer, "p_ts" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_currency_exchange_rate"("p_base_currency" "text", "p_quote_currency" "text", "p_rate" numeric, "p_source" "text" DEFAULT NULL::"text", "p_fetched_at" timestamp with time zone DEFAULT "now"()) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  INSERT INTO public.currency_exchange_rates (
    base_currency,
    quote_currency,
    rate,
    source,
    fetched_at
  )
  VALUES (
    upper(btrim(p_base_currency)),
    upper(btrim(p_quote_currency)),
    p_rate,
    NULLIF(btrim(COALESCE(p_source, '')), ''),
    COALESCE(p_fetched_at, now())
  )
  ON CONFLICT (base_currency, quote_currency) DO UPDATE
  SET
    rate = EXCLUDED.rate,
    source = EXCLUDED.source,
    fetched_at = EXCLUDED.fetched_at,
    updated_at = now();
END;
$$;


ALTER FUNCTION "public"."upsert_currency_exchange_rate"("p_base_currency" "text", "p_quote_currency" "text", "p_rate" numeric, "p_source" "text", "p_fetched_at" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_currency_exchange_rates_batch"("p_base_currency" "text", "p_rates" "jsonb", "p_source" "text" DEFAULT NULL::"text", "p_fetched_at" timestamp with time zone DEFAULT "now"()) RETURNS integer
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $_$
DECLARE
  v_base_currency text := upper(btrim(COALESCE(p_base_currency, '')));
  v_source text := NULLIF(btrim(COALESCE(p_source, '')), '');
  v_fetched_at timestamptz := COALESCE(p_fetched_at, now());
  v_row record;
  v_rate numeric;
  v_count integer := 0;
BEGIN
  IF v_base_currency !~ '^[A-Z]{3}$' THEN
    RAISE EXCEPTION 'Invalid base currency: %', p_base_currency;
  END IF;

  IF p_rates IS NULL OR jsonb_typeof(p_rates) <> 'object' THEN
    RAISE EXCEPTION 'p_rates must be a JSON object';
  END IF;

  INSERT INTO public.currency_exchange_rates (
    base_currency,
    quote_currency,
    rate,
    source,
    fetched_at
  )
  VALUES (
    v_base_currency,
    v_base_currency,
    1,
    v_source,
    v_fetched_at
  )
  ON CONFLICT (base_currency, quote_currency) DO UPDATE
  SET
    rate = EXCLUDED.rate,
    source = EXCLUDED.source,
    fetched_at = EXCLUDED.fetched_at,
    updated_at = now();

  FOR v_row IN
    SELECT key, value
    FROM jsonb_each_text(p_rates)
  LOOP
    BEGIN
      IF upper(btrim(v_row.key)) !~ '^[A-Z]{3}$' THEN
        CONTINUE;
      END IF;

      v_rate := NULLIF(btrim(v_row.value), '')::numeric;
      IF v_rate IS NULL OR v_rate <= 0 THEN
        CONTINUE;
      END IF;

      INSERT INTO public.currency_exchange_rates (
        base_currency,
        quote_currency,
        rate,
        source,
        fetched_at
      )
      VALUES (
        v_base_currency,
        upper(btrim(v_row.key)),
        v_rate,
        v_source,
        v_fetched_at
      )
      ON CONFLICT (base_currency, quote_currency) DO UPDATE
      SET
        rate = EXCLUDED.rate,
        source = EXCLUDED.source,
        fetched_at = EXCLUDED.fetched_at,
        updated_at = now();

      v_count := v_count + 1;
    EXCEPTION
      WHEN invalid_text_representation THEN
        CONTINUE;
    END;
  END LOOP;

  RETURN v_count + 1;
END;
$_$;


ALTER FUNCTION "public"."upsert_currency_exchange_rates_batch"("p_base_currency" "text", "p_rates" "jsonb", "p_source" "text", "p_fetched_at" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_user_recent_match"("p_user_id" "uuid", "p_match_id" "uuid", "p_other_user_id" "uuid", "p_match_type" "text", "p_matched_intent" "text", "p_activity" timestamp with time zone DEFAULT "now"(), "p_created_at" timestamp with time zone DEFAULT "now"()) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO public.user_recent_matches (user_id, match_id, other_user_id, match_type, matched_intent, last_activity_at, created_at)
  VALUES (p_user_id, p_match_id, p_other_user_id, p_match_type, p_matched_intent, p_activity, p_created_at)
  ON CONFLICT (user_id, match_id) DO UPDATE
  SET
    other_user_id = EXCLUDED.other_user_id,
    match_type = COALESCE(EXCLUDED.match_type, user_recent_matches.match_type),
    matched_intent = COALESCE(EXCLUDED.matched_intent, user_recent_matches.matched_intent),
    last_activity_at = GREATEST(user_recent_matches.last_activity_at, EXCLUDED.last_activity_at),
    created_at = LEAST(user_recent_matches.created_at, EXCLUDED.created_at);
END;
$$;


ALTER FUNCTION "public"."upsert_user_recent_match"("p_user_id" "uuid", "p_match_id" "uuid", "p_other_user_id" "uuid", "p_match_type" "text", "p_matched_intent" "text", "p_activity" timestamp with time zone, "p_created_at" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_user_session"("p_user_id" "uuid", "p_platform" "text", "p_id" "uuid" DEFAULT NULL::"uuid", "p_client_id" "text" DEFAULT NULL::"text", "p_token_hash" "text" DEFAULT NULL::"text", "p_refresh_token_hash" "text" DEFAULT NULL::"text", "p_device_id" "text" DEFAULT NULL::"text", "p_device_model" "text" DEFAULT NULL::"text", "p_user_agent" "text" DEFAULT NULL::"text", "p_ip" "inet" DEFAULT NULL::"inet", "p_country" "text" DEFAULT NULL::"text", "p_expires_at" timestamp with time zone DEFAULT NULL::timestamp with time zone, "p_is_persistent" boolean DEFAULT false, "p_auth_method" "text" DEFAULT NULL::"text", "p_metadata" "jsonb" DEFAULT '{}'::"jsonb") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_id uuid;
  v_platform text;
  v_device_id text;
BEGIN
  v_platform := NULLIF(btrim(COALESCE(p_platform, '')), '');
  IF v_platform IS NULL THEN
    RAISE EXCEPTION 'platform is required';
  END IF;

  v_device_id := NULLIF(btrim(COALESCE(p_device_id, '')), '');

  IF auth.jwt() ->> 'role' <> 'service_role' THEN
    IF auth.uid() IS NULL OR auth.uid()::uuid <> p_user_id THEN
      RAISE EXCEPTION 'Not authorized to create or modify sessions for other users';
    END IF;
  END IF;

  IF v_device_id IS NOT NULL THEN
    INSERT INTO public.user_session (
      id,
      user_id,
      client_id,
      token_hash,
      refresh_token_hash,
      platform,
      device_id,
      device_model,
      user_agent,
      ip,
      country,
      created_at,
      last_active_at,
      expires_at,
      is_persistent,
      auth_method,
      metadata
    )
    VALUES (
      COALESCE(p_id, gen_random_uuid()),
      p_user_id,
      p_client_id,
      p_token_hash,
      p_refresh_token_hash,
      v_platform,
      v_device_id,
      p_device_model,
      p_user_agent,
      p_ip,
      p_country,
      NOW(),
      NOW(),
      p_expires_at,
      p_is_persistent,
      p_auth_method,
      p_metadata
    )
    ON CONFLICT (user_id, platform, device_id)
      WHERE device_id IS NOT NULL AND btrim(device_id) <> ''
    DO UPDATE SET
      client_id = EXCLUDED.client_id,
      token_hash = EXCLUDED.token_hash,
      refresh_token_hash = EXCLUDED.refresh_token_hash,
      device_model = EXCLUDED.device_model,
      user_agent = EXCLUDED.user_agent,
      ip = EXCLUDED.ip,
      country = EXCLUDED.country,
      last_active_at = NOW(),
      expires_at = EXCLUDED.expires_at,
      revoked = false,
      revoked_at = NULL,
      logout_at = NULL,
      terminated_by = NULL,
      is_persistent = EXCLUDED.is_persistent,
      auth_method = EXCLUDED.auth_method,
      metadata = COALESCE(EXCLUDED.metadata, '{}'::jsonb)
    RETURNING id INTO v_id;

    RETURN v_id;
  END IF;

  v_id := COALESCE(p_id, gen_random_uuid());

  INSERT INTO public.user_session (
    id,
    user_id,
    client_id,
    token_hash,
    refresh_token_hash,
    platform,
    device_id,
    device_model,
    user_agent,
    ip,
    country,
    created_at,
    last_active_at,
    expires_at,
    is_persistent,
    auth_method,
    metadata
  )
  VALUES (
    v_id,
    p_user_id,
    p_client_id,
    p_token_hash,
    p_refresh_token_hash,
    v_platform,
    NULL,
    p_device_model,
    p_user_agent,
    p_ip,
    p_country,
    NOW(),
    NOW(),
    p_expires_at,
    p_is_persistent,
    p_auth_method,
    p_metadata
  )
  ON CONFLICT (id)
  DO UPDATE SET
    client_id = EXCLUDED.client_id,
    token_hash = EXCLUDED.token_hash,
    refresh_token_hash = EXCLUDED.refresh_token_hash,
    platform = EXCLUDED.platform,
    device_id = EXCLUDED.device_id,
    device_model = EXCLUDED.device_model,
    user_agent = EXCLUDED.user_agent,
    ip = EXCLUDED.ip,
    country = EXCLUDED.country,
    last_active_at = NOW(),
    expires_at = EXCLUDED.expires_at,
    revoked = EXCLUDED.revoked,
    is_persistent = EXCLUDED.is_persistent,
    auth_method = EXCLUDED.auth_method,
    metadata = COALESCE(EXCLUDED.metadata, '{}'::jsonb);

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."upsert_user_session"("p_user_id" "uuid", "p_platform" "text", "p_id" "uuid", "p_client_id" "text", "p_token_hash" "text", "p_refresh_token_hash" "text", "p_device_id" "text", "p_device_model" "text", "p_user_agent" "text", "p_ip" "inet", "p_country" "text", "p_expires_at" timestamp with time zone, "p_is_persistent" boolean, "p_auth_method" "text", "p_metadata" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."upsert_user_session"("p_user_id" "uuid", "p_platform" "text", "p_id" "uuid" DEFAULT NULL::"uuid", "p_client_id" "text" DEFAULT NULL::"text", "p_token_hash" "text" DEFAULT NULL::"text", "p_refresh_token_hash" "text" DEFAULT NULL::"text", "p_device_id" "text" DEFAULT NULL::"text", "p_device_model" "text" DEFAULT NULL::"text", "p_user_agent" "text" DEFAULT NULL::"text", "p_ip" "inet" DEFAULT NULL::"inet", "p_country" "text" DEFAULT NULL::"text", "p_expires_at" timestamp with time zone DEFAULT NULL::timestamp with time zone, "p_is_persistent" boolean DEFAULT false, "p_auth_method" "text" DEFAULT NULL::"text", "p_mfa_verified" boolean DEFAULT false, "p_metadata" "jsonb" DEFAULT '{}'::"jsonb") RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_id uuid;
  v_platform text;
  v_device_id text;
BEGIN
  v_platform := NULLIF(btrim(COALESCE(p_platform, '')), '');
  IF v_platform IS NULL THEN
    RAISE EXCEPTION 'platform is required';
  END IF;

  v_device_id := NULLIF(btrim(COALESCE(p_device_id, '')), '');

  IF auth.jwt() ->> 'role' <> 'service_role' THEN
    IF auth.uid() IS NULL OR auth.uid()::uuid <> p_user_id THEN
      RAISE EXCEPTION 'Not authorized to create or modify sessions for other users';
    END IF;
  END IF;

  IF v_device_id IS NOT NULL THEN
    INSERT INTO public.user_session (
      id,
      user_id,
      client_id,
      token_hash,
      refresh_token_hash,
      platform,
      device_id,
      device_model,
      user_agent,
      ip,
      country,
      created_at,
      last_active_at,
      expires_at,
      is_persistent,
      auth_method,
      mfa_verified,
      metadata
    )
    VALUES (
      COALESCE(p_id, gen_random_uuid()),
      p_user_id,
      p_client_id,
      p_token_hash,
      p_refresh_token_hash,
      v_platform,
      v_device_id,
      p_device_model,
      p_user_agent,
      p_ip,
      p_country,
      NOW(),
      NOW(),
      p_expires_at,
      p_is_persistent,
      p_auth_method,
      COALESCE(p_mfa_verified, false),
      p_metadata
    )
    ON CONFLICT (user_id, platform, device_id)
    DO UPDATE SET
      client_id = EXCLUDED.client_id,
      token_hash = EXCLUDED.token_hash,
      refresh_token_hash = EXCLUDED.refresh_token_hash,
      device_model = EXCLUDED.device_model,
      user_agent = EXCLUDED.user_agent,
      ip = EXCLUDED.ip,
      country = COALESCE(NULLIF(btrim(EXCLUDED.country), ''), user_session.country),
      last_active_at = NOW(),
      expires_at = EXCLUDED.expires_at,
      revoked = false,
      revoked_at = NULL,
      logout_at = NULL,
      terminated_by = NULL,
      is_persistent = EXCLUDED.is_persistent,
      auth_method = EXCLUDED.auth_method,
      mfa_verified = COALESCE(EXCLUDED.mfa_verified, false),
      metadata = COALESCE(EXCLUDED.metadata, '{}'::jsonb)
    RETURNING id INTO v_id;

    RETURN v_id;
  END IF;

  v_id := COALESCE(p_id, gen_random_uuid());

  INSERT INTO public.user_session (
    id,
    user_id,
    client_id,
    token_hash,
    refresh_token_hash,
    platform,
    device_id,
    device_model,
    user_agent,
    ip,
    country,
    created_at,
    last_active_at,
    expires_at,
    is_persistent,
    auth_method,
    mfa_verified,
    metadata
  )
  VALUES (
    v_id,
    p_user_id,
    p_client_id,
    p_token_hash,
    p_refresh_token_hash,
    v_platform,
    NULL,
    p_device_model,
    p_user_agent,
    p_ip,
    p_country,
    NOW(),
    NOW(),
    p_expires_at,
    p_is_persistent,
    p_auth_method,
    COALESCE(p_mfa_verified, false),
    p_metadata
  )
  ON CONFLICT (id)
  DO UPDATE SET
    client_id = EXCLUDED.client_id,
    token_hash = EXCLUDED.token_hash,
    refresh_token_hash = EXCLUDED.refresh_token_hash,
    platform = EXCLUDED.platform,
    device_id = EXCLUDED.device_id,
    device_model = EXCLUDED.device_model,
    user_agent = EXCLUDED.user_agent,
    ip = EXCLUDED.ip,
    country = COALESCE(NULLIF(btrim(EXCLUDED.country), ''), user_session.country),
    last_active_at = NOW(),
    expires_at = EXCLUDED.expires_at,
    revoked = EXCLUDED.revoked,
    is_persistent = EXCLUDED.is_persistent,
    auth_method = EXCLUDED.auth_method,
    mfa_verified = COALESCE(EXCLUDED.mfa_verified, false),
    metadata = COALESCE(EXCLUDED.metadata, '{}'::jsonb);

  RETURN v_id;
END;
$$;


ALTER FUNCTION "public"."upsert_user_session"("p_user_id" "uuid", "p_platform" "text", "p_id" "uuid", "p_client_id" "text", "p_token_hash" "text", "p_refresh_token_hash" "text", "p_device_id" "text", "p_device_model" "text", "p_user_agent" "text", "p_ip" "inet", "p_country" "text", "p_expires_at" timestamp with time zone, "p_is_persistent" boolean, "p_auth_method" "text", "p_mfa_verified" boolean, "p_metadata" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."user_can_receive_ads"("p_user_id" "uuid") RETURNS boolean
    LANGUAGE "plpgsql" STABLE
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_tier text := 'free';
  v_expires_at timestamptz;
BEGIN
  IF p_user_id IS NULL THEN
    RETURN false;
  END IF;

  SELECT
    COALESCE(NULLIF(lower(btrim(subscription_tier)), ''), 'free'),
    subscription_expires_at
  INTO v_tier, v_expires_at
  FROM public.users
  WHERE id = p_user_id;

  IF NOT FOUND THEN
    RETURN false;
  END IF;

  IF v_tier = 'free' THEN
    RETURN true;
  END IF;

  IF v_expires_at IS NOT NULL AND v_expires_at <= NOW() THEN
    RETURN true;
  END IF;

  RETURN false;
END;
$$;


ALTER FUNCTION "public"."user_can_receive_ads"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."user_presence_join"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Only allow users to update their own presence or functions to update any
  IF auth.uid() IS NOT NULL AND auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Users can only update their own presence';
  END IF;

  INSERT INTO public.user_presence (user_id, is_online, last_seen, updated_at)
  VALUES (p_user_id, TRUE, NOW(), NOW())
  ON CONFLICT (user_id)
  DO UPDATE SET
    is_online = TRUE,
    last_seen = NOW(),
    updated_at = NOW();
END;
$$;


ALTER FUNCTION "public"."user_presence_join"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."user_presence_leave"("p_user_id" "uuid" DEFAULT "auth"."uid"()) RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
BEGIN
  -- Only allow users to update their own presence or functions to update any
  IF auth.uid() IS NOT NULL AND auth.uid() != p_user_id THEN
    RAISE EXCEPTION 'Users can only update their own presence';
  END IF;

  UPDATE public.user_presence
  SET is_online = FALSE, last_seen = NOW(), updated_at = NOW()
  WHERE user_id = p_user_id;
END;
$$;


ALTER FUNCTION "public"."user_presence_leave"("p_user_id" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."validate_promo_code"("p_code" "text", "p_user_id" "uuid" DEFAULT "auth"."uid"(), "p_for_tier" "text" DEFAULT NULL::"text") RETURNS TABLE("valid" boolean, "error_message" "text", "code_id" "uuid", "code_type" "text", "amount" integer, "upgrade_tier" "text", "max_uses_per_user" integer, "current_user_uses" integer, "total_uses" integer, "max_uses" integer)
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_code_id UUID;
  v_code_type TEXT;
  v_amount INT;
  v_upgrade_tier TEXT;
  v_max_uses_per_user INT;
  v_max_uses INT;
  v_user_uses INT := 0;
  v_total_uses INT := 0;
  v_applicable_tiers TEXT[];
  v_is_active BOOLEAN;
  v_valid_from TIMESTAMPTZ;
  v_valid_until TIMESTAMPTZ;
BEGIN
  p_user_id := COALESCE(p_user_id, auth.uid());

  IF p_user_id IS NULL THEN
    RETURN QUERY
    SELECT false, 'Not authenticated'::TEXT, NULL::UUID, NULL::TEXT, NULL::INT, NULL::TEXT, NULL::INT, NULL::INT, NULL::INT, NULL::INT;
    RETURN;
  END IF;

  p_code := UPPER(TRIM(p_code));

  SELECT
    pc.id,
    pc.code_type,
    pc.amount,
    pc.upgrade_tier,
    pc.max_uses_per_user,
    pc.max_uses,
    pc.applicable_tiers,
    pc.is_active,
    pc.valid_from,
    pc.valid_until
  INTO
    v_code_id,
    v_code_type,
    v_amount,
    v_upgrade_tier,
    v_max_uses_per_user,
    v_max_uses,
    v_applicable_tiers,
    v_is_active,
    v_valid_from,
    v_valid_until
  FROM public.promo_codes AS pc
  WHERE UPPER(pc.code) = p_code;

  IF v_code_id IS NULL THEN
    RETURN QUERY
    SELECT false, 'Promo code not found'::TEXT, NULL::UUID, NULL::TEXT, NULL::INT, NULL::TEXT, NULL::INT, NULL::INT, NULL::INT, NULL::INT;
    RETURN;
  END IF;

  IF v_is_active = false THEN
    RETURN QUERY
    SELECT false, 'Promo code is not active'::TEXT, v_code_id, NULL::TEXT, NULL::INT, NULL::TEXT, v_max_uses_per_user, 0::INT, 0::INT, v_max_uses;
    RETURN;
  END IF;

  IF now() < v_valid_from THEN
    RETURN QUERY
    SELECT false, 'Promo code is not yet valid'::TEXT, v_code_id, NULL::TEXT, NULL::INT, NULL::TEXT, v_max_uses_per_user, 0::INT, 0::INT, v_max_uses;
    RETURN;
  END IF;

  IF now() > v_valid_until THEN
    RETURN QUERY
    SELECT false, 'Promo code has expired'::TEXT, v_code_id, NULL::TEXT, NULL::INT, NULL::TEXT, v_max_uses_per_user, 0::INT, 0::INT, v_max_uses;
    RETURN;
  END IF;

  IF p_for_tier IS NOT NULL AND ARRAY_LENGTH(v_applicable_tiers, 1) > 0 THEN
    IF NOT p_for_tier = ANY(v_applicable_tiers) THEN
      RETURN QUERY
      SELECT false, 'This promo code is not applicable for the ' || p_for_tier || ' tier'::TEXT, v_code_id, NULL::TEXT, NULL::INT, NULL::TEXT, v_max_uses_per_user, 0::INT, 0::INT, v_max_uses;
      RETURN;
    END IF;
  END IF;

  SELECT COUNT(*)::INT
  INTO v_total_uses
  FROM public.promo_code_usages AS pcu
  WHERE pcu.promo_code_id = v_code_id;

  IF v_max_uses IS NOT NULL AND v_total_uses >= v_max_uses THEN
    RETURN QUERY
    SELECT false, 'Promo code has reached its usage limit'::TEXT, v_code_id, NULL::TEXT, NULL::INT, NULL::TEXT, v_max_uses_per_user, 0::INT, v_total_uses, v_max_uses;
    RETURN;
  END IF;

  SELECT COUNT(*)::INT
  INTO v_user_uses
  FROM public.promo_code_usages AS pcu
  WHERE pcu.promo_code_id = v_code_id
    AND pcu.user_id = p_user_id;

  IF v_user_uses >= v_max_uses_per_user THEN
    RETURN QUERY
    SELECT false, 'You have already used this promo code the maximum number of times'::TEXT, v_code_id, NULL::TEXT, NULL::INT, NULL::TEXT, v_max_uses_per_user, v_user_uses, v_total_uses, v_max_uses;
    RETURN;
  END IF;

  RETURN QUERY
  SELECT true, NULL::TEXT, v_code_id, v_code_type, v_amount, v_upgrade_tier, v_max_uses_per_user, v_user_uses, v_total_uses, v_max_uses;
END;
$$;


ALTER FUNCTION "public"."validate_promo_code"("p_code" "text", "p_user_id" "uuid", "p_for_tier" "text") OWNER TO "postgres";


COMMENT ON FUNCTION "public"."validate_promo_code"("p_code" "text", "p_user_id" "uuid", "p_for_tier" "text") IS 'Validates a promo code without redeeming it';



CREATE OR REPLACE FUNCTION "public"."verify_email_change_code"("p_user_id" "uuid", "p_code" "text") RETURNS TABLE("success" boolean, "new_email" "text", "message" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
DECLARE
  v_new_email text;
  v_verified_at timestamp with time zone;
BEGIN
  -- Find and verify the code
  SELECT new_email INTO v_new_email
  FROM public.pending_email_changes
  WHERE user_id = p_user_id
    AND verification_code = p_code
    AND expires_at > now()
    AND verified_at IS NULL
    AND completed_at IS NULL;

  IF v_new_email IS NULL THEN
    RETURN QUERY SELECT false, NULL::text, 'Invalid or expired code'::text;
    RETURN;
  END IF;

  -- Mark as verified
  UPDATE public.pending_email_changes
  SET verified_at = now()
  WHERE user_id = p_user_id
    AND verification_code = p_code;

  RETURN QUERY SELECT true, v_new_email, 'Code verified successfully'::text;
END;
$$;


ALTER FUNCTION "public"."verify_email_change_code"("p_user_id" "uuid", "p_code" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."verify_sensitive_action_email_code"("p_user_id" "uuid", "p_email" "text", "p_code" "text") RETURNS TABLE("success" boolean, "message" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
DECLARE
  v_stored_code text;
  v_code_record record;
BEGIN
  -- Find the most recent unused code for this user and email that hasn't expired
  SELECT 
    pgp_sym_decrypt(encrypted_code, 'MATCHME_INTERNAL_SECRET')::text as decrypted_code,
    id,
    expires_at
  INTO v_code_record
  FROM public.sensitive_action_email_codes
  WHERE user_id = p_user_id 
    AND email = LOWER(p_email)
    AND used_at IS NULL
    AND expires_at > now()
  ORDER BY created_at DESC
  LIMIT 1;
  
  -- Check if code was found
  IF v_code_record IS NULL THEN
    RETURN QUERY SELECT false, 'No valid code found for this email';
    RETURN;
  END IF;
  
  -- Compare the provided code with the decrypted stored code
  IF v_code_record.decrypted_code = p_code THEN
    -- Mark the code as used
    UPDATE public.sensitive_action_email_codes
    SET used_at = now()
    WHERE id = v_code_record.id;
    
    RETURN QUERY SELECT true, 'Code verified successfully';
  ELSE
    RETURN QUERY SELECT false, 'Invalid code';
  END IF;
END;
$$;


ALTER FUNCTION "public"."verify_sensitive_action_email_code"("p_user_id" "uuid", "p_email" "text", "p_code" "text") OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ad_campaigns" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "internal_name" "text" NOT NULL,
    "advertiser_name" "text" NOT NULL,
    "destination_url" "text" NOT NULL,
    "moderation_status" "text" DEFAULT 'draft'::"text" NOT NULL,
    "family_safe" boolean DEFAULT true NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "starts_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "ends_at" timestamp with time zone,
    "daily_impression_cap" integer,
    "total_impression_cap" integer,
    "sort_priority" integer DEFAULT 100 NOT NULL,
    "metadata" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_by" "uuid",
    "approved_by" "uuid",
    "approved_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ad_campaigns_daily_cap_positive" CHECK ((("daily_impression_cap" IS NULL) OR ("daily_impression_cap" > 0))),
    CONSTRAINT "ad_campaigns_end_after_start" CHECK ((("ends_at" IS NULL) OR ("ends_at" > "starts_at"))),
    CONSTRAINT "ad_campaigns_moderation_status_check" CHECK (("moderation_status" = ANY (ARRAY['draft'::"text", 'approved'::"text", 'rejected'::"text", 'paused'::"text"]))),
    CONSTRAINT "ad_campaigns_total_cap_positive" CHECK ((("total_impression_cap" IS NULL) OR ("total_impression_cap" > 0)))
);


ALTER TABLE "public"."ad_campaigns" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_campaigns" IS 'Moderated advertising campaigns used for family-safe sponsored content.';



CREATE TABLE IF NOT EXISTS "public"."ad_clicks" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "campaign_id" "uuid" NOT NULL,
    "creative_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "locale" "text" NOT NULL,
    "destination_url" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."ad_clicks" FORCE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_clicks" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_clicks" IS 'Audit trail for sponsored content clicks.';



CREATE TABLE IF NOT EXISTS "public"."ad_creatives" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "campaign_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "headline_key" "text" NOT NULL,
    "body_key" "text",
    "cta_key" "text",
    "sponsor_name_key" "text",
    "image_url" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "sort_priority" integer DEFAULT 100 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ad_creatives_https_image_url" CHECK ((("image_url" IS NULL) OR ("image_url" ~* '^https://'::"text"))),
    CONSTRAINT "ad_creatives_placement_check" CHECK (("placement" = ANY (ARRAY['home_inline'::"text", 'matches_inline'::"text", 'chats_inline'::"text", 'events_inline'::"text", 'profile_inline'::"text"]))),
    CONSTRAINT "ad_creatives_platform_check" CHECK (("platform" = ANY (ARRAY['all'::"text", 'android'::"text", 'ios'::"text", 'web'::"text", 'windows'::"text", 'macos'::"text", 'linux'::"text"])))
);


ALTER TABLE "public"."ad_creatives" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_creatives" IS 'Placement and platform-specific sponsored creative definitions backed by translations.';



CREATE TABLE IF NOT EXISTS "public"."ad_impressions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "campaign_id" "uuid" NOT NULL,
    "creative_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "locale" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."ad_impressions" FORCE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_impressions" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_impressions" IS 'Audit trail for sponsored content impressions.';



CREATE TABLE IF NOT EXISTS "public"."ad_impressions_daily" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "campaign_id" "uuid" NOT NULL,
    "creative_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "locale" "text" NOT NULL,
    "impression_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "impression_count" integer DEFAULT 0 NOT NULL,
    "last_impression_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."ad_impressions_daily" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_impressions_daily" IS 'Daily aggregated counts for sponsored ad impressions. Replaces individual rows in ad_impressions table.';



CREATE TABLE IF NOT EXISTS "public"."ad_network_analytics" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "network_id" "uuid" NOT NULL,
    "date" "date" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "impressions" integer DEFAULT 0 NOT NULL,
    "clicks" integer DEFAULT 0 NOT NULL,
    "conversions" integer DEFAULT 0 NOT NULL,
    "revenue_usd" numeric(12,2) DEFAULT 0 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."ad_network_analytics" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_network_analytics" IS 'Aggregated daily analytics for external ad networks.';



CREATE TABLE IF NOT EXISTS "public"."ad_networks" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider" "text" NOT NULL,
    "display_name" "text" NOT NULL,
    "is_enabled" boolean DEFAULT false NOT NULL,
    "priority" integer DEFAULT 100 NOT NULL,
    "config" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ad_networks_provider_check" CHECK (("provider" = ANY (ARRAY['admob'::"text", 'facebook'::"text", 'applovin'::"text", 'unity'::"text"])))
);

ALTER TABLE ONLY "public"."ad_networks" REPLICA IDENTITY FULL;


ALTER TABLE "public"."ad_networks" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_networks" IS 'External ad network providers (AdMob, Facebook, AppLovin, Unity).';



CREATE TABLE IF NOT EXISTS "public"."ad_reports" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "campaign_id" "uuid" NOT NULL,
    "creative_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "reason" "text" NOT NULL,
    "details" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);

ALTER TABLE ONLY "public"."ad_reports" FORCE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_reports" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_reports" IS 'User-submitted reports for sponsored content moderation review.';



CREATE TABLE IF NOT EXISTS "public"."ad_revenue_daily_stats" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "date" "date" NOT NULL,
    "network_id" "uuid" NOT NULL,
    "ad_unit_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "ad_format" "text" NOT NULL,
    "impressions" bigint DEFAULT 0,
    "clicks" bigint DEFAULT 0,
    "conversions" bigint DEFAULT 0,
    "revenue" numeric(10,2) DEFAULT 0.00,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."ad_revenue_daily_stats" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ad_revenue_events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "network_id" "uuid" NOT NULL,
    "ad_unit_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "event_type" "text" NOT NULL,
    "revenue_usd" numeric(10,6) DEFAULT 0 NOT NULL,
    "currency" "text" DEFAULT 'USD'::"text" NOT NULL,
    "ad_format" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_clicked_at" timestamp with time zone,
    "click_count" integer DEFAULT 0 NOT NULL,
    CONSTRAINT "ad_revenue_events_event_type_check" CHECK (("event_type" = ANY (ARRAY['impression'::"text", 'click'::"text", 'conversion'::"text"])))
);

ALTER TABLE ONLY "public"."ad_revenue_events" REPLICA IDENTITY FULL;


ALTER TABLE "public"."ad_revenue_events" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_revenue_events" IS 'Audit trail for external ad impressions, clicks, and revenue events.';



CREATE TABLE IF NOT EXISTS "public"."app_config" (
    "id" integer NOT NULL,
    "config_key" character varying(100) NOT NULL,
    "config_value" "jsonb",
    "config_type" character varying(50) NOT NULL,
    "category" character varying(50) NOT NULL,
    "description" "text" NOT NULL,
    "is_user_configurable" boolean DEFAULT false,
    "min_value" numeric,
    "max_value" numeric,
    "allowed_values" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."app_config" OWNER TO "postgres";


COMMENT ON TABLE "public"."app_config" IS 'Central configuration table for all app settings. Stores both system-wide configs and default values for user-configurable settings. User-specific overrides are stored in the users table.';



COMMENT ON COLUMN "public"."app_config"."config_key" IS 'Unique identifier for the configuration setting, using dot notation (e.g., gps.battery_low_threshold_percent)';



COMMENT ON COLUMN "public"."app_config"."config_value" IS 'The configuration value stored as JSONB for flexibility. Parse according to config_type.';



COMMENT ON COLUMN "public"."app_config"."config_type" IS 'Data type of the value: number, duration_seconds, boolean, array, string, percentage';



COMMENT ON COLUMN "public"."app_config"."category" IS 'Category grouping: gps, sync, cache, notification, ui, profile, calendar, translation, performance';



COMMENT ON COLUMN "public"."app_config"."is_user_configurable" IS 'If true, users can override this setting in their profile. If false, only admins can change it.';



COMMENT ON COLUMN "public"."app_config"."allowed_values" IS 'Optional JSONB array of allowed values for validation (e.g., [5, 10, 20, 30, 60])';



CREATE OR REPLACE VIEW "public"."ad_system_config_view" WITH ("security_invoker"='on') AS
 SELECT 'internal'::"text" AS "system_type",
    ( SELECT ("app_config"."config_value" = 'true'::"jsonb")
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.enabled'::"text")
         LIMIT 1) AS "is_enabled",
    ( SELECT "app_config"."config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.allowed_placements'::"text")
         LIMIT 1) AS "allowed_placements",
    ( SELECT "app_config"."config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.allowed_tiers'::"text")
         LIMIT 1) AS "allowed_tiers",
    ( SELECT "app_config"."config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.allowed_platforms'::"text")
         LIMIT 1) AS "allowed_platforms",
    ( SELECT ("app_config"."config_value")::integer AS "config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.max_impressions_per_session'::"text")
         LIMIT 1) AS "max_impressions_per_session",
    ( SELECT ("app_config"."config_value")::integer AS "config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.min_minutes_between_impressions'::"text")
         LIMIT 1) AS "min_minutes_between_impressions",
    ( SELECT ("app_config"."config_value")::integer AS "config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.internal.first_impression_delay_seconds'::"text")
         LIMIT 1) AS "first_impression_delay_seconds"
UNION ALL
 SELECT 'external'::"text" AS "system_type",
    ( SELECT ("app_config"."config_value" = 'true'::"jsonb")
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.external.enabled'::"text")
         LIMIT 1) AS "is_enabled",
    ( SELECT "app_config"."config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.external.allowed_placements'::"text")
         LIMIT 1) AS "allowed_placements",
    ( SELECT "app_config"."config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.external.allowed_tiers'::"text")
         LIMIT 1) AS "allowed_tiers",
    ( SELECT "app_config"."config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.external.allowed_platforms'::"text")
         LIMIT 1) AS "allowed_platforms",
    ( SELECT ("app_config"."config_value")::integer AS "config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.external.max_impressions_per_user_per_day'::"text")
         LIMIT 1) AS "max_impressions_per_session",
    ( SELECT ("app_config"."config_value")::integer AS "config_value"
           FROM "public"."app_config"
          WHERE (("app_config"."config_key")::"text" = 'ads.external.max_impressions_per_user_per_hour'::"text")
         LIMIT 1) AS "min_minutes_between_impressions",
    NULL::integer AS "first_impression_delay_seconds";


ALTER VIEW "public"."ad_system_config_view" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ad_system_schedules" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "system_config_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "description" "text",
    "is_active" boolean DEFAULT true NOT NULL,
    "start_date" "date" NOT NULL,
    "end_date" "date",
    "start_time" "text",
    "end_time" "text",
    "days_of_week" "jsonb" DEFAULT '["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]'::"jsonb" NOT NULL,
    "daily_impression_cap" integer,
    "total_impression_cap" integer,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."ad_system_schedules" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_system_schedules" IS 'Complex scheduling rules for ad systems.';



CREATE TABLE IF NOT EXISTS "public"."ad_units" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "network_id" "uuid" NOT NULL,
    "placement" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "ad_unit_id" "text" NOT NULL,
    "ad_format" "text" NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "priority" integer DEFAULT 100 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ad_units_ad_format_check" CHECK (("ad_format" = ANY (ARRAY['banner'::"text", 'interstitial'::"text", 'rewarded'::"text", 'native'::"text"]))),
    CONSTRAINT "ad_units_platform_check" CHECK (("platform" = ANY (ARRAY['android'::"text", 'ios'::"text", 'web'::"text"])))
);

ALTER TABLE ONLY "public"."ad_units" REPLICA IDENTITY FULL;


ALTER TABLE "public"."ad_units" OWNER TO "postgres";


COMMENT ON TABLE "public"."ad_units" IS 'Ad unit configurations for each network, placement, platform, and format combination.';



CREATE TABLE IF NOT EXISTS "public"."admin_broadcast_deliveries" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "broadcast_id" "uuid",
    "user_id" "uuid",
    "fcm_token" "text",
    "delivery_status" "text" DEFAULT 'pending'::"text",
    "delivered_at" timestamp with time zone,
    "failure_reason" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "admin_broadcast_deliveries_delivery_status_check" CHECK (("delivery_status" = ANY (ARRAY['pending'::"text", 'sent'::"text", 'delivered'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."admin_broadcast_deliveries" OWNER TO "postgres";


COMMENT ON TABLE "public"."admin_broadcast_deliveries" IS 'Tracks delivery status of broadcast messages to users';



CREATE TABLE IF NOT EXISTS "public"."admin_broadcasts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "title" "text" NOT NULL,
    "message" "text" NOT NULL,
    "message_type" "text" DEFAULT 'info'::"text",
    "action_url" "text",
    "action_url_text" "text" DEFAULT 'Learn More'::"text",
    "scheduled_at" timestamp with time zone,
    "sent_at" timestamp with time zone,
    "status" "text" DEFAULT 'draft'::"text",
    "filter_criteria" "jsonb" DEFAULT '{}'::"jsonb",
    "target_user_count" integer,
    "actual_sent_count" integer DEFAULT 0,
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "admin_broadcasts_message_type_check" CHECK (("message_type" = ANY (ARRAY['info'::"text", 'warning'::"text", 'promotion'::"text", 'update'::"text"]))),
    CONSTRAINT "admin_broadcasts_status_check" CHECK (("status" = ANY (ARRAY['draft'::"text", 'scheduled'::"text", 'sending'::"text", 'sent'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."admin_broadcasts" OWNER TO "postgres";


COMMENT ON TABLE "public"."admin_broadcasts" IS 'Stores admin broadcast messages with scheduling and filtering';



COMMENT ON COLUMN "public"."admin_broadcasts"."action_url" IS 'Optional URL for user action in broadcast message';



COMMENT ON COLUMN "public"."admin_broadcasts"."action_url_text" IS 'Text to display for the action URL button';



COMMENT ON COLUMN "public"."admin_broadcasts"."filter_criteria" IS 'JSONB object defining user filtering criteria';



CREATE TABLE IF NOT EXISTS "public"."admin_dashboard_tick" (
    "id" integer NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_table" "text",
    "last_op" "text"
);


ALTER TABLE "public"."admin_dashboard_tick" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ai_quota_alert_state" (
    "provider" "text" NOT NULL,
    "metric" "text" NOT NULL,
    "window_key" "text" NOT NULL,
    "severity" "text" NOT NULL,
    "last_sent_at" timestamp with time zone,
    "last_ratio" numeric,
    "last_used" numeric,
    "last_limit" numeric,
    CONSTRAINT "ai_quota_alert_state_severity_check" CHECK (("severity" = ANY (ARRAY['warn'::"text", 'critical'::"text"])))
);


ALTER TABLE "public"."ai_quota_alert_state" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ai_quota_status" (
    "provider" "text" NOT NULL,
    "metric" "text" NOT NULL,
    "window_key" "text" NOT NULL,
    "used" numeric,
    "limit_value" numeric,
    "unit" "text" DEFAULT ''::"text" NOT NULL,
    "status" "text" DEFAULT 'unknown'::"text" NOT NULL,
    "start_time" timestamp with time zone,
    "end_time" timestamp with time zone,
    "details" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ai_quota_status_status_check" CHECK (("status" = ANY (ARRAY['ok'::"text", 'warn'::"text", 'critical'::"text", 'unknown'::"text"])))
);


ALTER TABLE "public"."ai_quota_status" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."app_config_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."app_config_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."app_config_id_seq" OWNED BY "public"."app_config"."id";



CREATE TABLE IF NOT EXISTS "public"."app_gender_options" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "gender_key" "text" NOT NULL,
    "display_name_key" "text" NOT NULL,
    "sort_order" integer DEFAULT 0
);


ALTER TABLE "public"."app_gender_options" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."app_languages" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "language_code" "text" NOT NULL,
    "display_name" "text" NOT NULL,
    "text_direction" "text" DEFAULT 'LTR'::"text"
);


ALTER TABLE "public"."app_languages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."chats" (
    "user_id" "uuid" NOT NULL,
    "match_id" "uuid" NOT NULL,
    "other_user_id" "uuid" NOT NULL,
    "last_message_id" "uuid",
    "last_message_preview" "text",
    "last_message_at" timestamp with time zone,
    "unread_count" integer DEFAULT 0,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "translation_enabled" boolean DEFAULT false NOT NULL,
    "translation_language" "text"
);


ALTER TABLE "public"."chats" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."currency_exchange_rates" (
    "base_currency" "text" NOT NULL,
    "quote_currency" "text" NOT NULL,
    "rate" numeric(20,8) NOT NULL,
    "source" "text",
    "fetched_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "currency_exchange_rates_base_code_check" CHECK (("base_currency" ~ '^[A-Z]{3}$'::"text")),
    CONSTRAINT "currency_exchange_rates_quote_code_check" CHECK (("quote_currency" ~ '^[A-Z]{3}$'::"text")),
    CONSTRAINT "currency_exchange_rates_rate_check" CHECK (("rate" > (0)::numeric))
);


ALTER TABLE "public"."currency_exchange_rates" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."edge_function_invocations" (
    "id" bigint NOT NULL,
    "request_id" "uuid" NOT NULL,
    "function_name" "text" NOT NULL,
    "invoked_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "duration_ms" integer,
    "success" boolean NOT NULL,
    "http_status" integer,
    "error_type" "text",
    "error_message" "text",
    "user_id" "uuid",
    "ai_used" boolean DEFAULT false NOT NULL,
    "ai_provider" "text",
    "ai_model" "text",
    "ai_task" "text",
    "meta" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL
);


ALTER TABLE "public"."edge_function_invocations" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."edge_function_invocations_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."edge_function_invocations_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."edge_function_invocations_id_seq" OWNED BY "public"."edge_function_invocations"."id";



CREATE TABLE IF NOT EXISTS "public"."event_attendees" (
    "event_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."event_attendees" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."events" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "event_name" "text" NOT NULL,
    "event_venue" "text",
    "start_time" timestamp with time zone NOT NULL,
    "end_time" timestamp with time zone NOT NULL,
    "event_link" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "external_calendar_id" "text",
    "external_event_id" "text",
    "external_provider" "text",
    "is_all_day" boolean DEFAULT false NOT NULL,
    "description" "text"
);


ALTER TABLE "public"."events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."intents" (
    "id" bigint NOT NULL,
    "key" "text" NOT NULL,
    "parent_id" bigint,
    "translation_key" "text",
    "sort_order" integer DEFAULT 100,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "is_social" boolean,
    "is_business" boolean
);


ALTER TABLE "public"."intents" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."intents_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."intents_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."intents_id_seq" OWNED BY "public"."intents"."id";



CREATE TABLE IF NOT EXISTS "public"."interests" (
    "id" bigint NOT NULL,
    "key" "text" NOT NULL,
    "translation_key" "text",
    "parent_id" bigint,
    "sort_order" integer DEFAULT 100,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "is_social" boolean,
    "is_business" boolean
);


ALTER TABLE "public"."interests" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."interests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."interests_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."interests_id_seq" OWNED BY "public"."interests"."id";



CREATE TABLE IF NOT EXISTS "public"."match_rating_prompts" (
    "match_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "met_answer" boolean,
    "met_confirmed" boolean DEFAULT false NOT NULL,
    "met_answered_at" timestamp with time zone,
    "next_prompt_at" timestamp with time zone,
    "rating_submitted_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."match_rating_prompts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."match_ratings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "match_id" "uuid" NOT NULL,
    "rater_id" "uuid" NOT NULL,
    "ratee_id" "uuid" NOT NULL,
    "q1" smallint NOT NULL,
    "q2" smallint NOT NULL,
    "q3" smallint NOT NULL,
    "q4" smallint NOT NULL,
    "q5" smallint NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "match_ratings_q1_check" CHECK ((("q1" >= 1) AND ("q1" <= 5))),
    CONSTRAINT "match_ratings_q2_check" CHECK ((("q2" >= 1) AND ("q2" <= 5))),
    CONSTRAINT "match_ratings_q3_check" CHECK ((("q3" >= 1) AND ("q3" <= 5))),
    CONSTRAINT "match_ratings_q4_check" CHECK ((("q4" >= 1) AND ("q4" <= 5))),
    CONSTRAINT "match_ratings_q5_check" CHECK ((("q5" >= 1) AND ("q5" <= 5)))
);


ALTER TABLE "public"."match_ratings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."matches" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "user1_id" "uuid",
    "user2_id" "uuid",
    "matched_intent" "text",
    "match_type" "text",
    "event_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    CONSTRAINT "matches_ordered_users" CHECK (("user1_id" < "user2_id"))
);


ALTER TABLE "public"."matches" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."message_reactions" (
    "message_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "reaction" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."message_reactions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."notification_queue" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "fcm_token" "text" NOT NULL,
    "title" "text" NOT NULL,
    "body" "text" NOT NULL,
    "data" "jsonb" DEFAULT '{}'::"jsonb",
    "platform" "text",
    "status" "text" DEFAULT 'pending'::"text",
    "attempts" integer DEFAULT 0,
    "max_attempts" integer DEFAULT 3,
    "scheduled_at" timestamp with time zone DEFAULT "now"(),
    "sent_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "failure_reason" "text",
    CONSTRAINT "notification_queue_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'processing'::"text", 'sent'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."notification_queue" OWNER TO "postgres";


COMMENT ON TABLE "public"."notification_queue" IS 'Queue for tracking FCM notification status and delivery';



CREATE TABLE IF NOT EXISTS "public"."passkey_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "request_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "email" "text",
    "challenge" "text" NOT NULL,
    "challenge_type" "text" NOT NULL,
    "rp_id" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("timezone"('utc'::"text", "now"()) + '00:10:00'::interval) NOT NULL,
    CONSTRAINT "passkey_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "public"."passkey_challenges" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."passkey_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "text" NOT NULL,
    "public_key" "text" NOT NULL,
    "counter" bigint DEFAULT 0 NOT NULL,
    "rp_id" "text" NOT NULL,
    "transports" "text"[] DEFAULT ARRAY[]::"text"[] NOT NULL,
    "credential_device_type" "text",
    "credential_backed_up" boolean DEFAULT false NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "public"."passkey_credentials" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."pending_email_changes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "new_email" "text" NOT NULL,
    "verification_code" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "completed_at" timestamp with time zone,
    CONSTRAINT "new_email_not_empty" CHECK (("new_email" <> ''::"text")),
    CONSTRAINT "verification_code_not_empty" CHECK (("verification_code" <> ''::"text"))
);


ALTER TABLE "public"."pending_email_changes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."presence_events" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "event_type" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:01:00'::interval) NOT NULL,
    CONSTRAINT "presence_events_event_type_check" CHECK (("event_type" = ANY (ARRAY['offline'::"text", 'online'::"text"])))
);


ALTER TABLE "public"."presence_events" OWNER TO "postgres";


COMMENT ON TABLE "public"."presence_events" IS 'Broadcasts user online/offline events for real-time presence detection. Events expire after 1 minute and are cleaned up automatically.';



CREATE TABLE IF NOT EXISTS "public"."profile_edit_requests" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "user_id" "uuid",
    "requested_fields" "text"[],
    "message" "text",
    "status" "text" DEFAULT 'pending'::"text",
    "attachments" "jsonb" DEFAULT '[]'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "reviewed_at" timestamp with time zone,
    "reviewed_by" "uuid",
    "reviewer_note" "text",
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_seen_at" timestamp with time zone
);


ALTER TABLE "public"."profile_edit_requests" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."promo_code_usages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "promo_code_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "subscription_queue_id" "uuid",
    "redeemed_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "discount_value_cents" integer,
    "applied_tier" "text",
    "ip_address" "text",
    "user_agent" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."promo_code_usages" OWNER TO "postgres";


COMMENT ON TABLE "public"."promo_code_usages" IS 'Tracks redemptions of promo codes';



CREATE TABLE IF NOT EXISTS "public"."promo_codes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "code" "text" NOT NULL,
    "description" "text",
    "code_type" "text" NOT NULL,
    "amount" integer,
    "upgrade_tier" "text",
    "applicable_tiers" "text"[] DEFAULT ARRAY[]::"text"[] NOT NULL,
    "min_tier" "text",
    "max_uses" integer,
    "max_uses_per_user" integer DEFAULT 1 NOT NULL,
    "valid_from" timestamp with time zone DEFAULT "now"() NOT NULL,
    "valid_until" timestamp with time zone DEFAULT ("now"() + '90 days'::interval) NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "campaign_name" "text",
    "created_by" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "promo_codes_code_type_check" CHECK (("code_type" = ANY (ARRAY['discount_percentage'::"text", 'discount_fixed'::"text", 'free_days'::"text", 'tier_upgrade'::"text"]))),
    CONSTRAINT "promo_codes_max_uses_check" CHECK ((("max_uses" IS NULL) OR ("max_uses" >= 1))),
    CONSTRAINT "promo_codes_max_uses_per_user_check" CHECK (("max_uses_per_user" >= 1)),
    CONSTRAINT "promo_codes_valid_range_check" CHECK (("valid_until" >= "valid_from"))
);


ALTER TABLE "public"."promo_codes" OWNER TO "postgres";


COMMENT ON TABLE "public"."promo_codes" IS 'Stores promotional code configurations';



CREATE TABLE IF NOT EXISTS "public"."referral_visits" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referral_code" "text" NOT NULL,
    "ip_address" "text",
    "user_agent" "text",
    "claimed" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "claimed_at" timestamp with time zone
);


ALTER TABLE "public"."referral_visits" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."referrals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "referrer_id" "uuid",
    "referee_id" "uuid",
    "status" "text" DEFAULT 'pending'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "completed_at" timestamp with time zone,
    "device_id" "text",
    CONSTRAINT "referrals_status_check" CHECK (("status" = ANY (ARRAY['pending'::"text", 'completed'::"text"])))
);


ALTER TABLE "public"."referrals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sensitive_action_email_codes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "email" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "used_at" timestamp with time zone,
    "encrypted_code" "bytea",
    CONSTRAINT "email_not_empty" CHECK (("email" <> ''::"text"))
);


ALTER TABLE "public"."sensitive_action_email_codes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."signup_fraud_signals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_id" "uuid",
    "email_hash" "text" NOT NULL,
    "platform" "text" NOT NULL,
    "device_id_hash" "text",
    "install_id_hash" "text",
    "ip_hash" "text",
    "ip_prefix_hash" "text",
    "user_agent_hash" "text",
    "device_model_hash" "text",
    "decision" "text" NOT NULL,
    "reason_code" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    CONSTRAINT "signup_fraud_signals_decision_check" CHECK (("decision" = ANY (ARRAY['allowed'::"text", 'blocked'::"text"])))
);


ALTER TABLE "public"."signup_fraud_signals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."translations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "locale" "text" NOT NULL,
    "key" "text" NOT NULL,
    "value" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."translations" OWNER TO "postgres";


COMMENT ON TABLE "public"."translations" IS 'Updated with promo code translation keys for multi-language support';



CREATE TABLE IF NOT EXISTS "public"."unmatched_pairs" (
    "user1_id" "uuid" NOT NULL,
    "user2_id" "uuid" NOT NULL,
    "created_by" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "match_type" "text",
    "match_id" "uuid",
    CONSTRAINT "unmatched_pairs_ordered_users" CHECK (("user1_id" < "user2_id"))
);


ALTER TABLE "public"."unmatched_pairs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_activity" (
    "user_id" "uuid" NOT NULL,
    "last_activity" timestamp with time zone DEFAULT "now"(),
    "is_online" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "is_visible" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."user_activity" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_intents" (
    "id" bigint NOT NULL,
    "user_id" "uuid" NOT NULL,
    "intent_id" bigint NOT NULL,
    "metadata" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_intents" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."user_intents_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."user_intents_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."user_intents_id_seq" OWNED BY "public"."user_intents"."id";



CREATE TABLE IF NOT EXISTS "public"."user_interests" (
    "id" bigint NOT NULL,
    "user_id" "uuid" NOT NULL,
    "interest_id" bigint NOT NULL,
    "metadata" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_interests" OWNER TO "postgres";


CREATE SEQUENCE IF NOT EXISTS "public"."user_interests_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."user_interests_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."user_interests_id_seq" OWNED BY "public"."user_interests"."id";



CREATE TABLE IF NOT EXISTS "public"."user_invisibility_rules" (
    "user_id" "uuid" NOT NULL,
    "rules_data" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_invisibility_rules" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_locations" (
    "user_id" "uuid" NOT NULL,
    "latitude" double precision NOT NULL,
    "longitude" double precision NOT NULL,
    "speed" double precision,
    "heading" double precision,
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_locations" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_mfa_recovery_codes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "code_hash" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "used_at" timestamp with time zone
);


ALTER TABLE "public"."user_mfa_recovery_codes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_presence" (
    "user_id" "uuid" NOT NULL,
    "is_online" boolean DEFAULT false NOT NULL,
    "last_seen" timestamp with time zone DEFAULT "now"(),
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_presence" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_profiles" (
    "user_id" "uuid" NOT NULL,
    "intent_type" "text" NOT NULL,
    "profile_data" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_profiles" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_recent_matches" (
    "user_id" "uuid" NOT NULL,
    "match_id" "uuid" NOT NULL,
    "other_user_id" "uuid" NOT NULL,
    "match_type" "text",
    "matched_intent" "text",
    "last_activity_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."user_recent_matches" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_session" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "text",
    "token_hash" "text",
    "refresh_token_hash" "text",
    "platform" "text" NOT NULL,
    "device_id" "text",
    "device_model" "text",
    "user_agent" "text",
    "ip" "inet",
    "country" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_active_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone,
    "revoked" boolean DEFAULT false NOT NULL,
    "revoked_at" timestamp with time zone,
    "logout_at" timestamp with time zone,
    "is_persistent" boolean DEFAULT false NOT NULL,
    "auth_method" "text",
    "mfa_verified" boolean,
    "last_rotated_at" timestamp with time zone,
    "terminated_by" "text",
    "metadata" "jsonb" DEFAULT '{}'::"jsonb"
);


ALTER TABLE "public"."user_session" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_subscription_queue" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "tier" character varying(50) NOT NULL,
    "status" character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    "starts_at" timestamp with time zone NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "payment_provider" character varying(20),
    "transaction_id" "text",
    "purchase_metadata" "jsonb" DEFAULT '{}'::"jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "activated_at" timestamp with time zone,
    "cancelled_at" timestamp with time zone,
    "cancellation_reason" "text"
);


ALTER TABLE "public"."user_subscription_queue" OWNER TO "postgres";


COMMENT ON TABLE "public"."user_subscription_queue" IS 'Stores queued subscriptions for users, allowing infinite successive subscriptions';



COMMENT ON COLUMN "public"."user_subscription_queue"."status" IS 'pending=waiting for current to expire, active=currently active, completed=finished, cancelled=cancelled before activation';



CREATE TABLE IF NOT EXISTS "public"."user_visibility_schedules" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "user_id" "uuid",
    "rrule" "text",
    "is_active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."user_visibility_schedules" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."users" (
    "id" "uuid" NOT NULL,
    "email" "text",
    "name" "text",
    "date_of_birth" "date",
    "gender" "text",
    "preferred_language" "text",
    "active_modes" "text"[],
    "subscription_tier" "text" DEFAULT 'free'::"text",
    "is_profile_complete" boolean DEFAULT false,
    "match_radius_default" integer DEFAULT 50,
    "gps_interval_default" integer DEFAULT 300,
    "smart_gps_throttling_enabled" boolean DEFAULT true,
    "editable_profile_fields" "text"[],
    "bio" "text",
    "photos" "text"[],
    "user_visibility_setting" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "system_visibility_status" "text" DEFAULT 'visible'::"text",
    "languages_known" "jsonb" DEFAULT '{}'::"jsonb",
    "shared_event_matching_enabled" boolean DEFAULT false,
    "shared_movement_matching_enabled" boolean DEFAULT false,
    "gender_preferences" "jsonb",
    "age_preferences" "jsonb",
    "strict_gender_age_enforcement" boolean DEFAULT false,
    "unit_system" "text" DEFAULT 'system'::"text",
    "time_format" "text" DEFAULT 'system'::"text",
    "is_verified" boolean DEFAULT false,
    "verification_photo_path" "text",
    "verification_status" "text" DEFAULT 'unverified'::"text",
    "verification_submitted_at" timestamp with time zone,
    "verification_reviewed_at" timestamp with time zone,
    "verification_reviewer_id" "uuid",
    "verification_similarity_score" numeric(3,2),
    "verification_ai_analysis" "jsonb",
    "verification_auto_rejected" boolean DEFAULT false,
    "is_admin" boolean DEFAULT false NOT NULL,
    "subscription_expires_at" timestamp with time zone,
    "referral_code" "text",
    "credits" integer DEFAULT 0,
    "approved_primary_photos" "jsonb" DEFAULT '[]'::"jsonb",
    "notification_preferences" "jsonb" DEFAULT '{"enable_sound": true, "enable_vibration": true, "enable_chat_notifications": true, "enable_admin_notifications": true, "enable_in_app_notifications": true, "enable_match_expiry_notifications": true}'::"jsonb",
    "theme_mode" "text" DEFAULT 'system'::"text" NOT NULL,
    "high_accuracy_mode" boolean DEFAULT false,
    "verification_reference_artifact" "jsonb",
    "verification_reference_generated_at" timestamp with time zone,
    "verification_photo_retention_until" timestamp with time zone,
    "preferred_currency" "text",
    "recent_currencies" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    CONSTRAINT "system_visibility_status_check" CHECK (("system_visibility_status" = ANY (ARRAY['visible'::"text", 'invisible'::"text", 'invisible_rules'::"text", 'offline'::"text", 'gps_problem'::"text", 'network_offline'::"text"]))),
    CONSTRAINT "users_preferred_currency_format_check" CHECK ((("preferred_currency" IS NULL) OR ("preferred_currency" ~ '^[A-Z]{3}$'::"text"))),
    CONSTRAINT "users_recent_currencies_format_check" CHECK ("public"."is_valid_currency_code_array"("recent_currencies")),
    CONSTRAINT "users_theme_mode_check" CHECK (("theme_mode" = ANY (ARRAY['system'::"text", 'light'::"text", 'dark'::"text"]))),
    CONSTRAINT "users_verification_status_check" CHECK (("verification_status" = ANY (ARRAY['unverified'::"text", 'analyzing'::"text", 'pending'::"text", 'approved'::"text", 'rejected'::"text"])))
);

ALTER TABLE ONLY "public"."users" REPLICA IDENTITY FULL;


ALTER TABLE "public"."users" OWNER TO "postgres";


COMMENT ON COLUMN "public"."users"."languages_known" IS 'JSON object of languages known with skills (e.g., {"languages": ["en", "es"], "en": ["read", "speak"], "es": ["read"]})';



COMMENT ON COLUMN "public"."users"."shared_event_matching_enabled" IS 'Enables matching with users attending the same events';



COMMENT ON COLUMN "public"."users"."shared_movement_matching_enabled" IS 'Enables matching with users traveling in similar directions and speeds';



COMMENT ON COLUMN "public"."users"."gender_preferences" IS 'JSON object mapping intent keys to lists of preferred gender keys';



COMMENT ON COLUMN "public"."users"."age_preferences" IS 'JSON object mapping intent keys to age range arrays [min, max]';



COMMENT ON COLUMN "public"."users"."strict_gender_age_enforcement" IS 'Whether to strictly enforce gender/age preferences or just prioritize them';



COMMENT ON COLUMN "public"."users"."is_verified" IS 'Whether the user has been verified through photo verification';



COMMENT ON COLUMN "public"."users"."verification_photo_path" IS 'Supabase storage path to the verification photo';



COMMENT ON COLUMN "public"."users"."verification_status" IS 'Current status of verification: unverified, pending, approved, rejected';



COMMENT ON COLUMN "public"."users"."verification_submitted_at" IS 'When the verification was submitted';



COMMENT ON COLUMN "public"."users"."verification_reviewed_at" IS 'When the verification was reviewed';



COMMENT ON COLUMN "public"."users"."verification_reviewer_id" IS 'ID of the admin who reviewed the verification';



COMMENT ON COLUMN "public"."users"."verification_similarity_score" IS 'AI-calculated similarity score between profile photo and verification photo (0.00-1.00)';



COMMENT ON COLUMN "public"."users"."verification_ai_analysis" IS 'Detailed AI analysis results from face comparison';



COMMENT ON COLUMN "public"."users"."verification_auto_rejected" IS 'Whether verification was automatically rejected due to low similarity score';



COMMENT ON COLUMN "public"."users"."approved_primary_photos" IS 'List of photo object paths approved as primary photos';



COMMENT ON COLUMN "public"."users"."verification_reference_artifact" IS 'Derived non-image verification reference metadata used for fraud prevention after verification review';



COMMENT ON COLUMN "public"."users"."verification_reference_generated_at" IS 'When the derived verification reference artifact was generated';



COMMENT ON COLUMN "public"."users"."verification_photo_retention_until" IS 'When the raw verification photo should no longer be retained';



ALTER TABLE ONLY "public"."app_config" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."app_config_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."edge_function_invocations" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."edge_function_invocations_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."intents" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."intents_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."interests" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."interests_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."user_intents" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."user_intents_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."user_interests" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."user_interests_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."ad_campaigns"
    ADD CONSTRAINT "ad_campaigns_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_clicks"
    ADD CONSTRAINT "ad_clicks_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_creatives"
    ADD CONSTRAINT "ad_creatives_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_impressions_daily"
    ADD CONSTRAINT "ad_impressions_daily_campaign_id_creative_id_user_id_placem_key" UNIQUE ("campaign_id", "creative_id", "user_id", "placement", "platform", "locale", "impression_date");



ALTER TABLE ONLY "public"."ad_impressions_daily"
    ADD CONSTRAINT "ad_impressions_daily_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_impressions"
    ADD CONSTRAINT "ad_impressions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_network_analytics"
    ADD CONSTRAINT "ad_network_analytics_network_id_date_placement_platform_key" UNIQUE ("network_id", "date", "placement", "platform");



ALTER TABLE ONLY "public"."ad_network_analytics"
    ADD CONSTRAINT "ad_network_analytics_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_networks"
    ADD CONSTRAINT "ad_networks_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_networks"
    ADD CONSTRAINT "ad_networks_provider_key" UNIQUE ("provider");



ALTER TABLE ONLY "public"."ad_reports"
    ADD CONSTRAINT "ad_reports_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_revenue_daily_stats"
    ADD CONSTRAINT "ad_revenue_daily_stats_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_revenue_events"
    ADD CONSTRAINT "ad_revenue_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_system_schedules"
    ADD CONSTRAINT "ad_system_schedules_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ad_units"
    ADD CONSTRAINT "ad_units_network_id_placement_platform_ad_format_key" UNIQUE ("network_id", "placement", "platform", "ad_format");



ALTER TABLE ONLY "public"."ad_units"
    ADD CONSTRAINT "ad_units_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."admin_broadcast_deliveries"
    ADD CONSTRAINT "admin_broadcast_deliveries_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."admin_broadcasts"
    ADD CONSTRAINT "admin_broadcasts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."admin_dashboard_tick"
    ADD CONSTRAINT "admin_dashboard_tick_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ai_quota_alert_state"
    ADD CONSTRAINT "ai_quota_alert_state_pkey" PRIMARY KEY ("provider", "metric", "window_key", "severity");



ALTER TABLE ONLY "public"."ai_quota_status"
    ADD CONSTRAINT "ai_quota_status_pkey" PRIMARY KEY ("provider", "metric", "window_key");



ALTER TABLE ONLY "public"."app_config"
    ADD CONSTRAINT "app_config_config_key_key" UNIQUE ("config_key");



ALTER TABLE ONLY "public"."app_config"
    ADD CONSTRAINT "app_config_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."app_gender_options"
    ADD CONSTRAINT "app_gender_options_gender_key_key" UNIQUE ("gender_key");



ALTER TABLE ONLY "public"."app_gender_options"
    ADD CONSTRAINT "app_gender_options_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."app_languages"
    ADD CONSTRAINT "app_languages_language_code_key" UNIQUE ("language_code");



ALTER TABLE ONLY "public"."app_languages"
    ADD CONSTRAINT "app_languages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."chats"
    ADD CONSTRAINT "chats_pkey" PRIMARY KEY ("user_id", "match_id");



ALTER TABLE ONLY "public"."currency_exchange_rates"
    ADD CONSTRAINT "currency_exchange_rates_pkey" PRIMARY KEY ("base_currency", "quote_currency");



ALTER TABLE ONLY "public"."edge_function_invocations"
    ADD CONSTRAINT "edge_function_invocations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."event_attendees"
    ADD CONSTRAINT "event_attendees_pkey" PRIMARY KEY ("event_id", "user_id");



ALTER TABLE ONLY "public"."events"
    ADD CONSTRAINT "events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."intents"
    ADD CONSTRAINT "intents_key_key" UNIQUE ("key");



ALTER TABLE ONLY "public"."intents"
    ADD CONSTRAINT "intents_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."interests"
    ADD CONSTRAINT "interests_key_key" UNIQUE ("key");



ALTER TABLE ONLY "public"."interests"
    ADD CONSTRAINT "interests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."match_rating_prompts"
    ADD CONSTRAINT "match_rating_prompts_pkey" PRIMARY KEY ("match_id", "user_id");



ALTER TABLE ONLY "public"."match_ratings"
    ADD CONSTRAINT "match_ratings_one_per_rater_per_match" UNIQUE ("match_id", "rater_id");



ALTER TABLE ONLY "public"."match_ratings"
    ADD CONSTRAINT "match_ratings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."matches"
    ADD CONSTRAINT "matches_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."matches"
    ADD CONSTRAINT "matches_unique_pair" UNIQUE ("user1_id", "user2_id");



ALTER TABLE ONLY "public"."message_reactions"
    ADD CONSTRAINT "message_reactions_pkey" PRIMARY KEY ("message_id", "user_id");



ALTER TABLE ONLY "public"."notification_queue"
    ADD CONSTRAINT "notification_queue_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."passkey_challenges"
    ADD CONSTRAINT "passkey_challenges_challenge_key" UNIQUE ("challenge");



ALTER TABLE ONLY "public"."passkey_challenges"
    ADD CONSTRAINT "passkey_challenges_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."passkey_challenges"
    ADD CONSTRAINT "passkey_challenges_request_id_key" UNIQUE ("request_id");



ALTER TABLE ONLY "public"."passkey_credentials"
    ADD CONSTRAINT "passkey_credentials_credential_id_key" UNIQUE ("credential_id");



ALTER TABLE ONLY "public"."passkey_credentials"
    ADD CONSTRAINT "passkey_credentials_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."pending_email_changes"
    ADD CONSTRAINT "pending_email_changes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."presence_events"
    ADD CONSTRAINT "presence_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."profile_edit_requests"
    ADD CONSTRAINT "profile_edit_requests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."promo_code_usages"
    ADD CONSTRAINT "promo_code_usages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."promo_codes"
    ADD CONSTRAINT "promo_codes_code_key" UNIQUE ("code");



ALTER TABLE ONLY "public"."promo_codes"
    ADD CONSTRAINT "promo_codes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."referral_visits"
    ADD CONSTRAINT "referral_visits_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referee_id_key" UNIQUE ("referee_id");



ALTER TABLE ONLY "public"."sensitive_action_email_codes"
    ADD CONSTRAINT "sensitive_action_email_codes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."signup_fraud_signals"
    ADD CONSTRAINT "signup_fraud_signals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."subscription_plans"
    ADD CONSTRAINT "subscription_plans_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."subscription_tiers"
    ADD CONSTRAINT "subscription_tiers_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."translations"
    ADD CONSTRAINT "translations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."unmatched_pairs"
    ADD CONSTRAINT "unmatched_pairs_pkey" PRIMARY KEY ("user1_id", "user2_id");



ALTER TABLE ONLY "public"."ad_revenue_daily_stats"
    ADD CONSTRAINT "uq_daily_stats" UNIQUE ("date", "network_id", "ad_unit_id", "placement", "platform", "ad_format");



ALTER TABLE ONLY "public"."user_activity"
    ADD CONSTRAINT "user_activity_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."user_intents"
    ADD CONSTRAINT "user_intents_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_intents"
    ADD CONSTRAINT "user_intents_user_id_intent_id_key" UNIQUE ("user_id", "intent_id");



ALTER TABLE ONLY "public"."user_interests"
    ADD CONSTRAINT "user_interests_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_interests"
    ADD CONSTRAINT "user_interests_user_id_interest_id_key" UNIQUE ("user_id", "interest_id");



ALTER TABLE ONLY "public"."user_invisibility_rules"
    ADD CONSTRAINT "user_invisibility_rules_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."user_locations"
    ADD CONSTRAINT "user_locations_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."user_mfa_recovery_codes"
    ADD CONSTRAINT "user_mfa_recovery_codes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_mfa_recovery_codes"
    ADD CONSTRAINT "user_mfa_recovery_codes_user_id_code_hash_key" UNIQUE ("user_id", "code_hash");



ALTER TABLE ONLY "public"."user_presence"
    ADD CONSTRAINT "user_presence_pkey" PRIMARY KEY ("user_id");



ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_pkey" PRIMARY KEY ("user_id", "intent_type");



ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_user_id_intent_type_key" UNIQUE ("user_id", "intent_type");



ALTER TABLE ONLY "public"."user_recent_matches"
    ADD CONSTRAINT "user_recent_matches_pkey" PRIMARY KEY ("user_id", "match_id");



ALTER TABLE ONLY "public"."user_session"
    ADD CONSTRAINT "user_session_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_subscription_queue"
    ADD CONSTRAINT "user_subscription_queue_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_visibility_schedules"
    ADD CONSTRAINT "user_visibility_schedules_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_referral_code_key" UNIQUE ("referral_code");



CREATE INDEX "currency_exchange_rates_base_currency_idx" ON "public"."currency_exchange_rates" USING "btree" ("base_currency", "fetched_at" DESC);



CREATE INDEX "edge_function_invocations_ai_idx" ON "public"."edge_function_invocations" USING "btree" ("ai_used", "ai_provider", "ai_model", "ai_task");



CREATE INDEX "edge_function_invocations_function_name_idx" ON "public"."edge_function_invocations" USING "btree" ("function_name");



CREATE INDEX "edge_function_invocations_invoked_at_idx" ON "public"."edge_function_invocations" USING "btree" ("invoked_at" DESC);



CREATE INDEX "edge_function_invocations_success_idx" ON "public"."edge_function_invocations" USING "btree" ("success");



CREATE INDEX "idx_ad_campaigns_live" ON "public"."ad_campaigns" USING "btree" ("is_active", "moderation_status", "family_safe", "starts_at", "ends_at", "sort_priority");



CREATE INDEX "idx_ad_clicks_campaign_created" ON "public"."ad_clicks" USING "btree" ("campaign_id", "created_at");



CREATE INDEX "idx_ad_creatives_lookup" ON "public"."ad_creatives" USING "btree" ("placement", "platform", "is_active", "sort_priority");



CREATE INDEX "idx_ad_impressions_campaign_created" ON "public"."ad_impressions" USING "btree" ("campaign_id", "created_at");



CREATE INDEX "idx_ad_impressions_daily_campaign_date" ON "public"."ad_impressions_daily" USING "btree" ("campaign_id", "impression_date" DESC);



CREATE INDEX "idx_ad_impressions_daily_placement_date" ON "public"."ad_impressions_daily" USING "btree" ("placement", "impression_date" DESC);



CREATE INDEX "idx_ad_impressions_daily_user_date" ON "public"."ad_impressions_daily" USING "btree" ("user_id", "impression_date" DESC);



CREATE INDEX "idx_ad_impressions_user_created" ON "public"."ad_impressions" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_ad_network_analytics_date" ON "public"."ad_network_analytics" USING "btree" ("network_id", "date" DESC);



CREATE INDEX "idx_ad_networks_enabled" ON "public"."ad_networks" USING "btree" ("is_enabled", "priority");



CREATE INDEX "idx_ad_reports_campaign_created" ON "public"."ad_reports" USING "btree" ("campaign_id", "created_at" DESC);



CREATE INDEX "idx_ad_revenue_events_click_count" ON "public"."ad_revenue_events" USING "btree" ("network_id", "click_count") WHERE ("click_count" > 0);



CREATE INDEX "idx_ad_revenue_events_last_clicked" ON "public"."ad_revenue_events" USING "btree" ("network_id", "last_clicked_at") WHERE ("last_clicked_at" IS NOT NULL);



CREATE INDEX "idx_ad_revenue_events_network_created" ON "public"."ad_revenue_events" USING "btree" ("network_id", "created_at" DESC);



CREATE INDEX "idx_ad_revenue_events_placement_created" ON "public"."ad_revenue_events" USING "btree" ("placement", "created_at" DESC);



CREATE INDEX "idx_ad_revenue_events_user_created" ON "public"."ad_revenue_events" USING "btree" ("user_id", "created_at" DESC);



CREATE INDEX "idx_ad_system_schedules_config" ON "public"."ad_system_schedules" USING "btree" ("system_config_id", "is_active");



CREATE INDEX "idx_ad_units_lookup" ON "public"."ad_units" USING "btree" ("network_id", "placement", "platform", "ad_format", "is_active");



CREATE INDEX "idx_admin_broadcast_deliveries_broadcast_id" ON "public"."admin_broadcast_deliveries" USING "btree" ("broadcast_id");



CREATE INDEX "idx_admin_broadcast_deliveries_status" ON "public"."admin_broadcast_deliveries" USING "btree" ("delivery_status");



CREATE INDEX "idx_admin_broadcast_deliveries_user_id" ON "public"."admin_broadcast_deliveries" USING "btree" ("user_id");



CREATE INDEX "idx_admin_broadcasts_scheduled_at" ON "public"."admin_broadcasts" USING "btree" ("scheduled_at");



CREATE INDEX "idx_admin_broadcasts_status" ON "public"."admin_broadcasts" USING "btree" ("status");



CREATE INDEX "idx_ai_quota_status_provider" ON "public"."ai_quota_status" USING "btree" ("provider");



CREATE INDEX "idx_ai_quota_status_updated_at" ON "public"."ai_quota_status" USING "btree" ("updated_at");



CREATE INDEX "idx_app_config_category" ON "public"."app_config" USING "btree" ("category");



CREATE INDEX "idx_app_config_key" ON "public"."app_config" USING "btree" ("config_key");



CREATE INDEX "idx_app_config_user_configurable" ON "public"."app_config" USING "btree" ("is_user_configurable");



CREATE INDEX "idx_chat_messages_created_at" ON "public"."chat_messages" USING "btree" ("created_at");



CREATE INDEX "idx_chat_messages_delivered_at" ON "public"."chat_messages" USING "btree" ("delivered_at");



CREATE INDEX "idx_chat_messages_encryption_version" ON "public"."chat_messages" USING "btree" ("encryption_version");



CREATE INDEX "idx_chat_messages_match_id" ON "public"."chat_messages" USING "btree" ("match_id");



CREATE INDEX "idx_chat_messages_match_id_created_at" ON "public"."chat_messages" USING "btree" ("match_id", "created_at");



CREATE INDEX "idx_chat_messages_sender_id" ON "public"."chat_messages" USING "btree" ("sender_id");



CREATE INDEX "idx_chats_user_last_message" ON "public"."chats" USING "btree" ("user_id", "last_message_at" DESC NULLS LAST);



CREATE INDEX "idx_daily_stats_date" ON "public"."ad_revenue_daily_stats" USING "btree" ("date" DESC);



CREATE INDEX "idx_daily_stats_network" ON "public"."ad_revenue_daily_stats" USING "btree" ("network_id");



CREATE INDEX "idx_daily_stats_placement" ON "public"."ad_revenue_daily_stats" USING "btree" ("placement");



CREATE INDEX "idx_daily_stats_platform" ON "public"."ad_revenue_daily_stats" USING "btree" ("platform");



CREATE INDEX "idx_event_attendees_event_id" ON "public"."event_attendees" USING "btree" ("event_id");



CREATE INDEX "idx_event_attendees_user_id" ON "public"."event_attendees" USING "btree" ("user_id");



CREATE INDEX "idx_intents_parent_id" ON "public"."intents" USING "btree" ("parent_id");



CREATE INDEX "idx_interests_parent_id" ON "public"."interests" USING "btree" ("parent_id");



CREATE INDEX "idx_match_rating_prompts_user_next_prompt" ON "public"."match_rating_prompts" USING "btree" ("user_id", "next_prompt_at") WHERE ("next_prompt_at" IS NOT NULL);



CREATE INDEX "idx_match_ratings_match_id" ON "public"."match_ratings" USING "btree" ("match_id");



CREATE INDEX "idx_match_ratings_ratee_created_at" ON "public"."match_ratings" USING "btree" ("ratee_id", "created_at" DESC);



CREATE INDEX "idx_matches_user_a_id" ON "public"."matches" USING "btree" ("user1_id");



CREATE INDEX "idx_matches_user_b_id" ON "public"."matches" USING "btree" ("user2_id");



CREATE INDEX "idx_message_reactions_message_id" ON "public"."message_reactions" USING "btree" ("message_id");



CREATE INDEX "idx_message_reactions_user_id" ON "public"."message_reactions" USING "btree" ("user_id");



CREATE INDEX "idx_notification_queue_scheduled_at" ON "public"."notification_queue" USING "btree" ("scheduled_at");



CREATE INDEX "idx_notification_queue_status" ON "public"."notification_queue" USING "btree" ("status");



CREATE INDEX "idx_notification_queue_updated_at" ON "public"."notification_queue" USING "btree" ("updated_at");



CREATE INDEX "idx_passkey_challenges_expiry" ON "public"."passkey_challenges" USING "btree" ("expires_at");



CREATE INDEX "idx_passkey_challenges_lookup" ON "public"."passkey_challenges" USING "btree" ("request_id", "challenge_type");



CREATE INDEX "idx_passkey_credentials_rp_id" ON "public"."passkey_credentials" USING "btree" ("rp_id");



CREATE INDEX "idx_passkey_credentials_user_id" ON "public"."passkey_credentials" USING "btree" ("user_id");



CREATE INDEX "idx_pending_email_changes_expires_at" ON "public"."pending_email_changes" USING "btree" ("expires_at");



CREATE INDEX "idx_pending_email_changes_new_email" ON "public"."pending_email_changes" USING "btree" ("new_email");



CREATE INDEX "idx_pending_email_changes_user_id" ON "public"."pending_email_changes" USING "btree" ("user_id");



CREATE INDEX "idx_presence_events_created_at" ON "public"."presence_events" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_presence_events_expires_at" ON "public"."presence_events" USING "btree" ("expires_at");



CREATE INDEX "idx_presence_events_user_id" ON "public"."presence_events" USING "btree" ("user_id");



CREATE INDEX "idx_profile_edit_requests_status" ON "public"."profile_edit_requests" USING "btree" ("status") WHERE ("status" = 'pending'::"text");



CREATE INDEX "idx_profile_edit_requests_user_id" ON "public"."profile_edit_requests" USING "btree" ("user_id");



CREATE INDEX "idx_promo_codes_active" ON "public"."promo_codes" USING "btree" ("is_active", "valid_until");



CREATE INDEX "idx_promo_codes_campaign" ON "public"."promo_codes" USING "btree" ("campaign_name");



CREATE INDEX "idx_promo_codes_code" ON "public"."promo_codes" USING "btree" ("code");



CREATE INDEX "idx_promo_usages_promo" ON "public"."promo_code_usages" USING "btree" ("promo_code_id");



CREATE INDEX "idx_promo_usages_redeemed_at" ON "public"."promo_code_usages" USING "btree" ("redeemed_at");



CREATE INDEX "idx_promo_usages_user" ON "public"."promo_code_usages" USING "btree" ("user_id");



CREATE INDEX "idx_promo_usages_user_promo" ON "public"."promo_code_usages" USING "btree" ("user_id", "promo_code_id");



CREATE INDEX "idx_referral_visits_fingerprint" ON "public"."referral_visits" USING "btree" ("ip_address", "user_agent", "created_at");



CREATE INDEX "idx_referrals_device_id" ON "public"."referrals" USING "btree" ("device_id");



CREATE INDEX "idx_referrals_referee" ON "public"."referrals" USING "btree" ("referee_id");



CREATE INDEX "idx_referrals_referrer" ON "public"."referrals" USING "btree" ("referrer_id");



CREATE INDEX "idx_sensitive_action_email_codes_expires_at" ON "public"."sensitive_action_email_codes" USING "btree" ("expires_at");



CREATE INDEX "idx_sensitive_action_email_codes_user_id" ON "public"."sensitive_action_email_codes" USING "btree" ("user_id");



CREATE INDEX "idx_signup_fraud_signals_created_at" ON "public"."signup_fraud_signals" USING "btree" ("created_at" DESC);



CREATE INDEX "idx_signup_fraud_signals_device_id_hash" ON "public"."signup_fraud_signals" USING "btree" ("device_id_hash") WHERE ("device_id_hash" IS NOT NULL);



CREATE INDEX "idx_signup_fraud_signals_install_id_hash" ON "public"."signup_fraud_signals" USING "btree" ("install_id_hash") WHERE ("install_id_hash" IS NOT NULL);



CREATE INDEX "idx_signup_fraud_signals_ip_prefix_hash" ON "public"."signup_fraud_signals" USING "btree" ("ip_prefix_hash") WHERE ("ip_prefix_hash" IS NOT NULL);



CREATE INDEX "idx_subscription_queue_starts_at" ON "public"."user_subscription_queue" USING "btree" ("starts_at");



CREATE INDEX "idx_subscription_queue_status" ON "public"."user_subscription_queue" USING "btree" ("status");



CREATE INDEX "idx_subscription_queue_user_id" ON "public"."user_subscription_queue" USING "btree" ("user_id");



CREATE INDEX "idx_subscription_queue_user_status" ON "public"."user_subscription_queue" USING "btree" ("user_id", "status");



CREATE INDEX "idx_user_activity_is_online" ON "public"."user_activity" USING "btree" ("is_online");



CREATE INDEX "idx_user_activity_last_activity" ON "public"."user_activity" USING "btree" ("last_activity");



CREATE INDEX "idx_user_activity_online_visible" ON "public"."user_activity" USING "btree" ("is_online", "is_visible") WHERE (("is_online" = true) AND ("is_visible" = true));



CREATE INDEX "idx_user_intents_intent_id" ON "public"."user_intents" USING "btree" ("intent_id");



CREATE INDEX "idx_user_interests_interest_id" ON "public"."user_interests" USING "btree" ("interest_id");



CREATE INDEX "idx_user_locations_updated" ON "public"."user_locations" USING "btree" ("updated_at");



CREATE INDEX "idx_user_mfa_recovery_codes_user_active" ON "public"."user_mfa_recovery_codes" USING "btree" ("user_id", "used_at");



CREATE INDEX "idx_user_presence_online" ON "public"."user_presence" USING "btree" ("is_online", "updated_at");



CREATE INDEX "idx_user_recent_matches_user_last_activity" ON "public"."user_recent_matches" USING "btree" ("user_id", "last_activity_at" DESC);



CREATE INDEX "idx_user_session_active_per_user" ON "public"."user_session" USING "btree" ("user_id") WHERE ("revoked" = false);



CREATE INDEX "idx_user_session_expires_at" ON "public"."user_session" USING "btree" ("expires_at");



CREATE INDEX "idx_user_session_last_active" ON "public"."user_session" USING "btree" ("last_active_at");



CREATE INDEX "idx_user_session_user_id" ON "public"."user_session" USING "btree" ("user_id");



CREATE UNIQUE INDEX "idx_user_session_user_platform_device_id_unique" ON "public"."user_session" USING "btree" ("user_id", "platform", "device_id") WHERE (("device_id" IS NOT NULL) AND ("btrim"("device_id") <> ''::"text"));



CREATE INDEX "idx_user_subscription_queue_expires_at" ON "public"."user_subscription_queue" USING "btree" ("expires_at");



CREATE INDEX "idx_user_subscription_queue_starts_at" ON "public"."user_subscription_queue" USING "btree" ("starts_at");



CREATE INDEX "idx_user_subscription_queue_status" ON "public"."user_subscription_queue" USING "btree" ("status");



CREATE INDEX "idx_user_subscription_queue_user_id" ON "public"."user_subscription_queue" USING "btree" ("user_id");



CREATE INDEX "idx_user_subscription_queue_user_status" ON "public"."user_subscription_queue" USING "btree" ("user_id", "status");



CREATE INDEX "idx_user_visibility_schedules_user_id" ON "public"."user_visibility_schedules" USING "btree" ("user_id");



CREATE INDEX "idx_users_active_modes" ON "public"."users" USING "gin" ("active_modes");



CREATE INDEX "idx_users_age_preferences" ON "public"."users" USING "gin" ("age_preferences");



CREATE INDEX "idx_users_gender_preferences" ON "public"."users" USING "gin" ("gender_preferences");



CREATE INDEX "idx_users_gps_interval_default" ON "public"."users" USING "btree" ("gps_interval_default");



CREATE INDEX "idx_users_high_accuracy_mode" ON "public"."users" USING "btree" ("high_accuracy_mode");



CREATE INDEX "idx_users_is_admin" ON "public"."users" USING "btree" ("is_admin") WHERE ("is_admin" = true);



CREATE INDEX "idx_users_languages_known" ON "public"."users" USING "gin" ("languages_known");



CREATE INDEX "idx_users_match_radius_default" ON "public"."users" USING "btree" ("match_radius_default");



CREATE INDEX "idx_users_normalized_bio_lookup" ON "public"."users" USING "btree" ("public"."normalize_profile_bio_text"("bio")) WHERE (("bio" IS NOT NULL) AND ("btrim"("bio") <> ''::"text"));



CREATE INDEX "idx_users_notification_preferences" ON "public"."users" USING "gin" ("notification_preferences");



CREATE INDEX "idx_users_preferred_language" ON "public"."users" USING "btree" ("preferred_language");



CREATE INDEX "idx_users_referral_code" ON "public"."users" USING "btree" ("referral_code");



CREATE INDEX "idx_users_subscription_expires_at" ON "public"."users" USING "btree" ("subscription_expires_at");



CREATE INDEX "idx_users_theme_mode" ON "public"."users" USING "btree" ("theme_mode");



CREATE INDEX "idx_users_time_format" ON "public"."users" USING "btree" ("time_format");



CREATE INDEX "idx_users_unit_system" ON "public"."users" USING "btree" ("unit_system");



CREATE INDEX "idx_users_verification_status" ON "public"."users" USING "btree" ("verification_status") WHERE ("verification_status" = 'pending'::"text");



CREATE INDEX "intents_key_idx" ON "public"."intents" USING "btree" ("key");



CREATE INDEX "interests_key_idx" ON "public"."interests" USING "btree" ("key");



CREATE INDEX "translations_locale_idx" ON "public"."translations" USING "btree" ("locale");



CREATE UNIQUE INDEX "translations_locale_key_uq" ON "public"."translations" USING "btree" ("locale", "key");



CREATE OR REPLACE TRIGGER "Chat Translation" AFTER INSERT ON "public"."chat_messages" FOR EACH ROW EXECUTE FUNCTION "supabase_functions"."http_request"('https://vazkmvrbshxwyodentng.supabase.co/functions/v1/translate-proxy', 'POST', '{"Content-type":"application/json","Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZhemttdnJic2h4d3lvZGVudG5nIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MDY4ODI5MiwiZXhwIjoyMDc2MjY0MjkyfQ.zS0p7smdEf4th7Lfp3_8CQsL3YUyfnftGrsF1uUBM2M"}', '{}', '5000');



CREATE OR REPLACE TRIGGER "Match Notification" AFTER INSERT ON "public"."matches" FOR EACH ROW EXECUTE FUNCTION "supabase_functions"."http_request"('https://vazkmvrbshxwyodentng.supabase.co/functions/v1/push-message', 'POST', '{"Content-type":"application/json","Authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZhemttdnJic2h4d3lvZGVudG5nIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2MDY4ODI5MiwiZXhwIjoyMDc2MjY0MjkyfQ.zS0p7smdEf4th7Lfp3_8CQsL3YUyfnftGrsF1uUBM2M","x-matchme-internal":"kNktdHg3znzkJsHltIWb"}', '{}', '5000');



CREATE OR REPLACE TRIGGER "currency_exchange_rates_set_updated_at" BEFORE UPDATE ON "public"."currency_exchange_rates" FOR EACH ROW EXECUTE FUNCTION "public"."set_currency_exchange_rates_updated_at"();



CREATE OR REPLACE TRIGGER "intents_set_timestamp" BEFORE UPDATE ON "public"."intents" FOR EACH ROW EXECUTE FUNCTION "public"."trigger_set_timestamp"();



CREATE OR REPLACE TRIGGER "interests_set_timestamp" BEFORE UPDATE ON "public"."interests" FOR EACH ROW EXECUTE FUNCTION "public"."trigger_set_timestamp"();



CREATE OR REPLACE TRIGGER "prevent_past_event_start_time" BEFORE INSERT OR UPDATE ON "public"."events" FOR EACH ROW EXECUTE FUNCTION "public"."check_event_start_not_past"();



CREATE OR REPLACE TRIGGER "trg_block_protected_user_fields_update" BEFORE UPDATE ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."block_protected_user_fields_update"();



CREATE OR REPLACE TRIGGER "trg_check_delete_messages_on_chat_deletion" AFTER DELETE ON "public"."chats" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chat_deletion_check_messages"();



CREATE OR REPLACE TRIGGER "trg_cleanup_profile_edit_attachments_on_decision" AFTER UPDATE OF "status" ON "public"."profile_edit_requests" FOR EACH ROW EXECUTE FUNCTION "public"."cleanup_profile_edit_attachments_on_decision"();



CREATE OR REPLACE TRIGGER "trg_enforce_basic_details_one_time_edit" BEFORE UPDATE ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."enforce_basic_details_one_time_edit"();



CREATE OR REPLACE TRIGGER "trg_enforce_unique_profile_bio" BEFORE INSERT OR UPDATE OF "bio" ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."enforce_unique_profile_bio"();



CREATE OR REPLACE TRIGGER "trg_enqueue_profile_edit_request_review_fcm" AFTER UPDATE OF "status" ON "public"."profile_edit_requests" FOR EACH ROW EXECUTE FUNCTION "public"."enqueue_profile_edit_request_review_fcm"();



CREATE OR REPLACE TRIGGER "trg_handle_chat_message_delete_for_chats" AFTER DELETE ON "public"."chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chat_message_delete_for_chats"();



CREATE OR REPLACE TRIGGER "trg_handle_chat_message_for_chats" AFTER INSERT ON "public"."chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chat_message_for_chats"();



CREATE OR REPLACE TRIGGER "trg_handle_chat_message_update_for_chats" AFTER UPDATE ON "public"."chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chat_message_update_for_chats"();



CREATE OR REPLACE TRIGGER "trg_handle_message_read_for_chats" AFTER UPDATE ON "public"."chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."handle_message_read_for_chats"();



CREATE OR REPLACE TRIGGER "trg_handle_new_match" AFTER INSERT ON "public"."matches" FOR EACH ROW EXECUTE FUNCTION "public"."handle_new_match"();



CREATE OR REPLACE TRIGGER "trg_message_reactions_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."message_reactions" FOR EACH ROW EXECUTE FUNCTION "public"."handle_message_reactions_change"();



CREATE OR REPLACE TRIGGER "trg_prevent_duplicate_pending_profile_edit_requests" BEFORE INSERT ON "public"."profile_edit_requests" FOR EACH ROW EXECUTE FUNCTION "public"."prevent_duplicate_pending_profile_edit_requests"();



CREATE OR REPLACE TRIGGER "trg_prevent_sensitive_user_field_updates" BEFORE UPDATE ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."prevent_sensitive_user_field_updates"();



CREATE OR REPLACE TRIGGER "trg_profile_edit_requests_set_updated_at" BEFORE UPDATE ON "public"."profile_edit_requests" FOR EACH ROW EXECUTE FUNCTION "public"."profile_edit_requests_set_updated_at"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_admin_broadcasts" AFTER INSERT OR DELETE OR UPDATE ON "public"."admin_broadcasts" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_ai_quota_status" AFTER INSERT OR DELETE OR UPDATE ON "public"."ai_quota_status" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_chat_messages" AFTER INSERT ON "public"."chat_messages" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_chats" AFTER INSERT OR DELETE OR UPDATE ON "public"."chats" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_matches" AFTER INSERT ON "public"."matches" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_notification_queue" AFTER INSERT OR DELETE OR UPDATE ON "public"."notification_queue" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_profile_edit_requests" AFTER INSERT OR DELETE OR UPDATE ON "public"."profile_edit_requests" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_user_locations" AFTER INSERT OR DELETE OR UPDATE ON "public"."user_locations" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_touch_admin_dashboard_tick_users" AFTER INSERT OR DELETE OR UPDATE ON "public"."users" FOR EACH STATEMENT EXECUTE FUNCTION "public"."touch_admin_dashboard_tick"();



CREATE OR REPLACE TRIGGER "trg_translate_recent_messages_on_chat_translation_change" AFTER UPDATE OF "translation_enabled", "translation_language" ON "public"."chats" FOR EACH ROW EXECUTE FUNCTION "public"."translate_recent_messages_on_chat_translation_change"();



CREATE OR REPLACE TRIGGER "trg_user_preferred_language_change_translate_last" AFTER UPDATE OF "preferred_language" ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."handle_user_preferred_language_change"();



CREATE OR REPLACE TRIGGER "trigger_ad_campaigns_updated_at" BEFORE UPDATE ON "public"."ad_campaigns" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_ad_creatives_updated_at" BEFORE UPDATE ON "public"."ad_creatives" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_ad_impressions_daily_updated_at" BEFORE UPDATE ON "public"."ad_impressions_daily" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_ad_network_analytics_updated_at" BEFORE UPDATE ON "public"."ad_network_analytics" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_ad_networks_updated_at" BEFORE UPDATE ON "public"."ad_networks" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_ad_system_schedules_updated_at" BEFORE UPDATE ON "public"."ad_system_schedules" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_ad_units_updated_at" BEFORE UPDATE ON "public"."ad_units" FOR EACH ROW EXECUTE FUNCTION "public"."set_row_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_app_config_updated_at" BEFORE UPDATE ON "public"."app_config" FOR EACH ROW EXECUTE FUNCTION "public"."update_app_config_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_event_matching" AFTER INSERT ON "public"."event_attendees" FOR EACH ROW EXECUTE FUNCTION "public"."trigger_perform_event_matching"();



CREATE OR REPLACE TRIGGER "trigger_match_rating_prompts_updated_at" BEFORE UPDATE ON "public"."match_rating_prompts" FOR EACH ROW EXECUTE FUNCTION "public"."update_match_rating_prompts_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_normalize_subscription_v2" BEFORE UPDATE ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."normalize_user_subscription_v2"();



CREATE OR REPLACE TRIGGER "trigger_update_admin_broadcasts_updated_at" BEFORE UPDATE ON "public"."admin_broadcasts" FOR EACH ROW EXECUTE FUNCTION "public"."update_admin_broadcasts_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_update_notification_queue_updated_at" BEFORE UPDATE ON "public"."notification_queue" FOR EACH ROW EXECUTE FUNCTION "public"."update_notification_queue_updated_at"();



CREATE OR REPLACE TRIGGER "trigger_user_location_matching" AFTER INSERT OR UPDATE ON "public"."user_locations" FOR EACH STATEMENT EXECUTE FUNCTION "public"."trigger_perform_user_location_matching"();



CREATE OR REPLACE TRIGGER "trigger_user_visibility_update" AFTER UPDATE OF "user_visibility_setting", "system_visibility_status" ON "public"."users" FOR EACH ROW EXECUTE FUNCTION "public"."trigger_update_user_visibility"();



CREATE OR REPLACE TRIGGER "update_ad_revenue_daily_stats_updated_at" BEFORE UPDATE ON "public"."ad_revenue_daily_stats" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();



CREATE OR REPLACE TRIGGER "update_promo_codes_updated_at" BEFORE UPDATE ON "public"."promo_codes" FOR EACH ROW EXECUTE FUNCTION "public"."set_promo_codes_updated_at"();



CREATE OR REPLACE TRIGGER "update_user_presence_updated_at" BEFORE UPDATE ON "public"."user_presence" FOR EACH ROW EXECUTE FUNCTION "public"."update_user_presence_updated_at"();



ALTER TABLE ONLY "public"."ad_campaigns"
    ADD CONSTRAINT "ad_campaigns_approved_by_fkey" FOREIGN KEY ("approved_by") REFERENCES "public"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."ad_campaigns"
    ADD CONSTRAINT "ad_campaigns_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."ad_clicks"
    ADD CONSTRAINT "ad_clicks_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "public"."ad_campaigns"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_clicks"
    ADD CONSTRAINT "ad_clicks_creative_id_fkey" FOREIGN KEY ("creative_id") REFERENCES "public"."ad_creatives"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_clicks"
    ADD CONSTRAINT "ad_clicks_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_creatives"
    ADD CONSTRAINT "ad_creatives_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "public"."ad_campaigns"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_impressions"
    ADD CONSTRAINT "ad_impressions_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "public"."ad_campaigns"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_impressions"
    ADD CONSTRAINT "ad_impressions_creative_id_fkey" FOREIGN KEY ("creative_id") REFERENCES "public"."ad_creatives"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_impressions_daily"
    ADD CONSTRAINT "ad_impressions_daily_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "public"."ad_campaigns"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_impressions_daily"
    ADD CONSTRAINT "ad_impressions_daily_creative_id_fkey" FOREIGN KEY ("creative_id") REFERENCES "public"."ad_creatives"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_impressions_daily"
    ADD CONSTRAINT "ad_impressions_daily_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_impressions"
    ADD CONSTRAINT "ad_impressions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_network_analytics"
    ADD CONSTRAINT "ad_network_analytics_network_id_fkey" FOREIGN KEY ("network_id") REFERENCES "public"."ad_networks"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_reports"
    ADD CONSTRAINT "ad_reports_campaign_id_fkey" FOREIGN KEY ("campaign_id") REFERENCES "public"."ad_campaigns"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_reports"
    ADD CONSTRAINT "ad_reports_creative_id_fkey" FOREIGN KEY ("creative_id") REFERENCES "public"."ad_creatives"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_reports"
    ADD CONSTRAINT "ad_reports_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_revenue_daily_stats"
    ADD CONSTRAINT "ad_revenue_daily_stats_ad_unit_id_fkey" FOREIGN KEY ("ad_unit_id") REFERENCES "public"."ad_units"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_revenue_daily_stats"
    ADD CONSTRAINT "ad_revenue_daily_stats_network_id_fkey" FOREIGN KEY ("network_id") REFERENCES "public"."ad_networks"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_revenue_events"
    ADD CONSTRAINT "ad_revenue_events_ad_unit_id_fkey" FOREIGN KEY ("ad_unit_id") REFERENCES "public"."ad_units"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_revenue_events"
    ADD CONSTRAINT "ad_revenue_events_network_id_fkey" FOREIGN KEY ("network_id") REFERENCES "public"."ad_networks"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_revenue_events"
    ADD CONSTRAINT "ad_revenue_events_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ad_units"
    ADD CONSTRAINT "ad_units_network_id_fkey" FOREIGN KEY ("network_id") REFERENCES "public"."ad_networks"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."admin_broadcast_deliveries"
    ADD CONSTRAINT "admin_broadcast_deliveries_broadcast_id_fkey" FOREIGN KEY ("broadcast_id") REFERENCES "public"."admin_broadcasts"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."admin_broadcast_deliveries"
    ADD CONSTRAINT "admin_broadcast_deliveries_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."admin_broadcasts"
    ADD CONSTRAINT "admin_broadcasts_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_match_id_fkey" FOREIGN KEY ("match_id") REFERENCES "public"."matches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "chat_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."event_attendees"
    ADD CONSTRAINT "event_attendees_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."event_attendees"
    ADD CONSTRAINT "event_attendees_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."chat_messages"
    ADD CONSTRAINT "fk_chat_messages_reply_to_message" FOREIGN KEY ("reply_to_message_id") REFERENCES "public"."chat_messages"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."intents"
    ADD CONSTRAINT "intents_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "public"."intents"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."interests"
    ADD CONSTRAINT "interests_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "public"."interests"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."match_rating_prompts"
    ADD CONSTRAINT "match_rating_prompts_match_id_fkey" FOREIGN KEY ("match_id") REFERENCES "public"."matches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."match_rating_prompts"
    ADD CONSTRAINT "match_rating_prompts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."match_ratings"
    ADD CONSTRAINT "match_ratings_match_id_fkey" FOREIGN KEY ("match_id") REFERENCES "public"."matches"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."match_ratings"
    ADD CONSTRAINT "match_ratings_ratee_id_fkey" FOREIGN KEY ("ratee_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."match_ratings"
    ADD CONSTRAINT "match_ratings_rater_id_fkey" FOREIGN KEY ("rater_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."matches"
    ADD CONSTRAINT "matches_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "public"."events"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."matches"
    ADD CONSTRAINT "matches_user_a_id_fkey" FOREIGN KEY ("user1_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."matches"
    ADD CONSTRAINT "matches_user_b_id_fkey" FOREIGN KEY ("user2_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."message_reactions"
    ADD CONSTRAINT "message_reactions_message_id_fkey" FOREIGN KEY ("message_id") REFERENCES "public"."chat_messages"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."notification_queue"
    ADD CONSTRAINT "notification_queue_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."passkey_challenges"
    ADD CONSTRAINT "passkey_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."passkey_credentials"
    ADD CONSTRAINT "passkey_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."pending_email_changes"
    ADD CONSTRAINT "pending_email_changes_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."presence_events"
    ADD CONSTRAINT "presence_events_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."profile_edit_requests"
    ADD CONSTRAINT "profile_edit_requests_reviewed_by_fkey" FOREIGN KEY ("reviewed_by") REFERENCES "auth"."users"("id");



ALTER TABLE ONLY "public"."profile_edit_requests"
    ADD CONSTRAINT "profile_edit_requests_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."promo_code_usages"
    ADD CONSTRAINT "promo_code_usages_promo_code_id_fkey" FOREIGN KEY ("promo_code_id") REFERENCES "public"."promo_codes"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."promo_code_usages"
    ADD CONSTRAINT "promo_code_usages_subscription_queue_id_fkey" FOREIGN KEY ("subscription_queue_id") REFERENCES "public"."user_subscription_queue"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."promo_code_usages"
    ADD CONSTRAINT "promo_code_usages_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."promo_codes"
    ADD CONSTRAINT "promo_codes_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "public"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referee_id_fkey" FOREIGN KEY ("referee_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."referrals"
    ADD CONSTRAINT "referrals_referrer_id_fkey" FOREIGN KEY ("referrer_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."sensitive_action_email_codes"
    ADD CONSTRAINT "sensitive_action_email_codes_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."signup_fraud_signals"
    ADD CONSTRAINT "signup_fraud_signals_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."subscription_plans"
    ADD CONSTRAINT "subscription_plans_tier_id_fkey" FOREIGN KEY ("tier_id") REFERENCES "public"."subscription_tiers"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_activity"
    ADD CONSTRAINT "user_activity_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_intents"
    ADD CONSTRAINT "user_intents_intent_id_fkey" FOREIGN KEY ("intent_id") REFERENCES "public"."intents"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_interests"
    ADD CONSTRAINT "user_interests_interest_id_fkey" FOREIGN KEY ("interest_id") REFERENCES "public"."interests"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_invisibility_rules"
    ADD CONSTRAINT "user_invisibility_rules_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_locations"
    ADD CONSTRAINT "user_locations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_mfa_recovery_codes"
    ADD CONSTRAINT "user_mfa_recovery_codes_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_presence"
    ADD CONSTRAINT "user_presence_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_session"
    ADD CONSTRAINT "user_session_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_subscription_queue"
    ADD CONSTRAINT "user_subscription_queue_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_visibility_schedules"
    ADD CONSTRAINT "user_visibility_schedules_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_id_fkey" FOREIGN KEY ("id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."users"
    ADD CONSTRAINT "users_verification_reviewer_id_fkey" FOREIGN KEY ("verification_reviewer_id") REFERENCES "auth"."users"("id");



CREATE POLICY "Admins can insert usages" ON "public"."promo_code_usages" FOR INSERT WITH CHECK (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true))));



CREATE POLICY "Admins can manage ad_campaigns" ON "public"."ad_campaigns" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_clicks" ON "public"."ad_clicks" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_creatives" ON "public"."ad_creatives" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_impressions" ON "public"."ad_impressions" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_impressions_daily" ON "public"."ad_impressions_daily" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_network_analytics" ON "public"."ad_network_analytics" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_networks" ON "public"."ad_networks" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_reports" ON "public"."ad_reports" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_revenue_events" ON "public"."ad_revenue_events" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_system_schedules" ON "public"."ad_system_schedules" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage ad_units" ON "public"."ad_units" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can manage broadcasts" ON "public"."admin_broadcasts" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Admins can read admin_dashboard_tick" ON "public"."admin_dashboard_tick" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users" "u"
  WHERE (("u"."id" = "auth"."uid"()) AND ("u"."is_admin" = true)))));



CREATE POLICY "Admins can read ai_quota_alert_state" ON "public"."ai_quota_alert_state" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users" "u"
  WHERE (("u"."id" = "auth"."uid"()) AND ("u"."is_admin" = true)))));



CREATE POLICY "Admins can read ai_quota_status" ON "public"."ai_quota_status" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users" "u"
  WHERE (("u"."id" = "auth"."uid"()) AND ("u"."is_admin" = true)))));



CREATE POLICY "Admins can view all promo codes" ON "public"."promo_codes" FOR SELECT USING (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true))));



CREATE POLICY "Admins can view all usages" ON "public"."promo_code_usages" FOR SELECT USING (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true))));



CREATE POLICY "Allow admins create promo codes" ON "public"."promo_codes" FOR INSERT WITH CHECK (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true))));



CREATE POLICY "Allow admins delete promo codes" ON "public"."promo_codes" FOR DELETE USING (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true))));



CREATE POLICY "Allow admins update promo codes" ON "public"."promo_codes" FOR UPDATE USING (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true)))) WITH CHECK (("auth"."uid"() IN ( SELECT "u"."id"
   FROM "public"."users" "u"
  WHERE ("u"."is_admin" = true))));



CREATE POLICY "Allow all users to read presence events" ON "public"."presence_events" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Allow public read access to subscription_plans" ON "public"."subscription_plans" FOR SELECT USING (true);



CREATE POLICY "Allow public read access to subscription_tiers" ON "public"."subscription_tiers" FOR SELECT USING (true);



CREATE POLICY "Allow public read active promo codes" ON "public"."promo_codes" FOR SELECT USING ((("is_active" = true) AND ("valid_from" <= "now"()) AND ("valid_until" > "now"())));



CREATE POLICY "Allow system to insert presence events" ON "public"."presence_events" FOR INSERT TO "authenticated" WITH CHECK (true);



CREATE POLICY "Anyone can read app_config" ON "public"."app_config" FOR SELECT TO "anon", "authenticated" USING (true);



CREATE POLICY "Anyone can view gender options" ON "public"."app_gender_options" FOR SELECT USING (true);



CREATE POLICY "Anyone can view languages" ON "public"."app_languages" FOR SELECT USING (true);



CREATE POLICY "Anyone can view translations" ON "public"."translations" FOR SELECT USING (true);



CREATE POLICY "Auth users can read own visits" ON "public"."referral_visits" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Authenticated users can create events" ON "public"."events" FOR INSERT WITH CHECK ((( SELECT "auth"."uid"() AS "uid") IS NOT NULL));



CREATE POLICY "Authenticated users can read ad revenue stats" ON "public"."ad_revenue_daily_stats" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Authenticated users can read ad_networks" ON "public"."ad_networks" FOR SELECT TO "authenticated" USING (("is_enabled" = true));



CREATE POLICY "Authenticated users can read ad_units" ON "public"."ad_units" FOR SELECT TO "authenticated" USING (("is_active" = true));



CREATE POLICY "Enable delete for service role" ON "public"."matches" FOR DELETE TO "service_role" USING (true);



CREATE POLICY "Enable delete for service role" ON "public"."user_profiles" FOR DELETE USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Enable delete for service role" ON "public"."users" FOR DELETE USING (("id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Functions can read all presence" ON "public"."user_presence" FOR SELECT USING (true);



CREATE POLICY "Match engine can create matches" ON "public"."matches" FOR INSERT TO "authenticated" WITH CHECK (true);



CREATE POLICY "Only admins can delete app_config" ON "public"."app_config" FOR DELETE TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Only admins can insert app_config" ON "public"."app_config" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Only admins can update app_config" ON "public"."app_config" FOR UPDATE TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."users"
  WHERE (("users"."id" = "auth"."uid"()) AND ("users"."is_admin" = true)))));



CREATE POLICY "Public can log visits" ON "public"."referral_visits" FOR INSERT TO "anon" WITH CHECK (true);



CREATE POLICY "Service role can access all reactions" ON "public"."message_reactions" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "Service role can access all recent matches" ON "public"."user_recent_matches" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "Service role can do everything" ON "public"."referral_visits" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Service role can insert email codes" ON "public"."sensitive_action_email_codes" FOR INSERT TO "service_role" WITH CHECK (true);



CREATE POLICY "Service role can manage ad revenue stats" ON "public"."ad_revenue_daily_stats" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Service role can manage pending email changes" ON "public"."pending_email_changes" FOR INSERT WITH CHECK (true);



CREATE POLICY "Service role can manage visibility schedules" ON "public"."user_visibility_schedules" USING (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "Service role can select email codes" ON "public"."sensitive_action_email_codes" FOR SELECT TO "service_role" USING (true);



CREATE POLICY "Service role can update email codes" ON "public"."sensitive_action_email_codes" FOR UPDATE TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "Service role can update pending email changes" ON "public"."pending_email_changes" FOR UPDATE USING (true) WITH CHECK (true);



CREATE POLICY "Service role full access" ON "public"."user_activity" USING ((("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text"));



CREATE POLICY "Service role full access" ON "public"."user_session" USING ((("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text"));



CREATE POLICY "Service role manages notification queue" ON "public"."notification_queue" USING ((("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text"));



CREATE POLICY "UserProfiles: delete service only" ON "public"."user_profiles" FOR DELETE USING ((("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text"));



CREATE POLICY "UserProfiles: owner insert" ON "public"."user_profiles" FOR INSERT WITH CHECK ((("auth"."uid"() = "user_id") OR (("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text")));



CREATE POLICY "UserProfiles: owner update" ON "public"."user_profiles" FOR UPDATE USING ((("auth"."uid"() = "user_id") OR (("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text"))) WITH CHECK ((("auth"."uid"() = "user_id") OR (("auth"."jwt"() ->> 'role'::"text") = 'service_role'::"text")));



CREATE POLICY "Users can create requests" ON "public"."profile_edit_requests" FOR INSERT WITH CHECK (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can delete their own matches" ON "public"."matches" FOR DELETE USING ((("user1_id" = ( SELECT "auth"."uid"() AS "uid")) OR ("user2_id" = ( SELECT "auth"."uid"() AS "uid"))));



CREATE POLICY "Users can delete their own messages" ON "public"."chat_messages" FOR DELETE USING (("auth"."uid"() = "sender_id"));



CREATE POLICY "Users can delete their own passkey credentials" ON "public"."passkey_credentials" FOR DELETE TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can insert messages for their matches" ON "public"."chat_messages" FOR INSERT WITH CHECK ((("auth"."uid"() = "sender_id") AND (EXISTS ( SELECT 1
   FROM "public"."matches" "m"
  WHERE (("m"."id" = "chat_messages"."match_id") AND (("m"."user1_id" = "auth"."uid"()) OR ("m"."user2_id" = "auth"."uid"())))))));



CREATE POLICY "Users can insert own profile" ON "public"."user_profiles" FOR INSERT WITH CHECK (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can insert own profile" ON "public"."users" FOR INSERT WITH CHECK (("id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can insert their own ad_revenue_events" ON "public"."ad_revenue_events" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "Users can insert their own presence" ON "public"."user_presence" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can insert their own subscription queue entries" ON "public"."user_subscription_queue" FOR INSERT WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can manage own activity" ON "public"."user_activity" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can manage own reactions" ON "public"."message_reactions" USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can manage own sessions" ON "public"."user_session" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can read own recent matches" ON "public"."user_recent_matches" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can update messages in their matches" ON "public"."chat_messages" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."matches" "m"
  WHERE (("m"."id" = "chat_messages"."match_id") AND (("m"."user1_id" = "auth"."uid"()) OR ("m"."user2_id" = "auth"."uid"())))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."matches" "m"
  WHERE (("m"."id" = "chat_messages"."match_id") AND (("m"."user1_id" = "auth"."uid"()) OR ("m"."user2_id" = "auth"."uid"()))))));



CREATE POLICY "Users can update own deliveries" ON "public"."admin_broadcast_deliveries" FOR UPDATE USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "Users can update own profile" ON "public"."user_profiles" FOR UPDATE USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can update request seen at" ON "public"."profile_edit_requests" FOR UPDATE USING (("user_id" = ( SELECT "auth"."uid"() AS "uid"))) WITH CHECK (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can update their own matches" ON "public"."matches" FOR UPDATE USING ((("user1_id" = ( SELECT "auth"."uid"() AS "uid")) OR ("user2_id" = ( SELECT "auth"."uid"() AS "uid"))));



CREATE POLICY "Users can update their own presence" ON "public"."user_presence" FOR UPDATE USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can update their own visibility schedules" ON "public"."user_visibility_schedules" FOR UPDATE USING ((("user_id" = "auth"."uid"()) OR ("auth"."role"() = 'service_role'::"text")));



CREATE POLICY "Users can upsert their own invisibility rules" ON "public"."user_invisibility_rules" USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can view activity for real-time updates" ON "public"."user_activity" FOR SELECT USING (true);



CREATE POLICY "Users can view all profiles" ON "public"."user_profiles" FOR SELECT USING (true);



CREATE POLICY "Users can view events" ON "public"."events" FOR SELECT USING ((( SELECT "auth"."uid"() AS "uid") IS NOT NULL));



CREATE POLICY "Users can view messages for their matches" ON "public"."chat_messages" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."matches" "m"
  WHERE (("m"."id" = "chat_messages"."match_id") AND (("m"."user1_id" = "auth"."uid"()) OR ("m"."user2_id" = "auth"."uid"()))))));



CREATE POLICY "Users can view other users profiles" ON "public"."users" FOR SELECT TO "authenticated" USING (true);



CREATE POLICY "Users can view own deliveries" ON "public"."admin_broadcast_deliveries" FOR SELECT USING (("user_id" = "auth"."uid"()));



CREATE POLICY "Users can view their own email codes" ON "public"."sensitive_action_email_codes" FOR SELECT TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view their own matches" ON "public"."matches" FOR SELECT USING ((("user1_id" = ( SELECT "auth"."uid"() AS "uid")) OR ("user2_id" = ( SELECT "auth"."uid"() AS "uid"))));



CREATE POLICY "Users can view their own passkey credentials" ON "public"."passkey_credentials" FOR SELECT TO "authenticated" USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view their own pending email changes" ON "public"."pending_email_changes" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view their own presence" ON "public"."user_presence" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view their own requests" ON "public"."profile_edit_requests" FOR SELECT USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "Users can view their own subscription queue" ON "public"."user_subscription_queue" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view their own usage" ON "public"."promo_code_usages" FOR SELECT USING (("auth"."uid"() = "user_id"));



CREATE POLICY "Users can view their own visibility schedules" ON "public"."user_visibility_schedules" FOR SELECT USING ((("user_id" = "auth"."uid"()) OR ("auth"."role"() = 'service_role'::"text")));



CREATE POLICY "Users own attendance only" ON "public"."event_attendees" USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



ALTER TABLE "public"."ad_campaigns" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_clicks" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_creatives" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_impressions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_impressions_daily" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_network_analytics" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_networks" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_reports" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_revenue_daily_stats" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_revenue_events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_system_schedules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ad_units" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."admin_broadcast_deliveries" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."admin_broadcasts" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."admin_dashboard_tick" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ai_quota_alert_state" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ai_quota_status" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "anon_select_truly_visible" ON "public"."users" FOR SELECT TO "anon" USING (("public"."is_user_truly_visible"("id") = true));



ALTER TABLE "public"."app_config" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."app_gender_options" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."app_languages" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."chat_messages" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."chats" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."currency_exchange_rates" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "currency_exchange_rates_select_authenticated" ON "public"."currency_exchange_rates" FOR SELECT TO "authenticated" USING (true);



ALTER TABLE "public"."edge_function_invocations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."event_attendees" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."intents" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "intents_service_write" ON "public"."intents" USING ((( SELECT "auth"."uid"() AS "uid") IS NOT NULL));



ALTER TABLE "public"."interests" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "interests_service_write" ON "public"."interests" USING ((( SELECT "auth"."uid"() AS "uid") IS NOT NULL));



ALTER TABLE "public"."match_rating_prompts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "match_rating_prompts_select_own" ON "public"."match_rating_prompts" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "match_rating_prompts_update_own" ON "public"."match_rating_prompts" FOR UPDATE TO "authenticated" USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "match_rating_prompts_upsert_own" ON "public"."match_rating_prompts" FOR INSERT TO "authenticated" WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."matches" "m"
  WHERE (("m"."id" = "match_rating_prompts"."match_id") AND (("m"."user1_id" = "auth"."uid"()) OR ("m"."user2_id" = "auth"."uid"())))))));



ALTER TABLE "public"."match_ratings" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "match_ratings_insert_own" ON "public"."match_ratings" FOR INSERT TO "authenticated" WITH CHECK ((("rater_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."matches" "m"
  WHERE (("m"."id" = "match_ratings"."match_id") AND ((("m"."user1_id" = "auth"."uid"()) AND ("match_ratings"."ratee_id" = "m"."user2_id")) OR (("m"."user2_id" = "auth"."uid"()) AND ("match_ratings"."ratee_id" = "m"."user1_id"))))))));



CREATE POLICY "match_ratings_select_own" ON "public"."match_ratings" FOR SELECT TO "authenticated" USING ((("rater_id" = "auth"."uid"()) OR ("ratee_id" = "auth"."uid"())));



ALTER TABLE "public"."matches" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."message_reactions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."notification_queue" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."passkey_challenges" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."passkey_credentials" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."pending_email_changes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."presence_events" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."profile_edit_requests" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."promo_code_usages" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."promo_codes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."referral_visits" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."referrals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."sensitive_action_email_codes" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "service_role can manage ai_quota_alert_state" ON "public"."ai_quota_alert_state" TO "service_role" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role can manage ai_quota_status" ON "public"."ai_quota_status" TO "service_role" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role can manage notification_queue" ON "public"."notification_queue" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role can manage passkey_challenges" ON "public"."passkey_challenges" TO "service_role" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role can manage passkey_credentials" ON "public"."passkey_credentials" TO "service_role" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role can manage signup_fraud_signals" ON "public"."signup_fraud_signals" TO "service_role" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role can update chat_messages" ON "public"."chat_messages" FOR UPDATE USING (true) WITH CHECK (true);



CREATE POLICY "service_role_full_access" ON "public"."user_locations" TO "service_role" USING (true) WITH CHECK (true);



CREATE POLICY "service_role_full_access_users" ON "public"."users" USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role_read_all_chats" ON "public"."chats" FOR SELECT USING (("auth"."role"() = 'service_role'::"text"));



CREATE POLICY "service_role_update_all_chats" ON "public"."chats" FOR UPDATE USING (("auth"."role"() = 'service_role'::"text")) WITH CHECK (("auth"."role"() = 'service_role'::"text"));



ALTER TABLE "public"."signup_fraud_signals" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."subscription_plans" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."subscription_tiers" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."translations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."unmatched_pairs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "unmatched_pairs_insert_policy" ON "public"."unmatched_pairs" FOR INSERT TO "authenticated" WITH CHECK ((("auth"."uid"() = "user1_id") OR ("auth"."uid"() = "user2_id")));



CREATE POLICY "unmatched_pairs_select_policy" ON "public"."unmatched_pairs" FOR SELECT TO "authenticated" USING ((("auth"."uid"() = "user1_id") OR ("auth"."uid"() = "user2_id")));



ALTER TABLE "public"."user_activity" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_intents" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "user_intents_owner" ON "public"."user_intents" USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "user_intents_service" ON "public"."user_intents" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") IS NOT NULL));



ALTER TABLE "public"."user_interests" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "user_interests_owner" ON "public"."user_interests" USING (("user_id" = ( SELECT "auth"."uid"() AS "uid")));



CREATE POLICY "user_interests_service" ON "public"."user_interests" TO "authenticated" USING ((( SELECT "auth"."uid"() AS "uid") IS NOT NULL));



ALTER TABLE "public"."user_invisibility_rules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_locations" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_mfa_recovery_codes" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "user_mfa_recovery_codes_select_own" ON "public"."user_mfa_recovery_codes" FOR SELECT TO "authenticated" USING (("auth"."uid"() = "user_id"));



ALTER TABLE "public"."user_presence" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_profiles" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_recent_matches" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_session" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_subscription_queue" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."user_visibility_schedules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."users" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "users_insert_own_chats" ON "public"."chats" FOR INSERT WITH CHECK ((("auth"."uid"() = "user_id") OR ("auth"."uid"() = "other_user_id")));



CREATE POLICY "users_manage_own_location" ON "public"."user_locations" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "users_read_own_chats" ON "public"."chats" FOR SELECT USING ((("auth"."uid"() = "user_id") OR ("auth"."uid"() = "other_user_id")));



CREATE POLICY "users_update_own_chats" ON "public"."chats" FOR UPDATE USING ((("auth"."uid"() = "user_id") OR ("auth"."uid"() = "other_user_id"))) WITH CHECK ((("auth"."uid"() = "user_id") OR ("auth"."uid"() = "other_user_id")));



CREATE POLICY "users_update_own_profile" ON "public"."users" FOR UPDATE TO "authenticated" USING (("id" = "auth"."uid"())) WITH CHECK (("id" = "auth"."uid"()));





ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";






ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ad_network_analytics";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ad_networks";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ad_revenue_events";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ad_units";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."admin_broadcast_deliveries";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."admin_broadcasts";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."admin_dashboard_tick";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."app_config";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chat_messages";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chats";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."matches";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."notification_queue";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."presence_events";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."profile_edit_requests";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."user_activity";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."user_invisibility_rules";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."user_locations";



ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."users";









REVOKE USAGE ON SCHEMA "public" FROM PUBLIC;
GRANT ALL ON SCHEMA "public" TO "anon";
GRANT ALL ON SCHEMA "public" TO "authenticated";
GRANT ALL ON SCHEMA "public" TO "service_role";
























































































































































































































GRANT ALL ON FUNCTION "public"."add_subscription_to_queue"("p_user_id" "uuid", "p_tier" character varying, "p_duration_seconds" integer, "p_payment_provider" character varying, "p_transaction_id" "text", "p_metadata" "jsonb") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."admin_assert_is_admin"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_assert_is_admin"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_bulk_upsert_translations"("p_items" "jsonb") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_create_promo_code"("p_code" "text", "p_description" "text", "p_code_type" "text", "p_amount" integer, "p_upgrade_tier" "text", "p_applicable_tiers" "text"[], "p_campaign_name" "text", "p_max_uses" integer, "p_max_uses_per_user" integer, "p_valid_from" timestamp with time zone, "p_valid_until" timestamp with time zone, "p_min_tier" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_delete_intent"("p_id" bigint) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_delete_interest"("p_id" bigint) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_delete_subscription_plan"("p_id" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_delete_subscription_tier"("p_id" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_delete_translation_key"("p_key" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_delete_translation_locale_key"("p_locale" "text", "p_key" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_ai_quota_status"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_dashboard_drilldown"("p_window" "text", "p_metric" "text", "p_param" "text", "p_limit" integer, "p_offset" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_dashboard_stats"("p_window" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_promo_discount_by_date"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_promo_usage_by_code"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_promo_usage_by_user"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_promo_usage_stats"("p_promo_code_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_promo_usage_user_details"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_get_user_ui_languages"("p_user_ids" "uuid"[]) TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_get_user_ui_languages"("p_user_ids" "uuid"[]) TO "service_role";



REVOKE ALL ON FUNCTION "public"."admin_list_external_ad_event_details"("p_filter_type" "text", "p_filter_value" "text", "p_start_date" "date", "p_end_date" "date", "p_limit" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_list_external_ad_event_details"("p_filter_type" "text", "p_filter_value" "text", "p_start_date" "date", "p_end_date" "date", "p_limit" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_list_intents"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_list_interests"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_list_profile_edit_requests"("p_status" "text", "p_query" "text", "p_limit" integer, "p_offset" integer) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."admin_list_recent_sponsored_ad_reports"("p_limit" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_list_recent_sponsored_ad_reports"("p_limit" integer) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."admin_list_sponsored_campaign_event_details"("p_campaign_id" "uuid", "p_event_type" "text", "p_limit" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_list_sponsored_campaign_event_details"("p_campaign_id" "uuid", "p_event_type" "text", "p_limit" integer) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."admin_list_sponsored_campaign_metrics"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_list_sponsored_campaign_metrics"() TO "authenticated";



REVOKE ALL ON FUNCTION "public"."admin_list_sponsored_campaign_report_details"("p_campaign_id" "uuid", "p_limit" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_list_sponsored_campaign_report_details"("p_campaign_id" "uuid", "p_limit" integer) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."admin_list_sponsored_campaign_report_summaries"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."admin_list_sponsored_campaign_report_summaries"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_list_target_users_for_broadcast"("filter_criteria" "jsonb", "p_limit" integer, "p_offset" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_list_target_users_for_broadcast"("filter_criteria" "jsonb", "p_limit" integer, "p_offset" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_list_verification_users"("p_status" "text", "p_query" "text", "p_limit" integer, "p_offset" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_reschedule_broadcast"("p_broadcast_id" "uuid", "p_scheduled_at" timestamp with time zone) TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_reschedule_broadcast"("p_broadcast_id" "uuid", "p_scheduled_at" timestamp with time zone) TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_resend_broadcast_now"("p_broadcast_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_resend_broadcast_now"("p_broadcast_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_review_profile_edit_request"("p_request_id" "uuid", "p_decision" "text", "p_reviewer_note" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_search_users"("p_query" "text", "p_limit" integer, "p_offset" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."admin_search_users"("p_query" "text", "p_limit" integer, "p_offset" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_set_user_verification_status"("p_user_id" "uuid", "p_status" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_update_app_config"("p_config_key" "text", "p_config_value" "jsonb", "p_config_type" "text", "p_category" "text", "p_description" "text", "p_is_user_configurable" boolean, "p_min_value" numeric, "p_max_value" numeric, "p_allowed_values" "jsonb") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_update_promo_code"("p_id" "uuid", "p_code" "text", "p_is_active" boolean, "p_valid_until" timestamp with time zone, "p_valid_from" timestamp with time zone, "p_max_uses" integer, "p_description" "text", "p_code_type" "text", "p_amount" integer, "p_upgrade_tier" "text", "p_max_uses_per_user" integer, "p_applicable_tiers" "text"[], "p_campaign_name" "text", "p_min_tier" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_update_promo_codes_config"("p_enabled" boolean) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_upsert_intent"("p_id" bigint, "p_key" "text", "p_parent_id" bigint, "p_translation_key" "text", "p_sort_order" integer, "p_is_social" boolean, "p_is_business" boolean) TO "authenticated";



GRANT ALL ON FUNCTION "public"."admin_upsert_interest"("p_id" bigint, "p_key" "text", "p_parent_id" bigint, "p_translation_key" "text", "p_sort_order" integer, "p_is_social" boolean, "p_is_business" boolean) TO "authenticated";



GRANT SELECT ON TABLE "public"."subscription_plans" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."subscription_plans" TO "authenticated";
GRANT SELECT ON TABLE "public"."subscription_plans" TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_upsert_subscription_plan"("p_id" "text", "p_tier_id" "text", "p_duration" "text", "p_price_display" "text", "p_savings_text" "text", "p_revenue_cat_package_identifier" "text", "p_sort_order" integer) TO "authenticated";



GRANT SELECT ON TABLE "public"."subscription_tiers" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."subscription_tiers" TO "authenticated";
GRANT SELECT ON TABLE "public"."subscription_tiers" TO "service_role";



GRANT ALL ON FUNCTION "public"."admin_upsert_subscription_tier"("p_id" "text", "p_revenue_cat_package_identifier" "text", "p_title_key" "text", "p_subtitle_key" "text", "p_features_key" "text", "p_badge_key" "text", "p_sort_order" integer, "p_is_active" boolean) TO "authenticated";



GRANT ALL ON FUNCTION "public"."aggregate_ad_revenue_daily"("p_date" "date") TO "authenticated";



GRANT ALL ON FUNCTION "public"."aggregate_ad_revenue_last_n_days"("p_days" integer) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."app_config_jsonb"("p_key" "text", "p_default" "jsonb") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."app_config_jsonb"("p_key" "text", "p_default" "jsonb") TO "authenticated";



GRANT ALL ON FUNCTION "public"."apply_manual_subscription_purchase"("p_tier" "text", "p_duration_seconds" integer, "p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."apply_revenuecat_subscription"("p_tier" "text", "p_expires_at" timestamp with time zone, "p_user_id" "uuid") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."apply_verification_decision"("p_user_id" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."apply_verification_decision"("p_user_id" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."approve_primary_photo"("p_user_id" "uuid", "p_photo_path" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."approve_primary_photo"("p_user_id" "uuid", "p_photo_path" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."broadcast_user_online_event"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."cancel_queued_subscription"("p_queue_id" "uuid", "p_reason" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."check_and_normalize_user_subscription"("p_user_id" "uuid") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."check_profile_bio_uniqueness"("p_user_id" "uuid", "p_bio" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."check_profile_bio_uniqueness"("p_user_id" "uuid", "p_bio" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."check_profile_bio_uniqueness"("p_user_id" "uuid", "p_bio" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."cleanup_expired_matches"("p_cutoff" timestamp with time zone, "p_limit" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."cleanup_old_presence_events"() TO "authenticated";



REVOKE ALL ON FUNCTION "public"."cleanup_orphan_profile_photos"("p_min_age_minutes" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."cleanup_orphan_profile_photos"("p_min_age_minutes" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."cleanup_orphaned_chat_messages"() TO "authenticated";



REVOKE ALL ON FUNCTION "public"."cleanup_profile_edit_attachments_on_decision"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."cleanup_profile_edit_attachments_on_decision"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."cleanup_stale_presence"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."cleanup_stale_presence"() TO "anon";



GRANT ALL ON FUNCTION "public"."clear_mfa_recovery_codes"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."clear_user_subscription"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."consume_mfa_recovery_code"("p_code" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."count_event_attendees"("event_id_param" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."count_event_attendees"("event_id_param" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."count_target_users"("filter_criteria" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "public"."count_target_users"("filter_criteria" "jsonb") TO "service_role";



GRANT ALL ON FUNCTION "public"."debug_get_external_ad_for_placement"("p_placement" "text", "p_platform" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."detect_and_broadcast_offline_users"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."edge_require_internal_secret"() TO "anon";
GRANT ALL ON FUNCTION "public"."edge_require_internal_secret"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."edge_update_verification"("p_user_id" "uuid", "p_patch" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "public"."edge_update_verification"("p_user_id" "uuid", "p_patch" "jsonb") TO "authenticated";



GRANT ALL ON TABLE "public"."chat_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."chat_messages" TO "anon";
GRANT SELECT,UPDATE ON TABLE "public"."chat_messages" TO "service_role";



GRANT ALL ON FUNCTION "public"."edit_message"("p_message_id" "uuid", "p_user_id" "uuid", "p_new_content" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."find_nearby_users"("current_user_id" "uuid", "current_lat" double precision, "current_lng" double precision, "radius_km" double precision) TO "authenticated";
GRANT ALL ON FUNCTION "public"."find_nearby_users"("current_user_id" "uuid", "current_lat" double precision, "current_lng" double precision, "radius_km" double precision) TO "anon";



GRANT ALL ON FUNCTION "public"."find_shared_events"("user1_id" "uuid", "user2_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."find_shared_events"("user1_id" "uuid", "user2_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."generate_mfa_recovery_codes"("p_replace_existing" boolean) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."get_ad_network_analytics"("p_network_id" "uuid", "p_start_date" "date", "p_end_date" "date") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."get_ad_network_analytics"("p_network_id" "uuid", "p_start_date" "date", "p_end_date" "date") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."get_broadcast_stats"("p_broadcast_id" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."get_broadcast_stats"("p_broadcast_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_broadcast_stats"("p_broadcast_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."get_current_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_current_timestamp"() TO "service_role";



GRANT ALL ON FUNCTION "public"."get_due_match_rating_prompts"("p_user_id" "uuid", "p_initial_delay_seconds" integer, "p_limit" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_external_ad_for_placement"("p_placement" "text", "p_platform" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_message_reactors"("message_id" "uuid", "reaction" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_mfa_recovery_code_status"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_nearby_users_count"("p_user_id" "uuid", "p_radius_km" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_nearby_users_count"("p_user_id" "uuid", "p_radius_km" integer) TO "anon";



GRANT ALL ON FUNCTION "public"."get_next_queued_subscription"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_online_user_counts_by_country"("p_recent_seconds" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_online_users_count"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_online_users_count"("p_user_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."get_online_users_count_excluding_self"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_online_users_count_excluding_self"("p_user_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."get_potential_event_matches"("p_event_id" "uuid", "p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_potential_event_matches"("p_event_id" "uuid", "p_user_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."get_promo_code_details"("p_code" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_recent_chats"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_recent_chats"("p_user_id" "uuid") TO "anon";



REVOKE ALL ON FUNCTION "public"."get_sponsored_ad_for_placement"("p_placement" "text", "p_locale" "text", "p_platform" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."get_sponsored_ad_for_placement"("p_placement" "text", "p_locale" "text", "p_platform" "text") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."get_user_ad_consent"("p_user_id" "uuid") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."get_user_ad_consent"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_user_profiles"("p_user_id" "uuid") TO "service_role";
GRANT ALL ON FUNCTION "public"."get_user_profiles"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_user_rating_summary"("p_user_id" "uuid", "p_min_count" integer, "p_last_n" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_user_recent_chats"("p_user_id" "uuid", "p_limit" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_user_recent_chats"("p_user_id" "uuid", "p_limit" integer) TO "anon";



GRANT ALL ON FUNCTION "public"."get_user_recent_matches"("p_user_id" "uuid", "p_limit" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_user_recent_matches"("p_user_id" "uuid", "p_limit" integer) TO "anon";



GRANT ALL ON FUNCTION "public"."get_user_subscription_timeline"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."get_users_for_broadcast"("filter_criteria" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_users_for_broadcast"("filter_criteria" "jsonb") TO "service_role";



GRANT ALL ON FUNCTION "public"."get_visible_online_user_map_cells"("p_requesting_user_id" "uuid", "p_center_lat" double precision, "p_center_lng" double precision, "p_radius_km" double precision, "p_cell_meters" integer, "p_recent_minutes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_visible_online_user_map_cells"("p_requesting_user_id" "uuid", "p_center_lat" double precision, "p_center_lng" double precision, "p_radius_km" double precision, "p_cell_meters" integer, "p_recent_minutes" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."handle_chat_deletion_check_messages"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."health_check"() TO "anon";
GRANT ALL ON FUNCTION "public"."health_check"() TO "authenticated";



GRANT ALL ON FUNCTION "public"."is_user_online"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_user_online"("p_user_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."is_user_online_realtime"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_user_online_realtime"("p_user_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."is_user_truly_visible"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_user_truly_visible"("p_user_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."is_user_truly_visible_realtime"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_user_truly_visible_realtime"("p_user_id" "uuid") TO "anon";



REVOKE ALL ON FUNCTION "public"."list_orphan_profile_photos"("p_min_age_minutes" integer, "p_limit" integer) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."list_orphan_profile_photos"("p_min_age_minutes" integer, "p_limit" integer) TO "service_role";



GRANT ALL ON FUNCTION "public"."log_edge_function_invocation"("p_request_id" "uuid", "p_function_name" "text", "p_duration_ms" integer, "p_success" boolean, "p_http_status" integer, "p_error_type" "text", "p_error_message" "text", "p_user_id" "uuid", "p_ai_used" boolean, "p_ai_provider" "text", "p_ai_model" "text", "p_ai_task" "text", "p_meta" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "public"."log_edge_function_invocation"("p_request_id" "uuid", "p_function_name" "text", "p_duration_ms" integer, "p_success" boolean, "p_http_status" integer, "p_error_type" "text", "p_error_message" "text", "p_user_id" "uuid", "p_ai_used" boolean, "p_ai_provider" "text", "p_ai_model" "text", "p_ai_task" "text", "p_meta" "jsonb") TO "authenticated";



GRANT ALL ON FUNCTION "public"."mark_message_delivered"("p_message_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."mark_messages_as_read"("p_match_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."mark_messages_as_read"("p_match_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."mask_full_name"("full_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."mask_full_name"("full_name" "text") TO "anon";



GRANT ALL ON FUNCTION "public"."normalize_broadcast_filter_criteria"("p_criteria" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "public"."normalize_broadcast_filter_criteria"("p_criteria" "jsonb") TO "service_role";



GRANT ALL ON FUNCTION "public"."normalize_user_subscription"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."normalize_user_subscription_queue"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."on_chat_open"("p_match_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."perform_continuous_event_matching"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."perform_continuous_event_matching"() TO "anon";



GRANT ALL ON FUNCTION "public"."perform_continuous_user_matching"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."perform_continuous_user_matching"() TO "anon";



GRANT ALL ON FUNCTION "public"."perform_event_matching"("p_event_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."perform_event_matching"("p_event_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."perform_event_matching_debug"("p_event_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."perform_event_matching_debug"("p_event_id" "uuid") TO "anon";



GRANT ALL ON FUNCTION "public"."process_notification_queue"() TO "service_role";



GRANT ALL ON FUNCTION "public"."prune_expired_sessions"("p_older_than" interval) TO "service_role";



GRANT ALL ON FUNCTION "public"."queue_fcm_notification"("p_fcm_token" "text", "p_title" "text", "p_body" "text", "p_data" "jsonb", "p_platform" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."queue_fcm_notification"("p_user_id" "uuid", "p_fcm_token" "text", "p_title" "text", "p_body" "text", "p_data" "jsonb", "p_platform" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."record_ad_click"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text", "p_destination_url" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."record_ad_click"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text", "p_destination_url" "text") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."record_ad_impression"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."record_ad_impression"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_platform" "text", "p_locale" "text") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."record_ad_revenue"("p_user_id" "uuid", "p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_event_type" "text", "p_revenue_usd" numeric, "p_ad_format" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."record_ad_revenue"("p_user_id" "uuid", "p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_event_type" "text", "p_revenue_usd" numeric, "p_ad_format" "text") TO "service_role";



REVOKE ALL ON FUNCTION "public"."record_external_ad_click"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."record_external_ad_click"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."record_external_ad_impression"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."record_external_ad_impression"("p_network_id" "uuid", "p_ad_unit_id" "uuid", "p_placement" "text", "p_platform" "text", "p_ad_format" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."redeem_promo_code"("p_code" "text", "p_user_id" "uuid", "p_subscription_queue_id" "uuid", "p_discount_value_cents" integer) TO "authenticated";



REVOKE ALL ON FUNCTION "public"."report_ad"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_reason" "text", "p_details" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."report_ad"("p_campaign_id" "uuid", "p_creative_id" "uuid", "p_placement" "text", "p_reason" "text", "p_details" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."revoke_all_passkeys"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."revoke_all_user_sessions"("p_user_id" "uuid", "p_terminated_by" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."revoke_all_user_sessions"("p_user_id" "uuid", "p_terminated_by" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."revoke_user_session"("p_session_id" "uuid", "p_terminated_by" "text") TO "authenticated";



GRANT ALL ON FUNCTION "public"."send_admin_broadcast"("broadcast_id" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."send_chat_message"("p_match_id" "uuid", "p_content_original" "text", "p_reply_to_message_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."set_chat_translation"("p_user_id" "uuid", "p_match_id" "uuid", "p_enabled" boolean, "p_language" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_chat_translation"("p_user_id" "uuid", "p_match_id" "uuid", "p_enabled" boolean, "p_language" "text") TO "anon";



GRANT ALL ON FUNCTION "public"."set_match_met_answer"("p_match_id" "uuid", "p_met" boolean, "p_repeat_delay_seconds" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."set_message_reaction"("p_message_id" "uuid", "p_reaction" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_message_reaction"("p_message_id" "uuid", "p_reaction" "text") TO "anon";



GRANT ALL ON FUNCTION "public"."should_delete_match_messages"("p_match_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."submit_match_rating"("p_match_id" "uuid", "p_q1" integer, "p_q2" integer, "p_q3" integer, "p_q4" integer, "p_q5" integer) TO "authenticated";



GRANT ALL ON FUNCTION "public"."trigger_perform_event_matching"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."trigger_perform_event_matching"() TO "anon";



GRANT ALL ON FUNCTION "public"."trigger_perform_user_location_matching"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."trigger_perform_user_location_matching"() TO "anon";



GRANT ALL ON FUNCTION "public"."trigger_set_timestamp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."trigger_set_timestamp"() TO "anon";



GRANT ALL ON FUNCTION "public"."trigger_user_proximity_matching"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."trigger_user_proximity_matching"() TO "anon";



GRANT ALL ON FUNCTION "public"."unmatch_from_system_match"("p_match_id" "uuid") TO "authenticated";



REVOKE ALL ON FUNCTION "public"."update_user_ad_consent"("p_personalized_ads" boolean, "p_non_personalized_ads" boolean) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."update_user_ad_consent"("p_personalized_ads" boolean, "p_non_personalized_ads" boolean) TO "authenticated";



GRANT ALL ON FUNCTION "public"."update_user_visibility"("p_user_id" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_user_visibility"("p_user_id" "uuid") TO "anon";



REVOKE ALL ON FUNCTION "public"."upsert_currency_exchange_rate"("p_base_currency" "text", "p_quote_currency" "text", "p_rate" numeric, "p_source" "text", "p_fetched_at" timestamp with time zone) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."upsert_currency_exchange_rate"("p_base_currency" "text", "p_quote_currency" "text", "p_rate" numeric, "p_source" "text", "p_fetched_at" timestamp with time zone) TO "service_role";



REVOKE ALL ON FUNCTION "public"."upsert_currency_exchange_rates_batch"("p_base_currency" "text", "p_rates" "jsonb", "p_source" "text", "p_fetched_at" timestamp with time zone) FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."upsert_currency_exchange_rates_batch"("p_base_currency" "text", "p_rates" "jsonb", "p_source" "text", "p_fetched_at" timestamp with time zone) TO "service_role";



GRANT ALL ON FUNCTION "public"."upsert_user_session"("p_user_id" "uuid", "p_platform" "text", "p_id" "uuid", "p_client_id" "text", "p_token_hash" "text", "p_refresh_token_hash" "text", "p_device_id" "text", "p_device_model" "text", "p_user_agent" "text", "p_ip" "inet", "p_country" "text", "p_expires_at" timestamp with time zone, "p_is_persistent" boolean, "p_auth_method" "text", "p_metadata" "jsonb") TO "authenticated";



GRANT ALL ON FUNCTION "public"."upsert_user_session"("p_user_id" "uuid", "p_platform" "text", "p_id" "uuid", "p_client_id" "text", "p_token_hash" "text", "p_refresh_token_hash" "text", "p_device_id" "text", "p_device_model" "text", "p_user_agent" "text", "p_ip" "inet", "p_country" "text", "p_expires_at" timestamp with time zone, "p_is_persistent" boolean, "p_auth_method" "text", "p_mfa_verified" boolean, "p_metadata" "jsonb") TO "authenticated";



GRANT ALL ON FUNCTION "public"."user_presence_join"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."user_presence_leave"("p_user_id" "uuid") TO "authenticated";



GRANT ALL ON FUNCTION "public"."validate_promo_code"("p_code" "text", "p_user_id" "uuid", "p_for_tier" "text") TO "authenticated";






























GRANT SELECT ON TABLE "public"."ad_campaigns" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_campaigns" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_campaigns" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_clicks" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_clicks" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_clicks" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_creatives" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_creatives" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_creatives" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_impressions" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_impressions" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_impressions" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_impressions_daily" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_impressions_daily" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_impressions_daily" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_network_analytics" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_network_analytics" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_network_analytics" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_networks" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_networks" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_networks" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_reports" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_reports" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_reports" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_revenue_daily_stats" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_revenue_daily_stats" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_revenue_daily_stats" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_revenue_events" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_revenue_events" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_revenue_events" TO "service_role";



GRANT SELECT ON TABLE "public"."app_config" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."app_config" TO "authenticated";
GRANT SELECT ON TABLE "public"."app_config" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_system_config_view" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_system_config_view" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_system_config_view" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_system_schedules" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_system_schedules" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_system_schedules" TO "service_role";



GRANT SELECT ON TABLE "public"."ad_units" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ad_units" TO "authenticated";
GRANT SELECT ON TABLE "public"."ad_units" TO "service_role";



GRANT SELECT ON TABLE "public"."admin_broadcast_deliveries" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."admin_broadcast_deliveries" TO "authenticated";
GRANT ALL ON TABLE "public"."admin_broadcast_deliveries" TO "service_role";



GRANT SELECT ON TABLE "public"."admin_broadcasts" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."admin_broadcasts" TO "authenticated";
GRANT ALL ON TABLE "public"."admin_broadcasts" TO "service_role";



GRANT SELECT ON TABLE "public"."admin_dashboard_tick" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."admin_dashboard_tick" TO "authenticated";
GRANT SELECT ON TABLE "public"."admin_dashboard_tick" TO "service_role";



GRANT SELECT ON TABLE "public"."ai_quota_alert_state" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ai_quota_alert_state" TO "authenticated";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ai_quota_alert_state" TO "service_role";



GRANT SELECT ON TABLE "public"."ai_quota_status" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ai_quota_status" TO "authenticated";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."ai_quota_status" TO "service_role";



GRANT SELECT,USAGE ON SEQUENCE "public"."app_config_id_seq" TO "authenticated";
GRANT SELECT,USAGE ON SEQUENCE "public"."app_config_id_seq" TO "anon";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."app_gender_options" TO "authenticated";
GRANT SELECT ON TABLE "public"."app_gender_options" TO "anon";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."app_languages" TO "authenticated";
GRANT SELECT ON TABLE "public"."app_languages" TO "anon";



GRANT SELECT ON TABLE "public"."chats" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."chats" TO "authenticated";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."chats" TO "service_role";



GRANT SELECT ON TABLE "public"."currency_exchange_rates" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."currency_exchange_rates" TO "authenticated";
GRANT SELECT ON TABLE "public"."currency_exchange_rates" TO "service_role";



GRANT SELECT ON TABLE "public"."edge_function_invocations" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."edge_function_invocations" TO "authenticated";
GRANT SELECT ON TABLE "public"."edge_function_invocations" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."event_attendees" TO "authenticated";
GRANT SELECT ON TABLE "public"."event_attendees" TO "anon";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."events" TO "authenticated";
GRANT SELECT ON TABLE "public"."events" TO "anon";



GRANT SELECT ON TABLE "public"."intents" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."intents" TO "authenticated";
GRANT ALL ON TABLE "public"."intents" TO "service_role";



GRANT SELECT ON TABLE "public"."interests" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."interests" TO "authenticated";
GRANT ALL ON TABLE "public"."interests" TO "service_role";



GRANT SELECT ON TABLE "public"."match_rating_prompts" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."match_rating_prompts" TO "authenticated";
GRANT SELECT ON TABLE "public"."match_rating_prompts" TO "service_role";



GRANT SELECT ON TABLE "public"."match_ratings" TO "anon";
GRANT SELECT,INSERT ON TABLE "public"."match_ratings" TO "authenticated";
GRANT SELECT ON TABLE "public"."match_ratings" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."matches" TO "authenticated";
GRANT SELECT ON TABLE "public"."matches" TO "anon";
GRANT SELECT ON TABLE "public"."matches" TO "service_role";



GRANT SELECT ON TABLE "public"."message_reactions" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."message_reactions" TO "authenticated";



GRANT ALL ON TABLE "public"."notification_queue" TO "service_role";



GRANT SELECT ON TABLE "public"."passkey_challenges" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."passkey_challenges" TO "authenticated";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."passkey_challenges" TO "service_role";



GRANT SELECT ON TABLE "public"."passkey_credentials" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."passkey_credentials" TO "authenticated";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."passkey_credentials" TO "service_role";



GRANT SELECT ON TABLE "public"."pending_email_changes" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."pending_email_changes" TO "authenticated";
GRANT SELECT ON TABLE "public"."pending_email_changes" TO "service_role";



GRANT SELECT ON TABLE "public"."presence_events" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."presence_events" TO "authenticated";
GRANT SELECT ON TABLE "public"."presence_events" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."profile_edit_requests" TO "authenticated";
GRANT SELECT ON TABLE "public"."profile_edit_requests" TO "anon";



GRANT UPDATE("user_seen_at") ON TABLE "public"."profile_edit_requests" TO "authenticated";



GRANT SELECT ON TABLE "public"."promo_code_usages" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."promo_code_usages" TO "authenticated";
GRANT SELECT ON TABLE "public"."promo_code_usages" TO "service_role";



GRANT SELECT ON TABLE "public"."promo_codes" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."promo_codes" TO "authenticated";
GRANT SELECT ON TABLE "public"."promo_codes" TO "service_role";



GRANT SELECT,INSERT ON TABLE "public"."referral_visits" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."referral_visits" TO "authenticated";
GRANT ALL ON TABLE "public"."referral_visits" TO "service_role";



GRANT SELECT ON TABLE "public"."referrals" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."referrals" TO "authenticated";
GRANT SELECT ON TABLE "public"."referrals" TO "service_role";



GRANT SELECT ON TABLE "public"."sensitive_action_email_codes" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."sensitive_action_email_codes" TO "authenticated";
GRANT SELECT ON TABLE "public"."sensitive_action_email_codes" TO "service_role";



GRANT SELECT ON TABLE "public"."signup_fraud_signals" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."signup_fraud_signals" TO "authenticated";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."signup_fraud_signals" TO "service_role";



GRANT SELECT ON TABLE "public"."translations" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."translations" TO "authenticated";



GRANT SELECT ON TABLE "public"."unmatched_pairs" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."unmatched_pairs" TO "authenticated";
GRANT SELECT ON TABLE "public"."unmatched_pairs" TO "service_role";



GRANT SELECT ON TABLE "public"."user_activity" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_activity" TO "authenticated";



GRANT SELECT ON TABLE "public"."user_intents" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_intents" TO "authenticated";
GRANT ALL ON TABLE "public"."user_intents" TO "service_role";



GRANT SELECT ON TABLE "public"."user_interests" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_interests" TO "authenticated";
GRANT ALL ON TABLE "public"."user_interests" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_invisibility_rules" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_invisibility_rules" TO "anon";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_locations" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_locations" TO "anon";



GRANT SELECT ON TABLE "public"."user_mfa_recovery_codes" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_mfa_recovery_codes" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_mfa_recovery_codes" TO "service_role";



GRANT SELECT ON TABLE "public"."user_presence" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_presence" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_presence" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_profiles" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_profiles" TO "anon";



GRANT SELECT ON TABLE "public"."user_recent_matches" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_recent_matches" TO "authenticated";



GRANT SELECT ON TABLE "public"."user_session" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_session" TO "authenticated";
GRANT ALL ON TABLE "public"."user_session" TO "service_role";



GRANT SELECT ON TABLE "public"."user_subscription_queue" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_subscription_queue" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_subscription_queue" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_visibility_schedules" TO "authenticated";
GRANT SELECT ON TABLE "public"."user_visibility_schedules" TO "anon";
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."user_visibility_schedules" TO "service_role";



GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE "public"."users" TO "authenticated";
GRANT SELECT,UPDATE ON TABLE "public"."users" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT SELECT ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT SELECT ON TABLES TO "service_role";




























