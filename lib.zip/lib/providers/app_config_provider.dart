import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/services/public_reference_data_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/utils/offline_utils.dart';

const String _appConfigCacheKey = 'cached_app_config';

// Global cache variable for synchronous access
Map<String, String> _cachedAppConfig = {};

/// Initialize app config cache from persistent storage (call at app startup)
/// This function is exported to be called from main.dart during app initialization
Future<void> initializeAppConfigCache() async {
  try {
    final prefs = await SharedPreferences.getInstance();
    final configJson = prefs.getString(_appConfigCacheKey);
    if (configJson != null) {
      final Map<String, dynamic> cacheData = jsonDecode(configJson);
      _cachedAppConfig = cacheData.map(
        (key, value) => MapEntry(key, value.toString()),
      );
      if (kDebugMode) {
        print('[AppConfig] Initialized cache with ${_cachedAppConfig.length} config values');
      }
    }
  } catch (e) {
    if (kDebugMode) {
      print('[AppConfig] Error initializing config cache: $e');
    }
  }
}

/// Save app config to persistent storage
Future<void> _saveAppConfigCache(Map<String, String> config) async {
  try {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_appConfigCacheKey, jsonEncode(config));
    _cachedAppConfig = config; // Update in-memory cache
    if (kDebugMode) {
      print('[AppConfig] Saved ${config.length} config values to cache');
    }
  } catch (e) {
    if (kDebugMode) {
      print('[AppConfig] Error saving config cache: $e');
    }
  }
}

/// Provider to fetch all app configuration with realtime updates
final appConfigProvider = NotifierProvider<AppConfigNotifier, Map<String, String>>(() {
  return AppConfigNotifier();
});

/// Provider to check if external ads are enabled (with realtime updates)
final externalAdsEnabledProvider = Provider<bool>((ref) {
  final config = ref.watch(appConfigProvider);
  final value = config['ads.external.enabled']?.toLowerCase() ?? 'false';
  return value == 'true';
});

/// Provider to check if internal ads are enabled (with realtime updates)
final internalAdsEnabledProvider = Provider<bool>((ref) {
  final config = ref.watch(appConfigProvider);
  final value = config['ads.internal.enabled']?.toLowerCase() ?? 'true';
  return value == 'true';
});

/// Provider to check display order when both ad systems are enabled
/// 'external_first' (default) or 'internal_first'
final adDisplayOrderProvider = Provider<String>((ref) {
  final config = ref.watch(appConfigProvider);
  final value = config['ads.display_order']?.toLowerCase() ?? 'external_first';
  return value == 'internal_first' ? 'internal_first' : 'external_first';
});

class AppConfigNotifier extends Notifier<Map<String, String>>
    with WidgetsBindingObserver {
  final supabase = Supabase.instance.client;
  RealtimeChannel? _configSubscription;
  void Function()? _resumeDispose;

  // Debouncing to prevent multiple rapid config loads
  Timer? _loadConfigDebounceTimer;
  bool _loadConfigInProgress = false;
  DateTime? _lastLoadConfigCall;
  static const Duration _loadConfigCooldown = Duration(seconds: 30);

  // Debouncing to prevent repeated subscription recreation when there's a persistent error
  DateTime? _lastSubscriptionRecreation;
  static const Duration _subscriptionRecreationCooldown = Duration(seconds: 30);

  @override
  Map<String, String> build() {
    // Register callback to reload config when connectivity is restored.
    // Clean up old callback first to prevent accumulation on rebuilds.
    _resumeDispose?.call();
    _resumeDispose = onSupabaseResume(() {
      if (!ref.mounted) return;
      _loadConfig();
    });

    // Always use cached config as initial state (for fast offline support)
    Map<String, String> initialState = _cachedAppConfig;
    if (_cachedAppConfig.isNotEmpty) {
      print('[AppConfig] Using cached config as initial state: ${_cachedAppConfig.length} keys');
    } else {
      print('[AppConfig] No cached config available, starting with empty state');
    }

    // If online, fetch fresh config from Supabase in background
    if (!shouldSkipSupabaseCalls()) {
      print('[AppConfig] Online - fetching fresh config from database');
      _loadConfig();
    } else {
      print('[AppConfig] Offline - using cached config only');
    }

    // Set up realtime subscription
    _ensureRealtimeSubscription();

    // Listen to app lifecycle changes to refresh config when resumed
    // Remove first to prevent duplicate registration if build() is called multiple times
    WidgetsBinding.instance.removeObserver(this);
    WidgetsBinding.instance.addObserver(this);

    // Cleanup on dispose
    ref.onDispose(() {
      WidgetsBinding.instance.removeObserver(this);
      _clearRealtimeSubscription();
      _loadConfigDebounceTimer?.cancel();
    });

    return initialState; // Return initial state (cached or empty)
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // Don't refresh config on resume - realtime subscription will handle changes
      // Refreshing on resume causes unnecessary provider invalidations and ad reloads
      print('[AppConfig] App resumed, skipping config refresh (realtime handles updates)');
      // Just ensure subscription is active
      _ensureRealtimeSubscription();
    }
  }

  Future<void> _loadConfig() async {
    // Debouncing: Skip if load is already in progress
    if (_loadConfigInProgress) {
      print('[AppConfig] Skipping config load - already in progress');
      return;
    }

    // Debouncing: Skip if within cooldown period
    final now = DateTime.now();
    if (_lastLoadConfigCall != null) {
      final timeSinceLastCall = now.difference(_lastLoadConfigCall!);
      if (timeSinceLastCall < _loadConfigCooldown) {
        print('[AppConfig] Skipping config load - cooldown active (${timeSinceLastCall.inSeconds}s < ${_loadConfigCooldown.inSeconds}s)');
        return;
      }
    }

    // Skip config loading when offline
    if (shouldSkipSupabaseCalls()) {
      print('[AppConfig] Skipping config fetch - Supabase communication paused');
      return;
    }

    try {
      _loadConfigInProgress = true;
      _lastLoadConfigCall = now;

      print('[AppConfig] Loading config from database...');
      final results = await publicReferenceDataService.fetchAppConfigRows();

      final config = <String, String>{};
      for (final row in results) {
        config[row['config_key'] as String] = row['config_value'].toString();
      }

      print('[AppConfig] Loaded ${config.length} config entries');
      state = config;
      // Save to persistent cache for offline use
      _saveAppConfigCache(config);
    } catch (e) {
      print('[AppConfig] Error loading config: $e');
      // If error is due to offline/network issue, keep current state (don't clear it)
      // This prevents losing cached config when offline
      if (e.toString().contains('SocketException') ||
          e.toString().contains('Failed host lookup') ||
          e.toString().contains('network')) {
        print('[AppConfig] Network error - keeping current config state');
      } else {
        // For other errors, also keep current state
        print('[AppConfig] Error - keeping current config state');
      }
    } finally {
      _loadConfigInProgress = false;
    }
  }

  void _ensureRealtimeSubscription() {
    if (supabase.auth.currentSession == null || supabase.auth.currentUser == null) {
      return;
    }

    // Skip subscription setup when Supabase communication is paused
    if (shouldSkipSupabaseCalls()) {
      print('[AppConfig] Skipping realtime subscription setup - Supabase communication paused');
      return;
    }

    // Only create subscription if one doesn't already exist
    if (_configSubscription != null) {
      return;
    }

    try {
      print('[AppConfig] Setting up realtime subscription...');
      _configSubscription = supabase
          .channel('app_config_changes')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'app_config',
            callback: (payload) {
              print('[AppConfig] Realtime update received');
              print('[AppConfig] New record: ${payload.newRecord}');
              print('[AppConfig] Old record: ${payload.oldRecord}');
              final next = Map<String, String>.from(state);
              if (payload.eventType == PostgresChangeEvent.delete) {
                final key = (payload.oldRecord['config_key'] ?? '').toString();
                if (key.isNotEmpty) {
                  next.remove(key);
                }
              } else {
                final key = (payload.newRecord['config_key'] ?? '').toString();
                if (key.isNotEmpty) {
                  next[key] = (payload.newRecord['config_value'] ?? '').toString();
                }
              }
              state = next;
              // Save updated config to persistent cache for offline use
              _saveAppConfigCache(next);
              // Don't call _loadConfig() here - we already updated state with the realtime payload
              // Calling _loadConfig() would overwrite our realtime update with a full fetch
            },
          )
          .subscribe((status, [error]) {
            print('[AppConfig] Subscription status: $status');
            if (error != null && !isExpectedOfflineFailure(error)) {
              print('[AppConfig] Subscription error: $error');
            }
            // When subscribed, do a background refresh to ensure we have latest data
            if (status == RealtimeSubscribeStatus.subscribed) {
              final now = DateTime.now();
              final recentlyLoaded = _lastLoadConfigCall != null &&
                  now.difference(_lastLoadConfigCall!) < _loadConfigCooldown;
              if (!recentlyLoaded) {
                print('[AppConfig] Subscription active, refreshing config');
                unawaited(_loadConfig());
              }
            }
            // If subscription is closed, errored, or timed out, clear it so it can be recreated
            if (status == RealtimeSubscribeStatus.closed ||
                status == RealtimeSubscribeStatus.channelError ||
                status == RealtimeSubscribeStatus.timedOut) {
              // Check cooldown to prevent repeated recreation when there's a persistent error
              final now = DateTime.now();
              if (_lastSubscriptionRecreation != null) {
                final timeSinceLastRecreation = now.difference(_lastSubscriptionRecreation!);
                if (timeSinceLastRecreation < _subscriptionRecreationCooldown) {
                  print('[AppConfig] Subscription disconnected, skipping recreation - cooldown active (${timeSinceLastRecreation.inSeconds}s < ${_subscriptionRecreationCooldown.inSeconds}s)');
                  return;
                }
              }
              print('[AppConfig] Subscription disconnected, will recreate');
              _configSubscription = null;
              _lastSubscriptionRecreation = now;
            }
          });
    } catch (e) {
      print('[AppConfig] Error setting up realtime: $e');
    }
  }

  void _clearRealtimeSubscription() {
    if (_configSubscription != null) {
      print('[AppConfig] Clearing realtime subscription');
      try {
        supabase.removeChannel(_configSubscription!);
      } catch (e) {
        print('[AppConfig] Error unsubscribing: $e');
      }
      _configSubscription = null;
    }
  }

  /// Manually refresh config (e.g., after app comes to foreground)
  Future<void> refresh() async {
    print('[AppConfig] Manual refresh requested');
    await _loadConfig();
  }
}
