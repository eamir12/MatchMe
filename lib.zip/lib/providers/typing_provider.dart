// lib/providers/typing_provider.dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/utils/offline_utils.dart';

final supabase = Supabase.instance.client;

/// Parameters to scope typing channel per conversation
class TypingParams {
  final String matchId;
  final String selfUserId;
  final String otherUserId;
  const TypingParams({
    required this.matchId,
    required this.selfUserId,
    required this.otherUserId,
  });

  @override
  String toString() =>
      'TypingParams(matchId: $matchId, self: $selfUserId, other: $otherUserId)';

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is TypingParams &&
        other.matchId == matchId &&
        other.selfUserId == selfUserId &&
        other.otherUserId == otherUserId;
  }

  @override
  int get hashCode => Object.hash(matchId, selfUserId, otherUserId);
}

/// Provider to get a scoped TypingService instance
/// NOTE: not autoDispose so the service remains alive while the chat is open.
/// UI consumers can still use autoDispose StreamProviders to observe the stream.
final typingServiceProvider = Provider.family<TypingService, TypingParams>((
  ref,
  params,
) {
  final svc = TypingService(params);
  ref.onDispose(() {
    svc.dispose();
  });
  return svc;
});

/// Provider to subscribe to the "other user is typing" stream as Riverpod state
/// Listens to the database is_typing column for the other user's chat row
final isOtherTypingProvider = StreamProvider.autoDispose
    .family<bool, TypingParams>((ref, params) {
  RealtimeChannel? channel;

  // Skip realtime subscription when paused (offline)
  if (!shouldSkipSupabaseCalls()) {
    channel = supabase
        .channel('typing:chats:${params.matchId}:${params.otherUserId}')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'chats',
          filter: PostgresChangeFilter(
            type: PostgresChangeFilterType.eq,
            column: 'user_id',
            value: params.otherUserId,
          ),
          callback: (payload) {
            // is_typing changes will trigger a new stream value via the StreamController below
          },
        )
        .subscribe();
  }

  // Create a stream controller that polls the database for is_typing status
  final controller = StreamController<bool>.broadcast();

  Timer? pollTimer;
  bool isPolling = true;

  // Initial fetch and periodic polling
  Future<void> fetchTypingStatus() async {
    if (!isPolling) return;
    if (shouldSkipSupabaseCalls()) return;
    try {
      final row = await supabase
          .from('chats')
          .select('is_typing')
          .eq('user_id', params.otherUserId)
          .eq('match_id', params.matchId)
          .maybeSingle();

      if (!controller.isClosed) {
        controller.add(row?['is_typing'] == true);
      }
    } catch (e) {
      if (kDebugMode && !isExpectedOfflineFailure(e)) {
        print('Error fetching typing status: $e');
      }
      if (!controller.isClosed) {
        controller.add(false);
      }
    }
  }

  void startPolling() {
    if (pollTimer != null) return;
    isPolling = true;
    fetchTypingStatus();
    pollTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      fetchTypingStatus();
    });
  }

  void stopPolling() {
    isPolling = false;
    pollTimer?.cancel();
    pollTimer = null;
  }

  // Fetch immediately
  fetchTypingStatus();

  // Start polling
  startPolling();

  // Add lifecycle listener to stop polling when app is in background
  final lifecycleListener = AppLifecycleListener(
    onStateChange: (AppLifecycleState state) {
      if (state == AppLifecycleState.paused || state == AppLifecycleState.detached) {
        stopPolling();
      } else if (state == AppLifecycleState.resumed) {
        startPolling();
      }
    },
  );

  ref.onDispose(() {
    stopPolling();
    lifecycleListener.dispose();
    if (channel != null) {
      supabase.removeChannel(channel);
    }
    controller.close();
  });

  return controller.stream;
});

/// Service that updates the is_typing column in the database for the current user
class TypingService {
  final TypingParams _p;
  Timer? _stopTypingTimer;
  bool _isTyping = false;

  TypingService(this._p);

  /// Update the database with the typing status for the current user's chat row
  Future<void> _updateTypingStatus(bool typing) async {
    if (shouldSkipSupabaseCalls()) {
      _isTyping = typing;
      return;
    }
    try {
      await supabase
          .from('chats')
          .update({'is_typing': typing})
          .eq('user_id', _p.selfUserId)
          .eq('match_id', _p.matchId);
      _isTyping = typing;
    } catch (e) {
      if (kDebugMode) {
        print('Error updating typing status: $e');
      }
    }
  }

  /// Should be called on every local text change
  void startTyping() {
    // Cancel any pending stop typing timer
    _stopTypingTimer?.cancel();
    
    // Only update if not already typing to reduce database writes
    if (!_isTyping) {
      _updateTypingStatus(true);
    }
  }

  /// Should be called after inactivity / on send / on dispose
  void stopTyping() {
    _stopTypingTimer?.cancel();
    if (_isTyping) {
      _updateTypingStatus(false);
    }
  }

  /// Schedule stop typing after a delay (used for idle timeout)
  void scheduleStopTyping({Duration delay = const Duration(seconds: 3)}) {
    _stopTypingTimer?.cancel();
    _stopTypingTimer = Timer(delay, () {
      stopTyping();
    });
  }

  Future<void> dispose() async {
    _stopTypingTimer?.cancel();
    // Ensure we mark as not typing when disposing
    await _updateTypingStatus(false);
  }
}
