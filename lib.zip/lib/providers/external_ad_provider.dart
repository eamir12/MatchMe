import 'package:flutter/foundation.dart' show kDebugMode, kIsWeb, defaultTargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/app_config_provider.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/services/ad_consent_service.dart';
import 'package:matchme/services/ad_mediation_service.dart';
import 'package:matchme/services/ad_revenue_service.dart';
import 'package:matchme/services/admob_service.dart';
import 'package:matchme/services/external_ad_service.dart';
import 'package:matchme/services/mobile_ad_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/utils/offline_utils.dart';

final externalAdsRealtimeProvider = Provider<void>((ref) {
  final supabase = Supabase.instance.client;
  RealtimeChannel? adUnitsChannel;
  RealtimeChannel? adNetworksChannel;

  void subscribe() {
    adUnitsChannel = supabase
        .channel('ad_units_changes')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'ad_units',
          callback: (_) {
            ref.invalidate(externalAdProvider);
          },
        )
        .subscribe();

    adNetworksChannel = supabase
        .channel('ad_networks_changes')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: 'ad_networks',
          callback: (_) {
            ref.invalidate(externalAdProvider);
          },
        )
        .subscribe();
  }

  subscribe();

  ref.onDispose(() {
    if (adUnitsChannel != null) {
      supabase.removeChannel(adUnitsChannel!);
      adUnitsChannel = null;
    }
    if (adNetworksChannel != null) {
      supabase.removeChannel(adNetworksChannel!);
      adNetworksChannel = null;
    }
  });
});

/// Provider for ExternalAdService
final externalAdServiceProvider = Provider<ExternalAdService>((ref) {
  return ExternalAdService();
});

/// Provider for AdMobService
final adMobServiceProvider = Provider<AdMobService>((ref) {
  return AdMobService();
});

/// Provider for MobileAdService
final mobileAdServiceProvider = Provider<MobileAdService>((ref) {
  return MobileAdService();
});

/// Provider for AdMediationService
final adMediationServiceProvider = Provider<AdMediationService>((ref) {
  final externalAdService = ref.watch(externalAdServiceProvider);
  return AdMediationService(externalAdService: externalAdService);
});

/// Provider for AdRevenueService
final adRevenueServiceProvider = Provider<AdRevenueService>((ref) {
  return AdRevenueService();
});

/// Provider for AdConsentService
final adConsentServiceProvider = Provider<AdConsentService>((ref) {
  final externalAdService = ref.watch(externalAdServiceProvider);
  return AdConsentService(externalAdService: externalAdService);
});

/// Narrow config key so unrelated app_config changes do not refetch every placement.
final _externalAdConfigKeyProvider = Provider<String>((ref) {
  final config = ref.watch(appConfigProvider);
  final enabled = config['ads.external.enabled'] ?? 'false';
  final placements =
      config['ads.external.allowed_placements'] ?? '[]';
  final tiers = config['ads.external.allowed_tiers'] ?? '[]';
  final platforms =
      config['ads.external.allowed_platforms'] ?? '[]';
  return '$enabled|$placements|$tiers|$platforms';
});

/// Provider for getting external ad for a placement.
/// Mirrors [sponsoredAdProvider] debounce/cache so revisiting a tab does not refetch.
final externalAdProvider = FutureProvider.family<AdUnit?, String>((ref, placement) async {
  final _ = ref.watch(_externalAdConfigKeyProvider);

  final connectivityAsync = ref.watch(connectivityProvider);
  final isOnline = connectivityAsync.value ?? false;

  final platform = _currentPlatformKey();
  final cacheKey = '${placement}_$platform';
  final mediationService = ref.watch(adMediationServiceProvider);

  Future<AdUnit?> serveFromPersistentCache() async {
    if (peekCachedExternalAd(cacheKey) != null) {
      return peekCachedExternalAd(cacheKey);
    }
    await loadExternalAdCache();
    return peekCachedExternalAd(cacheKey);
  }

  if (!isOnline || shouldSkipSupabaseCalls()) {
    if (kDebugMode) {
      print('[ExternalAdProvider] $cacheKey: offline - attempting to serve from cache');
    }
    return serveFromPersistentCache();
  }

  final now = DateTime.now();
  final lastFetch = peekExternalAdFetchTime(cacheKey);

  if (lastFetch != null &&
      now.difference(lastFetch) < const Duration(seconds: 10)) {
    final cached = peekCachedExternalAd(cacheKey);
    if (cached != null) {
      if (kDebugMode) {
        print('[ExternalAdProvider] $cacheKey: using cached ad - debounce active');
      }
      return cached;
    }
  }

  final cached = peekCachedExternalAd(cacheKey);
  if (cached != null &&
      (lastFetch == null ||
          now.difference(lastFetch) < const Duration(seconds: 60))) {
    if (kDebugMode) {
      print('[ExternalAdProvider] $cacheKey: reusing cached ad');
    }
    recordExternalAdCacheHit(cacheKey);
    return cached;
  }

  final ad = await mediationService.getBestAdForPlacement(
    placement: placement,
    platform: platform,
  );

  if (ad == null) {
    // Keep last known unit when mediation has no fill (same as internal ads).
    return peekCachedExternalAd(cacheKey) ?? await serveFromPersistentCache();
  }

  if (kDebugMode) {
    print('[ExternalAdProvider] $cacheKey: fetch result=${ad.adUnitId}');
  }
  return ad;
});

/// Provider for user ad consent
final userAdConsentProvider = FutureProvider.family<AdConsent?, String>((ref, userId) async {
  final consentService = ref.watch(adConsentServiceProvider);
  return consentService.getUserConsent(userId);
});

/// Helper function to get current platform
String _currentPlatformKey() {
  if (kIsWeb) {
    return 'web';
  }

  if (defaultTargetPlatform == TargetPlatform.android) {
    return 'android';
  }

  if (defaultTargetPlatform == TargetPlatform.iOS) {
    return 'ios';
  }

  return 'web';
}
