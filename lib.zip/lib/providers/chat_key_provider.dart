import 'dart:async';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/models/user_chat_key_model.dart';
import 'package:matchme/services/chat_key_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatKeyState {
  final bool isLoaded;
  final bool isLocked;
  final UserChatKeyModel? activeKey;
  final Uint8List? privateKeyBytes;
  final bool hasRecoveryKey;
  final bool hasPasswordWrapper;

  const ChatKeyState({
    this.isLoaded = false,
    this.isLocked = true,
    this.activeKey,
    this.privateKeyBytes,
    this.hasRecoveryKey = false,
    this.hasPasswordWrapper = false,
  });

  ChatKeyState copyWith({
    bool? isLoaded,
    bool? isLocked,
    UserChatKeyModel? activeKey,
    Uint8List? privateKeyBytes,
    bool? hasRecoveryKey,
    bool? hasPasswordWrapper,
  }) {
    return ChatKeyState(
      isLoaded: isLoaded ?? this.isLoaded,
      isLocked: isLocked ?? this.isLocked,
      activeKey: activeKey ?? this.activeKey,
      privateKeyBytes: privateKeyBytes ?? this.privateKeyBytes,
      hasRecoveryKey: hasRecoveryKey ?? this.hasRecoveryKey,
      hasPasswordWrapper: hasPasswordWrapper ?? this.hasPasswordWrapper,
    );
  }
}

class ChatKeyNotifier extends Notifier<ChatKeyState> {
  final ChatKeyService _chatKeyService = ChatKeyService.instance;
  late Future<void> _initFuture;

  @override
  ChatKeyState build() {
    _initFuture = _init();
    return const ChatKeyState();
  }

  Future<void> get initializationComplete => _initFuture;

  Future<void> _init() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final hasLocal = await _chatKeyService.hasPrivateKeyLocally(userId);
      final activeKey = await _chatKeyService.fetchActiveKey(userId);
      final hasCrk = await _chatKeyService.loadCrkBytes(userId) != null;
      final hasPassword = activeKey != null &&
          (await _chatKeyService.fetchWrapperByType(activeKey.id, 'password')) != null;

      if (hasLocal) {
        final privateKey = await _chatKeyService.loadPrivateKeyBytes(userId);
        state = ChatKeyState(
          isLoaded: true,
          isLocked: false,
          activeKey: activeKey,
          privateKeyBytes: privateKey,
          hasRecoveryKey: hasCrk,
          hasPasswordWrapper: hasPassword,
        );
      } else if (activeKey != null) {
        state = ChatKeyState(
          isLoaded: true,
          isLocked: true,
          activeKey: activeKey,
          hasRecoveryKey: hasCrk,
          hasPasswordWrapper: hasPassword,
        );
      } else {
        state = ChatKeyState(
          isLoaded: true,
          isLocked: false,
          hasRecoveryKey: false,
          hasPasswordWrapper: false,
        );
      }
    } catch (e) {
      // Network or DB error during init — fall back to local-only state
      final hasLocal = await _chatKeyService.hasPrivateKeyLocally(userId);
      final hasCrk = await _chatKeyService.loadCrkBytes(userId) != null;
      if (hasLocal) {
        final privateKey = await _chatKeyService.loadPrivateKeyBytes(userId);
        state = ChatKeyState(
          isLoaded: true,
          isLocked: false,
          privateKeyBytes: privateKey,
          hasRecoveryKey: hasCrk,
        );
      } else {
        state = ChatKeyState(
          isLoaded: true,
          isLocked: true,
          hasRecoveryKey: hasCrk,
        );
      }
    }
  }

  Future<void> unlockWithPassword(String password) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) throw Exception('Not authenticated');

    final activeKey = state.activeKey;
    if (activeKey == null) throw Exception('No active key');

    final privateKey = await _chatKeyService.unlockWithPassword(
      userId: userId,
      userChatKeyId: activeKey.id,
      password: password,
    );

    if (privateKey != null) {
      state = state.copyWith(isLocked: false, privateKeyBytes: privateKey);
    } else {
      throw Exception('Invalid password');
    }
  }

  Future<void> unlockWithCrk(Uint8List crkBytes) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) throw Exception('Not authenticated');

    final activeKey = state.activeKey;
    if (activeKey == null) throw Exception('No active key');

    final privateKey = await _chatKeyService.unlockWithCrk(
      userId: userId,
      userChatKeyId: activeKey.id,
      crkBytes: crkBytes,
    );

    if (privateKey != null) {
      state = state.copyWith(isLocked: false, privateKeyBytes: privateKey);
    } else {
      throw Exception('Invalid recovery key');
    }
  }

  Future<void> setupEncryption({String? password}) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) throw Exception('Not authenticated');

    final newKey = await _chatKeyService.setupEncryption(
      userId: userId,
      password: password,
    );

    final privateKey = await _chatKeyService.loadPrivateKeyBytes(userId);

    state = ChatKeyState(
      isLoaded: true,
      isLocked: false,
      activeKey: newKey,
      privateKeyBytes: privateKey,
      hasRecoveryKey: true,
      hasPasswordWrapper: password != null && password.isNotEmpty,
    );
  }

  /// Replaces a zombie/locked key (no local private key and no recovery option)
  /// by retiring the old key in the DB and creating a fresh one.
  Future<void> replaceEncryption() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) throw Exception('Not authenticated');

    final oldKey = await _chatKeyService.deleteActiveKey(userId);
    if (oldKey != null) {
      await _chatKeyService.setupEncryption(
        userId: userId,
        existingKeyId: oldKey.id,
      );
    } else {
      await _chatKeyService.setupEncryption(userId: userId);
    }

    final privateKey = await _chatKeyService.loadPrivateKeyBytes(userId);
    final activeKey = await _chatKeyService.fetchActiveKey(userId);
    final hasCrk = await _chatKeyService.loadCrkBytes(userId) != null;

    state = ChatKeyState(
      isLoaded: true,
      isLocked: false,
      activeKey: activeKey,
      privateKeyBytes: privateKey,
      hasRecoveryKey: hasCrk,
      hasPasswordWrapper: false,
    );
  }

  Future<void> refresh() async {
    await _init();
  }

  Future<void> lock() async {
    state = state.copyWith(isLocked: true, privateKeyBytes: null);
  }

  bool get canSendEncrypted =>
      state.isLoaded && !state.isLocked && state.activeKey != null;
}

final chatKeyProvider =
    NotifierProvider<ChatKeyNotifier, ChatKeyState>(() {
  return ChatKeyNotifier();
});
