// lib/providers/connectivity_provider.dart
import 'dart:async';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:http/http.dart' as http;
import 'package:matchme/providers/user_preferences_provider.dart';
import 'package:matchme/services/connectivity_restore_coordinator.dart';
import 'package:matchme/services/offline_cache_manager.dart';
import 'package:matchme/services/runtime_supabase_config.dart';
import 'package:matchme/utils/offline_utils.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum ConnectivityHealthStatus { online, degraded, offline }

class ConnectivityHealth {
  final ConnectivityHealthStatus status;
  final bool hasNetworkTransport;
  final bool internetReachable;
  final bool backendReachable;
  final int consecutiveProbeFailures;
  final int consecutiveProbeSuccesses;

  const ConnectivityHealth({
    required this.status,
    required this.hasNetworkTransport,
    required this.internetReachable,
    required this.backendReachable,
    required this.consecutiveProbeFailures,
    required this.consecutiveProbeSuccesses,
  });

  bool get isOnline => internetReachable;
  bool get isBackendHealthy => backendReachable;
  bool get isUiOnline => status != ConnectivityHealthStatus.offline;

  String describe() {
    return '${status.name}(transport:$hasNetworkTransport,internet:$internetReachable,backend:$backendReachable,failures:$consecutiveProbeFailures,successes:$consecutiveProbeSuccesses)';
  }
}

class ConnectivityMonitorConfig {
  final Duration probeTimeout;
  final Duration healthyProbeInterval;
  final Duration suspectProbeInterval;
  final Duration offlineReprobeInterval;
  final Duration transientFailureProbeInterval;
  final Duration offlineGracePeriod;
  final Duration resumeGracePeriod;
  final Duration backgroundProbeInterval;
  final Duration backgroundOfflineGracePeriod;
  final int degradedProbeFailures;
  final int offlineBackendFailures;
  final int offlineTransportFailures;
  final int onlineProbeSuccesses;

  const ConnectivityMonitorConfig({
    this.probeTimeout = const Duration(seconds: 5),
    this.healthyProbeInterval = const Duration(seconds: 10),
    this.suspectProbeInterval = const Duration(seconds: 2),
    this.offlineReprobeInterval = const Duration(seconds: 5),
    this.transientFailureProbeInterval = const Duration(seconds: 3),
    this.offlineGracePeriod = const Duration(seconds: 20),
    this.resumeGracePeriod = const Duration(seconds: 12),
    this.backgroundProbeInterval = const Duration(seconds: 20),
    this.backgroundOfflineGracePeriod = const Duration(seconds: 60),
    this.degradedProbeFailures = 2,
    this.offlineBackendFailures = 4,
    this.offlineTransportFailures = 3,
    this.onlineProbeSuccesses = 2,
  });
}

Future<bool> _checkInternetConnectivity(Duration timeout) async {
  final baseUrl =
      (runtimeSupabaseUrl ?? '').trim().replaceFirst(RegExp(r'/$'), '');
  
  // Try the HTTP Auth health endpoint first (fast, no DB overhead).
  // If it fails, fall back to the Supabase RPC health_check which is
  // known to work on all instances (aligned with bootstrap health check).
  if (baseUrl.isNotEmpty) {
    try {
      final uri = Uri.parse('$baseUrl/auth/v1/health');
      final headers = <String, String>{'cache-control': 'no-cache'};
      final anonKey = runtimeSupabaseAnonKey;
      if (anonKey != null && anonKey.isNotEmpty) {
        headers['apikey'] = anonKey;
      }
      final response = await http
          .get(uri, headers: headers)
          .timeout(timeout);
      if (response.statusCode >= 200 && response.statusCode < 400) return true;
    } catch (_) {
      // Fall through to RPC check
    }
  }

  // Fall back to Supabase RPC health check (same mechanism as bootstrap
  // health check which is proven to work).
  try {
    await Supabase.instance.client.rpc('health_check').timeout(timeout);
    return true;
  } catch (_) {
    return false;
  }
}

Future<bool> _checkBackendConnectivity(Duration timeout) async {
  try {
    final dynamic resp = await Supabase.instance.client.rpc('health_check').timeout(timeout);
    if (resp == null) return false;

    Map<String, dynamic>? m;
    if (resp is Map) {
      try {
        m = Map<String, dynamic>.from(resp);
      } catch (_) {
        m = null;
      }
    }

    if (m != null) {
      final dynamic okVal = m['ok'];
      if (okVal is bool) return okVal;
      if (okVal is String) return okVal.toLowerCase() == 'true';
      return false;
    }

    if (resp is bool) return resp;

    return false;
  } catch (_) {
    return false;
  }
}

Future<ConnectivityHealth> getCurrentConnectivityHealth({
  ConnectivityMonitorConfig config = const ConnectivityMonitorConfig(),
}) async {
  final initialResults = await Connectivity().checkConnectivity();
  final hasTransport = !initialResults.contains(ConnectivityResult.none);
  if (!hasTransport) {
    return const ConnectivityHealth(
      status: ConnectivityHealthStatus.offline,
      hasNetworkTransport: false,
      internetReachable: false,
      backendReachable: false,
      consecutiveProbeFailures: 0,
      consecutiveProbeSuccesses: 0,
    );
  }
  final internetReachable = await _checkInternetConnectivity(config.probeTimeout);
  final backendReachable =
      internetReachable && await _checkBackendConnectivity(config.probeTimeout);
  return ConnectivityHealth(
    status: !internetReachable
        ? ConnectivityHealthStatus.offline
        : (backendReachable
            ? ConnectivityHealthStatus.online
            : ConnectivityHealthStatus.degraded),
    hasNetworkTransport: true,
    internetReachable: internetReachable,
    backendReachable: backendReachable,
    consecutiveProbeFailures: internetReachable ? 0 : 1,
    consecutiveProbeSuccesses: internetReachable ? 1 : 0,
  );
}

Stream<ConnectivityHealth> createConnectivityHealthStream({
  ConnectivityMonitorConfig config = const ConnectivityMonitorConfig(),
}) {
  debugPrint('🌐 [CONNECTIVITY] createConnectivityHealthStream: STARTING');
  bool disposed = false;
  int transportDownStreak = 0;
  int internetFailureStreak = 0;
  int backendFailureStreak = 0;
  int probeSuccessStreak = 0;
  ConnectivityHealthStatus currentStatus = ConnectivityHealthStatus.degraded;
  ConnectivityHealthStatus? lastEmittedStatus;
  String? lastSignature;
  Timer? probeTimer;
  bool probing = false;
  /// Screen off / background: probe less often but do not stop (screen off != offline).
  bool backgroundMode = false;
  bool lastHasTransport = false;
  AppLifecycleListener? appLifecycleListener;
  DateTime? lastBackendHealthyAt;
  DateTime? lastResumeAt;
  DateTime? lastTransportReconnectAt;
  StreamSubscription<List<ConnectivityResult>>? connectivitySubscription;

  final controller = StreamController<ConnectivityHealth>(
    onCancel: () {
      debugPrint('🌐 [CONNECTIVITY] Stream onCancel - cleaning up');
      disposed = true;
      probeTimer?.cancel();
      appLifecycleListener?.dispose();
      connectivitySubscription?.cancel();
    },
  );

  void safeAdd(ConnectivityHealth value) {
    if (disposed || controller.isClosed) return;
    final signature =
        '${value.status.name}|${value.hasNetworkTransport}|${value.internetReachable}|${value.backendReachable}|${value.consecutiveProbeFailures}|${value.consecutiveProbeSuccesses}';
    if (signature == lastSignature) return;
    lastSignature = signature;
    try {
      if (value.status == ConnectivityHealthStatus.online &&
          lastEmittedStatus != ConnectivityHealthStatus.online) {
        ConnectivityRestoreCoordinator.instance.scheduleRestore(
          reason: 'connectivity-online',
        );
      }
      lastEmittedStatus = value.status;
      controller.add(value);
    } catch (_) {}
  }

  void scheduleNextProbe(Duration interval, Future<void> Function() run) {
    probeTimer?.cancel();
    probeTimer = Timer(interval, () {
      run();
    });
  }

  bool shouldDelayOfflineTransition(DateTime now, {bool backendReachable = false}) {
    final withinResumeGrace =
        lastResumeAt != null &&
        now.difference(lastResumeAt!) < config.resumeGracePeriod &&
        !backendReachable;
    final withinTransportGrace =
        lastTransportReconnectAt != null &&
        now.difference(lastTransportReconnectAt!) < config.resumeGracePeriod &&
        !backendReachable;
    final offlineGrace = backgroundMode
        ? config.backgroundOfflineGracePeriod
        : config.offlineGracePeriod;
    final withinOfflineGrace =
        lastBackendHealthyAt != null &&
        now.difference(lastBackendHealthyAt!) < offlineGrace;
    return withinResumeGrace || withinTransportGrace || withinOfflineGrace;
  }

  Duration probeIntervalForStatus({
    required ConnectivityHealthStatus status,
    required bool hasPendingFailures,
  }) {
    if (backgroundMode) {
      return hasPendingFailures
          ? config.transientFailureProbeInterval
          : config.backgroundProbeInterval;
    }
    if (status == ConnectivityHealthStatus.offline) {
      return config.offlineReprobeInterval;
    }
    if (hasPendingFailures) {
      return config.transientFailureProbeInterval;
    }
    if (status == ConnectivityHealthStatus.online) {
      return config.healthyProbeInterval;
    }
    return config.suspectProbeInterval;
  }

  Future<void> sample([List<ConnectivityResult>? transportResults]) async {
    debugPrint(
      '🌐 [CONNECTIVITY] sample() called (disposed=$disposed probing=$probing background=$backgroundMode)',
    );
    if (disposed || probing) return;
    probing = true;
    try {
      final results = transportResults ?? await Connectivity().checkConnectivity();
      final hasTransport = !results.contains(ConnectivityResult.none);
      debugPrint('🌐 [CONNECTIVITY] Probe: transport=$hasTransport');
      
      if (!lastHasTransport && hasTransport) {
        debugPrint('🌐 [CONNECTIVITY] Transport came back online - immediate probe');
        lastTransportReconnectAt = DateTime.now();
        probeTimer?.cancel();
      }
      lastHasTransport = hasTransport;
      
      bool internetReachable = false;
      bool backendReachable = false;

      if (!hasTransport) {
        transportDownStreak += 1;
        internetFailureStreak = 0;
        backendFailureStreak = 0;
        probeSuccessStreak = 0;
      } else {
        transportDownStreak = 0;
        internetReachable = await _checkInternetConnectivity(config.probeTimeout);
        if (internetReachable) {
          backendReachable = await _checkBackendConnectivity(config.probeTimeout);
          internetFailureStreak = 0;
          if (backendReachable) {
            backendFailureStreak = 0;
            probeSuccessStreak += 1;
          } else {
            backendFailureStreak += 1;
            probeSuccessStreak = 0;
          }
        } else {
          internetFailureStreak += 1;
          backendFailureStreak = 0;
          probeSuccessStreak = 0;
        }
      }

      final now = DateTime.now();
      if (hasTransport && internetReachable && backendReachable) {
        lastBackendHealthyAt = now;
      }

      final wantsOffline =
          (!hasTransport &&
              transportDownStreak >= config.offlineTransportFailures) ||
          (hasTransport &&
              !internetReachable &&
              internetFailureStreak >= config.degradedProbeFailures) ||
          (hasTransport &&
              internetReachable &&
              !backendReachable &&
              backendFailureStreak >= config.offlineBackendFailures);

      if (wantsOffline) {
        final isWithinResumeGrace =
            lastResumeAt != null && now.difference(lastResumeAt!) < config.resumeGracePeriod;
        final isWithinTransportGrace =
            lastTransportReconnectAt != null && now.difference(lastTransportReconnectAt!) < config.resumeGracePeriod;
        final isWithinAnyGrace = isWithinResumeGrace || isWithinTransportGrace;
        
        final hasSingleFailureOnly =
            (internetFailureStreak == 1 && backendFailureStreak == 0 && transportDownStreak == 0) ||
            (backendFailureStreak == 1 && internetFailureStreak == 0 && transportDownStreak == 0);
        
        if (isWithinAnyGrace && hasSingleFailureOnly) {
          currentStatus = ConnectivityHealthStatus.online;
          debugPrint(
            '🌐 [CONNECTIVITY] Assuming online during grace period despite probe failure '
            '(internet_streak=$internetFailureStreak, backend_streak=$backendFailureStreak, '
            'transport_streak=$transportDownStreak, resumeGrace=$isWithinResumeGrace, '
            'transportGrace=$isWithinTransportGrace)',
          );
        } else {
          currentStatus = shouldDelayOfflineTransition(now, backendReachable: backendReachable)
              ? ConnectivityHealthStatus.degraded
              : ConnectivityHealthStatus.offline;
        }
      } else if (hasTransport &&
          internetReachable &&
          backendReachable &&
          probeSuccessStreak >= config.onlineProbeSuccesses) {
        currentStatus = ConnectivityHealthStatus.online;
      } else if (hasTransport &&
          internetReachable &&
          !backendReachable) {
        currentStatus = ConnectivityHealthStatus.degraded;
      }

      debugPrint('🌐 [CONNECTIVITY] Emitting: status=${currentStatus.name} internet=$internetReachable backend=$backendReachable');

      safeAdd(
        ConnectivityHealth(
          status: currentStatus,
          hasNetworkTransport: hasTransport,
          internetReachable: internetReachable,
          backendReachable: backendReachable,
          consecutiveProbeFailures: internetReachable
              ? backendFailureStreak
              : internetFailureStreak,
          consecutiveProbeSuccesses: probeSuccessStreak,
        ),
      );

      final hasPendingFailures =
          transportDownStreak > 0 ||
          internetFailureStreak > 0 ||
          backendFailureStreak > 0;
      final nextInterval = probeIntervalForStatus(
        status: currentStatus,
        hasPendingFailures: hasPendingFailures,
      );
      scheduleNextProbe(nextInterval, sample);
    } catch (e) {
      if (!isExpectedOfflineFailure(e)) {
        debugPrint('🌐 [CONNECTIVITY] Probe error: $e');
      }
      if (!disposed) {
        scheduleNextProbe(config.transientFailureProbeInterval, sample);
      }
    } finally {
      probing = false;
    }
  }

  connectivitySubscription =
      Connectivity().onConnectivityChanged.listen((results) {
    sample(results);
  });

  appLifecycleListener = AppLifecycleListener(
    onPause: () {
      backgroundMode = true;
      debugPrint(
        '🌐 [CONNECTIVITY] App paused (screen off/background) - slower probes, staying active',
      );
      probeTimer?.cancel();
      unawaited(sample());
    },
    onHide: () {
      backgroundMode = true;
      debugPrint('🌐 [CONNECTIVITY] App hidden - slower probes, staying active');
      probeTimer?.cancel();
      unawaited(sample());
    },
    onResume: () {
      if (disposed) return;
      backgroundMode = false;
      lastResumeAt = DateTime.now();
      debugPrint('🌐 [CONNECTIVITY] App resumed - immediate reachability probe');
      probeTimer?.cancel();
      unawaited(sample());
    },
  );

  unawaited(sample());
  debugPrint('🌐 [CONNECTIVITY] createConnectivityHealthStream: returning stream');
  return controller.stream;
}

final connectivityHealthProvider = StreamProvider<ConnectivityHealth>((ref) {
  return createConnectivityHealthStream();
});

final connectivityProvider = Provider<AsyncValue<bool>>((ref) {
  final prefs = ref.watch(userPreferencesProvider);
  OfflineCacheManager.instance.setForceOnline(prefs.highAccuracyMode);
  final healthAsync = ref.watch(connectivityHealthProvider);
  return healthAsync.whenData((health) => health.isOnline && OfflineCacheManager.instance.isSupabaseAvailable);
});
