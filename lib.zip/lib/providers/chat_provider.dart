// lib/providers/chat_provider.dart
import 'dart:async';
import 'dart:convert'; // For jsonEncode
import 'dart:io' show Platform;
import 'dart:math' show pow, Random;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/models/chat_message_model.dart';
import 'package:matchme/services/local_db_service.dart';
import 'package:matchme/services/translation_service.dart';
import 'package:matchme/services/translation_cache_manager.dart';
import 'package:matchme/services/web_notification_service.dart';
import 'package:matchme/services/offline_cache_manager.dart';
import 'package:matchme/services/encrypted_cache_service.dart';
import 'dart:typed_data';

import 'package:matchme/config/security_constants.dart';
import 'package:matchme/services/chat_key_service.dart';
import 'package:matchme/services/crypto_service.dart';
import 'package:matchme/providers/chat_key_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:uuid/uuid.dart';
import 'package:matchme/providers/translation_version_provider.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/services/global_sync_manager.dart';
import 'package:matchme/providers/home_providers.dart';
import 'package:matchme/utils/offline_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:matchme/providers/auth_provider.dart';
import 'package:matchme/web_imports.dart' as html;

final supabase = Supabase.instance.client;
final uuid = Uuid();

// Helper function to format sender name: "FirstName LastInitial." e.g., "John S."
String formatSenderNameForNotification(String fullName) {
  if (fullName.isEmpty) return 'MatchMe';

  final parts = fullName.trim().split(RegExp(r'\s+'));
  if (parts.length == 1) {
    return parts[0]; // Just first name if no last name
  }

  // First name + first letter of last name with period
  final firstName = parts[0];
  final lastInitial = parts[parts.length - 1][0].toUpperCase();
  return '$firstName $lastInitial.';
}

// Debouncer for reaction updates to prevent rapid clicks
final Map<String, Timer> _reactionDebouncer = {};
Future<void>? _startupTranslationSyncInFlight;

// --- ChatSyncService (Modified to take localDb as parameter) ---
class ChatSyncService {
  final LocalDbService localDb;
  ChatSyncService(this.localDb);

  Future<void> syncMessages(String matchId) async {
    if (matchId.isEmpty) return;
    try {
      // print('â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•');
      // print('ðŸ”„ SYNC START: syncMessages called for matchId=$matchId');
      // print('â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•');

      final data = await supabase
          .from('chat_messages')
          .select(
            'id, match_id, sender_id, content_original, content_translated, detected_source_language, translated_target_language, created_at, edited_at, delivered_at, read_at, reply_to_message_id, encryption_scheme, sender_key_id, recipient_key_id, content_original_encrypted, content_original_nonce, content_translated_encrypted, content_translated_nonce, wrapped_keys, translation_capable, recipient_id',
          )
          .eq('match_id', matchId)
          .order('created_at', ascending: true);

      // print('ðŸ”„ SYNC: Retrieved ${data.length} messages from Supabase');
      for (final _ in data) {
        // print('   - Message ${_['id']}: delivered_at=${_['delivered_at']}, sender=${_['sender_id']}');
      }

      // Replace all messages for this match with the current database state
      // This ensures deleted messages are removed from local cache
      await localDb.saveMessages(matchId, data.cast<Map<String, dynamic>>());

      // print('ðŸ”„ SYNC: Saved ${data.length} messages to local database');

      // Mark undelivered messages from the other user as delivered
      // (This user just received them by syncing)
      final currentUserId = supabase.auth.currentUser?.id;
      // print('ðŸ”„ SYNC: currentUserId=$currentUserId');

      if (currentUserId != null && data.isNotEmpty) {
        // Collect message IDs that need to be marked as delivered
        final messagesToDeliver = <String>[];

        for (final msg in data as List) {
          final msgId = msg['id'] as String?;
          final senderId = msg['sender_id'] as String?;
          final deliveredAt = msg['delivered_at'];

          // print('ðŸ”„ SYNC: Checking msg=$msgId (sender=$senderId, delivered=$deliveredAt, isOtherUser=${senderId != currentUserId})');

          // If this message is from the other user and not yet delivered, mark it
          if (senderId != null &&
              senderId != currentUserId &&
              (deliveredAt == null || deliveredAt == '')) {
            messagesToDeliver.add(msgId ?? '');
            // print('ðŸ”„ SYNC: âž• Added $msgId to delivery list (from other user, not yet delivered)');
          } else {
            final _ = senderId == currentUserId
                ? 'from this user'
                : 'already delivered';
            // print('ðŸ”„ SYNC: â­ï¸  Skipped $msgId ($reason)');
          }
        }

        // Batch mark messages as delivered with better error handling
        if (messagesToDeliver.isNotEmpty) {
          // print('ðŸ”„ SYNC: Marking ${messagesToDeliver.length} messages as delivered');

          try {
            final results = await Future.wait(
              messagesToDeliver.map((msgId) {
                // print('ðŸ”„ SYNC: Calling RPC mark_message_delivered for $msgId...');
                return supabase
                    .rpc(
                      'mark_message_delivered',
                      params: {'p_message_id': msgId},
                    )
                    .then((result) {
                      // print('âœ… SYNC: RPC succeeded for $msgId - result=$result');
                      return true;
                    })
                    .catchError((e, st) {
                      // print('âŒ SYNC: RPC FAILED for $msgId');
                      // print('   Error: $e');
                      // print('   Stack: $st');
                      return false;
                    });
              }),
              eagerError: false,
            );

            final _ = results.where((r) => r == true).length;
            // print('ðŸ”„ SYNC: Successfully marked $successCount/${messagesToDeliver.length} messages as delivered');
          } catch (e, _) {
            // print('ðŸ”„ SYNC: Error in batch delivery marking: $e\n$st');
            // Don't throw - marking as delivered is non-critical
          }
        } else {
          // print('ðŸ”„ SYNC: No messages to deliver (either no undelivered messages or no current user)');
        }
      }
    } catch (e, _) {
      // print('âŒ SYNC ERROR: $e\n$st');
      // Keep the error surfaced but avoid noisy logging here.
    }
    // print('â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•');
    // print('ðŸ”„ SYNC END: syncMessages completed');
    // print('â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•');
  }

  // Diagnostic function to test if RPC function is working
  Future<void> testRpcFunction(String testMessageId) async {
    try {
      // print('ðŸ§ª TEST: Testing RPC mark_message_delivered with messageId=$testMessageId');
      // print('ðŸ§ª TEST: Current user: ${supabase.auth.currentUser?.id}');

      final _ = await supabase.rpc(
        'mark_message_delivered',
        params: {'p_message_id': testMessageId},
      );

      // print('âœ… TEST: RPC call succeeded! Result: $_');
      // print('ðŸ§ª TEST: Check Supabase to see if delivered_at was updated for this message');
    } catch (e, _) {
      // print('âŒ TEST: RPC call FAILED!');
      // print('   Error: $e');
      // print('   Type: ${e.runtimeType}');
      // print('   Stack: $st');

      // Try to extract more details
      if (e is PostgrestException) {
        // print('   PostgrestException details:');
        // print('   - Code: ${e.code}');
        // print('   - Message: ${e.message}');
        // print('   - Details: ${e.details}');
      }
    }
  }
}

final chatSyncProvider = Provider.family<ChatSyncService, String>(
  (ref, matchId) => ChatSyncService(ref.read(localDbProvider)),
);

// --- UPDATED: chatMessagesProvider (Fixes bugs & uses local DB + realtime)
// Emits a stream of ChatMessageModel lists for a given matchId.
final chatMessagesProvider = StreamProvider.autoDispose.family<List<ChatMessageModel>, String>((
  ref,
  matchId,
) {
  try {
    if (matchId.isEmpty) return Stream.value([]);

    final localDb = ref.watch(localDbProvider);
    // Watch the private-key bytes so that the entire provider restarts when
    // the key transitions from null → loaded.  On the first run the key may
    // still be null (decryption is skipped); Riverpod re-creates this provider
    // when the key loads, and the second run decrypts immediately.
    // Using `select` avoids unnecessary restarts for unrelated state changes.
    ref.watch(chatKeyProvider.select((s) => s.privateKeyBytes));
    final localStream = localDb.watchMessages(matchId);

    final StreamController<List<ChatMessageModel>> streamController =
        StreamController<List<ChatMessageModel>>.broadcast();
    bool disposed = false;
    bool scheduledInitialSync = false;
    Timer? realtimeSyncDebounce;
    Timer? reconnectTimer;
    Timer? emitDebounce;
    // Coalesce rapid stream emissions so the chat UI only rebuilds once
    // when multiple sync/decryption cycles fire in quick succession.
    void debouncedEmit(List<ChatMessageModel> messages) {
      if (disposed || streamController.isClosed) return;
      emitDebounce?.cancel();
      emitDebounce = Timer(const Duration(milliseconds: 50), () {
        if (!disposed && !streamController.isClosed) {
          streamController.add(messages);
        }
      });
    }

    // Use syncService for an initial full sync once we subscribe
    ChatSyncService? syncService;
    try {
      syncService = ref.read(chatSyncProvider(matchId));
    } catch (e, _) {
      // print('chatSyncProvider init failed for $matchId: $e\n$st');
      syncService = null; // don't fail the provider; fall back to local-only
    }

    final channel = (() {
      try {
        return supabase.channel('public:chat_messages:match_id=eq.$matchId');
      } catch (e, _) {
        // print('Failed to create supabase channel for $matchId: $e\n$st');
        return null;
      }
    })();

    // Always emit local cached messages immediately (offline-first).
    final localSubscription = localStream.listen((messagesData) async {
      if (disposed || streamController.isClosed) return;
      try {
        // Normalize incoming local cache items to guard against inconsistent types (web IndexedDB variations).
        final normalized = messagesData.map((json) {
          try {
            // Ensure keys are strings and critical IDs are strings
            if (json.containsKey('sender_id') &&
                json['sender_id'] != null &&
                json['sender_id'] is! String) {
              json['sender_id'] = json['sender_id'].toString();
            }
            if (json.containsKey('match_id') &&
                json['match_id'] != null &&
                json['match_id'] is! String) {
              json['match_id'] = json['match_id'].toString();
            }
            if (json.containsKey('id') &&
                json['id'] != null &&
                json['id'] is! String) {
              json['id'] = json['id'].toString();
            }
            // Ensure reaction_summary is a Map if present; otherwise coerce to empty map
            if (json.containsKey('reaction_summary') &&
                json['reaction_summary'] is! Map) {
              json['reaction_summary'] = <String, int>{};
            }
          } catch (_) {}
          return json;
        }).toList();

        var models = normalized
            .map((json) => ChatMessageModel.fromJson(json))
            .toList();

        // Phase 1 — Emit raw models immediately so the loading spinner
        // disappears.  Decryption runs asynchronously in Phase 2.
        final byIdPhase1 = <String, ChatMessageModel>{};
        for (final m in models) {
          byIdPhase1[m.id] = m;
        }
        final resolvedPhase1 = models.map((m) {
          final replyId = m.replyToMessageId;
          if (replyId == null) return m;
          final original = byIdPhase1[replyId];
          if (original == null) return m;
          return m.copyWith(
            replyToSenderId: original.senderId,
            replyToContent: original.contentOriginal,
          );
        }).toList();
        debouncedEmit(resolvedPhase1);

        // Phase 2 — Decrypt v1 encrypted messages in the background
        // and re-emit when done.
        try {
          final chatKeyState = ref.read(chatKeyProvider);
          final currentUserId = supabase.auth.currentUser?.id;
          final chatKeyService = ChatKeyService.instance;
          final decryptedUpdates = <Map<String, dynamic>>[];
          if (currentUserId != null) {
            for (int i = 0; i < models.length; i++) {
              final m = models[i];
              if (m.encryptionScheme == 'v1' &&
                  m.contentOriginalEncrypted != null &&
                  m.contentOriginalEncrypted!.isNotEmpty &&
                  m.contentOriginalNonce != null &&
                  m.wrappedKeys != null &&
                  m.contentOriginal.isEmpty) {
                String? decrypted;
                if (chatKeyState.privateKeyBytes != null) {
                  try {
                    decrypted = await chatKeyService.decryptMessageContent(
                      currentUserId: currentUserId,
                      currentUserPrivateKey: chatKeyState.privateKeyBytes!,
                      messageId: m.id,
                      matchId: m.matchId,
                      senderId: m.senderId,
                      senderKeyId: m.senderKeyId!,
                      recipientKeyId: m.recipientKeyId!,
                      contentOriginalEncryptedBase64: m.contentOriginalEncrypted!,
                      contentOriginalNonceBase64: m.contentOriginalNonce!,
                      wrappedKeys: m.wrappedKeys!,
                      recipientId: null,
                    );
                  } catch (_) {}
                }
                if (decrypted == null) {
                  try {
                    final cached = normalized[i]['content_original_encrypted_cache'] as String?;
                    if (cached != null && cached.isNotEmpty) {
                      decrypted = await EncryptedCacheService.instance.decryptFromCache(cached);
                    }
                  } catch (_) {}
                }
                if (decrypted != null && decrypted.isNotEmpty) {
                  models[i] = m.copyWith(contentOriginal: decrypted);
                  decryptedUpdates.add({'id': m.id, 'content_original': decrypted});
                }
              }

              // Decrypt content_translated_encrypted for v1 messages
              if (m.encryptionScheme == 'v1' &&
                  m.contentTranslatedEncrypted != null &&
                  m.contentTranslatedEncrypted!.isNotEmpty &&
                  m.contentTranslatedNonce != null &&
                  m.wrappedKeys != null &&
                  (m.contentTranslated == null || m.contentTranslated!.isEmpty)) {
                String? decrypted;
                if (chatKeyState.privateKeyBytes != null) {
                  try {
                    // Use UI language as the target language for AAD — the edge
                    // function always encrypts for the current UI locale, but
                    // translatedTargetLanguage in the local DB may be stale
                    // from a previous language.
                    final locale = ref.read(localizationProvider);
                    final uiLang = locale.currentLocale.languageCode;
                    final normalizedTarget = normalizeLanguageCode(uiLang);
                    decrypted = await chatKeyService.decryptMessageTranslatedContent(
                      currentUserId: currentUserId,
                      currentUserPrivateKey: chatKeyState.privateKeyBytes!,
                      messageId: m.id,
                      matchId: m.matchId,
                      senderId: m.senderId,
                      senderKeyId: m.senderKeyId!,
                      recipientKeyId: m.recipientKeyId!,
                      contentTranslatedEncryptedBase64: m.contentTranslatedEncrypted!,
                      contentTranslatedNonceBase64: m.contentTranslatedNonce!,
                      wrappedKeys: m.wrappedKeys!,
                      detectedSourceLanguage: m.detectedSourceLanguage ?? 'und',
                      targetLanguage: normalizedTarget,
                      recipientId: null,
                    );
                  } catch (e) {
                    print('[chatMessagesProvider] decryptMessageTranslatedContent failed: $e');
                  }
                }
                if (decrypted == null) {
                  try {
                    final cached = normalized[i]['content_translated_encrypted_cache'] as String?;
                    if (cached != null && cached.isNotEmpty) {
                      decrypted = await EncryptedCacheService.instance.decryptFromCache(cached);
                    }
                  } catch (e) {
                    print('[chatMessagesProvider] cache fallback failed: $e');
                  }
                }
                if (decrypted != null && decrypted.isNotEmpty) {
                  models[i] = m.copyWith(contentTranslated: decrypted, translatedText: decrypted);
                  decryptedUpdates.add({'id': m.id, 'content_translated': decrypted});
                } else if (chatKeyState.privateKeyBytes != null && m.contentTranslatedEncrypted != null) {
                  // Key was available but decryption failed (likely broken AAD).
                  // Only clear in the local DB — DO NOT clear in Supabase, because
                  // the edge function may have already created a correctly-encrypted
                  // translation (e.g. from the smart retranslation running moments
                  // before).  Clearing Supabase here would destroy that valid result.
                  // The Supabase-side cleanup is handled by translationFamilyProvider
                  // before it triggers a batch re-translate, which avoids this race.
                  try {
                    await localDb.mergeMessages(matchId, [{
                      'id': m.id,
                      'content_translated_encrypted': null,
                      'content_translated_nonce': null,
                    }]);
                  } catch (_) {}
                }
              }
            }
            // Persist all decrypted content in a single batch write to avoid
            // triggering N separate watchMessages re-emissions (one per message),
            // which would cause the chat list to shuffle on every update.
            if (decryptedUpdates.isNotEmpty) {
              try {
                await localDb.mergeMessages(matchId, decryptedUpdates);
              } catch (_) {}
            }
          }

          // Update the chats-box last-message preview now that we've decrypted
          // any encrypted messages. This ensures the chat list shows a real
          // preview instead of a blank entry.
          if (currentUserId != null) {
            try {
              await localDb.recomputeChatLastMessagePreviewFromMessages(
                currentUserId,
                matchId,
              );
            } catch (_) {}
          }

          final byId = <String, ChatMessageModel>{};
          for (final m in models) {
            byId[m.id] = m;
          }
          final resolved = models.map((m) {
            final replyId = m.replyToMessageId;
            if (replyId == null) return m;
            final original = byId[replyId];
            if (original == null) return m;
            return m.copyWith(
              replyToSenderId: original.senderId,
              replyToContent: original.contentOriginal,
            );
          }).toList();

          debouncedEmit(resolved);
        } catch (_) {
          // Phase 2 best-effort; Phase 1 emission already happened.
        }

        // If there are no messages locally and we haven't scheduled an initial recovery sync,
        // schedule a few background sync attempts to cover intermittent failures (e.g., slow IndexedDB).
        if ((messagesData.isEmpty) &&
            !scheduledInitialSync &&
            syncService != null) {
          scheduledInitialSync = true;
          Future(() async {
            // print('chatMessagesProvider: initial empty local cache for $matchId; scheduling recovery sync attempts');
            final delays = [
              const Duration(seconds: 1),
              const Duration(seconds: 2),
              const Duration(seconds: 4),
            ];
            for (var i = 0; i < delays.length; i++) {
              try {
                await Future.delayed(delays[i]);
                // print('chatMessagesProvider: recovery sync attempt #${i + 1} for $matchId');
                await syncService!.syncMessages(matchId);
                // print('chatMessagesProvider: recovery sync successful for $matchId on attempt #${i + 1}');
                break;
              } catch (e, _) {
                // print('chatMessagesProvider: recovery sync attempt #${i + 1} failed for $matchId: $e\n$st');
              }
            }
          });
        }
      } catch (e, _) {
        // Log parsing errors so we can see why the stream isn't emitting
        try {
          // print('chatMessagesProvider: failed to parse local messages for $matchId: $e\n$st');
          if (messagesData.isNotEmpty) {
            // print('chatMessagesProvider: sample problematic message: ${messagesData.first}');
          }
        } catch (_) {}
      }
    });

    Future<void> handleChanges(PostgresChangePayload payload) async {
      if (disposed || !ref.mounted || syncService == null) {
        return;
      }
      final event = payload.eventType;
      if (event != PostgresChangeEvent.insert &&
          event != PostgresChangeEvent.update &&
          event != PostgresChangeEvent.delete) {
        return;
      }
      realtimeSyncDebounce?.cancel();
      realtimeSyncDebounce = Timer(const Duration(milliseconds: 120), () async {
        if (disposed || !ref.mounted || syncService == null) {
          return;
        }
        try {
          await syncService.syncMessages(matchId);
        } catch (e) {
          // print('Error syncing messages on realtime change for $matchId: $e');
        }
      });
    }

    int reconnectAttempt = 0;
    const int maxReconnectAttempts = 10;

    bool shouldSkipReconnect() {
      final lifecycle = WidgetsBinding.instance.lifecycleState;
      final isBackground =
          lifecycle == AppLifecycleState.paused ||
          lifecycle == AppLifecycleState.detached;
      if (isBackground) return true;
      if (!kIsWeb) return false;
      try {
        return html.document.hidden == true ||
            html.document.visibilityState == 'hidden';
      } catch (_) {
        return false;
      }
    }

    Duration getExponentialBackoffDuration(int attempt) {
      final baseMs = 500;
      final maxMs = 30000;
      final exponent = pow(2, attempt).toInt();
      final durationMs = baseMs * exponent;
      final clamped = durationMs > maxMs ? maxMs : durationMs;
      final jitter = Random().nextInt(1000);
      return Duration(milliseconds: clamped + jitter);
    }

    Future<void> reconnectChannel() async {
      if (disposed || !ref.mounted || shouldSkipReconnect()) {
        return;
      }
      try {
        // ignore: invalid_use_of_internal_member
        supabase.realtime.connect();
      } catch (e) {
        // print('Error reconnecting realtime socket for $matchId: $e');
      }
      // Re-subscribe the existing channel instead of invalidating the entire
      // provider.  ref.invalidateSelf() triggers a Riverpod assertion error
      // (pause-count mismatch) when the provider has watched/listened
      // dependencies, so we avoid it entirely.  The channel's status callback
      // will handle the re-sync on subscribe.
      if (channel == null) {
        if (syncService != null) {
          try {
            await syncService.syncMessages(matchId);
          } catch (_) {}
        }
        return;
      }
      try {
        channel.subscribe();
      } catch (e) {
        // print('Error re-subscribing channel for $matchId: $e');
        if (syncService != null) {
          try {
            await syncService.syncMessages(matchId);
          } catch (_) {}
        }
      }
    }

    if (channel != null) {
      channel
          .onPostgresChanges(
            event: PostgresChangeEvent
                .all, // Catches INSERTs, UPDATEs, and DELETEs
            schema: 'public',
            table: 'chat_messages',
            callback: handleChanges,
          )
          .subscribe((status, err) async {
            if (!ref.mounted || disposed) {
              // Provider no longer active - ignore subscription callbacks
              return;
            }
            if (status == RealtimeSubscribeStatus.subscribed) {
              reconnectTimer?.cancel();
              reconnectAttempt = 0; // Reset backoff on successful reconnection
              // Run a full sync ONCE on subscribe, to catch up (guarded)
              try {
                if (syncService != null) {
                  await syncService.syncMessages(matchId);
                }
              } catch (e) {
                // print('Error syncing messages on subscribe for $matchId: $e');
              }
            } else if (status == RealtimeSubscribeStatus.closed ||
                status == RealtimeSubscribeStatus.channelError) {
              // print('âš ï¸ Chat messages subscription disconnected for $matchId - status: $status, error: $err');

              if (shouldSkipReconnect()) {
                // print('Skipping auto-reconnect for chat $matchId due to app visibility/lifecycle');
                return;
              }
              reconnectTimer?.cancel();

              if (reconnectAttempt >= maxReconnectAttempts) {
                // Max reconnect attempts reached
                return;
              }

              final backoffDuration = getExponentialBackoffDuration(
                reconnectAttempt,
              );
              reconnectAttempt++;

              reconnectTimer = Timer(backoffDuration, () {
                unawaited(reconnectChannel());
              });
            } else if (err != null) {
              // print('Realtime subscription error for $matchId: $err');
            }
          });
    }

    ref.onDispose(() {
      disposed = true;
      realtimeSyncDebounce?.cancel();
      reconnectTimer?.cancel();
      emitDebounce?.cancel();
      localSubscription.cancel();
      try {
        if (channel != null) supabase.removeChannel(channel);
      } catch (_) {}
      streamController.close();
    });

    return streamController.stream;
  } catch (e, _) {
    // print('chatMessagesProvider failed to initialize for $matchId: $e\n$st');
    return Stream.value(<ChatMessageModel>[]);
  }
});

// --- chatServiceProvider (Unchanged) ---
final chatServiceProvider = Provider((ref) => ChatService(ref));

class ChatService {
  final Ref _ref;
  ChatService(this._ref);

  Future<void> sendMessage({
    required String matchId,
    required String text,
    String? replyToMessageId,
    bool allowPlaintextFallback = false,
  }) async {
    final user = supabase.auth.currentUser;
    if (user == null) throw Exception('User not logged in');
    final localDb = _ref.read(localDbProvider);
    final tempId = uuid.v4();

    // Check if we can send encrypted
    final chatKeyState = _ref.read(chatKeyProvider);
    final ChatKeyService chatKeyService = ChatKeyService.instance;

    bool canEncrypt =
        chatKeyState.isLoaded &&
        chatKeyState.activeKey != null &&
        chatKeyState.privateKeyBytes != null;
    if (!canEncrypt) {
      print(
        '🔐 [sendMessage] Cannot encrypt: isLoaded=${chatKeyState.isLoaded} activeKey=${chatKeyState.activeKey?.id} privateKey=${chatKeyState.privateKeyBytes != null}',
      );
    }
    String? recipientKeyId;
    Map<String, dynamic>? wrappedKeys;
    String? senderKeyId = chatKeyState.activeKey?.id;
    String? contentOriginalEncrypted;
    String? contentOriginalNonce;
    String? messageRecipientId;

    if (canEncrypt && senderKeyId != null) {
      print('🔐 [sendMessage] Starting encryption flow...');
      try {
        final matchResp = await supabase
            .from('matches')
            .select('user1_id, user2_id')
            .eq('id', matchId)
            .maybeSingle();
        if (matchResp != null) {
          final recipientId = matchResp['user1_id'] == user.id
              ? matchResp['user2_id'] as String
              : matchResp['user1_id'] as String;
          messageRecipientId = recipientId;
          final recipientActive = await chatKeyService.fetchActiveKey(
            recipientId,
          );
          if (recipientActive != null) {
            recipientKeyId = recipientActive.id;
            print(
              '🔐 [sendMessage] Recipient has active key: ${recipientActive.id}',
            );

            final crypto = CryptoService.instance;
            final senderPrivateKey = chatKeyState.privateKeyBytes!;
            final recipientPublicKeyBytes = base64Decode(
              recipientActive.publicKeyBase64,
            );

            final messageKey = await crypto.generateMessageKey();
            final contentNonce = crypto.generateNonce();

            final encryptedContent = await crypto.encryptOriginal(
              plaintext: Uint8List.fromList(utf8.encode(text)),
              messageKey: messageKey,
              nonce: contentNonce,
              messageId: tempId,
              matchId: matchId,
              senderId: user.id,
              recipientId: recipientId,
              senderKeyId: senderKeyId,
              recipientKeyId: recipientKeyId,
            );

            contentOriginalEncrypted = base64Encode(encryptedContent);
            contentOriginalNonce = base64Encode(contentNonce);

            final messageIdBytes = Uint8List.fromList(utf8.encode(tempId));

            final sharedSecret = await crypto.x25519SharedSecretFromPrivateKey(
              myPrivateKey: senderPrivateKey,
              theirPublicKey: recipientPublicKeyBytes,
            );

            final recipientWrapKey = await crypto.hkdfDeriveBytes(
              inputKeyMaterial: sharedSecret,
              salt: messageIdBytes,
              info: SecurityConstants.recipientWrapInfoLabel,
            );

            final recipientWrapNonce = crypto.generateNonce();
            final recipientWrapAad = crypto.buildWrapAad(
              purpose: 'recipient',
              messageId: tempId,
              senderKeyId: senderKeyId,
              recipientOrSupabaseKeyId: recipientKeyId,
            );

            final recipientWrappedMessageKey = await crypto.wrapMessageKey(
              messageKey: messageKey,
              wrapKey: recipientWrapKey,
              nonce: recipientWrapNonce,
              aad: recipientWrapAad,
            );

            final supabasePublicKeyBytes = base64Decode(
              SecurityConstants.supabaseTranslationPublicKeyBase64,
            );

            final supabaseSharedSecret = await crypto
                .x25519SharedSecretFromPrivateKey(
                  myPrivateKey: senderPrivateKey,
                  theirPublicKey: supabasePublicKeyBytes,
                );

            final supabaseWrapKey = await crypto.hkdfDeriveBytes(
              inputKeyMaterial: supabaseSharedSecret,
              salt: messageIdBytes,
              info: SecurityConstants.supabaseWrapInfoLabel,
            );

            final supabaseWrapNonce = crypto.generateNonce();
            final supabaseWrapAad = crypto.buildWrapAad(
              purpose: 'supabase',
              messageId: tempId,
              senderKeyId: senderKeyId,
              recipientOrSupabaseKeyId:
                  SecurityConstants.supabaseTranslationKeyId,
            );

            final supabaseWrappedMessageKey = await crypto.wrapMessageKey(
              messageKey: messageKey,
              wrapKey: supabaseWrapKey,
              nonce: supabaseWrapNonce,
              aad: supabaseWrapAad,
            );

            wrappedKeys = {
              'recipient': {
                'nonce': base64Encode(recipientWrapNonce),
                'ciphertext': base64Encode(recipientWrappedMessageKey),
              },
              'supabase': {
                'nonce': base64Encode(supabaseWrapNonce),
                'ciphertext': base64Encode(supabaseWrappedMessageKey),
              },
            };
            print('🔐 [sendMessage] Encryption succeeded, wrappedKeys built');
          } else {
            print(
              '🔐 [sendMessage] Recipient has NO active key - falling back to plaintext',
            );
            canEncrypt = false;
          }
        }
      } catch (e) {
        print('🔐 [sendMessage] Exception during encryption: $e');
        canEncrypt = false;
      }
    }

    final optimisticMessage = ChatMessageModel(
      id: tempId,
      matchId: matchId,
      senderId: user.id,
      contentOriginal: text,
      createdAt: DateTime.now(),
      isPending: true,
      replyToMessageId: replyToMessageId,
      encryptionScheme: canEncrypt ? 'v1' : 'plaintext',
      senderKeyId: canEncrypt ? senderKeyId : null,
      recipientKeyId: canEncrypt ? recipientKeyId : null,
      contentOriginalEncrypted: canEncrypt ? contentOriginalEncrypted : null,
      contentOriginalNonce: canEncrypt ? contentOriginalNonce : null,
      wrappedKeys: canEncrypt ? wrappedKeys : null,
      translationCapable: false,
    );
    try {
      await localDb.addMessages(matchId, [optimisticMessage.toJson()]);
    } catch (_) {}
    final connectivityResult = await Connectivity().checkConnectivity();
    final isOnline = connectivityResult.any(
      (r) => r != ConnectivityResult.none,
    );
    final supabasePayload = <String, dynamic>{
      'id': tempId,
      'match_id': matchId,
      'sender_id': user.id,
      if (canEncrypt) ...{
        'encryption_scheme': 'v1',
        'sender_key_id': senderKeyId,
        'recipient_key_id': recipientKeyId,
        'recipient_id': messageRecipientId,
        'content_original': null,
        'content_original_encrypted': contentOriginalEncrypted,
        'content_original_nonce': contentOriginalNonce,
        'wrapped_keys': wrappedKeys,
      } else ...{
        'content_original': text,
      },
      'reply_to_message_id': replyToMessageId,
    };
    if (isOnline) {
      try {
        final data = await supabase
            .from('chat_messages')
            .insert(supabasePayload)
            .select();
        if (data.isEmpty) {
          throw Exception(
            'Invalid response format: expected non-empty List, got ${data.runtimeType}',
          );
        }
        final firstItem = data[0];
        // Preserve original text for encrypted messages (server returns null for content_original)
        if (canEncrypt && firstItem['content_original'] == null) {
          firstItem['content_original'] = text;
        }
        await localDb.replaceMessage(matchId, tempId, firstItem);
        // Update the chats-box last-message preview immediately so the sender
        // sees their new last message in the chat list without waiting for a
        // realtime sync round-trip.
        await localDb.recomputeChatLastMessagePreviewFromMessages(
          user.id,
          matchId,
        );

        final currentUserId = supabase.auth.currentUser?.id;
        if (currentUserId != null) {
          _ref.invalidate(recentChatsProvider(currentUserId));
        }

        try {
          final messageId = (firstItem['id'] as String?)?.trim();
          if (messageId != null && messageId.isNotEmpty) {
            unawaited(() async {
              try {
                await supabase.functions.invoke(
                  'push-message',
                  body: {'message_id': messageId, 'match_id': matchId},
                );
              } catch (_) {}
            }());
          }
        } catch (_) {}
      } catch (e) {
        await _saveToOutbox(supabasePayload);
      }
    } else {
      await _saveToOutbox(supabasePayload);
    }
  }

  Future<void> _saveToOutbox(Map<String, dynamic> messagePayload) async {
    final localDb = _ref.read(localDbProvider);
    await localDb.saveMessageToOutbox(messagePayload);
  }

  /// Set or clear a reaction for a message. p_reaction==null clears reaction for current user.
  Future<void> setReaction({
    required String matchId,
    required String messageId,
    String? reaction,
  }) async {
    final user = supabase.auth.currentUser;
    if (user == null) throw Exception('User not logged in');
    final localDb = _ref.read(localDbProvider);

    // Debounce rapid clicks
    final key = '$matchId:$messageId';
    _reactionDebouncer[key]?.cancel();
    // print('setReaction: scheduling debounced update for $key (reaction=$reaction)');

    final completer = Completer<void>();
    _reactionDebouncer[key] = Timer(const Duration(milliseconds: 300), () async {
      // print('setReaction: debounced timer fired for $key (reaction=$reaction)');
      try {
        await _performSetReaction(matchId, messageId, reaction, user, localDb);
        completer.complete();
      } catch (e) {
        completer.completeError(e);
      } finally {
        _reactionDebouncer.remove(key);
      }
    });

    return completer.future;
  }

  Future<void> _performSetReaction(
    String matchId,
    String messageId,
    String? reaction,
    User user,
    LocalDbService localDb,
  ) async {
    // Store original state for rollback
    final originalMessages = await localDb.getMessages(matchId);

    try {
      // Optimistic update
      // print('performSetReaction: starting optimistic update for message $messageId (reaction=$reaction)');
      await _applyOptimisticUpdate(matchId, messageId, reaction, user, localDb);
      // print('performSetReaction: optimistic update applied for message $messageId');

      // Server call
      final payload = {'p_message_id': messageId, 'p_reaction': reaction};
      // print('Calling supabase.rpc set_message_reaction with payload: $payload');

      final res = await supabase
          .rpc('set_message_reaction', params: payload)
          .single();
      // print('set_message_reaction response: $res');

      // Apply server result (may differ from optimistic)
      final Map<String, dynamic> newSummary = Map<String, dynamic>.from(
        res as Map,
      );
      // print('Applying new reaction_summary for message $messageId: $newSummary');
      await localDb.mergeMessages(matchId, [
        {
          'id': messageId,
          'reaction_summary': newSummary,
          'my_reaction': reaction,
        },
      ]);
      // print('performSetReaction: merge from server applied for message $messageId');

      // Force provider refresh
      try {
        _ref.invalidate(chatMessagesProvider(matchId));
      } catch (e) {
        // ignore if invalidation fails
      }

      // Refresh per-reaction cached reactors from the server for affected keys so
      // local cache matches the authoritative server state immediately.
      try {
        final keys = <String>{};
        keys.addAll(newSummary.keys.map((k) => k.toString()));

        // Also include the previous my_reaction (if any) to ensure it is updated when clearing.
        final prevMy =
            originalMessages.firstWhere(
                  (m) => m['id']?.toString() == messageId,
                  orElse: () => {},
                )['my_reaction']
                as String?;
        if (prevMy != null && prevMy.isNotEmpty) keys.add(prevMy);

        if (keys.isNotEmpty) {
          await _refreshCachedReactors(matchId, messageId, keys, localDb);
        }
      } catch (e) {
        // print('Failed to refresh cached reactors after setReaction: $e');
      }
    } catch (e, _) {
      // print('set_message_reaction failed for message $messageId with error: $e\n$st');
      // Rollback optimistic update
      // print('performSetReaction: rolling back optimistic update for message $messageId');
      await _rollbackOptimisticUpdate(matchId, originalMessages, localDb);
      rethrow;
    }
  }

  /// Edit a message. Only the message sender may edit; server-side RPC enforces this.
  Future<void> editMessage({
    required String matchId,
    required String messageId,
    required String newText,
  }) async {
    if (shouldSkipSupabaseCalls()) {
      throw Exception('Cannot edit message while offline');
    }

    final user = supabase.auth.currentUser;
    if (user == null) throw Exception('User not logged in');
    final localDb = _ref.read(localDbProvider);
    final currentUserId = user.id;

    // Store original messages for rollback
    final originalMessages = await localDb.getMessages(matchId);

    try {
      // Optimistic update locally
      final nowIso = DateTime.now().toIso8601String();
      await localDb.mergeMessages(matchId, [
        {'id': messageId, 'content_original': newText, 'edited_at': nowIso},
      ]);
      // Recompute the chat's last message preview since we edited the current last message
      await localDb.recomputeChatLastMessagePreviewFromMessages(
        currentUserId,
        matchId,
      );
      // Call server RPC to perform secure edit (enforces sender == auth.uid())
      final payload = {'p_message_id': messageId, 'p_new_content': newText};
      // print('Calling supabase.rpc edit_chat_message with payload: $payload');

      dynamic res;
      try {
        res = await supabase.rpc('edit_chat_message', params: payload).single();
        // print('edit_chat_message response: $res');
      } catch (e, _) {
        // print('edit_chat_message failed for message $messageId with error: $e\n$st');
        // Some deployments may expose the RPC under a different name or signature.
        // Attempt a few fallbacks to maximize compatibility.
        // 1) Try historical name `edit_message` with (p_message_id, p_new_content)
        try {
          // print('Attempting fallback RPC edit_message(p_message_id, p_new_content) for message $messageId');
          res = await supabase.rpc('edit_message', params: payload).single();
          // print('edit_message response: $res');
        } catch (e2, _) {
          // print('edit_message(p_message_id, p_new_content) failed for message $messageId: $e2\n$_');
          // 2) Try alternative signature edit_message(p_message_id, p_new_content, p_user_id)
          try {
            final payloadWithUser = Map<String, dynamic>.from(payload);
            payloadWithUser['p_user_id'] = user.id;
            // print('Attempting fallback RPC edit_message(p_message_id, p_new_content, p_user_id) for message $messageId');
            res = await supabase
                .rpc('edit_message', params: payloadWithUser)
                .single();
            // print('edit_message(p_user_id) response: $res');
          } catch (e3, _) {
            // print('edit_message with p_user_id failed for message $messageId: $e3\n$_');
            // 3) Final fallback: attempt direct table update (will be subject to RLS/policies)
            try {
              // print('Attempting direct table UPDATE fallback for message $messageId');
              final nowIsoFinal = DateTime.now().toIso8601String();
              final updateRes = await supabase
                  .from('chat_messages')
                  .update({
                    'content_original': newText,
                    'edited_at': nowIsoFinal,
                  })
                  .eq('id', messageId)
                  .select()
                  .single();
              // print('Direct UPDATE response: $updateRes');
              res = updateRes;
            } catch (e4, _) {
              // print('Direct UPDATE fallback failed for message $messageId: $e4\n$_');
              // Exhausted fallbacks
              rethrow;
            }
          }
        }
      }

      // Normalize RPC response to a message row Map. The RPC may return different shapes across deployments
      // (a Map row, a List wrapping a row, or simply `true`/boolean on success). Handle gracefully by
      // fetching the authoritative row when needed.
      Map<String, dynamic> resMap;
      try {
        if (res is Map) {
          resMap = Map<String, dynamic>.from(res);
        } else if (res is List) {
          if (res.isNotEmpty && res[0] is Map) {
            resMap = Map<String, dynamic>.from(res[0]);
          } else {
            // print('RPC returned empty List, fetching row for $messageId');
            final rows = await supabase
                .from('chat_messages')
                .select()
                .eq('id', messageId)
                .limit(1);
            if (rows.isNotEmpty) {
              resMap = Map<String, dynamic>.from(rows[0]);
            } else {
              throw Exception(
                'RPC returned empty list and failed to find row for $messageId',
              );
            }
          }
        } else if (res is bool && res == true) {
          // Some RPCs simply return true on success; fetch the updated row.
          // print('RPC returned boolean true for edit; fetching authoritative row for $messageId');
          final rows = await supabase
              .from('chat_messages')
              .select()
              .eq('id', messageId)
              .limit(1);
          if (rows.isNotEmpty) {
            resMap = Map<String, dynamic>.from(rows[0]);
          } else {
            throw Exception(
              'RPC returned success but row not found for $messageId',
            );
          }
        } else {
          throw Exception(
            'Unexpected RPC response type for edit: ${res.runtimeType}',
          );
        }
      } catch (e, _) {
        // print('Failed to normalize RPC response for message $messageId: $e\n$st');
        rethrow;
      }

      await localDb.mergeMessages(matchId, [resMap]);
      // Recompute the chat's last message preview after the server confirms the edit
      await localDb.recomputeChatLastMessagePreviewFromMessages(
        currentUserId,
        matchId,
      );
      try {
        _ref.invalidate(chatMessagesProvider(matchId));
        _ref.invalidate(recentChatsProvider(currentUserId));
      } catch (e) {
        // print('Failed to invalidate providers after edit: $e');
      }
    } catch (e, _) {
      // print('edit_chat_message failed for message $messageId with error: $e\n$st');
      // Rollback optimistic update
      await _rollbackOptimisticUpdate(matchId, originalMessages, localDb);
      await localDb.recomputeChatLastMessagePreviewFromMessages(
        currentUserId,
        matchId,
      );
      rethrow;
    }
  }

  /// Delete a message. The server will enforce permissions via RLS/policies.
  Future<void> deleteMessage({
    required String matchId,
    required String messageId,
  }) async {
    if (shouldSkipSupabaseCalls()) {
      throw Exception('Cannot delete message while offline');
    }

    final user = supabase.auth.currentUser;
    if (user == null) throw Exception('User not logged in');
    final localDb = _ref.read(localDbProvider);
    final currentUserId = user.id;

    // Store original messages for rollback
    final originalMessages = await localDb.getMessages(matchId);

    try {
      // Optimistic local delete
      await localDb.deleteMessage(matchId, messageId);
      // Recompute the chat's last message preview after deletion
      await localDb.recomputeChatLastMessagePreviewFromMessages(
        currentUserId,
        matchId,
      );

      // Server delete
      await supabase.from('chat_messages').delete().eq('id', messageId);

      try {
        _ref.invalidate(chatMessagesProvider(matchId));
        // Invalidate recent chats to update the last message preview immediately
        _ref.invalidate(recentChatsProvider(currentUserId));
      } catch (e) {
        // print('Failed to invalidate providers after delete: $e');
      }
    } catch (e) {
      // print('deleteMessage failed: $e');
      // Rollback
      await _rollbackOptimisticUpdate(matchId, originalMessages, localDb);
      await localDb.recomputeChatLastMessagePreviewFromMessages(
        currentUserId,
        matchId,
      );
      rethrow;
    }
  }

  Future<void> _applyOptimisticUpdate(
    String matchId,
    String messageId,
    String? reaction,
    User user,
    LocalDbService localDb,
  ) async {
    // print('applyOptimisticUpdate START for message $messageId (reaction=$reaction)');
    final messages = await localDb.getMessages(matchId);
    final idx = messages.indexWhere((m) => m['id']?.toString() == messageId);
    if (idx == -1) {
      // print('applyOptimisticUpdate: message $messageId not found in local cache');
      return;
    }

    final msg = Map<String, dynamic>.from(messages[idx]);

    // Update my_reaction
    if (reaction == null) {
      msg.remove('my_reaction');
    } else {
      msg['my_reaction'] = reaction;
    }

    // Update reaction_summary counts optimistically
    final Map<String, dynamic> summary = (msg['reaction_summary'] is Map)
        ? Map<String, dynamic>.from(msg['reaction_summary'])
        : {};
    final prev = messages[idx]['my_reaction'] as String?;

    // Decrement previous reaction
    if (prev != null) {
      final int prevCount = (summary[prev] as int?) ?? 0;
      if (prevCount <= 1) {
        summary.remove(prev);
      } else {
        summary[prev] = prevCount - 1;
      }
    }

    // Increment new reaction
    if (reaction != null) {
      final int cur = (summary[reaction] as int?) ?? 0;
      summary[reaction] = cur + 1;
    }

    msg['reaction_summary'] = summary;
    messages[idx] = msg;
    await localDb.saveMessages(matchId, messages);

    // print('applyOptimisticUpdate DONE for message $messageId -> summary: ${summary.toString()} prev: ${prev ?? 'none'}');

    // Update cached reactors
    await _updateCachedReactors(
      matchId,
      messageId,
      reaction,
      prev,
      user.id,
      localDb,
    );
  }

  Future<void> _updateCachedReactors(
    String matchId,
    String messageId,
    String? reaction,
    String? prevReaction,
    String currentUserId,
    LocalDbService localDb,
  ) async {
    try {
      // Remove from previous reaction cache
      if (prevReaction != null) {
        final prevList = await localDb.getCachedReactors(
          matchId,
          messageId,
          prevReaction,
        );
        final updatedPrev = prevList
            .where((r) => r['user_id'] != currentUserId)
            .toList();
        await localDb.saveCachedReactors(
          matchId,
          messageId,
          prevReaction,
          updatedPrev,
        );
      }

      // Add to new reaction cache
      if (reaction != null) {
        final profile = await localDb.getLocalProfile(currentUserId);
        String? displayName;
        String? photoUrl;
        if (profile != null) {
          displayName = profile['name'] as String?;
          final photos = profile['photos'];
          if (photos is List && photos.isNotEmpty) {
            photoUrl = photos[0] as String?;
          }
        }

        final newEntry = {
          'user_id': currentUserId,
          'display_name': displayName,
          'photo': photoUrl,
        };

        final curList = await localDb.getCachedReactors(
          matchId,
          messageId,
          reaction,
        );
        final exists = curList.any((r) => r['user_id'] == currentUserId);
        if (!exists) {
          final updated = [...curList, newEntry];
          await localDb.saveCachedReactors(
            matchId,
            messageId,
            reaction,
            updated,
          );
        }
      }
    } catch (e) {
      // Ignore cache update failures
      // print('Failed to update cached reactors: $e');
    }
  }

  Future<void> _refreshCachedReactors(
    String matchId,
    String messageId,
    Iterable<String> keys,
    LocalDbService localDb,
  ) async {
    for (final k in keys) {
      try {
        final serverList = await getReactors(messageId: messageId, reaction: k);
        // Save whatever the server returns (including empty lists) so local cache matches server state.
        await localDb.saveCachedReactors(matchId, messageId, k, serverList);
      } catch (e) {
        final _ = e;
      }
    }
  }

  Future<void> _rollbackOptimisticUpdate(
    String matchId,
    List<Map<String, dynamic>> originalMessages,
    LocalDbService localDb,
  ) async {
    try {
      // print('rollbackOptimisticUpdate: restoring original messages for match $matchId');
      await localDb.saveMessages(matchId, originalMessages);
      // Also invalidate provider to refresh UI
      _ref.invalidate(chatMessagesProvider(matchId));
    } catch (e) {
      // print('Failed to rollback optimistic update: $e');
    }
  }

  /// Get list of reactors for a message/reaction. Returns list of maps with keys:
  /// `user_id`, `display_name`, `photo` (nullable).
  Future<List<Map<String, dynamic>>> getReactors({
    required String messageId,
    required String reaction,
  }) async {
    if (shouldSkipSupabaseCalls()) return [];

    try {
      // Prefer a server-side RPC that returns masked names/photos for reactors (avoids RLS issues).
      try {
        final rpcRows = await supabase.rpc(
          'get_message_reactors',
          params: {'message_id': messageId, 'reaction': reaction},
        );
        if (rpcRows != null && rpcRows.isNotEmpty) {
          final initial = (rpcRows as List).map<Map<String, dynamic>>((r) {
            final row = r as Map<String, dynamic>;
            return {
              'user_id': row['user_id']?.toString(),
              'display_name': row['display_name'] as String?,
              'photo': row['photo'] as String?,
            };
          }).toList();

          // Post-process: if any returned rows lack photos, attempt to fetch photos from users table as a fallback
          final idsMissingPhotos = initial
              .where((e) => e['photo'] == null)
              .map((e) => e['user_id'] as String?)
              .whereType<String>()
              .toList();
          if (idsMissingPhotos.isNotEmpty) {
            for (final id in idsMissingPhotos) {
              try {
                final userRows = await supabase
                    .from('users')
                    .select('id, photos')
                    .eq('id', id)
                    .limit(1);
                if (userRows.isNotEmpty) {
                  final ur = userRows[0];
                  final photos = (ur['photos'] is List)
                      ? List<String>.from(ur['photos'])
                      : null;
                  if (photos != null && photos.isNotEmpty) {
                    final idx = initial.indexWhere((e) => e['user_id'] == id);
                    if (idx >= 0) {
                      initial[idx]['photo'] = photos[0];
                    }
                  }
                }
              } catch (e) {
                final _ = e;
              }
            }
          }

          return initial;
        }
      } catch (e) {
        // RPC may not exist or be restricted; fall back to client-side fetching
      }

      final rows = await supabase
          .from('message_reactions')
          .select('user_id')
          .eq('message_id', messageId)
          .eq('reaction', reaction);
      if (rows.isEmpty) return [];
      final ids = rows
          .map((r) => r['user_id']?.toString())
          .whereType<String>()
          .toList();
      if (ids.isEmpty) return [];
      // Fetch user names sequentially to avoid PostgREST `in_` method compatibility issues
      final Map<String, Map<String, dynamic>> byId = {};
      for (final id in ids) {
        try {
          final userRows = await supabase
              .from('users')
              .select('id, name, photos')
              .eq('id', id)
              .limit(1);
          if (userRows.isNotEmpty) {
            final ur = userRows[0];
            final name = ur['name'] as String?;
            final photos = (ur['photos'] is List)
                ? List<String>.from(ur['photos'])
                : null;
            byId[id] = {'id': id, 'full_name': name, 'photos': photos};
          }
        } catch (_) {
          // ignore user fetch errors
        }
      }

      String? maskFullName(String? fullName) {
        if (fullName == null) return null;
        final parts = fullName.trim().split(RegExp(r'\s+'));
        if (parts.isEmpty) return null;
        if (parts.length == 1) return parts.first;
        final first = parts.first;
        final lastInitial = parts.last[0].toUpperCase();
        return '$first $lastInitial.';
      }

      final List<Map<String, dynamic>> result = [];
      for (final id in ids) {
        final p = byId[id];
        final masked = p != null
            ? maskFullName(p['full_name'] as String?)
            : null;
        result.add({
          'user_id': id,
          'display_name': masked,
          'photo':
              p != null &&
                  (p['photos'] is List && (p['photos'] as List).isNotEmpty)
              ? (p['photos'][0] as String)
              : null,
        });
      }

      return result;
    } catch (e) {
      return [];
    }
  }
}
// --- END chatServiceProvider ---

// ---
// --- UPDATED: Translation State Management (listens to locale changes)
// ---
typedef TranslationStates = Map<String, String>;

/* Notification payload sent when translations are auto-disabled for a match. */
class TranslationNotification {
  final String matchId;
  final String text;
  TranslationNotification({required this.matchId, required this.text});
}

class TranslationNotificationNotifier
    extends Notifier<TranslationNotification?> {
  @override
  TranslationNotification? build() => null;

  void notify(TranslationNotification n) {
    state = n;
    Future.delayed(const Duration(seconds: 4), () {
      if (ref.mounted) state = null;
    });
  }

  void clear() {
    if (ref.mounted) state = null;
  }
}

final translationNotificationProvider =
    NotifierProvider<TranslationNotificationNotifier, TranslationNotification?>(
      () {
        return TranslationNotificationNotifier();
      },
    );

class TranslationNotifier extends Notifier<TranslationStates> {
  // Base prefs key - actual stored key is namespaced per-user: '${_prefsKeyBase}_<userId>'
  static const String _prefsKeyBase = 'translation_states';

  @override
  TranslationStates build() {
    // Load for the currently signed-in user (if any)
    _loadFromPrefsForCurrentUser();

    // Also listen to auth state changes so we can reload when user signs in/out/switches
    ref.listen<AsyncValue<AuthState>>(authStateProvider, (previous, next) {
      _loadFromPrefsForCurrentUser();
    });

    // When the UI language changes, only translate the last received message immediately.
    // All other messages will be translated on-demand when viewed.
    ref.listen(localizationProvider, (previous, next) {
      try {
        final newLang = next.currentLocale.languageCode;
        final matchesWithTranslation = state.keys.toList();
        if (matchesWithTranslation.isEmpty) return;

        // Schedule translation after a small delay to allow the localization change to settle
        Future.delayed(const Duration(milliseconds: 250), () async {
          if (!ref.mounted) return; // provider disposed
          try {
            String? userId;
            try {
              userId = Supabase.instance.client.auth.currentUser?.id;
            } catch (_) {
              userId = null;
            }

            if (userId == null) return;

            final localDb = ref.read(localDbProvider);
            final targetLanguage = normalizeLanguageCode(newLang);

            for (final matchId in matchesWithTranslation) {
              if (!ref.mounted) return;

              try {
                final messages = await localDb.getMessages(matchId);
                if (messages.isEmpty) continue;

                // Find the last message in the chat
                final lastMessage = messages.last;
                final lastMessageId = lastMessage['id']?.toString();
                final senderId = lastMessage['sender_id']?.toString();

                if (lastMessageId == null || senderId == null) continue;

                // Only translate if it's from the other user (incoming message)
                if (senderId == userId) continue;

                // Check if translation is needed (Case A: UI != source AND UI != target)
                final serverSourceLang =
                    lastMessage['detected_source_language'] as String?;
                final serverTargetLang =
                    (lastMessage['translated_target_language'] as String?) ??
                    (lastMessage['translated_lang'] as String?);
                final normalizedSource = serverSourceLang != null
                    ? normalizeLanguageCode(serverSourceLang)
                    : null;
                final normalizedTarget = serverTargetLang != null
                    ? normalizeLanguageCode(serverTargetLang)
                    : null;

                // Check if translation is needed
                final hasPlaintextTranslation = lastMessage['content_translated'] != null &&
                    (lastMessage['content_translated'] as String?)?.isNotEmpty == true;
                final hasEncryptedTranslation = lastMessage['content_translated_encrypted'] != null &&
                    (lastMessage['content_translated_encrypted'] as String?)?.isNotEmpty == true;
                final needsTranslation =
                    (normalizedSource != null &&
                        normalizedSource != targetLanguage) &&
                    (normalizedTarget == null ||
                        normalizedTarget != targetLanguage ||
                        // Encrypted-only translations (no plaintext) may be broken
                        (!hasPlaintextTranslation && hasEncryptedTranslation));

                if (needsTranslation) {
                  // Translate only the last message
                  try {
                    await TranslationProxy.invoke(
                      body: {
                        'match_id': matchId,
                        'target_language': targetLanguage,
                        'message_ids': [
                          lastMessageId,
                        ], // Only translate this specific message
                        'exclude_sender_id': userId,
                      },
                    );

                    // Clear cached translations for all OTHER messages (not the last one)
                    final otherMessageIds = messages
                        .where((m) => m['id']?.toString() != lastMessageId)
                        .map((m) => m['id']?.toString())
                        .whereType<String>()
                        .toList();

                    if (otherMessageIds.isNotEmpty) {
                      await localDb.clearCachedTranslationsForMessages(
                        matchId,
                        otherMessageIds,
                      );
                    }

                    // Trigger UI refresh for translations
                    if (ref.mounted) {
                      ref.read(translationVersionProvider.notifier).increment();
                    }
                  } catch (e) {
                    // Ignore translation errors - best-effort
                  }
                }
              } catch (_) {
                // ignore per-match errors - best-effort
              }
            }
          } catch (_) {
            // ignore errors - translation is best-effort
          }
        });
      } catch (_) {}
    });

    return {}; // Return empty state initially, will be updated when loaded
  }

  String _prefsKeyForUser(String? userId) =>
      '$_prefsKeyBase${userId == null ? '' : '_$userId'}';

  Future<void> _loadFromPrefsForCurrentUser() async {
    // Supabase.instance may not be initialized in test environments; guard against that.
    String? userId;
    try {
      userId = Supabase.instance.client.auth.currentUser?.id;
    } catch (_) {
      // Supabase not initialized (e.g., in tests); skip loading from prefs for now.
      return;
    }
    await _loadFromPrefsForUser(userId);
  }

  Future<void> _loadFromPrefsForUser(String? userId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final key = _prefsKeyForUser(userId);
      final jsonString = prefs.getString(key);
      if (jsonString != null) {
        final Map<String, dynamic> decoded = jsonDecode(jsonString);
        final Map<String, String> loaded = {};
        decoded.forEach((key, value) {
          if (value != null) loaded[key] = value as String;
        });
        state = loaded;
      } else {
        // No stored prefs for this user - leave state empty
        state = {};
      }
    } catch (e) {
      // Ignore errors, keep empty state
    }
  }

  Future<void> _saveToPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = Supabase.instance.client.auth.currentUser?.id;
      final key = _prefsKeyForUser(userId);
      final jsonString = jsonEncode(state);
      await prefs.setString(key, jsonString);
    } catch (e) {
      // Ignore errors
    }
  }

  Future<void> setTranslation(String matchId, String? targetLang) async {
    final previous = state[matchId];

    // Optimistically update in-memory state and prefs
    if (targetLang == null) {
      state = {...state}..remove(matchId);
    } else {
      state = {...state, matchId: targetLang};
    }
    await _saveToPrefs();

    final userId = Supabase.instance.client.auth.currentUser?.id;

    // Immediately update local cache to reflect the new flag for UX
    try {
      if (userId != null) {
        final localDb = ref.read(localDbProvider);
        await localDb.updateChatTranslation(
          userId,
          matchId,
          targetLang != null,
          targetLang,
        );
      }
    } catch (_) {
      // best-effort
    }

    // Notify UI providers to refresh translations
    ref.read(translationVersionProvider.notifier).increment();

    // If translation was turned OFF, clear any cached translations
    if (targetLang == null && matchId.isNotEmpty) {
      try {
        final localDb = ref.read(localDbProvider);
        await localDb.clearCachedTranslationsForMatch(matchId, userId: userId);
      } catch (e) {
        // Ignore failures - clearing cache is best-effort
      }
    }

    // Persist to server; skip if offline but still succeed locally
    // This allows toggling translations on/off even when offline
    if (!shouldSkipSupabaseCalls()) {
      try {
        if (userId != null) {
          await Supabase.instance.client.rpc(
            'set_chat_translation',
            params: {
              'p_user_id': userId,
              'p_match_id': matchId,
              'p_enabled': targetLang != null,
              'p_language': targetLang,
            },
          );

          // After successful write, trigger a background sync to pick up server canonical data
          try {
            await ref.read(globalSyncManagerProvider).syncChatsNow(userId);
            ref.invalidate(recentChatsProvider(userId));
          } catch (_) {}
        }
      } catch (e) {
        // Revert optimistic update only if RPC call fails
        if (previous == null) {
          state = {...state}..remove(matchId);
        } else {
          state = {...state, matchId: previous};
        }
        await _saveToPrefs();

        // Revert local cache
        try {
          if (userId != null) {
            final localDb = ref.read(localDbProvider);
            await localDb.updateChatTranslation(
              userId,
              matchId,
              previous != null,
              previous,
            );
          }
        } catch (_) {}

        rethrow;
      }
    } else {
      // Offline: changes are saved locally but won't sync to server until back online
      // The offline outbox or sync service will handle this later
    }
  }

  /// Silent update to translation state - used during sync to match server state
  /// Does NOT save to prefs or database - just updates in-memory state
  void setTranslationSilent(String matchId, String targetLang) {
    state = {...state, matchId: targetLang};
  }

  /// Silent removal from translation state - used during sync
  /// Does NOT save to prefs or database - just updates in-memory state
  void clearTranslationSilent(String matchId) {
    state = {...state}..remove(matchId);
  }
}

final translationProvider =
    NotifierProvider<TranslationNotifier, TranslationStates>(() {
      return TranslationNotifier();
    });
// --- END Translation State ---

// --- Translation Batch State (Prevents multiple simultaneous batch calls per match) ---
final translationBatchStateProvider =
    NotifierProvider<TranslationBatchNotifier, Map<String, bool>>(
      () => TranslationBatchNotifier(),
    );

class TranslationBatchNotifier extends Notifier<Map<String, bool>> {
  @override
  Map<String, bool> build() => {};

  bool isRunning(String matchId) => state[matchId] ?? false;

  void setRunning(String matchId, bool running) {
    state = {...state, matchId: running};
  }
}
// --- END Translation Batch State ---

// --- Available Translation Languages Per Match ---
/// Provider that tracks which languages have translations available in a specific match
/// Returns list of language codes (e.g., ['en', 'es', 'he']) that have cached translations
final availableTranslationLanguagesProvider = FutureProvider.autoDispose
    .family<List<String>, String>((ref, matchId) async {
      try {
        // Watch the chat messages to detect available translations
        final messagesAsync = ref.watch(chatMessagesProvider(matchId));

        // If messages are loading or errored, use last known available languages
        if (messagesAsync.isLoading) {
          return TranslationCacheManager.getDownloadedLanguagesForMatch(
            matchId,
          );
        }

        if (messagesAsync.hasError) {
          return TranslationCacheManager.getDownloadedLanguagesForMatch(
            matchId,
          );
        }

        final messages = messagesAsync.asData?.value ?? [];
        if (messages.isEmpty) {
          return [];
        }

        // Detect all unique languages that have translations in this match
        final Set<String> availableLangs = {};

        for (final msg in messages) {
          final translatedLang = msg.translatedLang;
          if (translatedLang != null && translatedLang.isNotEmpty) {
            // Normalize the language code
            final normalized = normalizeLanguageCode(translatedLang);
            availableLangs.add(normalized);
          }
        }

        // Update the cache manager tracking for faster lookups
        for (final lang in availableLangs) {
          await TranslationCacheManager.markLanguageDownloadedForMatch(
            matchId,
            lang,
          );
        }

        return availableLangs.toList()..sort();
      } catch (e) {
        // On error, return cached list
        return TranslationCacheManager.getDownloadedLanguagesForMatch(matchId);
      }
    });

/// Get human-readable names for language codes
Map<String, String> getLanguageDisplayNames(List<String> langCodes) {
  const Map<String, String> displayNames = {
    'en': 'English',
    'es': 'Español',
    'he': 'עברית (Hebrew)',
  };

  final result = <String, String>{};
  for (final code in langCodes) {
    result[code] = displayNames[code] ?? code.toUpperCase();
  }
  return result;
}
// --- END Available Translation Languages Provider ---

// ---
// --- *** UPDATED: translationFamilyProvider (translates to current UI language)
// --- Translates incoming messages to the current app UI language when translation is enabled.
// --- Only translates messages from other users, not outgoing messages.
// --- Uses smart Case A/B/C logic based on server-side translation data:
// --- - Case A: UI != source AND UI != target -> Call translate-proxy
// --- - Case B: UI == source -> Show original (no AI)
// --- - Case C: UI == target -> Reuse existing translation (no AI)
// ---
final translationFamilyProvider = FutureProvider.autoDispose.family<String, String>((
  ref,
  paramsString,
) async {
  // Depend on translation version to ensure re-evaluation when toggled
  ref.watch(translationVersionProvider);

  final Map<String, dynamic> params;
  try {
    params = jsonDecode(paramsString) as Map<String, dynamic>;
  } catch (e) {
    return 'Error parsing params';
  }

  final text = params['text'] as String?;
  final matchId = params['matchId'] as String?;
  final messageId = params['messageId'] as String?;

  if (text == null || matchId == null || messageId == null || text.isEmpty) {
    return text ?? 'Error: invalid params';
  }

  final localDb = ref.read(localDbProvider);

  // 1. Check if translation is even on for this chat
  final translationEnabled = ref.watch(translationProvider)[matchId] != null;

  if (!translationEnabled) {
    // Translation is off for this chat.
    return text;
  }

  // 2. Get the current UI language as the target language
  final currentUILocale = ref.watch(localizationProvider).currentLocale;
  final targetLanguage = normalizeLanguageCode(currentUILocale.languageCode);

  // 2. Load message data once from local DB for both sender check and cache check
  if (matchId.isEmpty) return text;

  final messages = await localDb.getMessages(matchId);
  final message = messages.firstWhere(
    (m) => m['id'].toString() == messageId,
    orElse: () => {},
  );
  final senderId = message['sender_id'] as String?;

  // Get server-side translation data (set by translate-proxy edge function)
  final serverSourceLang = message['detected_source_language'] as String?;
  final serverTargetLang = (message['translated_target_language'] as String?) ?? (message['translated_lang'] as String?);
  final serverTranslation = (message['content_translated'] as String?) ?? (message['translated_text'] as String?);

  // For encrypted messages, content_translated_encrypted may contain the
  // translation for the CURRENT target language (set by a recent batch or
  // smart retranslation), while content_translated may hold stale text from
  // a previous language.  Always try to decrypt content_translated_encrypted
  // for v1 messages — the decryption AAD includes the target language, so
  // it will only succeed if the encrypted translation matches the current UI.
  String? decryptedTranslation;
  final encScheme = message['encryption_scheme'] as String?;
  // Track whether Supabase has encrypted data for this message.
  // If it does, the message is effectively v1 even if the local DB
  // doesn't have encryption_scheme set (e.g., messages synced before
  // the encryption_scheme column was added).
  bool hasSupabaseEncrypted = false;
  if (encScheme == 'v1') {
    final encryptedTranslated = message['content_translated_encrypted'] as String?;
    final translatedNonce = message['content_translated_nonce'] as String?;
    if (encryptedTranslated != null && encryptedTranslated.isNotEmpty &&
        translatedNonce != null && translatedNonce.isNotEmpty) {
      try {
        final chatKeyState = ref.read(chatKeyProvider);
        if (chatKeyState.privateKeyBytes != null) {
          final currentUserId = supabase.auth.currentUser?.id ?? '';
          final String effectiveRecipientId = message['recipient_id'] as String? ?? '';
          decryptedTranslation = await ChatKeyService.instance.decryptMessageTranslatedContent(
            currentUserId: currentUserId,
            currentUserPrivateKey: chatKeyState.privateKeyBytes!,
            messageId: message['id'] as String,
            matchId: matchId,
            senderId: message['sender_id'] as String,
            senderKeyId: message['sender_key_id'] as String,
            recipientKeyId: message['recipient_key_id'] as String,
            contentTranslatedEncryptedBase64: encryptedTranslated,
            contentTranslatedNonceBase64: translatedNonce,
            wrappedKeys: (message['wrapped_keys'] as Map<String, dynamic>?) ?? {},
            // Always use UI language as target language — the edge function
            // always encrypts for the current UI locale, but serverTargetLang
            // in the local DB may be stale from a previous language.
            detectedSourceLanguage: serverSourceLang ?? 'und',
            targetLanguage: targetLanguage,
            recipientId: effectiveRecipientId.isNotEmpty ? effectiveRecipientId : null,
          );
        } else {
          print('[Translation] Cannot decrypt content_translated_encrypted: private key not loaded');
        }
      } catch (e) {
        print('[Translation] decryptMessageTranslatedContent failed: $e');
      }
    }

    // If local decrypt failed (content_translated_encrypted was unavailable
    // locally because Phase 2 cleared it, or the local data is stale), try
    // fetching content_translated_encrypted from Supabase.  This is the
    // authoritative source — the edge function always encrypts for the current
    // UI language.  Successful decryption (the AAD includes targetLanguage)
    // guarantees the translation is for the current UI.
    final supabaseUserId = supabase.auth.currentUser?.id ?? '';
    if (decryptedTranslation == null) {
      try {
        final serverMsg = await supabase
            .from('chat_messages')
            .select('id, content_translated_encrypted, content_translated_nonce, '
                'sender_key_id, recipient_key_id, wrapped_keys, sender_id, recipient_id')
            .eq('id', messageId)
            .maybeSingle();
        if (serverMsg != null) {
          final serverEncrypted = serverMsg['content_translated_encrypted'] as String?;
          final serverNonce = serverMsg['content_translated_nonce'] as String?;
          if (serverEncrypted != null && serverEncrypted.isNotEmpty &&
              serverNonce != null && serverNonce.isNotEmpty) {
            hasSupabaseEncrypted = true;
            final chatKeyState = ref.read(chatKeyProvider);
            if (chatKeyState.privateKeyBytes != null) {
              final serverSenderId = (serverMsg['sender_id'] ?? message['sender_id']) as String;
              final serverSenderKeyId = (serverMsg['sender_key_id'] ?? message['sender_key_id']) as String;
              final serverRecipientKeyId = (serverMsg['recipient_key_id'] ?? message['recipient_key_id']) as String;
              final serverWrappedKeys = (serverMsg['wrapped_keys'] as Map<String, dynamic>?) ??
                  (message['wrapped_keys'] as Map<String, dynamic>?) ?? {};
              String? serverRecipientId = serverMsg['recipient_id'] as String?;
              if (serverRecipientId == null || serverRecipientId.isEmpty) {
                serverRecipientId = message['recipient_id'] as String?;
              }
              decryptedTranslation = await ChatKeyService.instance.decryptMessageTranslatedContent(
                currentUserId: supabaseUserId,
                currentUserPrivateKey: chatKeyState.privateKeyBytes!,
                messageId: message['id'] as String,
                matchId: matchId,
                senderId: serverSenderId,
                senderKeyId: serverSenderKeyId,
                recipientKeyId: serverRecipientKeyId,
                contentTranslatedEncryptedBase64: serverEncrypted,
                contentTranslatedNonceBase64: serverNonce,
                wrappedKeys: serverWrappedKeys,
                detectedSourceLanguage: serverSourceLang ?? 'und',
                targetLanguage: targetLanguage,
                recipientId: serverRecipientId != null && serverRecipientId.isNotEmpty ? serverRecipientId : null,
              );
              if (decryptedTranslation != null && decryptedTranslation.isNotEmpty) {
                await localDb.mergeMessages(matchId, [{
                  'id': messageId,
                  'content_translated': decryptedTranslation,
                  'translated_target_language': targetLanguage,
                }]);
              }
            }
          }
        }
      } catch (e) {
        print('[Translation] Supabase content_translated_encrypted fetch/decrypt failed: $e');
      }
    }
  }

  // For encrypted (v1) messages, prefer the decrypted translation over the
  // server translation.  The server/content_translated column is only set
  // client-side by mergeMessages after a previous successful decryption for
  // an older language.  The decryptedTranslation above was derived from
  // content_translated_encrypted (which was created by the edge function for
  // the CURRENT target language), so it takes precedence.
  // If Supabase has encrypted data (hasSupabaseEncrypted) but decryption
  // failed (MAC error because the encrypted data is for a different
  // language), effectiveServerTranslation will be null, forcing Case A to
  // translate for the current UI language — preventing stale serverTranslation
  // from being returned for a wrong target language.
  final bool isEncrypted = (encScheme == 'v1') || hasSupabaseEncrypted;
  final effectiveServerTranslation = isEncrypted
      ? decryptedTranslation
      : (serverTranslation ?? decryptedTranslation);

  // Check if this is an outgoing message (from current user) - don't translate those
  final currentUserId = supabase.auth.currentUser?.id;
  if (senderId == currentUserId) {
    // This is our own message, don't translate it
    return text;
  }

  // 3. Case A/B/C Logic using server-side translation data
  // Normalize language codes for comparison
  final normalizedSource = serverSourceLang != null
      ? normalizeLanguageCode(serverSourceLang)
      : null;
  final normalizedTarget = serverTargetLang != null
      ? normalizeLanguageCode(serverTargetLang)
      : null;

  print(
    'ðŸ”„ Translation Provider: Case A/B/C check - UI=$targetLanguage, source=$normalizedSource, target=$normalizedTarget',
  );

  // Try to detect source language locally if not available from server
  // OR if server source seems suspicious (e.g., target == source which shouldn't happen)
  // This is critical for Case B (UI matches source) to work correctly
  String? sourceLanguage = normalizedSource;
  final bool serverSourceSuspicious =
      normalizedSource != null &&
      normalizedSource == normalizedTarget &&
      normalizedSource != targetLanguage;

  if (sourceLanguage == null || serverSourceSuspicious) {
    try {
      final translationService = ref.read(translationServiceProvider);
      final textForLangId = _stripEmojisForLanguageId(text);
      if (textForLangId.replaceAll(RegExp(r'\s+'), '').length >= 2) {
        final detectedLang = await translationService.identifyLanguage(
          textForLangId,
        );
        if (detectedLang.isNotEmpty) {
          sourceLanguage = normalizeLanguageCode(detectedLang);
          if (serverSourceSuspicious) {
            print(
              'ðŸ”„ Translation Provider: Server source suspicious ($normalizedSource == $normalizedTarget), re-detected as $sourceLanguage',
            );
          } else {
            print(
              'ðŸ”„ Translation Provider: Locally detected source language: $sourceLanguage',
            );
          }
        }
      }
    } catch (e) {
      print('ðŸ”„ Translation Provider: Local language detection failed: $e');
      // Don't overwrite sourceLanguage if detection fails
    }
  }

  // Case B (PRIORITY): UI language == source language -> Show original (no AI needed)
  // This takes priority over Case C because if the message is already in the user's language,
  // we should show the original regardless of any existing translations
  if (sourceLanguage != null && sourceLanguage == targetLanguage) {
    print(
      'ðŸ”„ Translation Provider: Case B - UI matches source ($sourceLanguage), showing original',
    );
    return text;
  }

  // Case C: UI language == target language -> Reuse existing translation (no AI needed)
  // Only use this if Case B didn't match (i.e., source != UI)
  // For encrypted (v1) messages, a successful decryption of
  // content_translated_encrypted (with UI language in the AAD) guarantees the
  // translation is for the current UI, even if serverTargetLang in the local DB
  // is stale from a previous language.  We now fetch directly from Supabase
  // above (if local decrypt failed), so decryptedTranslation is authoritative.
  // By requiring decryptedTranslation != null for v1 messages, we prevent
  // returning stale serverTranslation (from content_translated) that was set
  // by mergeMessages in a previous session for a different language.
  // The isEncrypted flag covers both locally-known v1 (encScheme == 'v1') and
  // messages whose encryption_scheme was lost locally but found in Supabase
  // (hasSupabaseEncrypted).  For encrypted messages, only a successful decrypt
  // permits Case C.  When isEncrypted is false (plaintext, no encrypted data
  // anywhere), the old normalizedTarget == targetLanguage check applies.
  if (effectiveServerTranslation != null &&
      effectiveServerTranslation.isNotEmpty &&
      (isEncrypted || normalizedTarget != null && normalizedTarget == targetLanguage)) {
    print(
      'ðŸ”„ Translation Provider: Case C - UI matches target ($normalizedTarget), reusing existing translation',
    );
    return effectiveServerTranslation;
  }

  // If we couldn't detect source language and there's no existing translation, show original
  if (sourceLanguage == null &&
      (normalizedTarget == null ||
          effectiveServerTranslation == null ||
          effectiveServerTranslation.isEmpty)) {
    print(
      'ðŸ”„ Translation Provider: No language info available, showing original',
    );
    return text;
  }

  // Case A: UI != source AND UI != target -> Need to translate
  // Use batch mode to translate ALL incoming messages (not just this one)
  // This ensures all messages are translated and saved to Supabase for sync
  print(
    'ðŸ”„ Translation Provider: Case A - Using batch translate for incoming messages (UI=$targetLanguage, source=$sourceLanguage, target=$normalizedTarget)',
  );

  // Always retranslate when in Case A - we need translations for a different language
  // Case A means: UI != source AND UI != target, so we definitely need new translations
  final doRetranslation = true;

  // Check if we're offline - if so, track this message for auto-fetch when online
  final isOffline = shouldSkipSupabaseCalls();
  if (isOffline) {
    _addPendingTranslation(matchId, messageId);
    return text; // Show original while offline
  }

  // If the message has an encrypted translation that we couldn't decrypt
  // (broken AAD from old webhook), clear it now so the batch query picks it up.
  if (effectiveServerTranslation == null && serverTranslation == null && decryptedTranslation == null) {
    final msgFromDb = (await localDb.getMessages(matchId)).where((m) => m['id']?.toString() == messageId).firstOrNull;
    if (msgFromDb?['content_translated_encrypted'] != null) {
      try {
        await supabase.from('chat_messages').update({
          'content_translated_encrypted': null,
          'content_translated_nonce': null,
        }).eq('id', messageId);
        await localDb.mergeMessages(matchId, [{
          'id': messageId,
          'content_translated_encrypted': null,
          'content_translated_nonce': null,
        }]);
      } catch (_) {}
    }
  }

  // Before triggering a batch translate, try fetching the message directly
  // from Supabase.  The smart retranslation may have already created a
  // content_translated_encrypted for the current UI language, but the local DB
  // still has the old broken data (from the initial webhook).  Fetching fresh
  // data avoids an unnecessary batch round trip.
  if (effectiveServerTranslation == null && serverTranslation == null) {
    try {
      final freshData = await supabase
          .from('chat_messages')
          .select('id, content_translated, content_translated_encrypted, content_translated_nonce, translated_target_language, detected_source_language, encryption_scheme, sender_id, sender_key_id, recipient_key_id, wrapped_keys, match_id, recipient_id')
          .eq('id', messageId)
          .maybeSingle();
      if (freshData != null) {
        final freshEnc = freshData['content_translated_encrypted'] as String?;
        final freshNonce = freshData['content_translated_nonce'] as String?;
        final freshTarget = freshData['translated_target_language'] as String?;
        final freshEncScheme = freshData['encryption_scheme'] as String?;
        if (freshEnc != null && freshEnc.isNotEmpty &&
            freshNonce != null && freshNonce.isNotEmpty &&
            freshEncScheme == 'v1' && freshTarget == targetLanguage) {
          final chatKeyState = ref.read(chatKeyProvider);
          if (chatKeyState.privateKeyBytes != null) {
            final currentUserId = supabase.auth.currentUser?.id ?? '';
            String? recipientId = freshData['recipient_id'] as String?;
            final freshDecrypted = await ChatKeyService.instance.decryptMessageTranslatedContent(
              currentUserId: currentUserId,
              currentUserPrivateKey: chatKeyState.privateKeyBytes!,
              messageId: freshData['id'] as String,
              matchId: matchId,
              senderId: freshData['sender_id'] as String,
              senderKeyId: freshData['sender_key_id'] as String,
              recipientKeyId: freshData['recipient_key_id'] as String,
              contentTranslatedEncryptedBase64: freshEnc,
              contentTranslatedNonceBase64: freshNonce,
              wrappedKeys: (freshData['wrapped_keys'] as Map<String, dynamic>?) ?? {},
              detectedSourceLanguage: freshData['detected_source_language'] as String? ?? 'und',
              targetLanguage: targetLanguage,
              recipientId: recipientId != null && recipientId.isNotEmpty ? recipientId : null,
            );
            if (freshDecrypted != null && freshDecrypted.isNotEmpty) {
              await localDb.mergeMessages(matchId, [{
                'id': messageId,
                'content_translated': freshDecrypted,
                'translated_target_language': freshTarget ?? targetLanguage,
              }]);
              final currentUserId2 = supabase.auth.currentUser?.id;
              if (currentUserId2 != null) {
                await localDb.updateChatLastMessageTranslation(
                  currentUserId2, matchId, messageId, freshDecrypted,
                );
              }
              return freshDecrypted;
            }
          }
        }
      }
    } catch (_) {}
  }

  // Call translate-proxy in BATCH mode to translate ALL incoming messages
  // This ensures proper sync with Supabase and uses exclude_sender_id to only
  // translate messages from OTHER users (incoming messages)
  final batchState = ref.read(translationBatchStateProvider.notifier);
  try {
    if (batchState.isRunning(matchId)) {
      // print('ðŸ”„ Translation Provider: Batch already running for $matchId, skipping');
      return text;
    }
    batchState.setRunning(matchId, true);

    final requestBody = {
      'match_id': matchId,
      'target_language': targetLanguage,
      // translate-proxy expects snake_case: retranslate_all
      'retranslate_all': doRetranslation,
      // IMPORTANT: Only translate messages from OTHER users (incoming messages)
      // This prevents translating our own messages when we change our UI language
      'exclude_sender_id': currentUserId,
    };

    // BUG FIX: Do NOT pass source_language - edge function auto-detects
    // if (sourceLanguage != null && sourceLanguage.isNotEmpty) {
    //   requestBody['source_language'] = sourceLanguage;
    // }

    // print('ðŸ”„ Translation Provider: Calling translate-proxy batch for match $matchId, target=$targetLanguage, exclude $currentUserId');

    final response = await TranslationProxy.invoke(body: requestBody);

    // Check if provider is still mounted before using ref
    if (!ref.mounted) {
      // print('ðŸ”„ Translation Provider: Provider disposed, returning original text');
      batchState.setRunning(matchId, false);
      return text;
    }

    if (response.data != null) {
      final _ = response.data['translated'] ?? 0;
      // print('ðŸ”„ Translation Provider: Batch translate response - translated: $translated');

      // Clear running flag so subsequent provider evaluations don't
      // see the batch as still running
      batchState.setRunning(matchId, false);

      // After batch translation, the NEW translation should be in Supabase
      // IMPORTANT: Fetch directly from Supabase, not from local cache, to get fresh data
      if (ref.mounted) {
        // Fetch fresh data directly from Supabase to bypass local cache
        final freshData = await supabase
            .from('chat_messages')
            .select('id, content_translated, content_translated_encrypted, content_translated_nonce, translated_target_language, detected_source_language, encryption_scheme, sender_id, sender_key_id, recipient_key_id, wrapped_keys, match_id, recipient_id')
            .eq('match_id', matchId)
            .eq('id', messageId)
            .maybeSingle();

        final newTranslation = freshData?['content_translated'] as String?;
        final newTargetLang =
            freshData?['translated_target_language'] as String?;

        // For encrypted messages, content_translated is NULL in the DB.
        // Try to decrypt content_translated_encrypted directly.
        String? decryptedTranslation;
        final encScheme = freshData?['encryption_scheme'] as String?;
        if ((newTranslation == null || newTranslation.isEmpty || newTranslation == 'null') &&
            encScheme == 'v1') {
          final encrypted = freshData?['content_translated_encrypted'] as String?;
          final nonce = freshData?['content_translated_nonce'] as String?;
          if (encrypted != null && encrypted.isNotEmpty && nonce != null && nonce.isNotEmpty) {
            try {
              final chatKeyState = ref.read(chatKeyProvider);
              if (chatKeyState.privateKeyBytes != null) {
                final currentUserId = supabase.auth.currentUser?.id ?? '';
                String? effectiveRecipientId = freshData!['recipient_id'] as String?;
                decryptedTranslation = await ChatKeyService.instance.decryptMessageTranslatedContent(
                  currentUserId: currentUserId,
                  currentUserPrivateKey: chatKeyState.privateKeyBytes!,
                  messageId: freshData['id'] as String,
                  matchId: matchId,
                  senderId: freshData['sender_id'] as String,
                  senderKeyId: freshData['sender_key_id'] as String,
                  recipientKeyId: freshData['recipient_key_id'] as String,
                  contentTranslatedEncryptedBase64: encrypted,
                  contentTranslatedNonceBase64: nonce,
                  wrappedKeys: (freshData['wrapped_keys'] as Map<String, dynamic>?) ?? {},
                  detectedSourceLanguage: freshData['detected_source_language'] as String? ?? 'und',
                  targetLanguage: newTargetLang ?? targetLanguage,
                  recipientId: effectiveRecipientId != null && effectiveRecipientId.isNotEmpty ? effectiveRecipientId : null,
                );
              }
            } catch (e) {
              print('[Translation] decryptMessageTranslatedContent (freshData) failed: $e');
            }

            // Fallback to encrypted cache
            if (decryptedTranslation == null) {
              try {
                final cached = freshData?['content_translated_encrypted_cache'] as String?;
                if (cached != null && cached.isNotEmpty) {
                  decryptedTranslation = await EncryptedCacheService.instance.decryptFromCache(cached);
                  print('[Translation] Decrypted via encrypted cache fallback');
                }
              } catch (e) {
                print('[Translation] Encrypted cache fallback failed: $e');
              }
            }
          }
        }

        // Use the plaintext translation or the decrypted one
        final effectiveTranslation = newTranslation ?? decryptedTranslation;

        // print('ðŸ”„ Translation Provider: After batch - fresh newTranslation: $newTranslation, newTargetLang: $newTargetLang');

        // Return the fresh translation if it matches our target language
        if (effectiveTranslation != null &&
            effectiveTranslation.isNotEmpty &&
            effectiveTranslation != 'null' &&
            newTargetLang == targetLanguage) {
          // print('ðŸ”„ Translation Provider: Returning fresh translation from DB');

          // Persist to local DB so subsequent evaluations find it
          // via Case C / hasTranslationForTarget
          try {
            await localDb.mergeMessages(matchId, [
              {
                'id': messageId,
                'content_translated': effectiveTranslation,
                'translated_target_language': newTargetLang ?? targetLanguage,
              },
            ]);
          } catch (_) {}

          // Update chat preview with translated message
          try {
            final currentUserId = supabase.auth.currentUser?.id;
            if (currentUserId != null) {
              await localDb.updateChatLastMessageTranslation(
                currentUserId,
                matchId,
                messageId,
                effectiveTranslation,
              );
              // print('ðŸ”„ Translation Provider: Updated chat preview with translation');

              // Show notification for newly translated message
              try {
                // Get message details to determine if this was an incoming message
                final messages = await localDb.getMessages(matchId);
                final messageData = messages.firstWhere(
                  (m) => m['id'].toString() == messageId,
                  orElse: () => {},
                );
                final senderId = messageData['sender_id'] as String?;
                final originalContent =
                    messageData['content_original'] as String?;

                // Only show notification for incoming messages (not our own)
                if (senderId != null &&
                    senderId != currentUserId &&
                    originalContent != null) {
                  // Fetch sender name
                  String senderName = 'MatchMe';
                  try {
                    final userData = await supabase
                        .from('users')
                        .select('name')
                        .eq('id', senderId)
                        .single();
                    senderName = formatSenderNameForNotification(
                      userData['name'] as String? ?? 'MatchMe',
                    );
                  } catch (e) {
                    // print('Failed to fetch sender name for delayed notification: $e');
                  }

                  // Show delayed notification with translated content
                  if (kIsWeb) {
                    WebNotificationService.showMessageNotification(
                      chatId: matchId,
                      senderName: senderName,
                      messageContent: effectiveTranslation,
                      matchId: matchId,
                    );
                  } else if (Platform.isAndroid) {
                    await MobileLocalNotificationService.showMessageNotification(
                      chatId: matchId,
                      senderName: senderName,
                      messageContent: effectiveTranslation,
                      matchId: matchId,
                    );
                  }
                  // print('ðŸ”„ Translation Provider: Showed delayed notification with translation');
                }
              } catch (e) {
                // print('ðŸ”„ Translation Provider: Failed to show delayed notification: $e');
              }
            }
          } catch (e) {
            // print('ðŸ”„ Translation Provider: Failed to update chat preview: $e');
          }

          return effectiveTranslation;
        }
      }
    }
  } catch (e) {
    // print('ðŸ”„ Translation Provider: Batch translate call failed: $e');
    batchState.setRunning(matchId, false);
  }

  // Check mounted again before returning
  if (!ref.mounted) {
    return text;
  }

  // Reset batch state if not already reset
  batchState.setRunning(matchId, false);

  // Return original text if no fresh translation available
  return text;
});

// Strip emojis and most non-letter characters to improve language identification.
String _stripEmojisForLanguageId(String input) {
  final buf = StringBuffer();
  for (final rune in input.runes) {
    final s = String.fromCharCodes([rune]);
    if (_looksLikeEmoji(s)) continue;
    if (RegExp(r'[\p{L}\p{N}\s]', unicode: true).hasMatch(s)) {
      buf.write(s);
    } else {
      buf.write(' ');
    }
  }
  return buf.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}

// Simple fallback language detection based on character patterns
// NOTE: This function is kept for potential future use but is not currently needed
// as we rely on server-side translation data (detected_source_language, translated_target_language)
// String _guessLanguageFromText(String text) {
//   if (text.trim().isEmpty) return 'und';
//   ... (omitted for brevity)
//   return 'und';
// }

bool _looksLikeEmoji(String grapheme) {
  // Broad, best-effort emoji/pictographic range match.
  return RegExp(
    r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]',
    unicode: true,
  ).hasMatch(grapheme);
}

/// Provider to ensure the last incoming chat message is aligned with the current UI language.
/// On app run/resume, this re-checks translation-enabled chats and translates only the
/// last message for each chat (the one shown in the chat preview). Other messages will be
/// translated on-demand when viewed.
final pendingMessageTranslationProvider = FutureProvider<void>((ref) async {
  if (_startupTranslationSyncInFlight != null) {
    await _startupTranslationSyncInFlight;
    return;
  }
  final completer = Completer<void>();
  _startupTranslationSyncInFlight = completer.future;
  if (offlineCacheManager.shouldUseCachedData()) {
    completer.complete();
    _startupTranslationSyncInFlight = null;
    return;
  }
  try {
    final authState = ref.watch(authStateProvider).value;
    if (authState == null) return;

    final session = authState.session;
    if (session == null) return;

    final userId = session.user.id;
    if (userId.isEmpty) return;

    final targetLanguage = normalizeLanguageCode(
      ref.read(localizationProvider).currentLocale.languageCode,
    );

    // print('🔄 Startup translation sync: target=$targetLanguage (lazy mode - only last message)');

    final chats = await supabase
        .from('chats')
        .select('match_id')
        .eq('user_id', userId)
        .eq('translation_enabled', true);

    if (chats.isEmpty) {
      // print('✅ Startup translation sync: no translation-enabled chats');
      return;
    }

    final localDb = ref.read(localDbProvider);

    for (final rawChat in chats as List) {
      // Check auth before each iteration in case user logged out mid-loop
      final currentSession = supabase.auth.currentSession;
      if (currentSession == null || currentSession.accessToken.isEmpty) {
        print('[Translation Sync] User logged out mid-sync, stopping');
        break;
      }

      try {
        final matchId = rawChat['match_id']?.toString() ?? '';
        if (matchId.isEmpty) {
          continue;
        }

        // Get the last message from local DB to check if it needs translation
        final messages = await localDb.getMessages(matchId);
        if (messages.isEmpty) continue;

        final lastMessage = messages.last;
        final lastMessageId = lastMessage['id']?.toString();
        final senderId = lastMessage['sender_id']?.toString();

        if (lastMessageId == null || senderId == null) continue;

        // Only translate if it's from the other user (incoming message)
        if (senderId == userId) continue;

        // Check if translation is needed (Case A: UI != source AND UI != target)
        final serverSourceLang =
            lastMessage['detected_source_language'] as String?;
        final serverTargetLang =
            (lastMessage['translated_target_language'] as String?) ??
            (lastMessage['translated_lang'] as String?);
        final normalizedSource = serverSourceLang != null
            ? normalizeLanguageCode(serverSourceLang)
            : null;
        final normalizedTarget = serverTargetLang != null
            ? normalizeLanguageCode(serverTargetLang)
            : null;

        // Check if translation is needed
        final hasPlaintextTranslation = lastMessage['content_translated'] != null &&
            (lastMessage['content_translated'] as String?)?.isNotEmpty == true;
        final hasEncryptedTranslation = lastMessage['content_translated_encrypted'] != null &&
            (lastMessage['content_translated_encrypted'] as String?)?.isNotEmpty == true;
        final needsTranslation =
            (normalizedSource != null && normalizedSource != targetLanguage) &&
            (normalizedTarget == null || normalizedTarget != targetLanguage ||
             // Encrypted-only translations (no plaintext) may be broken
             (!hasPlaintextTranslation && hasEncryptedTranslation));

        if (needsTranslation) {
          // Translate only the last message using message_ids parameter
          await TranslationProxy.invoke(
            body: {
              'match_id': matchId,
              'target_language': targetLanguage,
              'message_ids': [
                lastMessageId,
              ], // Only translate this specific message
              'exclude_sender_id': userId,
            },
          );

          // Clear cached translations for all OTHER messages (not the last one)
          final otherMessageIds = messages
              .where((m) => m['id']?.toString() != lastMessageId)
              .map((m) => m['id']?.toString())
              .whereType<String>()
              .toList();

          if (otherMessageIds.isNotEmpty) {
            await localDb.clearCachedTranslationsForMessages(
              matchId,
              otherMessageIds,
            );
          }

          // Update chat preview with translated message
          final latestIncoming = await supabase
              .from('chat_messages')
              .select('id, content_translated, translated_target_language')
              .eq('match_id', matchId)
              .eq('id', lastMessageId)
              .maybeSingle();

          final latestTranslated =
              latestIncoming?['content_translated'] as String?;
          final latestTarget = latestIncoming?['translated_target_language']
              ?.toString();
          final hasTranslated =
              latestTranslated != null &&
              latestTranslated.isNotEmpty &&
              latestTranslated != 'null';
          final matchesTarget =
              latestTarget != null &&
              latestTarget.isNotEmpty &&
              normalizeLanguageCode(latestTarget) == targetLanguage;

          if (hasTranslated && matchesTarget) {
            await localDb.updateChatLastMessageTranslation(
              userId,
              matchId,
              lastMessageId,
              latestTranslated,
            );
          }
        }
      } catch (e) {
        // print('⚠️ Startup translation sync failed for a chat: $e');
      }
    }

    if (ref.mounted) {
      await ref.read(globalSyncManagerProvider).syncChatsNow(userId);
      ref.read(translationVersionProvider.notifier).increment();
    }

    // print('✅ Startup translation sync complete (lazy mode)');
  } catch (e) {
    // print('⚠️ Startup translation sync error: $e');
  } finally {
    if (!completer.isCompleted) {
      completer.complete();
    }
    _startupTranslationSyncInFlight = null;
  }
});

// --- Auto-fetch translations on reconnect ---
/// Provider that watches connectivity and automatically fetches missing translations
/// for the currently viewed chat when coming back online
final translationAutoFetchOnReconnectProvider = FutureProvider<void>((
  ref,
) async {
  // This provider listens to connectivity changes and the current viewed chat
  // When reconnecting, it automatically fetches translations for messages that need them

  // We'll rely on the translationFamilyProvider which is already watching
  // connectivity and will automatically call translate-proxy when needed
  // This happens through the Case A/B/C logic when messages are viewed

  await Future.value(); // Completes immediately
});

// Store for tracking which messages have pending translations
final Map<String, Set<String>> _messagesWithPendingTranslations = {};

/// Mark a message as having a pending translation (needs to be fetched when online)
void _addPendingTranslation(String matchId, String messageId) {
  _messagesWithPendingTranslations.putIfAbsent(matchId, () => {});
  _messagesWithPendingTranslations[matchId]!.add(messageId);
}

/// Get all messages with pending translations for a match
Set<String> getPendingTranslations(String matchId) {
  return _messagesWithPendingTranslations[matchId] ?? {};
}

/// Clear pending translations for a match
void clearPendingTranslations(String matchId) {
  _messagesWithPendingTranslations.remove(matchId);
}
