// lib/providers/home_providers.dart
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:flutter/foundation.dart';
import 'dart:io' show Platform;
import 'dart:developer' as developer;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:matchme/models/chat_model.dart';
import 'package:matchme/models/match_model.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/services/local_db_service.dart';
import 'package:matchme/services/global_sync_manager.dart';
import 'package:matchme/services/background_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/services/web_notification_service.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/providers/profile_provider.dart';
import 'package:matchme/services/translation_service.dart';
import 'package:matchme/services/app_config_service.dart';
import 'package:matchme/services/user_activity_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:matchme/utils/offline_utils.dart';
import 'package:matchme/services/offline_cache_manager.dart';
import 'package:matchme/services/encrypted_notification_preview_service.dart';
import 'package:matchme/providers/chat_key_provider.dart';

final supabase = Supabase.instance.client;

// Helper function to format sender name: "FirstName LastInitial." e.g., "John S."
String formatSenderNameForNotification(String fullName) {
  if (fullName.isEmpty) return 'MatchMe';

  final parts = fullName.trim().split(RegExp(r'\s+'));
  if (parts.length == 1) {
    return parts[0]; // Just first name if no last name
  }

  // First name + first letter of last name with period
  final firstName = parts[0];
  final lastInitial = parts[parts.length - 1][0].toUpperCase();
  return '$firstName $lastInitial.';
}

// --- recentMatchesProvider (Reads Local DB Only) ---
final recentMatchesProvider = StreamProvider.autoDispose
    .family<List<MatchModel>, String>((ref, userId) {
      if (userId.isEmpty) return Stream.value([]);

      // Check if user is still authenticated
      if (supabase.auth.currentUser?.id != userId) {
        return Stream.value([]);
      }

      final localDb = ref.watch(localDbProvider);

      // Ensure sync manager is initialized to trigger initial data sync (use read, not watch, to avoid rebuilds)
      ref.read(globalSyncManagerProvider);

      final localStream = localDb.watchMatches();
      List<MatchModel>? lastEmitted;
      int emitCount = 0;

      return localStream.map((list) {
        final mapped = list
            .map((json) => MatchModel.fromJsonRpc(json, userId))
            .toList();

        // Only emit if data has actually changed (compare match IDs)
        if (lastEmitted != null && _areMatchesEqual(lastEmitted!, mapped)) {
          // Data unchanged, skip this emit
          return lastEmitted!;
        }

        lastEmitted = mapped;
        emitCount++;
        if (emitCount <= 5) {
          // Only log first 5 emits to avoid log spam
          developer.log(
            '🏠 recentMatchesProvider EMIT #$emitCount: user=$userId, count=${mapped.length}',
            name: 'MatchMeTrace',
          );
        }
        return mapped;
      });
    });

bool _areMatchesEqual(List<MatchModel> a, List<MatchModel> b) {
  if (a.length != b.length) return false;
  for (int i = 0; i < a.length; i++) {
    if (a[i].id != b[i].id) return false;
  }
  return true;
}

// --- END UPDATE ---

// Track previous chat states for detecting new unread messages via sync path
final Map<String, int> _previousChatUnreadCounts = {};
final Set<String> _pendingTranslatedNotificationMessageIds = <String>{};
final Set<String> _notifiedMessageIds = <String>{};
final Map<String, ChatModel> _recentChatSnapshots = <String, ChatModel>{};
final Set<String> _inFlightPreviewTranslationKeys = <String>{};

Future<void> _triggerImmediateLastMessageTranslation({
  required LocalDbService localDb,
  required String userId,
  required String matchId,
  required String messageId,
  required String targetLanguage,
}) async {
  final translationKey = '$userId|$matchId|$messageId|$targetLanguage';
  if (!_inFlightPreviewTranslationKeys.add(translationKey)) {
    return;
  }

  try {
    await TranslationProxy.invoke(
      body: {
        'match_id': matchId,
        'target_language': targetLanguage,
        'retranslate_all': true,
        'exclude_sender_id': userId,
      },
    );

    final refreshed = await supabase
        .from('chat_messages')
        .select('content_translated, translated_target_language')
        .eq('id', messageId)
        .maybeSingle();

    final translated = refreshed?['content_translated'] as String?;
    final translatedTarget = refreshed?['translated_target_language']
        ?.toString();
    final hasTranslated =
        translated != null && translated.isNotEmpty && translated != 'null';
    final matchesTarget =
        translatedTarget != null &&
        translatedTarget.isNotEmpty &&
        normalizeLanguageCode(translatedTarget) == targetLanguage;

    if (hasTranslated && matchesTarget) {
      await localDb.updateChatLastMessageTranslation(
        userId,
        matchId,
        messageId,
        translated,
      );
    }
  } catch (e) {
    print(
      '🔄 [SYNC FALLBACK] Immediate preview translation failed for $messageId: $e',
    );
  } finally {
    _inFlightPreviewTranslationKeys.remove(translationKey);
  }
}

Duration _jitteredBackoff(int attempt) {
  final base = Duration(milliseconds: (1000 * pow(2, attempt)).round());
  final jitter = Duration(milliseconds: Random().nextInt(1000));
  return base + jitter;
}

// --- recentChatsProvider (Reads Local DB Only) ---
final recentChatsProvider = StreamProvider.family<List<ChatModel>, String>((
  ref,
  userId,
) {
  if (userId.isEmpty) {
    return Stream.value([]);
  }

  // Reconnection attempt counters to prevent infinite loops
  int chatMessagesReconnectAttempts = 0;
  int matchesReconnectAttempts = 0;
  int chatsReconnectAttempts = 0;
  final int maxReconnectAttempts = 5;

  // Check if user is still authenticated
  if (supabase.auth.currentUser?.id != userId) {
    return Stream.value([]);
  }

  // Debug log to verify this provider is being called
  // Watch localizationProvider so the provider re-evaluates when the language
  // changes, picking up any freshly-decrypted translation that was saved to
  // the Recent Chats cache by the smart retranslation.
  final uiLangCode = ref.watch(localizationProvider).currentLocale.languageCode;
  print('🔍 Recent chats provider called for user $userId, UI=$uiLangCode');

  final localDb = ref.read(localDbProvider);
  String currentUiLang() => normalizeLanguageCode(
    ref.watch(localizationProvider).currentLocale.languageCode,
  );

  final localStream = localDb.watchChats(userId);

  // Add distinct to prevent duplicate emissions when data hasn't changed
  final distinctStream = localStream.distinct((prev, next) {
    final prevHash = prev.map((e) => e.toString()).join('|');
    final nextHash = next.map((e) => e.toString()).join('|');
    return prevHash == nextHash;
  });

  // Add logging for web debugging
  if (kIsWeb) {}

  // Use the correct provider name here
  final syncService = ref.read(globalSyncManagerProvider);

  final chatUpdateChannel = supabase
      .channel('public:chat_messages:for_user_$userId')
      .onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'chat_messages',
        callback: (payload) async {
          // Ignore callbacks if provider has been disposed
          if (!ref.mounted) {
            return;
          }

          // Handle message updates (insert, update, delete) - sync chats to update preview
          if (payload.eventType == PostgresChangeEvent.insert ||
              payload.eventType == PostgresChangeEvent.delete ||
              (payload.eventType == PostgresChangeEvent.update &&
                  payload.oldRecord['content_original'] !=
                      payload.newRecord['content_original'])) {
            try {
              // Add small delay to ensure database trigger has completed
              await Future.delayed(const Duration(milliseconds: 100));
              await syncService.syncChatsNow(userId);
              // Note: totalUnreadChatCountProvider watches recentChatsProvider,
              // so it will automatically update when the local DB changes
            } catch (e) {
              print('🔄 Error syncing chats on realtime change: $e');
            }
          }

          if (payload.eventType == PostgresChangeEvent.insert ||
              payload.eventType == PostgresChangeEvent.update) {
            final senderId = payload.newRecord['sender_id'];
            final currentUserId = supabase.auth.currentUser?.id;
            final matchId = payload.newRecord['match_id'] as String?;
            final messageId = payload.newRecord['id'] as String?;

            if (currentUserId != null && senderId != currentUserId) {
              final originalContent =
                  payload.newRecord['content_original'] as String?;
              final serverTranslatedContent =
                  payload.newRecord['content_translated'] as String?;
              final oldTranslatedContent =
                  payload.oldRecord['content_translated'] as String?;
              final hasTranslatedContent =
                  serverTranslatedContent != null &&
                  serverTranslatedContent.isNotEmpty &&
                  serverTranslatedContent != 'null';
              final wasTranslatedBefore =
                  oldTranslatedContent != null &&
                  oldTranslatedContent.isNotEmpty &&
                  oldTranslatedContent != 'null';
              final isTranslationUpdate =
                  payload.eventType == PostgresChangeEvent.update &&
                  hasTranslatedContent &&
                  !wasTranslatedBefore;

              // Try decrypting encrypted message content for notification preview
              String? decryptedContent;
              final encryptionScheme =
                  payload.newRecord['encryption_scheme'] as String?;
              if (encryptionScheme == 'v1' &&
                  (originalContent == null || originalContent.isEmpty)) {
                final senderKeyId =
                    payload.newRecord['sender_key_id'] as String?;
                final recipientKeyId =
                    payload.newRecord['recipient_key_id'] as String?;
                final contentEncrypted =
                    payload.newRecord['content_original_encrypted'] as String?;
                final contentNonce =
                    payload.newRecord['content_original_nonce'] as String?;
                final wrappedKeys = payload.newRecord['wrapped_keys'];
                if (senderKeyId != null &&
                    recipientKeyId != null &&
                    contentEncrypted != null &&
                    contentEncrypted.isNotEmpty &&
                    contentNonce != null &&
                    contentNonce.isNotEmpty &&
                    wrappedKeys != null &&
                    messageId != null &&
                    matchId != null) {
                  decryptedContent = await EncryptedNotificationPreviewService
                      .instance
                      .decryptPreview(
                        messageId: messageId,
                        matchId: matchId,
                        senderId: senderId as String,
                        recipientId: currentUserId,
                        senderKeyId: senderKeyId,
                        recipientKeyId: recipientKeyId,
                        contentOriginalEncryptedBase64: contentEncrypted,
                        contentOriginalNonceBase64: contentNonce,
                        wrappedKeysJson: jsonEncode(wrappedKeys),
                      );
                }
              }

              final usableContent =
                  originalContent != null && originalContent.isNotEmpty;
              if ((usableContent ||
                      hasTranslatedContent ||
                      encryptionScheme == 'v1') &&
                  messageId != null &&
                  matchId != null) {
                if (_notifiedMessageIds.contains(messageId)) {
                  if (isTranslationUpdate) {
                    _pendingTranslatedNotificationMessageIds.remove(messageId);
                  }
                  return;
                }

                try {
                  if (payload.eventType == PostgresChangeEvent.insert) {
                    final messagesToDeliver = await localDb.addMessages(
                      matchId,
                      [payload.newRecord],
                      currentUserId: currentUserId,
                    );
                    if (messagesToDeliver.isNotEmpty) {
                      unawaited(
                        Future.wait(
                          messagesToDeliver.map(
                            (msgId) => supabase
                                .rpc(
                                  'mark_message_delivered',
                                  params: {'p_message_id': msgId},
                                )
                                .catchError((e) {
                                  print(
                                    '❌ home_providers: Failed to mark $msgId as delivered: $e',
                                  );
                                }),
                          ),
                          eagerError: false,
                        ),
                      );
                    }
                  }
                } catch (e) {
                  print('❌ Failed to save message to local DB: $e');
                }

                bool isTranslationEnabled = false;
                try {
                  isTranslationEnabled = await localDb.isTranslationEnabled(
                    matchId,
                    userId: currentUserId,
                  );
                } catch (e) {
                  print('Failed to check translation status: $e');
                }

                if (payload.eventType == PostgresChangeEvent.insert &&
                    isTranslationEnabled &&
                    !hasTranslatedContent) {
                  _pendingTranslatedNotificationMessageIds.add(messageId);
                  return;
                }

                if (payload.eventType == PostgresChangeEvent.update) {
                  final shouldNotifyTranslationUpdate =
                      _pendingTranslatedNotificationMessageIds.contains(
                        messageId,
                      ) &&
                      hasTranslatedContent;
                  if (!shouldNotifyTranslationUpdate) {
                    return;
                  }
                }

                final displayContent = hasTranslatedContent
                    ? serverTranslatedContent
                    : (decryptedContent ??
                          originalContent ??
                          '🔒 Encrypted message');
                if (displayContent.isEmpty) {
                  return;
                }

                String senderName = 'MatchMe';
                try {
                  final userData = await supabase
                      .from('users')
                      .select('name')
                      .eq('id', senderId)
                      .single();
                  senderName = userData['name'] as String? ?? 'MatchMe';
                  senderName = formatSenderNameForNotification(senderName);
                } catch (e) {
                  print('⚠️ Failed to fetch sender name: $e');
                }

                final now = DateTime.now();
                final timestamp =
                    '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}.${(now.millisecond ~/ 10).toString().padLeft(2, '0')}';
                print(
                  '🔔 [NOTIFY] $timestamp | Chat=$matchId | From=$senderName | MessageId=$messageId | Translation=${isTranslationEnabled ? "YES" : "NO"}',
                );

                if (kIsWeb) {
                  final webTime = DateTime.now();
                  final webTimestamp =
                      '${webTime.hour.toString().padLeft(2, '0')}:${webTime.minute.toString().padLeft(2, '0')}:${webTime.second.toString().padLeft(2, '0')}.${(webTime.millisecond ~/ 10).toString().padLeft(2, '0')}';
                  print('🔔 [WEB_NOTIFY] $webTimestamp | Browser notification');
                  WebNotificationService.showMessageNotification(
                    chatId: matchId,
                    senderName: senderName,
                    messageContent: displayContent,
                    matchId: matchId,
                  );
                } else if (Platform.isAndroid) {
                  final androidTime = DateTime.now();
                  final androidTimestamp =
                      '${androidTime.hour.toString().padLeft(2, '0')}:${androidTime.minute.toString().padLeft(2, '0')}:${androidTime.second.toString().padLeft(2, '0')}.${(androidTime.millisecond ~/ 10).toString().padLeft(2, '0')}';
                  print(
                    '🔔 [ANDROID_NOTIFY] $androidTimestamp | Background service',
                  );
                  // On Android, trigger the background service to check for notifications immediately
                  // Use translated content for notification if translation is enabled
                  Future.delayed(const Duration(milliseconds: 200), () {
                    BackgroundService.triggerNotificationCheck(
                      messageId: messageId,
                      translatedContent: displayContent,
                      originalContent: originalContent,
                      senderName: senderName,
                      matchId: matchId,
                    );
                  });
                } else if (Platform.isIOS) {
                  // On iOS, use iOS notification service
                  final iosTime = DateTime.now();
                  final iosTimestamp =
                      '${iosTime.hour.toString().padLeft(2, '0')}:${iosTime.minute.toString().padLeft(2, '0')}:${iosTime.second.toString().padLeft(2, '0')}.${(iosTime.millisecond ~/ 10).toString().padLeft(2, '0')}';
                  print('🔔 [IOS_NOTIFY] $iosTimestamp | Local notification');
                  await MobileLocalNotificationService.showMessageNotification(
                    chatId: matchId,
                    senderName: senderName,
                    messageContent: displayContent,
                    matchId: matchId,
                  );
                }
                _notifiedMessageIds.add(messageId);
                _pendingTranslatedNotificationMessageIds.remove(messageId);
              }
            }
          }

          // All INSERT/UPDATE/DELETE events are synced above
        },
      )
      .subscribe((status, err) {
        if (status == RealtimeSubscribeStatus.subscribed) {
          print('✅ Chat messages subscription active for user: $userId');
          chatMessagesReconnectAttempts =
              0; // Reset counter on successful connection
        } else if (status == RealtimeSubscribeStatus.closed ||
            status == RealtimeSubscribeStatus.channelError ||
            status == RealtimeSubscribeStatus.timedOut) {
          if (err != null && !isExpectedOfflineFailure(err)) {
            print(
              '⚠️ Chat messages subscription disconnected - status: $status, error: $err',
            );
          }

          // If a network/WebSocket error caused the disconnect, force offline to prevent reconnection loops
          if (err != null &&
              (isExpectedOfflineFailure(err) ||
                  err.toString().toLowerCase().contains('closeevent'))) {
            offlineCacheManager.setSupabaseAvailability(false, force: true);
            debugPrint(
              '⏸️ [REALTIME] Network/WebSocket disconnect detected, forcing offline',
            );
            return;
          }

          // Prevent reconnect loop if app is in background
          if (WidgetsBinding.instance.lifecycleState ==
                  AppLifecycleState.paused ||
              WidgetsBinding.instance.lifecycleState ==
                  AppLifecycleState.detached) {
            print('⏸️ App in background, skipping auto-reconnect');
            return;
          }

          // Skip reconnection if Supabase communication is paused (offline mode)
          // Use debugPrint to suppress repeated log spam during rebuilds
          if (shouldSkipSupabaseCalls()) {
            debugPrint(
              '⏸️ Supabase communication paused, skipping chat messages reconnection',
            );
            return;
          }

          // Limit reconnection attempts to prevent infinite loops
          if (chatMessagesReconnectAttempts >= maxReconnectAttempts) {
            print(
              '🔄 Chat messages reconnection attempts exhausted ($maxReconnectAttempts), stopping auto-reconnect',
            );
            return;
          }

          chatMessagesReconnectAttempts++;
          final delay = _jitteredBackoff(chatMessagesReconnectAttempts);
          print(
            '🔄 Attempting to reconnect chat messages subscription (attempt $chatMessagesReconnectAttempts/$maxReconnectAttempts, delay=${delay.inMilliseconds}ms)...',
          );

          Future.delayed(delay, () async {
            if (ref.mounted) {
              try {
                await syncService.syncChatsNow(userId);
              } catch (e) {
                print('🔄 Reconnect recovery for chat messages failed: $e');
              }
            }
          });
        }
      });

  // Subscribe to matches table changes for real-time match deletions
  final matchUpdateChannel = supabase
      .channel('public:matches:for_user_$userId')
      .onPostgresChanges(
        event: PostgresChangeEvent.all,
        schema: 'public',
        table: 'matches',
        callback: (payload) async {
          print(
            'Realtime: Match ${payload.eventType} detected: ${payload.newRecord}',
          );
          // Ignore callbacks if provider has been disposed
          if (!ref.mounted) return;
          // When matches change, sync chats and matches to reflect any deletions
          try {
            await syncService.syncChatsNow(userId);
            await syncService.syncMatchesNow(userId);
          } catch (e) {
            print('Error syncing on match realtime update: $e');
          }
        },
      )
      .subscribe((status, err) {
        if (status == RealtimeSubscribeStatus.subscribed) {
          print('✅ Matches subscription active for user: $userId');
          matchesReconnectAttempts =
              0; // Reset counter on successful connection
        } else if (status == RealtimeSubscribeStatus.closed ||
            status == RealtimeSubscribeStatus.channelError ||
            status == RealtimeSubscribeStatus.timedOut) {
          if (err != null && !isExpectedOfflineFailure(err)) {
            print(
              '⚠️ Matches subscription disconnected - status: $status, error: $err',
            );
          }

          // If a network/WebSocket error caused the disconnect, force offline to prevent reconnection loops
          if (err != null &&
              (isExpectedOfflineFailure(err) ||
                  err.toString().toLowerCase().contains('closeevent'))) {
            offlineCacheManager.setSupabaseAvailability(false, force: true);
            debugPrint(
              '⏸️ [REALTIME] Network/WebSocket disconnect detected, forcing offline',
            );
            return;
          }

          // Prevent reconnect loop if app is in background
          if (WidgetsBinding.instance.lifecycleState ==
                  AppLifecycleState.paused ||
              WidgetsBinding.instance.lifecycleState ==
                  AppLifecycleState.detached) {
            print('⏸️ App in background, skipping auto-reconnect');
            return;
          }

          // Skip reconnection if Supabase communication is paused (offline mode)
          // Use debugPrint to suppress repeated log spam during rebuilds
          if (shouldSkipSupabaseCalls()) {
            debugPrint(
              '⏸️ Supabase communication paused, skipping matches reconnection',
            );
            return;
          }

          // Limit reconnection attempts to prevent infinite loops
          if (matchesReconnectAttempts >= maxReconnectAttempts) {
            print(
              '🔄 Matches reconnection attempts exhausted ($maxReconnectAttempts), stopping auto-reconnect',
            );
            return;
          }

          matchesReconnectAttempts++;
          final delay = _jitteredBackoff(matchesReconnectAttempts);
          print(
            '🔄 Attempting to reconnect matches subscription (attempt $matchesReconnectAttempts/$maxReconnectAttempts, delay=${delay.inMilliseconds}ms)...',
          );

          Future.delayed(delay, () async {
            if (ref.mounted) {
              try {
                await syncService.syncChatsNow(userId);
                await syncService.syncMatchesNow(userId);
              } catch (e) {
                print('🔄 Reconnect recovery for matches failed: $e');
              }
            }
          });
        }
      });

  // Subscribe to chats table changes for real-time chat deletions
  // Note: We don't sync on chat updates here to avoid feedback loops.
  // The chat_messages subscription already handles syncing when messages change.
  final chatsUpdateChannel = supabase
      .channel('public:chats:for_user_$userId')
      .onPostgresChanges(
        event: PostgresChangeEvent.delete,
        schema: 'public',
        table: 'chats',
        callback: (payload) async {
          // Ignore callbacks if provider has been disposed
          if (!ref.mounted) return;
          // Only sync on deletions to remove deleted chats from local DB
          try {
            await syncService.syncChatsNow(userId);
          } catch (e) {
            print('Error syncing on chat deletion: $e');
          }
        },
      )
      .subscribe((status, err) {
        if (status == RealtimeSubscribeStatus.subscribed) {
          print('✅ Chats subscription active');
          chatsReconnectAttempts = 0; // Reset counter on successful connection
        } else if (status == RealtimeSubscribeStatus.closed ||
            status == RealtimeSubscribeStatus.channelError ||
            status == RealtimeSubscribeStatus.timedOut) {
          if (err != null && !isExpectedOfflineFailure(err)) {
            print(
              '⚠️ Chats subscription disconnected - status: $status, error: $err',
            );
          }

          // If a network/WebSocket error caused the disconnect, force offline to prevent reconnection loops
          if (err != null &&
              (isExpectedOfflineFailure(err) ||
                  err.toString().toLowerCase().contains('closeevent'))) {
            offlineCacheManager.setSupabaseAvailability(false, force: true);
            debugPrint(
              '⏸️ [REALTIME] Network/WebSocket disconnect detected, forcing offline',
            );
            return;
          }

          // Prevent reconnect loop if app is in background
          if (WidgetsBinding.instance.lifecycleState ==
                  AppLifecycleState.paused ||
              WidgetsBinding.instance.lifecycleState ==
                  AppLifecycleState.detached) {
            print('⏸️ App in background, skipping auto-reconnect');
            return;
          }

          // Skip reconnection if Supabase communication is paused (offline mode)
          // Use debugPrint to suppress repeated log spam during rebuilds
          if (shouldSkipSupabaseCalls()) {
            debugPrint(
              '⏸️ Supabase communication paused, skipping chats reconnection',
            );
            return;
          }

          // Limit reconnection attempts to prevent infinite loops
          if (chatsReconnectAttempts >= maxReconnectAttempts) {
            print(
              '🔄 Chats reconnection attempts exhausted ($maxReconnectAttempts), stopping auto-reconnect',
            );
            return;
          }

          chatsReconnectAttempts++;
          final delay = _jitteredBackoff(chatsReconnectAttempts);
          print(
            '🔄 Attempting to reconnect chats subscription (attempt $chatsReconnectAttempts/$maxReconnectAttempts, delay=${delay.inMilliseconds}ms)...',
          );

          Future.delayed(delay, () async {
            if (ref.mounted) {
              try {
                await syncService.syncChatsNow(userId);
              } catch (e) {
                print('🔄 Reconnect recovery for chats failed: $e');
              }
            }
          });
        }
      });

  ref.onDispose(() {
    supabase.removeChannel(chatUpdateChannel);
    supabase.removeChannel(matchUpdateChannel);
    supabase.removeChannel(chatsUpdateChannel);
  });

  // When the chat key becomes available (first load or unlock), re-sync
  // chats so that encrypted last-message previews get decrypted.
  ref.listen<ChatKeyState>(chatKeyProvider, (prev, next) {
    if (!ref.mounted) return;
    if (prev?.privateKeyBytes == null && next.privateKeyBytes != null) {
      syncService.syncChatsNow(userId);
    }
  });

  // Handle translation display for Recent Chats and detect new messages via sync
  return distinctStream.asyncMap((list) async {
    try {
      final uiLang = currentUiLang();

      print(
        '🔄 Recent Chats Provider: Processing ${list.length} chats from local DB (data changed)',
      );

      for (final json in list) {
        final matchId = json['match_id']?.toString();
        if (matchId != null && matchId.isNotEmpty) {
          final snapshotKey = '$userId|$matchId';
          final existingChat = _recentChatSnapshots[snapshotKey];
          if (existingChat != null) {
            continue;
          }
          try {
            final chat = ChatModel.fromJsonRpc(json);
            _recentChatSnapshots[snapshotKey] = chat;
          } catch (e) {
            print('Recent chats snapshot parse failed for $snapshotKey: $e');
          }
        }
      }

      final chats = await Future.wait(
        list.map((json) async {
          try {
            final chat = ChatModel.fromJsonRpc(json);
            final matchId = json['match_id']?.toString();
            final unreadRaw = json['unread_count'];
            final unreadCount = unreadRaw is int
                ? unreadRaw
                : int.tryParse(unreadRaw?.toString() ?? '') ?? 0;
            final lastMessageSenderId = json['last_message_sender_id']
                ?.toString();

            print(
              '🔄 Recent Chats Provider: Chat $matchId - unreadCount: $unreadCount',
            );

            // Skip notifications for own messages
            if (lastMessageSenderId == userId && matchId != null) {
              print('🔄 [SYNC FALLBACK] Skipping notification for own message');
              _previousChatUnreadCounts[matchId] = unreadCount;
              // Continue to next chat without triggering notification
            } else if (matchId != null &&
                lastMessageSenderId != null &&
                unreadCount > 0) {
              final previousUnread = _previousChatUnreadCounts[matchId] ?? 0;

              final lastMessageId = json['last_message_id'] as String?;
              final translationEnabled = json['translation_enabled'] == true;
              final serverTranslatedContent =
                  json['last_message_translated'] as String?;
              final hasServerTranslation =
                  serverTranslatedContent != null &&
                  serverTranslatedContent.isNotEmpty &&
                  serverTranslatedContent != 'null';
              final isPendingTranslatedNotification =
                  lastMessageId != null &&
                  _pendingTranslatedNotificationMessageIds.contains(
                    lastMessageId,
                  );
              final shouldProcessNotification =
                  unreadCount > previousUnread ||
                  (isPendingTranslatedNotification && hasServerTranslation);

              if (shouldProcessNotification) {
                print(
                  '🔄 [SYNC FALLBACK] Detected new message(s) via sync for chat $matchId (was $previousUnread, now $unreadCount)',
                );

                // This message arrived via sync, not realtime - trigger notification as fallback
                try {
                  final messageContent =
                      json['last_message'] as String? ?? 'New message';
                  String? detectedSourceLang =
                      json['last_message_source_language']?.toString();
                  if (detectedSourceLang != null &&
                      detectedSourceLang.isNotEmpty &&
                      detectedSourceLang != 'null') {
                    detectedSourceLang = normalizeLanguageCode(
                      detectedSourceLang,
                    );
                  } else {
                    detectedSourceLang = null;
                  }

                  if ((detectedSourceLang == null ||
                          detectedSourceLang.isEmpty) &&
                      lastMessageId != null &&
                      lastMessageId.isNotEmpty) {
                    try {
                      final messages = await localDb.getMessages(matchId);
                      final rawMessage = messages.firstWhere(
                        (m) => (m['id']?.toString() ?? '') == lastMessageId,
                        orElse: () => <String, dynamic>{},
                      );
                      if (rawMessage.isNotEmpty) {
                        final rawSource =
                            (rawMessage['detected_source_language'] ??
                                    rawMessage['source_language'] ??
                                    rawMessage['language'])
                                ?.toString();
                        if (rawSource != null &&
                            rawSource.isNotEmpty &&
                            rawSource != 'null') {
                          detectedSourceLang = normalizeLanguageCode(rawSource);
                        }
                      }
                    } catch (_) {}
                  }

                  final shouldWaitForTranslation =
                      translationEnabled &&
                      !hasServerTranslation &&
                      (detectedSourceLang == null ||
                          detectedSourceLang != uiLang);

                  if (shouldWaitForTranslation &&
                      lastMessageId != null &&
                      lastMessageId.isNotEmpty) {
                    _pendingTranslatedNotificationMessageIds.add(lastMessageId);
                    print(
                      '🔄 [SYNC FALLBACK] Waiting for translation before notifying for message $lastMessageId',
                    );
                    _previousChatUnreadCounts[matchId] = unreadCount;
                    return chat;
                  }

                  final displayContent = hasServerTranslation
                      ? serverTranslatedContent
                      : messageContent;
                  if (displayContent.isEmpty) {
                    _previousChatUnreadCounts[matchId] = unreadCount;
                    return chat;
                  }

                  // Fetch sender name
                  String senderName = 'MatchMe';
                  try {
                    final userData = await supabase
                        .from('users')
                        .select('name')
                        .eq('id', lastMessageSenderId)
                        .single();
                    senderName = userData['name'] as String? ?? 'MatchMe';
                    senderName = formatSenderNameForNotification(senderName);
                    print(
                      '🔄 [SYNC FALLBACK] Formatted sender name for notification: "$senderName"',
                    );
                  } catch (e) {
                    print(
                      '🔄 [SYNC FALLBACK] Failed to fetch sender name: $e, using default',
                    );
                  }

                  print(
                    '🔄 [SYNC FALLBACK] ═══════════════════════════════════════════════════',
                  );
                  print(
                    '🔄 [SYNC FALLBACK] NOTIFICATION TRIGGER - Message arrived via sync',
                  );
                  print('🔄 [SYNC FALLBACK] Chat: $matchId');
                  if (translationEnabled) {
                    print(
                      '🔄 [SYNC FALLBACK] Translation: ENABLED (showing translated message)',
                    );
                  } else {
                    print(
                      '🔄 [SYNC FALLBACK] Translation: DISABLED (showing original message)',
                    );
                  }
                  print(
                    '🔄 [SYNC FALLBACK] ═══════════════════════════════════════════════════',
                  );

                  // Trigger notifications via platform-specific services
                  if (kIsWeb) {
                    print(
                      '🔄 [SYNC FALLBACK] Platform: Web - showing browser notification',
                    );
                    WebNotificationService.showMessageNotification(
                      chatId: matchId,
                      senderName: senderName,
                      messageContent: displayContent,
                      matchId: matchId,
                    );
                  } else if (Platform.isAndroid) {
                    // On Android, notification will be handled by background service
                    print(
                      '🔄 [SYNC FALLBACK] Platform: Android - notification handled by background service',
                    );
                  } else if (Platform.isIOS) {
                    print(
                      '🔄 [SYNC FALLBACK] Platform: iOS - showing local notification',
                    );
                    await MobileLocalNotificationService.showMessageNotification(
                      chatId: matchId,
                      senderName: senderName,
                      messageContent: displayContent,
                      matchId: matchId,
                    );
                  }
                  if (lastMessageId != null && lastMessageId.isNotEmpty) {
                    _pendingTranslatedNotificationMessageIds.remove(
                      lastMessageId,
                    );
                    _notifiedMessageIds.add(lastMessageId);
                  }
                } catch (e) {
                  print('🔄 [SYNC FALLBACK] Error triggering notification: $e');
                }
              }

              // Update state to current unread count
              _previousChatUnreadCounts[matchId] = unreadCount;
            }

            final translationEnabled = json['translation_enabled'] == true;
            final lastMessageSenderIdCheck =
                json['last_message_sender_id'] as String?;
            final isIncomingLastMessage =
                lastMessageSenderIdCheck != null &&
                lastMessageSenderIdCheck != userId;

            if (translationEnabled && isIncomingLastMessage) {
              final matchIdForCaseCheck =
                  json['match_id']?.toString() ?? chat.matchId;
              final lastMessageId = json['last_message_id']?.toString();
              String? detectedSourceLang;
              String? translatedTargetLang;
              String? translatedPreview =
                  json['last_message_translated'] as String?;

              // For v1 (encrypted) messages, the sync-stored
              // last_message_translated comes from cm.content_translated which
              // is set client-side by Phase 2.  The smart retranslation may
              // have since updated content_translated_encrypted to a new
              // language, making content_translated stale.  Skip it.
              final syncEncScheme =
                  json['last_message_encryption_scheme'] as String?;
              if (syncEncScheme == 'v1') {
                translatedPreview = null;
              } else if (translatedPreview != null) {
                print('🔍 Recent chats: Using sync last_message_translated for target=en, encScheme=$syncEncScheme');
              }

              try {
                if (matchIdForCaseCheck.isNotEmpty &&
                    lastMessageId != null &&
                    lastMessageId.isNotEmpty) {
                  final messages = await localDb.getMessages(
                    matchIdForCaseCheck,
                  );
                  final rawMessage = messages.firstWhere(
                    (m) => (m['id']?.toString() ?? '') == lastMessageId,
                    orElse: () => <String, dynamic>{},
                  );

                  if (rawMessage.isNotEmpty) {
                    final rawSource =
                        (rawMessage['detected_source_language'] ??
                                rawMessage['source_language'] ??
                                rawMessage['language'])
                            ?.toString();
                    if (rawSource != null &&
                        rawSource.isNotEmpty &&
                        rawSource != 'null') {
                      detectedSourceLang = normalizeLanguageCode(rawSource);
                    }

                    final rawTarget =
                        (rawMessage['translated_target_language'] ??
                                rawMessage['translated_lang'])
                            ?.toString();
                    if (rawTarget != null &&
                        rawTarget.isNotEmpty &&
                        rawTarget != 'null') {
                      translatedTargetLang = normalizeLanguageCode(rawTarget);
                    }

                    final rawTranslated =
                        (rawMessage['content_translated'] ??
                                rawMessage['translated_text'])
                            as String?;
                    if (rawTranslated != null &&
                        rawTranslated.isNotEmpty &&
                        rawTranslated != 'null') {
                      // Only use the message-level content_translated if its
                      // translated_target_language matches the current UI.
                      // The message-level data may be stale (from a previous
                      // language) since the sync only updates chat-level
                      // last_message_target_language and never refreshes
                      // individual message rows in the local DB.
                      final msgTarget =
                          (rawMessage['translated_target_language'] ??
                                  rawMessage['translated_lang'])
                              ?.toString();
                      final msgTargetNorm = msgTarget != null
                          ? normalizeLanguageCode(msgTarget)
                          : null;
                      // For v1 (encrypted) messages, do NOT trust
                      // content_translated even if translated_target_language
                      // matches the UI — the edge function only updates
                      // translated_target_language, not content_translated.
                      if (msgTargetNorm != null &&
                          msgTargetNorm == uiLang &&
                          syncEncScheme != 'v1') {
                        translatedPreview = rawTranslated;
                      }
                    }
                  }
                }
              } catch (_) {}

              final hasTranslatedPreview =
                  translatedPreview != null &&
                  translatedPreview.isNotEmpty &&
                  translatedPreview != 'null';

              // Check if this is a NEW message by comparing message IDs
              // OR if translation just became available for the SAME message
              final snapshotKey = '$userId|$matchIdForCaseCheck';
              final previousChat = _recentChatSnapshots[snapshotKey];

              // Determine if this is a new message (either no previous chat OR different message ID)
              final bool isNewMessage =
                  (previousChat == null ||
                  previousChat.lastMessageId != lastMessageId);

              // Handle the case where we need to check for translation availability
              // We can only check previousChat's translation if it exists
              bool translationJustBecameAvailable = false;
              if (previousChat != null) {
                // previousChat exists - check if translation just became available
                final String? prevTranslated =
                    previousChat.lastMessageTranslated;
                final bool prevHadNoTranslation =
                    (prevTranslated == null ||
                    prevTranslated.isEmpty ||
                    prevTranslated == 'null');
                translationJustBecameAvailable =
                    !isNewMessage &&
                    prevHadNoTranslation &&
                    hasTranslatedPreview;
              }

              // If translation just became available for this message, we should show it!
              // This is the key case: new translation arrived for the same message
              if (translationJustBecameAvailable) {
                // Translation just arrived - show it!
                // Keep lastMessage as original, only update lastMessageTranslated
                return chat.copyWith(
                  lastMessageTranslated: translatedPreview,
                  lastMessageSourceLanguage: detectedSourceLang,
                );
              }

              if ((detectedSourceLang == null || detectedSourceLang.isEmpty) &&
                  matchIdForCaseCheck.isNotEmpty &&
                  lastMessageId != null &&
                  lastMessageId.isNotEmpty) {
                try {
                  final serverMessage = await supabase
                      .from('chat_messages')
                      .select(
                        'detected_source_language, translated_target_language, content_translated, encryption_scheme',
                      )
                      .eq('id', lastMessageId)
                      .maybeSingle();
                  final serverSource =
                      serverMessage?['detected_source_language']?.toString();
                  if (serverSource != null &&
                      serverSource.isNotEmpty &&
                      serverSource != 'null') {
                    detectedSourceLang = normalizeLanguageCode(serverSource);
                  }
                  final serverTarget =
                      serverMessage?['translated_target_language']?.toString();
                  if (serverTarget != null &&
                      serverTarget.isNotEmpty &&
                      serverTarget != 'null') {
                    translatedTargetLang = normalizeLanguageCode(serverTarget);
                  }
                  final serverTranslated =
                      serverMessage?['content_translated'] as String?;
                  final serverEncScheme =
                      serverMessage?['encryption_scheme'] as String?;
                  // For v1 messages, content_translated is set client-side by
                  // Phase 2 and may be stale.  Only use it for non-v1 messages
                  // where the edge function sets it directly.
                  if (!hasTranslatedPreview &&
                      serverTranslated != null &&
                      serverTranslated.isNotEmpty &&
                      serverTranslated != 'null' &&
                      serverEncScheme != 'v1') {
                    translatedPreview = serverTranslated;
                  }
                } catch (_) {}
              }

              final hasTranslatedPreviewAfterServerCheck =
                  translatedPreview != null &&
                  translatedPreview.isNotEmpty &&
                  translatedPreview != 'null';

              // Check if server source is suspicious (source == target but != UI)
              // This indicates incorrect language detection in the database
              final bool serverSourceSuspicious =
                  detectedSourceLang != null &&
                  detectedSourceLang == translatedTargetLang &&
                  detectedSourceLang != uiLang;

              // If source is suspicious, try to detect locally
              if (serverSourceSuspicious &&
                  matchIdForCaseCheck.isNotEmpty &&
                  lastMessageId != null) {
                try {
                  final messages = await localDb.getMessages(
                    matchIdForCaseCheck,
                  );
                  final rawMessage = messages.firstWhere(
                    (m) => (m['id']?.toString() ?? '') == lastMessageId,
                    orElse: () => <String, dynamic>{},
                  );
                  if (rawMessage.isNotEmpty) {
                    final originalContent =
                        (rawMessage['content_original'] ??
                                rawMessage['content'])
                            ?.toString();
                    if (originalContent != null && originalContent.isNotEmpty) {
                      final translationService = ref.read(
                        translationServiceProvider,
                      );
                      final textForLangId = _stripEmojisForLanguageId(
                        originalContent,
                      );
                      if (textForLangId.replaceAll(RegExp(r'\s+'), '').length >=
                          2) {
                        final detectedLang = await translationService
                            .identifyLanguage(textForLangId);
                        if (detectedLang.isNotEmpty) {
                          detectedSourceLang = normalizeLanguageCode(
                            detectedLang,
                          );
                          print(
                            '🔍 Recent chats: Server source suspicious ($detectedSourceLang == $translatedTargetLang), re-detected as $detectedSourceLang',
                          );
                        }
                      }
                    }
                  }
                } catch (e) {
                  print(
                    '🔍 Recent chats: Failed to re-detect source language: $e',
                  );
                }
              }

              final isCaseBAfterServerCheck =
                  detectedSourceLang != null && detectedSourceLang == uiLang;
              final isCaseCAfterServerCheck =
                  translatedTargetLang != null &&
                  translatedTargetLang == uiLang;

              print(
                '🔍 Recent chats: Translation check - UI=$uiLang, source=$detectedSourceLang, target=$translatedTargetLang, CaseB=$isCaseBAfterServerCheck, CaseC=$isCaseCAfterServerCheck',
              );

              // If this is a NEW message without translation yet (source unknown or source != UI),
              // don't show anything - wait for translation to become available
              final isAbsoluteLastMessage =
                  lastMessageId != null && lastMessageId == chat.lastMessageId;

              if (isNewMessage &&
                  !hasTranslatedPreviewAfterServerCheck &&
                  (detectedSourceLang == null ||
                      detectedSourceLang != uiLang)) {
                if (isAbsoluteLastMessage &&
                    matchIdForCaseCheck.isNotEmpty &&
                    lastMessageId.isNotEmpty) {
                  unawaited(
                    _triggerImmediateLastMessageTranslation(
                      localDb: localDb,
                      userId: userId,
                      matchId: matchIdForCaseCheck,
                      messageId: lastMessageId,
                      targetLanguage: uiLang,
                    ),
                  );
                }
                // This is a new incoming message in a different language - don't update preview yet
                // If we have a previous chat, return it to keep showing old preview
                if (previousChat != null) {
                  return previousChat;
                }
                // If no previous chat exists (new chat entirely), return empty message
                return null;
              }

              if (isCaseBAfterServerCheck) {
                // Case B: UI language matches source language - show original message
                print(
                  '🔍 Recent chats: Case B triggered - UI matches source, using original message',
                );
                // The chat.lastMessage already contains the correct content from the DB
                // Include the source language so the UI knows to display the original message
                return chat.copyWith(
                  lastMessageSourceLanguage: detectedSourceLang,
                );
              }

              if (hasTranslatedPreviewAfterServerCheck &&
                  isCaseCAfterServerCheck) {
                // Keep lastMessage as original, only update lastMessageTranslated
                return chat.copyWith(
                  lastMessageTranslated: translatedPreview,
                  lastMessageSourceLanguage: detectedSourceLang,
                );
              }

              // If we have source language info, include it in the chat model
              if (detectedSourceLang != null) {
                return chat.copyWith(
                  lastMessageSourceLanguage: detectedSourceLang,
                );
              }

              return chat;
            }

            return chat;
          } catch (e) {
            final matchId = json['match_id']?.toString() ?? 'unknown_match';
            print('Recent chats item processing failed for $matchId: $e');
            return null;
          }
        }).toList(),
      );

      final visibleChats =
          chats
              .whereType<ChatModel>()
              .where((chat) => chat.otherUserId != userId)
              .toList()
            ..sort((a, b) => b.lastMessageAt.compareTo(a.lastMessageAt));
      for (final chat in visibleChats) {
        _recentChatSnapshots['$userId|${chat.matchId}'] = chat;
      }
      return visibleChats;
    } catch (e, st) {
      print('Recent chats stream mapping failed for user $userId: $e\n$st');
      return <ChatModel>[];
    }
  });
});

// Dashboard stats provider - cached stats with real-time updates
final dashboardStatsProvider = StreamProvider.autoDispose<Map<String, int>>((
  ref,
) {
  final userId = supabase.auth.currentUser?.id;

  if (userId == null) {
    return Stream.value({'nearby': 0, 'online': 0});
  }

  final controller = StreamController<Map<String, int>>();
  final localDb = ref.read(localDbProvider);
  Timer? periodicRefreshTimer;
  Timer? userActivityDebounceTimer;
  DateTime? lastFetchStatsTime;
  Map<String, int>? lastEmittedStats;
  DateTime? lastActivityCommitTimestamp;
  bool isFetchingStats = false;

  // Function to fetch current stats (with caching support)
  Future<Map<String, int>> fetchStats({
    bool useCache = true,
    bool saveToCache = true,
    bool force = false,
  }) async {
    // Throttle: prevent fetching more than once every 2 seconds unless forced
    // Also prevent concurrent fetches
    if (!force) {
      if (isFetchingStats) {
        return lastEmittedStats ?? {'nearby': 0, 'online': 0};
      }
      final now = DateTime.now();
      if (lastFetchStatsTime != null &&
          now.difference(lastFetchStatsTime!).inMilliseconds < 2000) {
        return lastEmittedStats ?? {'nearby': 0, 'online': 0};
      }
    }

    // Validate auth session before making API calls to prevent 401 errors on login screen
    final session = supabase.auth.currentSession;
    if (session == null) {
      print('fetchStats: No valid auth session, returning empty stats');
      return {'nearby': 0, 'online': 0};
    }

    // Verify token is not expired
    if (session.expiresAt != null) {
      final now = DateTime.now().millisecondsSinceEpoch ~/ 1000;
      if (session.expiresAt! < now) {
        print('fetchStats: Token expired, returning empty stats');
        return {'nearby': 0, 'online': 0};
      }
    }

    lastFetchStatsTime = DateTime.now();
    isFetchingStats = true;

    try {
      // Try cached stats first if allowed
      if (useCache) {
        final cachedStats = await localDb.getDashboardStats();
        if (cachedStats != null) {
          if (kIsWeb) {}
          return cachedStats;
        }
      }

      // Skip server fetch when offline or Supabase paused (unless forced)
      if (!force) {
        if (shouldSkipSupabaseCalls()) {
          print('📊 Dashboard stats: Skipping server fetch - Supabase paused');
          // Return cached stats or empty if no cache
          final cachedStats = await localDb.getDashboardStats();
          if (cachedStats != null) {
            return cachedStats;
          }
          return {'nearby': 0, 'online': 0};
        }
      }

      // Fetch fresh stats from server
      if (kIsWeb) {}

      // Get the user's radius setting from the users table
      int userRadiusKm = 50; // Default fallback
      try {
        final userResponse = await supabase
            .from('users')
            .select('match_radius_default')
            .eq('id', userId)
            .single();
        userRadiusKm = (userResponse['match_radius_default'] as int?) ?? 50;
      } catch (e) {
        if (!isExpectedOfflineFailure(e)) {
          print('Could not fetch user radius, using default: $e');
        }
      }

      final onlineResponse = await supabase.rpc(
        'get_online_users_count',
        params: {'p_user_id': userId},
      );
      final nearbyResponse = await supabase.rpc(
        'get_nearby_users_count',
        params: {'p_user_id': userId, 'p_radius_km': userRadiusKm},
      );

      final onlineCount = (onlineResponse as int?) ?? 0;
      final nearbyCount = (nearbyResponse as int?) ?? 0;

      final freshStats = {'nearby': nearbyCount, 'online': onlineCount};

      print(
        'Dashboard stats fetched: online=$onlineCount, nearby=$nearbyCount (radius=$userRadiusKm km)',
      );

      // Cache the fresh stats if requested
      if (saveToCache) {
        await localDb.saveDashboardStats(onlineCount, nearbyCount);
      }

      return freshStats;
    } catch (e) {
      if (!isExpectedOfflineFailure(e)) {
        print('Error fetching dashboard stats: $e');
      }

      // Try to return cached stats as fallback, even if expired
      try {
        final cachedStats = await localDb.getDashboardStats();
        if (cachedStats != null) {
          print('Dashboard stats: Using expired cache as fallback');
          return cachedStats;
        }
      } catch (cacheError) {
        print('Dashboard stats: Cache fallback also failed: $cacheError');
      }

      // Ultimate fallback
      return {'nearby': 0, 'online': 0};
    } finally {
      isFetchingStats = false;
    }
  }

  // Register callback to refresh stats when connectivity is restored
  onSupabaseResume(() async {
    if (!ref.mounted || controller.isClosed) return;
    print('📊 Dashboard stats: Connectivity restored, forcing refresh');
    try {
      final fresh = await fetchStats(
        useCache: false,
        saveToCache: true,
        force: true,
      );
      if (fresh != lastEmittedStats) {
        controller.add(fresh);
        lastEmittedStats = fresh;
      }
    } catch (e) {
      print('📊 Dashboard stats: Error on connectivity restore refresh: $e');
    }
  });

  // Emit initial stats (cache if available, then always refresh from server)
  (() async {
    try {
      final cachedStats = await localDb.getDashboardStats();
      if (cachedStats != null) {
        controller.add(cachedStats);
        lastEmittedStats = cachedStats;
      }
    } catch (_) {
      // ignore cache errors
    }

    try {
      final fresh = await fetchStats(useCache: false, saveToCache: true);
      if (fresh != lastEmittedStats) {
        controller.add(fresh);
        lastEmittedStats = fresh;
      }
    } catch (_) {
      // ignore initial refresh errors
    }
  })();

  // We intentionally avoid the Supabase Presence channel here.
  // `realtime_client` 2.7.0 can throw an uncaught null-cast exception during
  // presence sync after reconnects, especially around auth/OAuth transitions.
  // Instead, we rely on WebSocket subscriptions for real-time updates and use
  // a longer-interval fallback timer (30 minutes) to ensure data freshness.
  // This eliminates the flashing caused by constant polling.
  periodicRefreshTimer = Timer.periodic(const Duration(minutes: 30), (_) {
    if (!ref.mounted || controller.isClosed) return;
    if (supabase.auth.currentSession == null) {
      print('fetchStats skipped in periodic timer: No valid session');
      return;
    }
    fetchStats(useCache: false, saveToCache: true).then((stats) {
      try {
        // Only emit if stats have changed
        if (stats != lastEmittedStats) {
          controller.add(stats);
          lastEmittedStats = stats;
        }
      } catch (_) {
        // ignore closed controller
      }
    });
  });

  // Subscribe to users table for visibility setting changes
  // This works because users table RLS allows reading all users
  final visibilityChannel = supabase
      .channel('dashboard_stats_visibility_$userId')
      .onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'users',
        callback: (payload) {
          final newRecord = payload.newRecord as Map<String, dynamic>?;
          final oldRecord = payload.oldRecord as Map<String, dynamic>?;
          final changedUserId =
              (newRecord?['id'] ?? oldRecord?['id']) as String?;

          if (changedUserId == null || changedUserId == userId) return;

          final bool visibilityFieldPresent =
              (newRecord?.containsKey('user_visibility_setting') ?? false) ||
              (oldRecord?.containsKey('user_visibility_setting') ?? false);
          if (!visibilityFieldPresent) return;

          final newVisible = newRecord?['user_visibility_setting'] as bool?;
          final oldVisible = oldRecord?['user_visibility_setting'] as bool?;
          final bool shouldRefetch =
              oldRecord == null || newVisible != oldVisible;
          if (!shouldRefetch) return;

          print('Another user visibility setting changed');
          if (!ref.mounted) return;
          if (supabase.auth.currentSession == null) {
            print(
              'fetchStats skipped in visibility callback: No valid session',
            );
            return;
          }
          fetchStats(useCache: false, saveToCache: false).then((stats) {
            try {
              // Only emit if stats have changed
              if (stats != lastEmittedStats) {
                controller.add(stats);
                lastEmittedStats = stats;
              }
            } catch (e) {
              // ignore closed controller
            }
          });
        },
      )
      .subscribe((status, err) {
        if (err != null && !isExpectedOfflineFailure(err)) {
          print('Visibility channel status: $status, error: $err');
        }
      });

  // Subscribe to user_locations table for location changes that affect nearby count
  final locationChannel = supabase
      .channel('dashboard_stats_location_$userId')
      .onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'user_locations',
        callback: (payload) {
          final newRecord = payload.newRecord as Map<String, dynamic>?;
          final oldRecord = payload.oldRecord as Map<String, dynamic>?;
          final changedUserId =
              (newRecord?['user_id'] ?? oldRecord?['user_id']) as String?;

          if (changedUserId == null || changedUserId == userId) return;

          print('Another user location changed - refreshing nearby count');
          if (!ref.mounted) return;
          if (supabase.auth.currentSession == null) {
            print('fetchStats skipped in location callback: No valid session');
            return;
          }
          fetchStats(useCache: false, saveToCache: false).then((stats) {
            try {
              // Only emit if stats have changed
              if (stats != lastEmittedStats) {
                controller.add(stats);
                lastEmittedStats = stats;
              }
            } catch (e) {
              // ignore closed controller
            }
          });
        },
      )
      .subscribe((status, err) {
        if (err != null && !isExpectedOfflineFailure(err)) {
          print('Location channel status: $status, error: $err');
        }
      });

  // Subscribe to user_activity table for online status changes
  // This ensures the online count updates immediately when users come online/offline
  // Filter out own user_activity changes server-side to avoid wasted processing
  final activityChannel = supabase
      .channel('dashboard_stats_activity_$userId')
      .onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'user_activity',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.neq,
          column: 'user_id',
          value: userId,
        ),
        callback: (payload) {
          // Dedup by commit timestamp (handles duplicate events from Postgres)
          if (payload.commitTimestamp == lastActivityCommitTimestamp) {
            return;
          }
          lastActivityCommitTimestamp = payload.commitTimestamp;

          print('🔄 [REALTIME] user_activity INSERT event received: $payload');
          final newRecord = payload.newRecord as Map<String, dynamic>?;
          final changedUserId = newRecord?['user_id'] as String?;

          print(
            '🔄 [REALTIME] Changed user ID: $changedUserId, My user ID: $userId',
          );
          if (changedUserId == null || changedUserId == userId) {
            print('🔄 [REALTIME] Skipping - changed user is null or is me');
            return;
          }

          // Refetch on any user_activity change (online/offline)
          print(
            '🔄 [REALTIME] Another user activity changed - refreshing online count',
          );
          if (!ref.mounted) return;
          if (supabase.auth.currentSession == null) {
            print('fetchStats skipped in activity callback: No valid session');
            return;
          }
          fetchStats(useCache: false, saveToCache: false).then((stats) {
            try {
              // Only emit if stats have changed
              if (stats != lastEmittedStats) {
                controller.add(stats);
                lastEmittedStats = stats;
              }
            } catch (e) {
              // ignore closed controller
            }
          });
        },
      )
      .onPostgresChanges(
        event: PostgresChangeEvent.update,
        schema: 'public',
        table: 'user_activity',
        filter: PostgresChangeFilter(
          type: PostgresChangeFilterType.neq,
          column: 'user_id',
          value: userId,
        ),
        callback: (payload) {
          // Dedup: skip events with same commit timestamp (Postgres trigger duplicates)
          if (payload.commitTimestamp == lastActivityCommitTimestamp) {
            return;
          }
          lastActivityCommitTimestamp = payload.commitTimestamp;

          print('🔄 [REALTIME] user_activity UPDATE event received: $payload');
          final newRecord = payload.newRecord as Map<String, dynamic>?;
          final oldRecord = payload.oldRecord as Map<String, dynamic>?;
          final changedUserId =
              (newRecord?['user_id'] ?? oldRecord?['user_id']) as String?;

          print(
            '🔄 [REALTIME] Changed user ID: $changedUserId, My user ID: $userId',
          );
          if (changedUserId == null || changedUserId == userId) {
            print('🔄 [REALTIME] Skipping - changed user is null or is me');
            return;
          }

          // Debounce: cancel previous timer and schedule a new one
          userActivityDebounceTimer?.cancel();
          userActivityDebounceTimer = Timer(const Duration(milliseconds: 500), () {
            print(
              '🔄 [REALTIME] Another user activity updated - refreshing online count (debounced)',
            );
            if (!ref.mounted) return;
            if (supabase.auth.currentSession == null) {
              print(
                'fetchStats skipped in activity update callback: No valid session',
              );
              return;
            }
            fetchStats(useCache: false, saveToCache: false).then((stats) {
              try {
                // Only emit if stats have changed
                if (stats != lastEmittedStats) {
                  controller.add(stats);
                  lastEmittedStats = stats;
                }
              } catch (e) {
                // ignore closed controller
              }
            });
          });
        },
      )
      .subscribe((status, err) {
        if (err != null && !isExpectedOfflineFailure(err)) {
          print('🔄 [REALTIME] Activity channel status: $status, error: $err');
        }
      });

  // Listen to connectivity changes and force refresh when coming back online
  StreamSubscription? connectivitySubscription;
  ConnectivityHealthStatus? lastConnectivityStatus;
  connectivitySubscription = Connectivity().onConnectivityChanged.listen((
    _,
  ) async {
    if (!ref.mounted || controller.isClosed) return;

    // Check current connectivity health
    final currentHealth = await ref.read(connectivityHealthProvider.future);
    if (currentHealth.status != lastConnectivityStatus) {
      if (lastConnectivityStatus == ConnectivityHealthStatus.offline &&
          currentHealth.status == ConnectivityHealthStatus.online) {
        print('🌐 Dashboard stats: Device came back online - forcing refresh');
        if (supabase.auth.currentSession == null) {
          print(
            'fetchStats skipped in connectivity callback: No valid session',
          );
          return;
        }
        fetchStats(useCache: false, saveToCache: true, force: true).then((
          stats,
        ) {
          try {
            if (stats != lastEmittedStats) {
              controller.add(stats);
              lastEmittedStats = stats;
            }
          } catch (_) {
            // ignore closed controller
          }
        });
      }
      lastConnectivityStatus = currentHealth.status;
    }
  });

  // Set up periodic refresh (every 5 minutes) as a fallback
  // The cron job now handles setting is_online=false for stale users (triggers real-time events)
  // This timer is just a safety net for edge cases (e.g., cron job delays, missed real-time events)
  final cacheRefreshTimer = Timer.periodic(const Duration(minutes: 5), (_) {
    if (!controller.isClosed && ref.mounted) {
      // Skip if no valid session
      if (supabase.auth.currentSession == null) {
        print('fetchStats skipped in cache refresh timer: No valid session');
        return;
      }
      // Refresh cache with fresh data from server and emit if changed
      fetchStats(useCache: false, saveToCache: true).then((stats) {
        try {
          // Emit to stream if stats have changed
          if (stats != lastEmittedStats) {
            controller.add(stats);
            lastEmittedStats = stats;
          }
        } catch (e) {
          // ignore closed controller
        }
      });
    }
  });

  ref.onDispose(() {
    supabase.removeChannel(locationChannel);
    supabase.removeChannel(visibilityChannel);
    supabase.removeChannel(activityChannel);
    periodicRefreshTimer?.cancel();
    cacheRefreshTimer.cancel();
    userActivityDebounceTimer?.cancel();
    connectivitySubscription?.cancel();
    controller.close();
  });

  return controller.stream;
});

// Total unread chat count provider
// Uses ref.listen instead of ref.watch to avoid triggering invalidateSelf
// during the TickerMode resume flow, which causes a Riverpod reentrancy
// assertion (pause-count mismatch) when recentChatsProvider is resumed.
class TotalUnreadChatCountNotifier extends Notifier<int> {
  @override
  int build() {
    final userId = supabase.auth.currentUser?.id ?? '';
    final chatsAsync = ref.read(recentChatsProvider(userId));
    final initialValue = chatsAsync.asData?.value ?? [];
    final initial = initialValue.where((chat) => chat.unreadCount > 0).length;

    ref.listen(recentChatsProvider(userId), (prev, next) {
      final chats = next.value ?? [];
      final count = chats.where((chat) => chat.unreadCount > 0).length;
      if (count != state) {
        Future.microtask(() => state = count);
      }
    });

    return initial;
  }
}

final totalUnreadChatCountProvider =
    NotifierProvider<TotalUnreadChatCountNotifier, int>(
  TotalUnreadChatCountNotifier.new,
);

// Navigation index notifier
class NavigationIndexNotifier extends Notifier<int> {
  @override
  int build() => 0;

  void setIndex(int index) {
    state = index;
  }
}

// Navigation index provider
final navigationIndexProvider = NotifierProvider<NavigationIndexNotifier, int>(
  () {
    return NavigationIndexNotifier();
  },
);

// Global app resume tracker for preventing unnecessary reloads
class AppResumeNotifier extends Notifier<DateTime?> {
  DateTime? _resumeTime;
  bool _hasLoadedAdsOnce = false;

  @override
  DateTime? build() => _resumeTime;

  void markResumed() {
    _resumeTime = DateTime.now();
    state = _resumeTime;
    // Clear the resume flag after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      _resumeTime = null;
      state = null;
    });
  }

  bool shouldSkipAdLoad() {
    // Never skip on first load
    if (!_hasLoadedAdsOnce) {
      _hasLoadedAdsOnce = true;
      return false;
    }

    if (_resumeTime == null) return false;
    // Skip ad loads if resume was less than 3 seconds ago
    return DateTime.now().difference(_resumeTime!).inSeconds < 3;
  }
}

final appResumeNotifierProvider =
    NotifierProvider<AppResumeNotifier, DateTime?>(AppResumeNotifier.new);

// Activity update provider - updates user activity when accessed
final activityUpdateProvider = Provider.autoDispose<void>((ref) {
  final user = supabase.auth.currentUser;
  if (user != null && !shouldSkipSupabaseCalls()) {
    UserActivityService.instance.pingIfDue(
      user.id,
      source: 'activity-update-provider',
    );
  }
});

// Potential matches provider - fetches users that could be matches
final potentialMatchesProvider =
    FutureProvider.autoDispose<List<Map<String, dynamic>>>((ref) async {
      final user = supabase.auth.currentUser;
      if (user == null) return [];

      try {
        // Get current user's location and settings
        final userResponse = await supabase
            .from('users')
            .select('match_radius_default')
            .eq('id', user.id)
            .single();

        final matchRadius =
            userResponse['match_radius_default'] as int? ?? 50; // default 50km

        // Get current user's location
        final locationResponse = await supabase
            .from('user_locations')
            .select('latitude, longitude')
            .eq('user_id', user.id)
            .order('updated_at', ascending: false)
            .limit(1)
            .maybeSingle();

        if (locationResponse == null) return [];

        final userLat = locationResponse['latitude'] as double;
        final userLng = locationResponse['longitude'] as double;

        // DEBUG: Log auth state before matches query
        final session = supabase.auth.currentSession;
        final tokenPresent = session != null && session.accessToken.isNotEmpty;
        print(
          '🔐 [HOME] Before matches query - user: ${supabase.auth.currentUser?.id}, session: ${session != null}, token present: $tokenPresent',
        );

        // Get existing matches to exclude
        final existingMatches = await supabase
            .from('matches')
            .select('user1_id, user2_id')
            .or('user1_id.eq.${user.id},user2_id.eq.${user.id}');

        final matchedUserIds = <String>{};
        for (final match in existingMatches) {
          if (match['user1_id'] != user.id) {
            matchedUserIds.add(match['user1_id']);
          }
          if (match['user2_id'] != user.id) {
            matchedUserIds.add(match['user2_id']);
          }
        }

        // Query potential matches
        final potentialUsers = await supabase
            .from('users')
            .select('''
          id,
          display_name,
          profile_data,
          user_locations!inner(latitude, longitude)
        ''')
            .eq('user_visibility_setting', true)
            .neq('id', user.id)
            .not('id', 'in', '(${matchedUserIds.join(',')})')
            .filter('user_locations.latitude', 'not.is', null)
            .filter('user_locations.longitude', 'not.is', null);

        // Filter by distance
        final potentialMatches = <Map<String, dynamic>>[];
        for (final userData in potentialUsers) {
          final locations = userData['user_locations'] as List<dynamic>;
          if (locations.isNotEmpty) {
            final location = locations.first;
            final lat = location['latitude'] as double?;
            final lng = location['longitude'] as double?;
            if (lat != null && lng != null) {
              final distance = _calculateDistance(userLat, userLng, lat, lng);
              if (distance <= matchRadius) {
                potentialMatches.add({
                  ...userData,
                  'distance': distance,
                  'location': location,
                });
              }
            }
          }
        }

        // Sort by distance
        potentialMatches.sort(
          (a, b) =>
              (a['distance'] as double).compareTo(b['distance'] as double),
        );

        return potentialMatches;
      } catch (e) {
        print('Error fetching potential matches: $e');
        return [];
      }
    });

// Helper function to calculate distance between two points
double _calculateDistance(double lat1, double lng1, double lat2, double lng2) {
  const double earthRadius = 6371; // km
  final double dLat = _degreesToRadians(lat2 - lat1);
  final double dLng = _degreesToRadians(lng2 - lng1);
  final double a =
      sin(dLat / 2) * sin(dLat / 2) +
      cos(_degreesToRadians(lat1)) *
          cos(_degreesToRadians(lat2)) *
          sin(dLng / 2) *
          sin(dLng / 2);
  final double c = 2 * atan2(sqrt(a), sqrt(1 - a));
  return earthRadius * c;
}

double _degreesToRadians(double degrees) => degrees * (3.141592653589793 / 180);

// --- userChatIdsProvider ---
// Returns a set of match IDs that have chats for the given user
final userChatIdsProvider = StreamProvider.autoDispose
    .family<Set<String>, String>((ref, userId) {
      if (userId.isEmpty) {
        return Stream.value(<String>{});
      }

      final localDb = ref.watch(localDbProvider);
      final localStream = localDb.watchChats(userId);

      return localStream.map((chats) {
        return chats
            .map((chat) => chat['match_id'] as String?)
            .whereType<String>()
            .toSet();
      });
    });

// --- matchExpiryNowProvider ---
// Provides the current DateTime for calculating match expiry countdown
// Updates every second to keep countdown timers accurate
final matchExpiryNowProvider = StreamProvider<DateTime>((ref) {
  final controller = StreamController<DateTime>();

  // Emit current time immediately
  controller.add(DateTime.now());

  // Update every second
  final timer = Timer.periodic(const Duration(seconds: 1), (_) {
    if (!controller.isClosed) {
      controller.add(DateTime.now());
    }
  });

  ref.onDispose(() {
    timer.cancel();
    controller.close();
  });

  return controller.stream;
});

final matchChatStartExpiryWarningProvider =
    NotifierProvider<MatchChatStartExpiryWarningNotifier, Object?>(() {
      return MatchChatStartExpiryWarningNotifier();
    });

class MatchChatStartExpiryWarningNotifier extends Notifier<Object?> {
  List<MatchModel> _matches = const [];
  Set<String> _chatIds = const <String>{};
  LocalizationState? _l10n;
  DateTime? _now;

  bool _checkScheduled = false;
  bool _checkInProgress = false;

  List<Duration> _warningThresholds = const [Duration(minutes: 60)];
  DateTime? _warningThresholdsFetchedAt;

  final Set<String> _notifiedThisSession = <String>{};
  final Set<String> _checkInFlightMatchIds = <String>{};

  @override
  Object? build() {
    final userId = supabase.auth.currentUser?.id ?? '';
    if (userId.isEmpty) return null;

    ref.listen<AsyncValue<List<MatchModel>>>(recentMatchesProvider(userId), (
      previous,
      next,
    ) {
      _matches = next.asData?.value ?? const [];
      _scheduleCheck();
    });

    ref.listen<AsyncValue<Set<String>>>(userChatIdsProvider(userId), (
      previous,
      next,
    ) {
      _chatIds = next.asData?.value ?? const <String>{};
      _scheduleCheck();
    });

    ref.listen<LocalizationState>(localizationProvider, (previous, next) {
      _l10n = next;
      _scheduleCheck();
    });

    ref.listen<AsyncValue<DateTime>>(matchExpiryNowProvider, (previous, next) {
      final v = next.asData?.value;
      if (v != null) {
        _now = v;
        _scheduleCheck();
      }
    });

    Future.microtask(_scheduleCheck);

    return null;
  }

  void _scheduleCheck() {
    if (_checkScheduled) return;
    _checkScheduled = true;
    Future.microtask(() async {
      _checkScheduled = false;
      await _checkForWarnings();
    });
  }

  Future<List<Duration>> _getWarningThresholds(DateTime now) async {
    final last = _warningThresholdsFetchedAt;
    if (last != null && now.difference(last) < const Duration(minutes: 1)) {
      return _warningThresholds;
    }

    _warningThresholdsFetchedAt = now;
    final configured = await appConfigService.getDurationList(
      'matches.chat_start_expiry_warning_seconds',
      defaultValue: const [Duration(minutes: 60)],
    );

    final cleaned = configured.where((d) => d > Duration.zero).toSet().toList()
      ..sort((a, b) => a.inSeconds.compareTo(b.inSeconds));
    _warningThresholds = cleaned.isEmpty
        ? const [Duration(minutes: 60)]
        : cleaned;
    return _warningThresholds;
  }

  Future<String?> _getCachedOtherUserName(
    LocalDbService localDb,
    String otherUserId,
  ) async {
    if (otherUserId.trim().isEmpty) return null;
    try {
      final cached = await localDb.getOtherUserProfile(otherUserId);
      if (cached == null) return null;
      final raw =
          (cached['name'] ??
                  cached['display_name'] ??
                  cached['displayName'] ??
                  '')
              .toString();
      final trimmed = raw.trim();
      if (trimmed.isEmpty) return null;
      return formatSenderNameForNotification(trimmed);
    } catch (_) {
      return null;
    }
  }

  Future<String?> _resolveOtherUserName(
    LocalDbService localDb,
    String otherUserId,
  ) async {
    final cached = await _getCachedOtherUserName(localDb, otherUserId);
    if (cached != null && cached.trim().isNotEmpty) return cached;

    try {
      final profile = await ref.read(
        otherUserProfileProvider(otherUserId).future,
      );
      final raw = profile?.name.toString() ?? '';
      final trimmed = raw.trim();
      if (trimmed.isEmpty) return null;
      return formatSenderNameForNotification(trimmed);
    } catch (_) {
      return null;
    }
  }

  Future<void> _checkForWarnings() async {
    if (_checkInProgress) return;
    _checkInProgress = true;

    try {
      final l10n = _l10n;
      if (l10n == null) return;

      final userId = supabase.auth.currentUser?.id ?? '';
      if (userId.isEmpty) return;

      final matches = _matches;
      if (matches.isEmpty) return;

      final now = _now ?? DateTime.now();
      final thresholds = await _getWarningThresholds(now);
      final startThreshold = thresholds.isEmpty
          ? const Duration(minutes: 60)
          : thresholds.last;

      final localDb = ref.read(localDbProvider);
      final prefs = await SharedPreferences.getInstance();

      for (final match in matches) {
        final matchId = match.id.trim();
        if (matchId.isEmpty) continue;

        if (_chatIds.contains(matchId)) continue;

        final window = Duration(
          seconds:
              match.chatStartWindowSeconds ??
              const Duration(hours: 24).inSeconds,
        );
        final remaining = match.createdAt
            .toUtc()
            .add(window)
            .difference(now.toUtc());
        if (remaining <= Duration.zero) continue;
        if (remaining > startThreshold) continue;

        Duration? thresholdToSend;
        for (final t in thresholds) {
          if (remaining <= t) {
            thresholdToSend = t;
            break;
          }
        }
        if (thresholdToSend == null) continue;

        const templateVersion = 'match_expiry_minutes_v1';
        final sessionKey =
            '$matchId:${thresholdToSend.inSeconds}:$templateVersion';
        if (_notifiedThisSession.contains(sessionKey)) continue;
        if (_checkInFlightMatchIds.contains(matchId)) continue;
        _checkInFlightMatchIds.add(matchId);

        try {
          final prefsKey =
              'match_chat_start_expiry_warned_${matchId}_${thresholdToSend.inSeconds}_$templateVersion';
          final alreadyNotified = prefs.getBool(prefsKey) ?? false;
          if (alreadyNotified) {
            _notifiedThisSession.add(sessionKey);
            continue;
          }

          await prefs.setBool(prefsKey, true);
          _notifiedThisSession.add(sessionKey);

          final otherName = await _resolveOtherUserName(
            localDb,
            match.otherUserId,
          );
          final minutesLeft = max(1, (remaining.inSeconds / 60).ceil());
          final otherUserName = (otherName == null || otherName.trim().isEmpty)
              ? l10n.getString('generalUnknown')
              : otherName;

          final title = l10n.getString(
            'matchExpiryTitle',
            params: {'count': minutesLeft.toString()},
          );
          final body = l10n.getString(
            'matchExpiryBody',
            params: {
              'count': minutesLeft.toString(),
              'otherUserName': otherUserName,
            },
          );

          if (kIsWeb) {
            await WebNotificationService.showMatchNotification(
              matchId: matchId,
              matchName: otherUserName,
              matchPhotoUrl: '',
            );
          } else {
            await MobileLocalNotificationService.showMatchExpiryNotification(
              matchId: matchId,
              title: title,
              body: body,
              notificationKey:
                  'chat_start_expiry_${thresholdToSend.inSeconds}_$templateVersion',
            );
          }
        } catch (_) {
        } finally {
          _checkInFlightMatchIds.remove(matchId);
        }
      }
    } finally {
      _checkInProgress = false;
    }
  }
}

// Helper functions for language detection
bool _looksLikeEmoji(String grapheme) {
  return RegExp(
    r'[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}]',
    unicode: true,
  ).hasMatch(grapheme);
}

String _stripEmojisForLanguageId(String input) {
  final buf = StringBuffer();
  for (final rune in input.runes) {
    final s = String.fromCharCodes([rune]);
    if (_looksLikeEmoji(s)) continue;
    if (RegExp(r'[\p{L}\p{N}\s]', unicode: true).hasMatch(s)) {
      buf.write(s);
    } else {
      buf.write(' ');
    }
  }
  return buf.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}
