// lib/providers/auth_provider.dart
// ...existing code...
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/services/offline_cache_manager.dart';
import 'package:matchme/services/session_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class AuthUiMessageNotifier extends Notifier<String?> {
  @override
  String? build() => null;

  void setMessage(String? message) {
    state = message;
  }

  void clear() {
    state = null;
  }
}

final authUiMessageProvider =
    NotifierProvider<AuthUiMessageNotifier, String?>(() {
  return AuthUiMessageNotifier();
});

// This creates a stream that notifies the app when the auth state changes
final authStateProvider = StreamProvider<AuthState>((ref) {
  final controller = StreamController<AuthState>();
  final auth = Supabase.instance.client.auth;

  bool disposed = false;
  StreamSubscription<AuthState>? sub;
  bool validationInFlight = false;
  String? lastValidatedAccessToken;
  bool initialEventEmitted = false;
  bool initialEventFallbackInProgress = false;
  Timer? initialEventTimeout;

  void syncLanguageForAuthenticatedSession() {
    if (!offlineCacheManager.isSupabaseAvailable) {
      print('[AUTH] Skipping language sync - Supabase offline');
      return;
    }
    try {
      unawaited(
        ref
            .read(localizationProvider.notifier)
            .syncLanguageAfterLogin()
            .catchError((Object error, StackTrace stackTrace) {
              print('[AUTH] Language sync after auth failed: $error');
            }),
      );
    } catch (error) {
      print('[AUTH] Failed to schedule language sync after auth: $error');
    }
  }

  void bestEffortSignOut(Object error) {
    try {
      print('Auth error encountered: $error. Signing out...');
      unawaited(SessionService.clearPersistedSupabaseSessionSnapshot());
      unawaited(
        auth.signOut(scope: SignOutScope.local).catchError((_) {}),
      );
    } catch (_) {}
  }

  bool isLikelyNetworkAuthError(Object error) {
    final msg = (error is AuthException) ? error.message : error.toString();
    final lower = msg.toLowerCase();
    return lower.contains('socketexception') ||
        lower.contains('clientexception') ||
        lower.contains('failed host lookup') ||
        lower.contains('no address associated with hostname') ||
        lower.contains('network is unreachable') ||
        lower.contains('connection refused') ||
        lower.contains('connection reset') ||
        lower.contains('software caused connection abort') ||
        lower.contains('timed out') ||
        lower.contains('authretryablefetchexception');
  }

  bool shouldSignOutForError(Object error) {
    final msg = (error is AuthException) ? error.message : error.toString();
    final lower = msg.toLowerCase();
    if (isLikelyNetworkAuthError(error)) {
      return false;
    }
    return lower.contains('refresh_token_not_found') ||
        lower.contains('refresh token not found') ||
        lower.contains('invalid refresh token') ||
        lower.contains('refresh_token_already_used') ||
        lower.contains('already used') ||
        lower.contains('invalid jwt') ||
        lower.contains('jwt expired') ||
        lower.contains('token is expired') ||
        lower.contains('session expired') ||
        lower.contains('unauthorized') ||
        lower.contains('not authorized');
  }

  bool isPkceCodeVerifierError(Object error) {
    final msg = (error is AuthException) ? error.message : error.toString();
    return msg.toLowerCase().contains('code verifier could not be found');
  }

  bool isLikelyInvalidSessionError(Object error) {
    final msg = (error is AuthException) ? error.message : error.toString();
    final lower = msg.toLowerCase();
    return lower.contains('invalid jwt') ||
        lower.contains('jwt expired') ||
        lower.contains('token is expired') ||
        lower.contains('invalid refresh token') ||
        lower.contains('refresh_token_not_found') ||
        lower.contains('refresh token not found') ||
        lower.contains('refresh_token_already_used') ||
        lower.contains('already used') ||
        lower.contains('unauthorized') ||
        lower.contains('not authorized');
  }

  void validateSessionBestEffort(AuthState authState) {
    if (validationInFlight) return;
    final session = authState.session;
    if (session == null) return;
    if (!offlineCacheManager.isSupabaseAvailable ||
        offlineCacheManager.shouldUseCachedData() ||
        SessionService.recoveredPersistedSessionThisLaunch) {
      return;
    }
    final token = session.accessToken.trim();
    if (token.isEmpty) return;
    if (kIsWeb) {
      final now = DateTime.now().millisecondsSinceEpoch / 1000;
      final exp = session.expiresAt;
      if (exp != null && exp <= now) {
        bestEffortSignOut('Session expired');
        return;
      }
    }
    if (token == lastValidatedAccessToken) return;

    validationInFlight = true;
    () async {
      try {
        await auth.getUser();
        lastValidatedAccessToken = token;
      } catch (e) {
        if (disposed) return;
        if (isLikelyInvalidSessionError(e) || shouldSignOutForError(e)) {
          lastValidatedAccessToken = null;
          bestEffortSignOut(e);
        }
      } finally {
        validationInFlight = false;
      }
    }();
  }

  Future<void> emitInitialEvent() async {
    if (initialEventEmitted || disposed || initialEventFallbackInProgress) {
      return;
    }
    initialEventFallbackInProgress = true;
    try {
      if (auth.currentSession == null) {
        await SessionService.recoverPersistedSupabaseSession();
      }
      if (initialEventEmitted || disposed) return;

      initialEventEmitted = true;
      initialEventTimeout?.cancel();

      // Emit the current session state (cached locally)
      final currentSession = auth.currentSession;
      final currentUser = auth.currentUser;

      print('🔄 [AUTH] Emitting initial auth state from cache (offline fallback) - session: ${currentSession != null}, user: ${currentUser != null}');

      // Always emit an event, even if session is null
      // This unblocks the UI from the loading state
      controller.add(AuthState(
        AuthChangeEvent.initialSession,
        currentSession,
      ));
    } finally {
      initialEventFallbackInProgress = false;
    }
  }

  if (!offlineCacheManager.isSupabaseAvailable) {
    ref.onDispose(() => controller.close());
    unawaited(() async {
      try {
        if (auth.currentSession == null) {
          await SessionService.recoverPersistedSupabaseSession();
        }
        controller.add(AuthState(AuthChangeEvent.initialSession, auth.currentSession));
      } catch (e) {
        controller.add(AuthState(AuthChangeEvent.initialSession, null));
      } finally {
        controller.close();
      }
    }());
    return controller.stream;
  }

  sub = auth.onAuthStateChange.listen(
    (authState) async {
      if (disposed) return;

      AuthState effectiveAuthState = authState;

      if (effectiveAuthState.session == null && auth.currentSession != null) {
        effectiveAuthState = AuthState(
          authState.event,
          auth.currentSession,
        );
        print(
          '🔄 [AUTH] Replaced empty auth event session with current cached session',
        );
      }

      // Supabase can emit an immediate null initialSession before its own
      // storage restoration completes. Try our explicit offline recovery
      // before accepting that unauthenticated state.
      if (!initialEventEmitted &&
          authState.event == AuthChangeEvent.initialSession &&
          authState.session == null) {
        final recovered = await SessionService.recoverPersistedSupabaseSession();
        if (disposed) return;
        if (recovered && auth.currentSession != null) {
          effectiveAuthState = AuthState(
            AuthChangeEvent.initialSession,
            auth.currentSession,
          );
          print('🔄 [AUTH] Replaced null initial session with recovered persisted session');
        }
      }

      // Mark that we received an initial auth state.
      if (!initialEventEmitted) {
        initialEventEmitted = true;
        initialEventTimeout?.cancel();
        print('🔄 [AUTH] Stream emitted initial event');
      }

      if (effectiveAuthState.event == AuthChangeEvent.signedOut) {
        unawaited(SessionService.clearPersistedSupabaseSessionSnapshot());
      } else if (effectiveAuthState.session != null) {
        unawaited(SessionService.persistCurrentSupabaseSessionSnapshot());
      }

      if (effectiveAuthState.event == AuthChangeEvent.initialSession ||
          effectiveAuthState.event == AuthChangeEvent.signedIn ||
          effectiveAuthState.event == AuthChangeEvent.tokenRefreshed) {
        validateSessionBestEffort(effectiveAuthState);
      }
      if ((effectiveAuthState.event == AuthChangeEvent.initialSession ||
              effectiveAuthState.event == AuthChangeEvent.signedIn) &&
          effectiveAuthState.session != null) {
        syncLanguageForAuthenticatedSession();
      }
      controller.add(effectiveAuthState);
    },
    onError: (Object error, StackTrace stackTrace) {
      if (disposed) return;

      if (isPkceCodeVerifierError(error)) {
        try {
          final l10n = ref.read(localizationProvider);
          ref.read(authUiMessageProvider.notifier).setMessage(l10n.getString('authOAuthFailed'));
        } catch (_) {}
        return;
      }

      // Network errors during auth operations are non-fatal offline scenarios
      // Instead of crashing, emit cached session state
      if (isLikelyNetworkAuthError(error)) {
        print('🌐 [AUTH] Network error during auth operation (likely offline): $error');
        print('📋 [AUTH] Emitting cached session state instead of propagating error');
        offlineCacheManager.setSupabaseAvailability(false, force: true);
        try {
          final session = auth.currentSession;
          final user = auth.currentUser;
          controller.add(AuthState(
            AuthChangeEvent.initialSession,
            session,
          ));
          if (user == null && session == null) {
            print('📋 [AUTH] No cached session available, user will see unauthenticated state');
          }
        } catch (e) {
          print('❌ [AUTH] Failed to emit cached state: $e');
        }
        return;
      }

      if (shouldSignOutForError(error)) {
        bestEffortSignOut(error);
        return;
      }

      controller.addError(error, stackTrace);
    },
  );

  // Emit a cached session quickly if the auth stream stalls offline.
  initialEventTimeout = Timer(
    const Duration(seconds: 1),
    () => unawaited(emitInitialEvent()),
  );

  ref.onDispose(() {
    disposed = true;
    initialEventTimeout?.cancel();
    sub?.cancel();
    controller.close();
  });

  return controller.stream;
});
