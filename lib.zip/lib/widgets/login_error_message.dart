import 'package:flutter/material.dart';

class LoginErrorMessage extends StatelessWidget {
  final String? message;
  final bool isPasswordError;

  const LoginErrorMessage({
    required this.message,
    required this.isPasswordError,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    if (message == null || message!.isEmpty) {
      return SizedBox.shrink();
    }

    return Padding(
      padding: const EdgeInsets.only(top: 16.0),
      child: Container(
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          color: Colors.red.shade50,
          border: Border.all(color: Colors.red),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          message!,
          style: TextStyle(color: Colors.red.shade700),
        ),
      ),
    );
  }
}
