import 'package:flutter/material.dart';

class StartupLoaderScaffold extends StatelessWidget {
  const StartupLoaderScaffold({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: _StartupLoaderBody(),
      ),
    );
  }
}

class _StartupLoaderBody extends StatefulWidget {
  const _StartupLoaderBody();

  @override
  State<_StartupLoaderBody> createState() => _StartupLoaderBodyState();
}

class _StartupLoaderBodyState extends State<_StartupLoaderBody>
    with SingleTickerProviderStateMixin {
  static const double _nativeLaunchWidth = 96.0;
  static const double _nativeLaunchHeight = 106.0;

  late final AnimationController _controller;
  late final Animation<double> _scaleAnimation;
  late final Animation<double> _shadowAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();

    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: ConstantTween<double>(1.0),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.0, end: 1.08)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 12,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.08, end: 0.98)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 8,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 0.98, end: 1.12)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 14,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1.12, end: 1.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 18,
      ),
      TweenSequenceItem(
        tween: ConstantTween<double>(1.0),
        weight: 28,
      ),
    ]).animate(_controller);

    _shadowAnimation = TweenSequence<double>([
      TweenSequenceItem(
        tween: ConstantTween<double>(16.0),
        weight: 20,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 16.0, end: 24.0)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 12,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 24.0, end: 14.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 8,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 14.0, end: 28.0)
            .chain(CurveTween(curve: Curves.easeOut)),
        weight: 14,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 28.0, end: 16.0)
            .chain(CurveTween(curve: Curves.easeInOut)),
        weight: 18,
      ),
      TweenSequenceItem(
        tween: ConstantTween<double>(16.0),
        weight: 28,
      ),
    ]).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final shortestSide =
              constraints.maxWidth < constraints.maxHeight
                  ? constraints.maxWidth
                  : constraints.maxHeight;
          final width =
              shortestSide < 360 ? shortestSide * 0.27 : _nativeLaunchWidth;
          final height = width * (_nativeLaunchHeight / _nativeLaunchWidth);

          return AnimatedBuilder(
            animation: _controller,
            child: RepaintBoundary(
              child: SizedBox(
                width: width,
                height: height,
                child: Image.asset(
                  'assets/images/logo.png',
                  fit: BoxFit.contain,
                ),
              ),
            ),
            builder: (context, child) {
              return Transform.scale(
                scale: _scaleAnimation.value,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: _shadowAnimation.value,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: child,
                ),
              );
            },
          );
        },
      ),
    );
  }
}
