import 'dart:async';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/utils/offline_utils.dart';

class EmailChangeException implements Exception {
  const EmailChangeException({
    required this.code,
    required this.message,
    this.statusCode,
  });

  final String code;
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class EmailChangeResult {
  const EmailChangeResult({
    required this.success,
    required this.message,
    this.expiresAt,
  });

  final bool success;
  final String message;
  final DateTime? expiresAt;
}

class EmailChangeService {
  static const Duration _requestTimeout = Duration(seconds: 10);
  static DateTime? _activeEmailCodeExpiresAt;
  static String? _pendingNewEmail;

  static DateTime? get activeEmailCodeExpiresAt {
    final expiresAt = _activeEmailCodeExpiresAt;
    if (expiresAt == null) return null;
    if (DateTime.now().isAfter(expiresAt)) {
      _activeEmailCodeExpiresAt = null;
      return null;
    }
    return expiresAt;
  }

  static Future<bool> isEmailAvailable(String email) async {
    if (shouldSkipSupabaseCalls()) return false;
    
    final supabase = Supabase.instance.client;
    final auth = supabase.auth;
    final currentUser = auth.currentUser;

    if (currentUser == null) {
      return false;
    }

    try {
      final response = await supabase.rpc(
        'check_email_availability',
        params: {
          'p_email': email.trim().toLowerCase(),
          'p_exclude_user_id': currentUser.id,
        },
      ).timeout(const Duration(seconds: 5));

      if (response == null || (response is List && response.isEmpty)) {
        return false;
      }

      final data = response is List ? response[0] : response;
      return data['available'] as bool? ?? false;
    } catch (error) {
      print('Error checking email availability: $error');
      return false;
    }
  }

  static Future<EmailChangeResult> requestEmailChangeCode({
    required String newEmail,
    String? language,
  }) async {
    final supabase = Supabase.instance.client;
    final auth = supabase.auth;
    final currentUser = auth.currentUser;

    if (currentUser == null) {
      throw EmailChangeException(
        code: 'not_authenticated',
        message: 'A signed-in user is required.',
      );
    }

    if (newEmail.trim().isEmpty) {
      throw EmailChangeException(
        code: 'invalid_email',
        message: 'Email address cannot be empty.',
      );
    }

    final currentEmail = currentUser.email?.trim().toLowerCase();
    if (currentEmail == newEmail.trim().toLowerCase()) {
      throw EmailChangeException(
        code: 'same_email',
        message: 'New email must be different from current email.',
      );
    }

    if (shouldSkipSupabaseCalls()) {
      throw EmailChangeException(
        code: 'offline',
        message: 'Cannot change email while offline',
      );
    }

    try {
      // Call the RPC function directly to generate the code for the new email
      final response = await supabase.rpc(
        'generate_sensitive_action_email_code',
        params: {
          'p_user_id': currentUser.id,
          'p_email': newEmail.trim().toLowerCase(),
        },
      ).timeout(_requestTimeout);

      if (response == null || (response is List && response.isEmpty)) {
        throw EmailChangeException(
          code: 'generation_failed',
          message: 'Failed to generate verification code',
        );
      }

      final data = response is List ? response[0] : response;
      final code = data['code'] as String?;
      final expiresAtStr = data['expires_at'] as String?;

      if (code == null || expiresAtStr == null) {
        throw EmailChangeException(
          code: 'generation_failed',
          message: 'Failed to generate verification code',
        );
      }

      // Send the email with the code
      try {
        await supabase.functions.invoke(
          'sensitive-action-email-code',
          body: {
            'action': 'send_code_email',
            'email': newEmail.trim().toLowerCase(),
            'code': code,
            'language': language ?? 'en',
          },
        ).timeout(_requestTimeout);
      } catch (emailError) {
        // Log but don't fail - code was generated successfully
        print('Warning: Failed to send email: $emailError');
      }

      _pendingNewEmail = newEmail.trim().toLowerCase();
      _markEmailCodeWindow();

      return EmailChangeResult(
        success: true,
        message: 'Verification code sent to new email',
        expiresAt: activeEmailCodeExpiresAt,
      );
    } catch (error) {
      if (error is EmailChangeException) {
        rethrow;
      }
      throw EmailChangeException(
        code: 'generation_error',
        message: 'Failed to send verification code: $error',
      );
    }
  }

  static Future<EmailChangeResult> verifyEmailChangeCode({
    required String code,
  }) async {
    final supabase = Supabase.instance.client;
    final auth = supabase.auth;
    final currentUser = auth.currentUser;

    if (currentUser == null) {
      throw EmailChangeException(
        code: 'not_authenticated',
        message: 'A signed-in user is required.',
      );
    }

    if (code.trim().isEmpty) {
      throw EmailChangeException(
        code: 'invalid_code',
        message: 'Verification code cannot be empty.',
      );
    }

    if (_pendingNewEmail == null) {
      throw EmailChangeException(
        code: 'no_pending_email',
        message: 'No pending email change found.',
      );
    }

    try {
      // Query the database directly to verify the code exists and is valid
      final response = await supabase
          .from('sensitive_action_email_codes')
          .select()
          .eq('user_id', currentUser.id)
          .eq('email', _pendingNewEmail!)
          .eq('code', code.trim())
          .order('created_at', ascending: false)
          .limit(1);

      if (response.isEmpty) {
        throw EmailChangeException(
          code: 'invalid_code',
          message: 'Invalid or expired verification code',
        );
      }

      final record = response.first;
      final usedAt = record['used_at'];
      
      // Check if code has already been used
      if (usedAt != null) {
        throw EmailChangeException(
          code: 'code_already_used',
          message: 'This verification code has already been used',
        );
      }

      final expiresAt = DateTime.parse(record['expires_at'] as String);

      if (DateTime.now().isAfter(expiresAt)) {
        throw EmailChangeException(
          code: 'code_expired',
          message: 'Verification code has expired',
        );
      }

      // Mark the code as used
      await supabase
          .from('sensitive_action_email_codes')
          .update({'used_at': DateTime.now().toIso8601String()})
          .eq('id', record['id'] as String);

      return EmailChangeResult(
        success: true,
        message: 'Code verified successfully',
      );
    } catch (error) {
      if (error is EmailChangeException) {
        rethrow;
      }
      throw EmailChangeException(
        code: 'verification_error',
        message: 'Failed to verify code: $error',
      );
    }
  }

  static Future<EmailChangeResult> completeEmailChange({
    required String code,
  }) async {
    final supabase = Supabase.instance.client;
    final auth = supabase.auth;
    final currentUser = auth.currentUser;

    if (currentUser == null) {
      throw EmailChangeException(
        code: 'not_authenticated',
        message: 'A signed-in user is required.',
      );
    }

    if (code.trim().isEmpty) {
      throw EmailChangeException(
        code: 'invalid_code',
        message: 'Verification code cannot be empty.',
      );
    }

    if (_pendingNewEmail == null) {
      throw EmailChangeException(
        code: 'no_pending_email',
        message: 'No pending email change found.',
      );
    }

    try {
      final oldEmail = currentUser.email;

      // Update the user's email in Supabase Auth
      await auth.updateUser(
        UserAttributes(email: _pendingNewEmail!),
      );

      // Send notification email to old email address
      try {
        await supabase.functions.invoke(
          'sensitive-action-email-code',
          body: {
            'action': 'send_email_changed_notification',
            'old_email': oldEmail,
            'new_email': _pendingNewEmail,
            'language': 'en', // Will be determined by user's app language
          },
        ).timeout(_requestTimeout);
      } catch (emailError) {
        // Log but don't fail - email change was successful
        print('Warning: Failed to send notification email: $emailError');
      }

      clearEmailCodeWindow();

      return EmailChangeResult(
        success: true,
        message: 'Email changed successfully',
      );
    } on AuthException catch (error) {
      throw EmailChangeException(
        code: error.statusCode ?? 'auth_error',
        message: error.message,
        statusCode: int.tryParse(error.statusCode ?? ''),
      );
    } catch (error) {
      if (error is EmailChangeException) {
        rethrow;
      }
      throw EmailChangeException(
        code: 'completion_error',
        message: 'Failed to complete email change: $error',
      );
    }
  }

  static void _markEmailCodeWindow() {
    final expiresAt = DateTime.now().add(const Duration(minutes: 10));
    _activeEmailCodeExpiresAt = expiresAt;
  }

  static void clearEmailCodeWindow() {
    _activeEmailCodeExpiresAt = null;
    _pendingNewEmail = null;
  }
}
