import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:matchme/services/session_service.dart';

/// Coalesces [SessionService.registerSession] during startup so bootstrap, FCM,
/// auth listener, and background service do not stack concurrent registrations.
class SessionRegistrationCoordinator {
  SessionRegistrationCoordinator._();

  static final SessionRegistrationCoordinator instance =
      SessionRegistrationCoordinator._();

  Timer? _debounceTimer;
  String? _pendingUserId;
  String? _pendingPlatform;
  String? _pendingFcmToken;
  bool _running = false;
  bool _registeredWithFcm = false;

  void schedule({
    required String userId,
    String? platform,
    String? fcmToken,
    String source = 'unknown',
  }) {
    final uid = userId.trim();
    if (uid.isEmpty) return;

    _pendingUserId = uid;
    if (platform != null && platform.trim().isNotEmpty) {
      _pendingPlatform = platform.trim();
    }
    if (fcmToken != null && fcmToken.trim().isNotEmpty) {
      _pendingFcmToken = fcmToken.trim();
    }

    // If registration is already running, don't start a new timer.
    // The running method's finally block picks up the FCM token.
    if (_running) {
      if (kDebugMode) {
        debugPrint('[BGSESSION] coordinator: FCM captured during active registration ($source)');
      }
      return;
    }

    _debounceTimer?.cancel();
    _debounceTimer = Timer(const Duration(milliseconds: 1200), () {
      unawaited(_runPending(source: source));
    });

    if (kDebugMode) {
      debugPrint('[BGSESSION] coordinator: scheduled ($source) userId=$uid');
    }
  }

  Future<void> _runPending({required String source}) async {
    final userId = _pendingUserId;
    if (userId == null || userId.isEmpty) return;
    if (_running) {
      _debounceTimer = Timer(const Duration(milliseconds: 500), () {
        unawaited(_runPending(source: source));
      });
      return;
    }

    _running = true;
    final platform = _pendingPlatform;
    final fcm = _pendingFcmToken;
    try {
      await SessionService.registerSession(
        userId,
        platform: platform,
        fcmToken: fcm,
      );
      if (fcm != null && fcm.trim().isNotEmpty) {
        _registeredWithFcm = true;
      }
    } catch (e, st) {
      if (kDebugMode) {
        debugPrint('[BGSESSION] coordinator run failed ($source): $e\n$st');
      }
    } finally {
      _running = false;
      if (fcm == null && _pendingFcmToken != null && !_registeredWithFcm) {
        if (kDebugMode) {
          debugPrint('[BGSESSION] coordinator: FCM arrived post-registration, re-running with token');
        }
        _debounceTimer?.cancel();
        _debounceTimer = Timer(const Duration(milliseconds: 200), () {
          unawaited(_runPendingWithFcm());
        });
      }
    }
  }

  Future<void> _runPendingWithFcm() async {
    final userId = _pendingUserId;
    final fcm = _pendingFcmToken;
    if (userId == null || fcm == null) return;
    _pendingFcmToken = null;
    _running = true;
    try {
      await SessionService.registerSession(
        userId,
        platform: _pendingPlatform,
        fcmToken: fcm,
        bypassCooldown: true,
      );
      _registeredWithFcm = true;
    } catch (_) {
    } finally {
      _running = false;
    }
  }
}
