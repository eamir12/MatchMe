// lib/services/global_sync_manager.dart
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/providers/chat_provider.dart';
import 'package:matchme/services/local_db_service.dart';
import 'package:matchme/services/app_config_service.dart';
import 'package:matchme/services/offline_cache_manager.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/providers/auth_provider.dart';
import 'package:matchme/providers/chat_key_provider.dart';
import 'package:matchme/services/chat_key_service.dart';
import 'package:matchme/services/user_activity_service.dart';
import 'package:matchme/utils/offline_utils.dart';

final supabase = Supabase.instance.client;

/// This service manages periodic and real-time syncing of core Home/Match data.
class GlobalHomeSyncManager {
  final Ref _ref;
  Timer? _syncTimer;
  Duration _syncInterval = const Duration(seconds: 60);

  // Heartbeat to keep user_activity fresh so online status reflects connectivity
  Timer? _heartbeatTimer;
  Duration _heartbeatInterval = const Duration(seconds: 30);

  // Prevent rapid sync restarts when connectivity bounces
  DateTime? _lastSyncAttempt;
  static const Duration _syncCooldown = Duration(seconds: 30);

  // Prevent multiple priority syncs when connectivity flaps
  DateTime? _lastPrioritySync;
  static const Duration _prioritySyncCooldown = Duration(seconds: 10);

  // Track sync in progress to prevent concurrent syncs
  bool _syncInProgress = false;

  // Track if manager is disposed to prevent operations after dispose
  bool _disposed = false;

  // Debounce timer for syncChatsNow to prevent rapid successive calls
  Timer? _syncChatsDebounceTimer;
  bool _syncChatsScheduled = false;

  // Static cooldown for syncChatsNow to prevent rapid sequential calls from different sources
  static DateTime? _lastSyncChatsCall;
  static const Duration _syncChatsCooldown = Duration(seconds: 5);

  GlobalHomeSyncManager(this._ref) {
    // Load config values asynchronously
    Future.microtask(() async {
      _syncInterval = await appConfigService.getDuration(
        'sync.global_interval_seconds',
        defaultValue: const Duration(seconds: 60)
      );
       _heartbeatInterval = await appConfigService.getDuration(
         'sync.heartbeat_interval_seconds',
         defaultValue: const Duration(seconds: 30)
       );
    });

    // IMPORTANT: Only sync when we confirm we have a healthy connection.
    // This prevents startup delays when offline. The app will use cached data
    // until Supabase is reachable again, then sync.
    bool wasBackendHealthy = false;
    
    _ref.listen<AsyncValue<ConnectivityHealth>>(connectivityHealthProvider, (previous, next) {
      final isNowHealthy = next.value?.isBackendHealthy == true;
      final isTransitioningOnline = !wasBackendHealthy && isNowHealthy;

      if (isNowHealthy) {
        offlineCacheManager.setSupabaseAvailability(true);
        if (isTransitioningOnline) {
          unawaited(
            appConfigService.refresh().catchError((error, stackTrace) {
              print(
                '⚠️ [SYNC] Failed to refresh app config after reconnect: $error',
              );
            }),
          );
        }

        // Check priority sync cooldown to prevent multiple immediate syncs when connectivity flaps
        bool shouldDoPrioritySync = isTransitioningOnline;
        if (isTransitioningOnline && _lastPrioritySync != null) {
          final timeSinceLastPrioritySync = DateTime.now().difference(_lastPrioritySync!);
          if (timeSinceLastPrioritySync < _prioritySyncCooldown) {
            print('🔄 [SYNC] Skipping priority sync - cooldown active (${timeSinceLastPrioritySync.inSeconds}s < ${_prioritySyncCooldown.inSeconds}s)');
            shouldDoPrioritySync = false;
          }
        }

        // Only start periodic sync if transitioning online or timer not already running
        // This prevents multiple syncs from being triggered when health provider emits multiple times
        final timerAlreadyRunning = _syncTimer != null && _syncTimer!.isActive;
        final authState = _ref.read(authStateProvider).asData?.value;
        final isSignedIn = authState != null && authState.session?.user.id != null;
        if (isSignedIn && (isTransitioningOnline || !timerAlreadyRunning)) {
          if (isTransitioningOnline) {
            print('✅ [SYNC] Backend is healthy (transitioning online) - starting sync and heartbeat');
          } else {
            print('✅ [SYNC] Backend is healthy - starting sync and heartbeat');
          }
          _startPeriodicSync(prioritySync: shouldDoPrioritySync);
          _startHeartbeat();
        }
        if (isTransitioningOnline && shouldDoPrioritySync) {
          print('🌐 [SYNC] Just came online - resetting cooldown for immediate sync');
          _lastSyncAttempt = null; // Clear cooldown on online transition
          _lastPrioritySync = DateTime.now(); // Record priority sync time
        }
      } else {
        print('⏸️ [SYNC] Backend is not healthy - stopping sync and heartbeat');
        _stopPeriodicSync();
        _stopHeartbeat();
        offlineCacheManager.setSupabaseAvailability(false);
      }
      wasBackendHealthy = isNowHealthy;
    }, fireImmediately: true);

    // Clean up timers if this provider is disposed
    _ref.onDispose(() {
      _stopPeriodicSync();
      _stopHeartbeat();
    });
  }

  void _startHeartbeat() {
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    // Check if timer is already running before doing immediate update
    final wasAlreadyRunning = _heartbeatTimer != null && _heartbeatTimer!.isActive;

    if (!wasAlreadyRunning) {
      unawaited(
        UserActivityService.instance.pingIfDue(
          userId,
          force: true,
          source: 'heartbeat-start',
        ),
      );
    }

    if (_heartbeatTimer != null && _heartbeatTimer!.isActive) return;

    _heartbeatTimer = Timer.periodic(_heartbeatInterval, (_) {
      final userId = supabase.auth.currentUser?.id;
      if (userId == null) return;
      unawaited(
        UserActivityService.instance.pingIfDue(
          userId,
          source: 'heartbeat-timer',
        ),
      );
    });
  }

  void _stopHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
  }

  void _startPeriodicSync({bool prioritySync = false}) {
    if (_syncTimer != null && _syncTimer!.isActive) {
      // If already syncing and this is a priority sync (online transition), trigger immediately
      // But only if a sync is not already in progress
      if (prioritySync && !_syncInProgress) {
        final userId = supabase.auth.currentUser?.id;
        if (userId != null) {
          _runFullSync(userId, checkConnectivity: true, skipCooldown: true);
        }
      }
      return;
    }

    final userId = supabase.auth.currentUser?.id;
    if (userId == null) return;

    // Run the first sync immediately (skip cooldown on priority sync when coming online)
    Future.microtask(() => _runFullSync(userId, checkConnectivity: true, skipCooldown: prioritySync));

    // Schedule the periodic sync
    _syncTimer = Timer.periodic(_syncInterval, (timer) {
      _runFullSync(userId, checkConnectivity: true);
    });
  }

  void _stopPeriodicSync() {
    _syncTimer?.cancel();
    _syncTimer = null;
    // stopped (logging removed)
  }

  Future<void> _runFullSync(String userId, {bool checkConnectivity = true, bool skipCooldown = false}) async {
    if (_disposed) return;

    // Screen off / background: native MatchMeBackgroundService keeps Realtime +
    // heartbeat. Dart REST sync hits Doze DNS limits and spams failed host lookup logs.
    if (!isAppUiInForeground()) {
      return;
    }

    // Prevent concurrent syncs
    if (_syncInProgress) {
      print('⏸️ [SYNC] Sync already in progress, skipping...');
      return;
    }
    
    // Apply cooldown between sync attempts to prevent rapid retrials
    // (unless this is a priority sync from online transition)
    if (!skipCooldown) {
      final now = DateTime.now();
      if (_lastSyncAttempt != null && now.difference(_lastSyncAttempt!).inSeconds < _syncCooldown.inSeconds) {
        print('⏸️ [SYNC] Sync attempted too recently, applying cooldown...');
        return;
      }
      _lastSyncAttempt = now;
    } else {
      print('🚀 [SYNC] Priority sync - skipping cooldown');
      _lastSyncAttempt = DateTime.now();
    }
    
    _syncInProgress = true;

    try {
      if (checkConnectivity) {
        final health = _ref.read(connectivityHealthProvider).value;
        if (health?.isBackendHealthy != true) {
          if (health?.status == ConnectivityHealthStatus.offline) {
            offlineCacheManager.setSupabaseAvailability(false);
          }
          return;
        }
      }

      // Core sync tasks - wrap with error tracking
      bool anyTaskFailed = false;
      
      final syncTasks = [
        _syncMatches(userId).catchError((e) {
          if (!isExpectedOfflineFailure(e)) {
            print('⚠️ [SYNC] Matches sync failed: $e');
          }
          if (!isExpectedOfflineFailure(e)) anyTaskFailed = true;
        }),
        syncChatsNow(userId).catchError((e) {
          if (!isExpectedOfflineFailure(e)) {
            print('⚠️ [SYNC] Chats sync failed: $e');
          }
          if (!isExpectedOfflineFailure(e)) anyTaskFailed = true;
        }),
        _syncAllChatHistories(userId).catchError((e) {
          if (!isExpectedOfflineFailure(e)) {
            print('⚠️ [SYNC] Chat histories sync failed: $e');
          }
          if (!isExpectedOfflineFailure(e)) anyTaskFailed = true;
        }),
        _syncEventMatches().catchError((e) {
          if (!isExpectedOfflineFailure(e)) {
            print('⚠️ [SYNC] Event matches sync failed: $e');
          }
          if (!isExpectedOfflineFailure(e)) anyTaskFailed = true;
        }),
        _syncUserEvents(userId).catchError((e) {
          if (!isExpectedOfflineFailure(e)) {
            print('⚠️ [SYNC] User events sync failed: $e');
          }
          if (!isExpectedOfflineFailure(e)) anyTaskFailed = true;
        }),
        _syncPendingMutations().catchError((e) {
          print('⚠️ [SYNC] Pending mutations sync failed: $e');
          // Don't mark as failed - mutations can be retried
        }),
      ];

      await Future.wait(syncTasks, eagerError: false);
      
      // If all tasks succeeded, mark Supabase as available
      if (!anyTaskFailed) {
        offlineCacheManager.setSupabaseAvailability(true);
        print('✅ [SYNC] All sync tasks completed successfully');
      } else {
        print(
          '⚠️ [SYNC] Some sync tasks failed - keeping current connectivity state',
        );
      }
    } finally {
      _syncInProgress = false;
    }
  }

  /// Sync all pending mutations to Supabase
  Future<void> _syncPendingMutations() async {
    final pendingCount = await offlineCacheManager.getPendingMutationCount();
    if (pendingCount == 0) return;

    print('🔄 [SYNC] Syncing $pendingCount pending mutations...');
    final result = await offlineCacheManager.syncPendingMutations();
    
    if (result.isSuccess) {
      print('✅ [SYNC] All ${result.successful} mutations synced successfully');
    } else {
      print(
        '⚠️ [SYNC] Mutation sync partial: ${result.successful} successful, ${result.failed} failed',
      );
      if (result.errors.isNotEmpty) {
        print('   Errors: ${result.errors.join(', ')}');
      }
    }
  }

  // --- Core Sync Logic ---

  Future<void> _syncMatches(String userId) async {
    if (shouldSkipSupabaseCalls()) {
      print('⏸️ [SYNC] _syncMatches: skipped - offline');
      return;
    }
    try {
      final localDb = _ref.read(localDbProvider);
      final defaultWindowSeconds = await appConfigService.getInt(
        'matches.chat_start_window_seconds',
        defaultValue: const Duration(hours: 24).inSeconds,
      );

      final existing = await localDb.watchMatches().first;
      final existingByMatchId = <String, Map<String, dynamic>>{
        for (final m in existing)
          (m['match_id'] ?? m['id'])?.toString() ?? '': m,
      };

      // Fetch matches with event details for event matches
      final response = await supabase
          .from('matches')
          .select('''
            id,
            user1_id,
            user2_id,
            matched_intent,
            match_type,
            created_at,
            event_id,
            events:event_id (event_name, event_link)
          ''')
          .or('user1_id.eq.$userId,user2_id.eq.$userId');

      final List<Map<String, dynamic>> matchesData = response.cast<Map<String, dynamic>>();

      // Deduplicate by match ID (each match has a unique id)
      final seenIds = <String>{};
      final uniqueMatches = <Map<String, dynamic>>[];

      for (final match in matchesData) {
        final id = match['id']?.toString() ?? '';
        if (id.isEmpty || !seenIds.add(id)) continue;
        uniqueMatches.add(match);
      }

      final List<Map<String, dynamic>> transformedMatches = uniqueMatches.map((match) {
        final eventDetails = match['events'] as Map<String, dynamic>?;
        final matchId = (match['id'] ?? match['match_id'])?.toString() ?? '';
        final existingRow = existingByMatchId[matchId];
        final dynamic existingWindowRaw = existingRow?['chat_start_window_seconds'];
        final int? existingWindowSeconds = existingWindowRaw is int
            ? existingWindowRaw
            : int.tryParse(existingWindowRaw?.toString() ?? '');
        final dynamic incomingWindowRaw = match['chat_start_window_seconds'];
        final int? incomingWindowSeconds = incomingWindowRaw is int
            ? incomingWindowRaw
            : int.tryParse(incomingWindowRaw?.toString() ?? '');
        final resolvedWindowSeconds = incomingWindowSeconds ?? existingWindowSeconds ?? defaultWindowSeconds;
        return {
          'match_id': matchId,
          'user1_id': match['user1_id'],
          'user2_id': match['user2_id'],
          'matched_intent': match['matched_intent'],
          'match_type': match['match_type'],
          'chat_start_window_seconds': resolvedWindowSeconds,
          'created_at': match['created_at'],
          'event_id': match['event_id'],
          'event_name': eventDetails?['event_name'],
          'event_link': eventDetails?['event_link'],
        };
      }).toList();

      await localDb.saveMatches(transformedMatches);
      print('✅ [CACHE] Saved ${transformedMatches.length} matches to offline cache');
    } catch (e) {
      if (!isExpectedOfflineFailure(e)) {
        print('⚠️ [SYNC] _syncMatches failed: $e');
        rethrow;
      }
    }
  }

  Future<void> syncChatsNow(String userId) async {
    if (_disposed) return;

    // Skip sync if Supabase communication is paused
    if (shouldSkipSupabaseCalls()) {
      print('⏸️ [SYNC] syncChatsNow: Skipped - Supabase communication paused');
      return;
    }

    // Static cooldown to prevent rapid sequential calls from different sources
    final now = DateTime.now();
    if (_lastSyncChatsCall != null) {
      final timeSinceLastCall = now.difference(_lastSyncChatsCall!);
      if (timeSinceLastCall < _syncChatsCooldown) {
        if (kIsWeb) {
          print('🔍 [WEB] syncChatsNow: Skipping - cooldown active (${timeSinceLastCall.inSeconds}s < ${_syncChatsCooldown.inSeconds}s)');
        }
        return;
      }
    }

    // If a sync is already scheduled or in progress, return early
    if (_syncChatsScheduled) {
      return;
    }

    // Mark as scheduled and update timestamp
    _syncChatsScheduled = true;
    _lastSyncChatsCall = now;

    // Cancel existing debounce timer
    _syncChatsDebounceTimer?.cancel();

    // Create a completer to make this awaitable
    final completer = Completer<void>();

    _syncChatsDebounceTimer = Timer(const Duration(milliseconds: 500), () async {
      if (_disposed) {
        _syncChatsScheduled = false;
        completer.complete();
        return;
      }
      if (kIsWeb) {
        print('🔍 [WEB] syncChatsNow: Starting sync for user: $userId');
      }
      try {
        final localDb = _ref.read(localDbProvider);

        // Use simplified RPC function for better performance
        try {
          final recent = await supabase.rpc('get_user_recent_chats', params: {'p_user_id': userId, 'p_limit': 5});

          if (kIsWeb) {
            print('🔍 [WEB] syncChatsNow: Server returned ${recent.length} chats');
            for (final row in recent) {
              if (row is Map<String, dynamic>) {
                print('🔍 [WEB] syncChatsNow: Server chat ${row['match_id']}: unread_count=${row['unread_count']}');
              }
            }
          }

          if (recent is List) {
            final List<Map<String, dynamic>> transformed = [];

            for (final row in recent) {
              if (row is Map<String, dynamic>) {
                // Simple transformation - data comes pre-enriched from RPC
                transformed.add({
                  'match_id': row['match_id'],
                  'other_user_id': row['other_user_id'],
                  'other_user_name': row['other_name'] ?? 'Unknown User',
                  'other_user_photos': row['other_photos'] ?? [],
                  'last_message': row['last_message_preview'] ?? '',
                  'last_message_at': row['last_message_at'],
                  'unread_count': row['unread_count'] ?? 0,
                  'updated_at': row['updated_at'],
                  'translation_enabled': row['translation_enabled'] ?? false,
                  'translation_language': row['translation_language'],
                  'last_message_id': row['last_message_id'],
                  'last_message_sender_id': row['last_message_sender_id'],
                  'last_message_translated': row['last_message_translated'],
                  'last_message_source_language': row['detected_source_language'],
                  'last_message_encryption_scheme': row['encryption_scheme'],
                });
              }
            }

            // Decrypt v1 last message previews
            final chatKeyState = _ref.read(chatKeyProvider);
            if (chatKeyState.privateKeyBytes != null) {
              final chatKeyService = ChatKeyService.instance;
              for (int i = 0; i < transformed.length; i++) {
                final chat = transformed[i];
                final lastMessageId = chat['last_message_id'] as String?;
                // Only try decryption if we have a message ID and no readable content
                if (lastMessageId != null && lastMessageId.isNotEmpty) {
                  try {
                    final msgData = await supabase
                        .from('chat_messages')
                        .select('id, encryption_scheme, sender_key_id, recipient_key_id, content_original_encrypted, content_original_nonce, content_translated_encrypted, content_translated_nonce, wrapped_keys, sender_id, match_id, recipient_id, detected_source_language, translated_target_language, content_translated')
                        .eq('id', lastMessageId)
                        .maybeSingle();
                    if (msgData != null) {
                      transformed[i]['last_message_encryption_scheme'] = msgData['encryption_scheme'] as String?;
                      if (msgData['encryption_scheme'] == 'v1') {
                      final wrappedKeys = msgData['wrapped_keys'];
                      if (wrappedKeys is Map) {
                        // Decrypt original content
                        final decryptedOriginal = await chatKeyService.decryptMessageContent(
                          currentUserId: userId,
                          currentUserPrivateKey: chatKeyState.privateKeyBytes!,
                          messageId: msgData['id'] as String,
                          matchId: msgData['match_id'] as String,
                          senderId: msgData['sender_id'] as String,
                          senderKeyId: msgData['sender_key_id'] as String,
                          recipientKeyId: msgData['recipient_key_id'] as String,
                          contentOriginalEncryptedBase64: msgData['content_original_encrypted'] as String,
                          contentOriginalNonceBase64: msgData['content_original_nonce'] as String,
                          wrappedKeys: Map<String, dynamic>.from(wrappedKeys),
                          recipientId: msgData['recipient_id'] as String?,
                        );
                        if (decryptedOriginal != null) {
                          transformed[i]['last_message'] = decryptedOriginal;
                        }
                        
                        // Decrypt translated content
                        final translatedEncrypted = msgData['content_translated_encrypted'] as String?;
                        final translatedNonce = msgData['content_translated_nonce'] as String?;
                        final detectedSourceLang = msgData['detected_source_language'] as String?;
                        final targetLang = msgData['translated_target_language'] as String?;
                        if (translatedEncrypted != null && translatedNonce != null) {
                          final decryptedTranslated = await chatKeyService.decryptMessageTranslatedContent(
                            currentUserId: userId,
                            currentUserPrivateKey: chatKeyState.privateKeyBytes!,
                            messageId: msgData['id'] as String,
                            matchId: msgData['match_id'] as String,
                            senderId: msgData['sender_id'] as String,
                            senderKeyId: msgData['sender_key_id'] as String,
                            recipientKeyId: msgData['recipient_key_id'] as String,
                            contentTranslatedEncryptedBase64: translatedEncrypted,
                            contentTranslatedNonceBase64: translatedNonce,
                            wrappedKeys: Map<String, dynamic>.from(wrappedKeys),
                            detectedSourceLanguage: detectedSourceLang ?? 'und',
                            targetLanguage: targetLang ?? '',
                            recipientId: msgData['recipient_id'] as String?,
                          );
                          if (decryptedTranslated != null) {
                            transformed[i]['last_message_translated'] = decryptedTranslated;
                          }
                        }
                      }
                    }
                  }
                } catch (e) {
                    // Failed to decrypt preview - leave blank
                  }
                }
              }
            }

            if (kIsWeb) {
              print('🔍 [WEB] syncChatsNow: About to save ${transformed.length} chats to local DB');
              for (final chat in transformed) {
                print('🔍 [WEB] syncChatsNow: Saving chat ${chat['match_id']}: unread_count=${chat['unread_count']}');
              }
            }
            await localDb.saveChats(userId, transformed);
            if (kIsWeb) {
              print('🔍 [WEB] syncChatsNow: Completed saving chats to local DB');
            }

            // Sync translation settings from server for each chat to ensure they match database state
            for (final row in recent) {
              if (row is Map<String, dynamic>) {
                final matchId = row['match_id'];
                final translationEnabled = row['translation_enabled'] ?? false;
                final translationLanguage = row['translation_language'];

                if (matchId != null) {
                  await localDb.syncChatTranslationSettings(userId, matchId, translationEnabled, translationLanguage);
                }
              }
            }

            // Update translation provider state to match server - ensures UI reflects actual server state
            try {
              final translationNotifier = _ref.read(translationProvider.notifier);
              for (final row in recent) {
                if (row is Map<String, dynamic>) {
                  final matchId = row['match_id'] as String?;
                  final translationEnabled = row['translation_enabled'] == true;
                  final translationLanguage = row['translation_language'] as String?;

                  if (matchId != null) {
                    // Update provider state: if translation enabled, set language; otherwise remove
                    if (translationEnabled && translationLanguage != null) {
                      final currentState = _ref.read(translationProvider);
                      if (currentState[matchId] != translationLanguage) {
                        translationNotifier.setTranslationSilent(matchId, translationLanguage);
                      }
                    } else {
                      // Translation is disabled, remove from provider state
                      final currentState = _ref.read(translationProvider);
                      if (currentState.containsKey(matchId)) {
                        translationNotifier.clearTranslationSilent(matchId);
                      }
                    }
                  }
                }
              }
            } catch (e) {
              // Ignore provider update errors - they're best-effort
              print('⚠️ Failed to update translation provider: $e');
            }
          }
        } catch (e) {
          if (!isExpectedOfflineFailure(e)) {
            print('❌ syncChatsNow failed: $e');
          }
          // No complex fallback - keep it simple
        }
      } catch (e) {
        if (!isExpectedOfflineFailure(e)) {
          print('❌ syncChatsNow error: $e');
        }
      } finally {
        _syncChatsScheduled = false;
        completer.complete();
      }
    });

    return completer.future;
  }

  Future<void> syncMatchesNow(String userId) async {
    if (_disposed) return;

    // Skip sync if Supabase communication is paused
    if (shouldSkipSupabaseCalls()) {
      print('⏸️ [SYNC] syncMatchesNow: Skipped - Supabase communication paused');
      return;
    }

    try {
      final localDb = _ref.read(localDbProvider);
      final defaultWindowSeconds = await appConfigService.getInt(
        'matches.chat_start_window_seconds',
        defaultValue: const Duration(hours: 24).inSeconds,
      );
      final existing = await localDb.watchMatches().first;
      final existingByMatchId = <String, Map<String, dynamic>>{
        for (final m in existing)
          (m['match_id'] ?? m['id'])?.toString() ?? '': m,
      };

      // Use simplified RPC function for better performance
      try {
        final recent = await supabase.rpc('get_user_recent_matches', params: {'p_user_id': userId, 'p_limit': 5});

        if (recent is List) {
          final rows = recent.whereType<Map<String, dynamic>>().toList();

          final hasFullShape =
              rows.isNotEmpty &&
              rows.first.containsKey('user1_id') &&
              rows.first.containsKey('user2_id') &&
              rows.first.containsKey('matched_intent') &&
              rows.first.containsKey('match_type') &&
              rows.first.containsKey('created_at');

          if (hasFullShape) {
            final normalized = rows.map((r) {
              final copy = Map<String, dynamic>.from(r);
              final matchId = (copy['match_id'] ?? copy['id'])?.toString() ?? '';
              final dynamic incomingWindowRaw = copy['chat_start_window_seconds'];
              final int? incomingWindowSeconds = incomingWindowRaw is int
                  ? incomingWindowRaw
                  : int.tryParse(incomingWindowRaw?.toString() ?? '');
              final dynamic existingWindowRaw =
                  existingByMatchId[matchId]?['chat_start_window_seconds'];
              final int? existingWindowSeconds = existingWindowRaw is int
                  ? existingWindowRaw
                  : int.tryParse(existingWindowRaw?.toString() ?? '');
              final resolvedWindowSeconds =
                  incomingWindowSeconds ?? existingWindowSeconds ?? defaultWindowSeconds;
              copy['chat_start_window_seconds'] = resolvedWindowSeconds;
              return copy;
            }).toList();
            await localDb.saveMatches(normalized);
            return;
          }

          final matchIds =
              rows
                  .map((r) => (r['match_id'] ?? r['id'])?.toString() ?? '')
                  .where((id) => id.isNotEmpty)
                  .toList();

          if (matchIds.isEmpty) {
            await _syncMatches(userId);
            return;
          }

          final matchesResponse = await supabase
              .from('matches')
              .select('''
                id,
                user1_id,
                user2_id,
                matched_intent,
                match_type,
                created_at,
                event_id,
                events:event_id (event_name, event_link)
              ''')
              .inFilter('id', matchIds);

          final fetched = matchesResponse.cast<Map<String, dynamic>>();
          final byId = <String, Map<String, dynamic>>{
            for (final m in fetched) (m['id']?.toString() ?? ''): m,
          };

          final transformedMatches = <Map<String, dynamic>>[];
          for (final id in matchIds) {
            final m = byId[id];
            if (m == null) continue;
            final eventDetails = m['events'] as Map<String, dynamic>?;
            final dynamic existingWindowRaw = existingByMatchId[id]?['chat_start_window_seconds'];
            final int? existingWindowSeconds = existingWindowRaw is int
                ? existingWindowRaw
                : int.tryParse(existingWindowRaw?.toString() ?? '');
            final resolvedWindowSeconds = existingWindowSeconds ?? defaultWindowSeconds;

            transformedMatches.add({
              'match_id': m['id'],
              'user1_id': m['user1_id'],
              'user2_id': m['user2_id'],
              'matched_intent': m['matched_intent'],
              'match_type': m['match_type'],
              'chat_start_window_seconds': resolvedWindowSeconds,
              'created_at': m['created_at'],
              'event_id': m['event_id'],
              'event_name': eventDetails?['event_name'],
              'event_link': eventDetails?['event_link'],
            });
          }

          if (transformedMatches.isNotEmpty) {
            await localDb.saveMatches(transformedMatches);
            return;
          }

          await _syncMatches(userId);
        }
      } catch (e) {
        if (!isExpectedOfflineFailure(e)) {
          print('syncMatchesNow: get_user_recent_matches RPC failed: $e');
        }
        // Fallback to original method
        await _syncMatches(userId);
      }
    } catch (e) {
      if (!isExpectedOfflineFailure(e)) {
        print('syncMatchesNow error: $e');
      }
    }
  }

  // ---
  // --- UPDATED: This function now performs an incremental sync for messages
  // ---
  Future<void> _syncAllChatHistories(String userId) async {
    if (shouldSkipSupabaseCalls()) {
      print('⏸️ [SYNC] _syncAllChatHistories: Skipped - Supabase communication paused');
      return;
    }
    
    try {
      final localDb = _ref.read(localDbProvider);

      // 1. Get all match IDs the user is currently in
      final matchesResponse = await supabase
          .from('matches')
          .select('id')
          .or('user1_id.eq.$userId,user2_id.eq.$userId');

      final allMatchIds = (matchesResponse as List)
          .map((e) => e['id'] as String)
          .where((id) => id.isNotEmpty)
          .toList();

      if (allMatchIds.isEmpty) return;

      // 2. Create a separate sync task for each match
      final syncTasks = allMatchIds.map((matchId) async {
        try {
          // 3. Get the timestamp of the last message we have
          final latestTimestamp = await localDb.getLatestMessageTimestamp(matchId);

          // 4. Build the query
          var query = supabase.from('chat_messages').select('id, match_id, sender_id, content_original, content_translated, encryption_scheme, sender_key_id, recipient_key_id, content_original_encrypted, content_original_nonce, content_translated_encrypted, content_translated_nonce, wrapped_keys, translation_capable, detected_source_language, translated_target_language, created_at, edited_at, delivered_at, read_at, reply_to_message_id, recipient_id').eq('match_id', matchId);

          // 5. If we have a timestamp, only ask for messages *after* it
          if (latestTimestamp != null) {
            query = query.gt('created_at', latestTimestamp);
          }

          final newMessages = await query;

          // 6. Add the new messages to the local cache and get messages to deliver
          if (newMessages.isNotEmpty) {
            final messagesToDeliver = await localDb.addMessages(
              matchId,
              newMessages.cast<Map<String, dynamic>>(),
              currentUserId: userId,
            );
            
            // 7. Mark messages as delivered to server (non-blocking, batch RPC calls)
            if (messagesToDeliver.isNotEmpty) {
              print('🔄 GLOBAL_SYNC: Marking ${messagesToDeliver.length} messages as delivered for match $matchId');
              unawaited(
                Future.wait(
                  messagesToDeliver.map((msgId) =>
                    supabase.rpc('mark_message_delivered', params: {'p_message_id': msgId})
                      .then((_) {
                        print('✅ GLOBAL_SYNC: Message $msgId marked as delivered');
                      })
                      .catchError((e) {
                        print('❌ GLOBAL_SYNC: Failed to mark $msgId as delivered: $e');
                      })
                  ),
                  eagerError: false,
                )
              );
            }
          }
        } catch (_) {
          // suppressed error logging per-match to avoid noisy logs
        }
      }).toList();

      // 7. Run all sync tasks in parallel
      await Future.wait(syncTasks);
    } catch (_) {
      // suppressed error logging
    }
  }

  // --- User events sync
  // ---
  Future<void> _syncUserEvents(String userId) async {
    try {
      final localDb = _ref.read(localDbProvider);

      // Query events the current user is attending
      final response = await supabase
          .from('event_attendees')
          .select('''
            notes,
            events!inner(
              id,
              event_name,
              event_venue,
              start_time,
              end_time,
              event_link
            )
          ''')
          .eq('user_id', userId)
          .order('events(start_time)', ascending: true);

      // Transform the response to include attendee count
      final List<Map<String, dynamic>> eventsData = [];

      for (final row in response as List) {
        final eventData = row['events'] as Map<String, dynamic>;

        // Get attendee count for this event
        final countResponse = await supabase.rpc(
          'count_event_attendees',
          params: {'event_id_param': eventData['id']}
        );

        final attendeeCount = (countResponse as int?) ?? 1;

        final fullEventData = {
          ...eventData,
          'notes': row['notes'],
          'attendee_count': attendeeCount,
        };

        eventsData.add(fullEventData);
      }

      // Cache the events data
      await localDb.saveUserEvents(userId, eventsData);
    } catch (_) {
      // Silently fail - events sync is not critical
    }
  }

  // --- Periodic event matching sync
  // ---
  Future<void> _syncEventMatches() async {
    try {
      // Get all current events
      final eventsResponse = await supabase
          .from('events')
          .select('id')
          .gte('start_time', DateTime.now().toIso8601String()); // Only future/current events

      final events = eventsResponse as List<dynamic>;

      for (final event in events) {
        final eventId = event['id'] as String;

        // Call backend RPC to perform matching for this event
        await supabase.rpc('perform_event_matching', params: {'p_event_id': eventId});
      }
    } catch (e) {
      // suppressed error logging
    }
  }
  // --- End Core Sync Logic ---

  void restartSyncForUser(String userId) {
    // Stop current sync
    _stopPeriodicSync();
    
    // Reset sync state to ensure new user's data is fetched immediately
    // Prevents stale _syncInProgress from blocking a fresh sync when user changes
    _syncInProgress = false;
    _lastSyncAttempt = null;
    
    // Start new sync for the new user
    _runFullSync(userId, checkConnectivity: false);
    
    // Restart periodic sync if online
    final isOnline = _ref.read(connectivityProvider).value ?? false;
    if (isOnline) {
      _startPeriodicSync();
    }
  }

  void dispose() {
    _disposed = true;
    _syncTimer?.cancel();
    _syncTimer = null;
    _heartbeatTimer?.cancel();
    _heartbeatTimer = null;
    _syncChatsDebounceTimer?.cancel();
    _syncChatsDebounceTimer = null;
  }
}

// Provider to manage the lifecycle of the Global Sync Manager
final globalSyncManagerProvider = Provider<GlobalHomeSyncManager>((ref) {
  final manager = GlobalHomeSyncManager(ref);
  
  // Listen to auth state changes and restart sync when user changes
  ref.listen<AsyncValue<AuthState>>(authStateProvider, (previous, next) {
    final currentUser = next.value?.session?.user;
    if (currentUser != null) {
      // User logged in or changed, restart sync
      manager.restartSyncForUser(currentUser.id);
    } else {
      // User logged out, stop all sync activity
      manager.dispose();
    }
  });
  
  ref.onDispose(() => manager.dispose());
  return manager;
});
