import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:matchme/config/security_constants.dart';
import 'package:matchme/services/crypto_service.dart';

class EncryptedCacheService {
  EncryptedCacheService._();
  static final EncryptedCacheService instance = EncryptedCacheService._();

  static const _secureStorage = FlutterSecureStorage();
  static const _dckPrefix = 'chat_cache_key:';

  final CryptoService _crypto = CryptoService.instance;
  String? _currentUserId;
  Uint8List? _currentDck;
  bool _initialized = false;

  Future<void> initialize(String userId) async {
    if (_initialized && _currentUserId == userId && _currentDck != null) {
      return;
    }
    _currentUserId = userId;
    _currentDck = await _loadDck(userId);
    if (_currentDck == null) {
      _currentDck =
          await _crypto.generateRandomBytes(SecurityConstants.messageKeyLength);
      await _storeDck(userId, _currentDck!);
    }
    _initialized = true;
  }

  Future<void> resetForUser(String userId) async {
    _currentUserId = userId;
    await _secureStorage.delete(key: '$_dckPrefix$userId');
    _currentDck =
        await _crypto.generateRandomBytes(SecurityConstants.messageKeyLength);
    await _storeDck(userId, _currentDck!);
  }

  Future<Uint8List?> _loadDck(String userId) async {
    final encoded = await _secureStorage.read(key: '$_dckPrefix$userId');
    if (encoded == null || encoded.isEmpty) return null;
    return base64Decode(encoded);
  }

  Future<void> _storeDck(String userId, Uint8List dck) async {
    await _secureStorage.write(
        key: '$_dckPrefix$userId', value: base64Encode(dck));
  }

  Uint8List? get currentDck => _currentDck;

  Future<String> encryptForCache(String plaintext) async {
    if (_currentDck == null) return plaintext;
    final nonce = _crypto.generateNonce();
    final aad = Uint8List.fromList(utf8.encode('matchme-chat-cache-v1'));
    final ciphertext = await _crypto.aesGcmEncrypt(
      plaintext: Uint8List.fromList(utf8.encode(plaintext)),
      key: _currentDck!,
      nonce: nonce,
      aad: aad,
    );
    final combined = Uint8List(nonce.length + ciphertext.length)
      ..setRange(0, nonce.length, nonce)
      ..setRange(nonce.length, nonce.length + ciphertext.length, ciphertext);
    return base64Encode(combined);
  }

  Future<String> decryptFromCache(String encrypted) async {
    if (_currentDck == null) return encrypted;
    try {
      final combined = base64Decode(encrypted);
      if (combined.length < 12) return encrypted;
      final nonce = combined.sublist(0, 12);
      final ciphertext = combined.sublist(12);
      final aad = Uint8List.fromList(utf8.encode('matchme-chat-cache-v1'));
      final plaintext = await _crypto.aesGcmDecrypt(
        ciphertext: ciphertext,
        key: _currentDck!,
        nonce: nonce,
        aad: aad,
      );
      return utf8.decode(plaintext);
    } catch (_) {
      return encrypted;
    }
  }

  Future<Map<String, dynamic>?> encryptMessageJson(
      Map<String, dynamic> messageJson) async {
    if (_currentDck == null) return messageJson;
    try {
      final jsonStr = jsonEncode(messageJson);
      final encrypted = await encryptForCache(jsonStr);
      return {
        'encrypted_content': encrypted,
        'is_encrypted': true,
      };
    } catch (_) {
      return messageJson;
    }
  }

  Future<Map<String, dynamic>?> decryptMessageJson(
      Map<String, dynamic> cached) async {
    if (cached['is_encrypted'] == true &&
        cached['encrypted_content'] != null) {
      try {
        final decrypted =
            await decryptFromCache(cached['encrypted_content'] as String);
        return jsonDecode(decrypted) as Map<String, dynamic>;
      } catch (_) {
        return null;
      }
    }
    return cached;
  }
}
