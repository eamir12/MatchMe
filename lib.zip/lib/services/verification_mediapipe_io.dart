// Mobile/desktop: MediaPipe gesture capture via WebView (same flow as web).
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';

/// Opens the MediaPipe gesture capture page in a full-screen WebView. When the user
/// captures a photo, [onPhoto] is called with the JPEG bytes. [context] is required
/// to push the WebView route.
void openMediaPipeVerificationCapture({
  required String gestureCode,
  required void Function(Uint8List?) onPhoto,
  String? gestureLabel,
  String? gestureDescription,
  String? localeCode,
  Map<String, String>? captureStrings,
  Uint8List? inputImageBytes,
  BuildContext? context,
}) {
  final ctx = context;
  if (ctx == null || !ctx.mounted) {
    onPhoto(null);
    return;
  }

  Navigator.of(ctx).push<void>(
    MaterialPageRoute<void>(
      builder: (context) => _MediaPipeCapturePage(
        gestureCode: gestureCode,
        gestureLabel: gestureLabel,
        gestureDescription: gestureDescription,
        localeCode: localeCode,
        captureStrings: captureStrings,
        inputImageBytes: inputImageBytes,
        onPhoto: onPhoto,
      ),
    ),
  ).then((_) {
    // If route was popped without sending a photo, ensure we don't leave callback dangling
    // (onPhoto is only called when we receive base64 from the WebView)
  });
}

class _MediaPipeCapturePage extends ConsumerStatefulWidget {
  const _MediaPipeCapturePage({
    required this.gestureCode,
    required this.gestureLabel,
    required this.gestureDescription,
    required this.localeCode,
    required this.captureStrings,
    required this.inputImageBytes,
    required this.onPhoto,
  });

  final String gestureCode;
  final String? gestureLabel;
  final String? gestureDescription;
  final String? localeCode;
  final Map<String, String>? captureStrings;
  final Uint8List? inputImageBytes;
  final void Function(Uint8List?) onPhoto;

  @override
  ConsumerState<_MediaPipeCapturePage> createState() => _MediaPipeCapturePageState();
}

class _MediaPipeCapturePageState extends ConsumerState<_MediaPipeCapturePage> {
  bool _sent = false;
  WebViewController? _controller;
  String? _loadError;
  bool _cameraPermissionDenied = false;

   void _onPhotoReceived(Uint8List? bytes) {
     if (_sent) return;
     _sent = true;
     
     // Fix for PigeonProxyApiRegistrar memory leak: dispose controller before popping
     _controller = null;
     
     WidgetsBinding.instance.addPostFrameCallback((_) {
       if (mounted) {
         Navigator.of(context).pop();
       }
       widget.onPhoto(bytes);
     });
   }

  Future<void> _handleWebViewPermissionRequest(
    WebViewPermissionRequest request,
  ) async {
    // Android WebView denies camera access unless the host app responds to the
    // embedded page's permission request.
    final needsCamera = request.types.contains(
      WebViewPermissionResourceType.camera,
    );
    final needsMicrophone = request.types.contains(
      WebViewPermissionResourceType.microphone,
    );

    var cameraGranted = !needsCamera;
    if (needsCamera) {
      var cameraStatus = await Permission.camera.status;
      if (!cameraStatus.isGranted) {
        cameraStatus = await Permission.camera.request();
      }
      cameraGranted = cameraStatus.isGranted;
    }

    var microphoneGranted = !needsMicrophone;
    if (needsMicrophone) {
      var microphoneStatus = await Permission.microphone.status;
      if (!microphoneStatus.isGranted) {
        microphoneStatus = await Permission.microphone.request();
      }
      microphoneGranted = microphoneStatus.isGranted;
    }

    if (cameraGranted && microphoneGranted) {
      print(
        'Granting WebView permission request: ${request.types.map((type) => type.name).join(', ')}',
      );
      await request.grant();
      return;
    }

    await request.deny();
    if (!mounted) return;

    final l10n = ref.read(localizationProvider);
    setState(() {
      _cameraPermissionDenied = needsCamera && !cameraGranted;
      _loadError = l10n.getString('verificationCaptureCameraPermissionDenied');
    });
  }

  Future<void> _initController() async {
    // Skip native camera permission check on iOS - let WebView handle its own camera permission
    // On iOS, the WebView has its own permission system and will prompt for camera access
    // The native permission check can fail incorrectly due to permission_handler limitations
    if (Platform.isIOS) {
      print('iOS detected - letting WebView handle camera permission');
    } else {
      // For Android, check native camera permission first
      var cameraStatus = await Permission.camera.status;
      print('Camera permission status: $cameraStatus');
      print('Camera status isGranted: ${cameraStatus.isGranted}');
      print('Camera status isDenied: ${cameraStatus.isDenied}');
      print('Camera status isPermanentlyDenied: ${cameraStatus.isPermanentlyDenied}');
      print('Camera status isRestricted: ${cameraStatus.isRestricted}');
      print('Camera status isLimited: ${cameraStatus.isLimited}');
      
      if (!cameraStatus.isGranted) {
        if (cameraStatus.isPermanentlyDenied || cameraStatus.isRestricted) {
          print('Camera permission permanently denied/restricted - showing settings');
        } else {
          print('Requesting camera permission...');
          cameraStatus = await Permission.camera.request();
          print('After request, camera status: $cameraStatus');
        }
      }
      if (!cameraStatus.isGranted) {
        final l10n = ref.read(localizationProvider);
        if (mounted) {
          setState(
            () {
              _cameraPermissionDenied = true;
              _loadError = l10n.getString('verificationCaptureCameraPermissionDenied');
            },
          );
        }
        print('Camera permission denied, showing error UI');
        return;
      }
    }
    
    print('Loading WebView...');
    
    try {
      final html = await rootBundle.loadString('assets/verification_capture/index.html');
      print('Loaded HTML successfully, length: ${html.length}');
      
      final htmlWithParams = html
          .replaceFirst('__GESTURE_CODE_JSON__', jsonEncode(widget.gestureCode))
          .replaceFirst('__GESTURE_LABEL_JSON__', jsonEncode(widget.gestureLabel ?? ''))
          .replaceFirst('__GESTURE_DESCRIPTION_JSON__', jsonEncode(widget.gestureDescription ?? ''))
          .replaceFirst('__LOCALE_CODE_JSON__', jsonEncode(widget.localeCode ?? 'en'))
          .replaceFirst(
            '__CAPTURE_STRINGS_JSON__',
            jsonEncode(widget.captureStrings ?? <String, String>{}),
          )
          .replaceFirst(
            '__INPUT_IMAGE_BASE64_JSON__',
            jsonEncode(
              widget.inputImageBytes == null ? '' : base64Encode(widget.inputImageBytes!),
            ),
          );
      print('HTML with params prepared');
      
      if (!mounted) return;
      
      PlatformWebViewControllerCreationParams params =
          const PlatformWebViewControllerCreationParams();
      if (WebViewPlatform.instance is WebKitWebViewPlatform) {
        params = WebKitWebViewControllerCreationParams.fromPlatformWebViewControllerCreationParams(
          params,
          allowsInlineMediaPlayback: true,
          mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
        );
       } else if (WebViewPlatform.instance is AndroidWebViewPlatform) {
         params = AndroidWebViewControllerCreationParams.fromPlatformWebViewControllerCreationParams(
           params,
         );
       }
      
      print('Creating WebView controller with platform: ${WebViewPlatform.instance}');
      
       final c = WebViewController.fromPlatformCreationParams(
         params,
         onPermissionRequest: (WebViewPermissionRequest request) {
           unawaited(_handleWebViewPermissionRequest(request));
         },
       );
       
       c
         ..setJavaScriptMode(JavaScriptMode.unrestricted)
         ..setBackgroundColor(Colors.black)

         ..addJavaScriptChannel(
           'PhotoCapture',
           onMessageReceived: (JavaScriptMessage message) {
             try {
               final bytes = Uint8List.fromList(base64Decode(message.message));
               print('Received photo from WebView, length: ${bytes.length}');
               _onPhotoReceived(bytes);
             } catch (e) {
               print('Error decoding photo from WebView: $e');
               _onPhotoReceived(null);
             }
           },
         )
         ..setNavigationDelegate(
           NavigationDelegate(
             onPageStarted: (String url) {
               print('WebView page started: $url');
             },
             onPageFinished: (String url) async {
               print('WebView page finished: $url');
               // Fix for Android WebView camera permission race condition
               await Future<void>.delayed(const Duration(milliseconds: 1000));
             },
             onWebResourceError: (WebResourceError error) {
               print('WebView resource error: $error');
             },
             onNavigationRequest: (NavigationRequest request) {
               if (request.url.startsWith('https://cdn.jsdelivr.net') ||
                   request.url.startsWith('https://unpkg.com')) {
                 return NavigationDecision.navigate;
               }
               print('Blocking navigation to: ${request.url}');
               return NavigationDecision.prevent;
             },
           ),
         )
         ..loadHtmlString(
           htmlWithParams,
           baseUrl: 'https://cdn.jsdelivr.net/',
         );
      
      print('WebView controller created');
      
      if (!mounted) return;
      setState(() {
        _controller = c;
      });
      print('WebView controller set in state');
    } catch (e) {
      print('Error initializing WebView controller: $e');
      if (mounted) {
        setState(() => _loadError = e.toString());
      }
    }
  }

   @override
   void initState() {
     super.initState();
     WidgetsBinding.instance.addPostFrameCallback((_) async {
       // Critical fix for Android WebView race condition: wait for platform view to be fully attached
       await Future<void>.delayed(const Duration(milliseconds: 500));
       if (!mounted) return;
       _initController().catchError((e) {
         if (mounted) setState(() => _loadError = e.toString());
       });
     });
   }

  @override
  Widget build(BuildContext context) {
    if (_loadError != null) {
      final l10n = ref.watch(localizationProvider);
      return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(title: Text(l10n.getString('verification'))),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              l10n
                  .getString('verificationCaptureWrapperFailedToLoad')
                  .replaceAll('{error}', _loadError ?? ''),
            ),
          ),
        ),
        bottomNavigationBar: _cameraPermissionDenied
            ? SafeArea(
                minimum: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                child: FilledButton(
                  onPressed: () async {
                    await openAppSettings();
                  },
                  child: Text(l10n.getString('permActionOpenSettings')),
                ),
              )
            : null,
      );
    }
    if (_controller == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(child: CircularProgressIndicator()),
      );
    }
    return Scaffold(body: WebViewWidget(controller: _controller!));
  }
}
