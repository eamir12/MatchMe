import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:matchme/config/security_constants.dart';
import 'package:matchme/models/user_chat_key_model.dart';
import 'package:matchme/services/crypto_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatKeyService {
  ChatKeyService._();
  static final ChatKeyService instance = ChatKeyService._();

  static const _secureStorage = FlutterSecureStorage();
  static const _privateKeyPrefix = 'chat_private_key:';
  static const _crkPrefix = 'chat_crk:';
  static const _recoveryConfirmedPrefix = 'chat_recovery_confirmed:';

  final CryptoService _crypto = CryptoService.instance;
  final Map<String, UserChatKeyModel?> _peerKeyCache = {};

  Future<bool> hasPrivateKeyLocally(String userId) async {
    final key = await _secureStorage.read(key: '$_privateKeyPrefix$userId');
    return key != null && key.isNotEmpty;
  }

  Future<Uint8List?> loadPrivateKeyBytes(String userId) async {
    final encoded = await _secureStorage.read(key: '$_privateKeyPrefix$userId');
    if (encoded == null || encoded.isEmpty) return null;
    return base64Decode(encoded);
  }

  Future<void> storePrivateKeyBytes(
      String userId, Uint8List privateKey) async {
    final encoded = base64Encode(privateKey);
    await _secureStorage.write(
        key: '$_privateKeyPrefix$userId', value: encoded);
  }

  Future<Uint8List?> loadCrkBytes(String userId) async {
    final encoded = await _secureStorage.read(key: '$_crkPrefix$userId');
    if (encoded == null || encoded.isEmpty) return null;
    return base64Decode(encoded);
  }

  Future<void> storeCrkBytes(String userId, Uint8List crkBytes) async {
    final encoded = base64Encode(crkBytes);
    await _secureStorage.write(key: '$_crkPrefix$userId', value: encoded);
  }

  Future<bool> isRecoveryConfirmed(String userId) async {
    final val =
        await _secureStorage.read(key: '$_recoveryConfirmedPrefix$userId');
    return val == 'true';
  }

  Future<void> setRecoveryConfirmed(String userId, bool confirmed) async {
    await _secureStorage.write(
        key: '$_recoveryConfirmedPrefix$userId', value: confirmed ? 'true' : 'false');
  }

  Future<UserChatKeyModel?> fetchActiveKey(String userId) async {
    final supabase = Supabase.instance.client;
    final data = await supabase
        .from('user_chat_keys')
        .select()
        .eq('user_id', userId)
        .eq('status', 'active')
        .maybeSingle();
    if (data == null) return null;
    return UserChatKeyModel.fromJson(data);
  }

  Future<UserChatKeyModel?> fetchKeyById(String keyId) async {
    final supabase = Supabase.instance.client;
    final data = await supabase
        .from('user_chat_keys')
        .select()
        .eq('id', keyId)
        .maybeSingle();
    if (data == null) return null;
    return UserChatKeyModel.fromJson(data);
  }

  Future<List<UserChatKeyWrapperModel>> fetchWrappers(
      String userChatKeyId) async {
    final supabase = Supabase.instance.client;
    final data = await supabase
        .from('user_chat_key_wrappers')
        .select()
        .eq('user_chat_key_id', userChatKeyId);
    return data
        .map((e) => UserChatKeyWrapperModel.fromJson(e))
        .toList();
  }

  Future<UserChatKeyWrapperModel?> fetchWrapperByType(
      String userChatKeyId, String wrapperType) async {
    final supabase = Supabase.instance.client;
    final data = await supabase
        .from('user_chat_key_wrappers')
        .select()
        .eq('user_chat_key_id', userChatKeyId)
        .eq('wrapper_type', wrapperType)
        .maybeSingle();
    if (data == null) return null;
    return UserChatKeyWrapperModel.fromJson(data);
  }

  /// Attempts to deactivate the active key by setting its status to 'retired'.
  /// If RLS blocks the UPDATE (returns 0 rows affected), falls back to keeping
  /// the old key intact. Returns the old key (or null if none existed).
  Future<UserChatKeyModel?> deleteActiveKey(String userId) async {
    final supabase = Supabase.instance.client;
    final activeKey = await fetchActiveKey(userId);
    if (activeKey == null) return null;
    final result = await supabase
        .from('user_chat_keys')
        .update({'status': 'retired', 'retired_at': DateTime.now().toIso8601String()})
        .eq('id', activeKey.id)
        .select();
    if (result.isEmpty) {
      return activeKey;
    }
    return null;
  }

  /// Decrypts a v1-encrypted message's content using the current user's private key.
  /// [recipientId] is the user who received the message (not the current user).
  /// If null, it will be derived from the match.
  Future<String?> decryptMessageContent({
    required String currentUserId,
    required Uint8List currentUserPrivateKey,
    required String messageId,
    required String matchId,
    required String senderId,
    required String senderKeyId,
    required String recipientKeyId,
    required String contentOriginalEncryptedBase64,
    required String contentOriginalNonceBase64,
    required Map<String, dynamic> wrappedKeys,
    String? recipientId,
  }) async {
    final supabase = Supabase.instance.client;

    String effectiveRecipientId;
    if (recipientId != null && recipientId.isNotEmpty) {
      effectiveRecipientId = recipientId;
    } else {
      final matchResp = await supabase
          .from('matches')
          .select('user1_id, user2_id')
          .eq('id', matchId)
          .maybeSingle();
      if (matchResp == null) return null;
      effectiveRecipientId = matchResp['user1_id'] == senderId
          ? matchResp['user2_id'] as String
          : matchResp['user1_id'] as String;
    }

    final bool iAmSender = currentUserId == senderId;
    final String peerKeyId = iAmSender ? recipientKeyId : senderKeyId;

    final peerKey = await fetchPeerPublicKey(peerKeyId);
    if (peerKey == null) return null;
    final peerPublicKeyBytes = base64Decode(peerKey.publicKeyBase64);

    final sharedSecret = await _crypto.x25519SharedSecretFromPrivateKey(
      myPrivateKey: currentUserPrivateKey,
      theirPublicKey: peerPublicKeyBytes,
    );

    final messageIdBytes = Uint8List.fromList(utf8.encode(messageId));
    final wrapKey = await _crypto.hkdfDeriveBytes(
      inputKeyMaterial: sharedSecret,
      salt: messageIdBytes,
      info: SecurityConstants.recipientWrapInfoLabel,
    );

    final wrapAad = _crypto.buildWrapAad(
      purpose: 'recipient',
      messageId: messageId,
      senderKeyId: senderKeyId,
      recipientOrSupabaseKeyId: recipientKeyId,
    );

    final recipientWrap = wrappedKeys['recipient'] as Map<String, dynamic>?;
    if (recipientWrap == null) return null;
    final wrapNonceBase64 = recipientWrap['nonce'] as String?;
    final wrapCiphertextBase64 = recipientWrap['ciphertext'] as String?;
    if (wrapNonceBase64 == null || wrapCiphertextBase64 == null) return null;

    final messageKey = await _crypto.unwrapMessageKey(
      wrappedKey: base64Decode(wrapCiphertextBase64),
      wrapKey: wrapKey,
      nonce: base64Decode(wrapNonceBase64),
      aad: wrapAad,
    );

    final decryptedBytes = await _crypto.decryptOriginal(
      ciphertext: base64Decode(contentOriginalEncryptedBase64),
      messageKey: messageKey,
      nonce: base64Decode(contentOriginalNonceBase64),
      messageId: messageId,
      matchId: matchId,
      senderId: senderId,
      recipientId: effectiveRecipientId,
      senderKeyId: senderKeyId,
      recipientKeyId: recipientKeyId,
    );

    return utf8.decode(decryptedBytes);
  }

  Future<String?> decryptMessageTranslatedContent({
    required String currentUserId,
    required Uint8List currentUserPrivateKey,
    required String messageId,
    required String matchId,
    required String senderId,
    required String senderKeyId,
    required String recipientKeyId,
    required String contentTranslatedEncryptedBase64,
    required String contentTranslatedNonceBase64,
    required Map<String, dynamic> wrappedKeys,
    required String detectedSourceLanguage,
    required String targetLanguage,
    String? recipientId,
  }) async {
    final supabase = Supabase.instance.client;

    String effectiveRecipientId;
    if (recipientId != null && recipientId.isNotEmpty) {
      effectiveRecipientId = recipientId;
    } else {
      final matchResp = await supabase
          .from('matches')
          .select('user1_id, user2_id')
          .eq('id', matchId)
          .maybeSingle();
      if (matchResp == null) return null;
      effectiveRecipientId = matchResp['user1_id'] == senderId
          ? matchResp['user2_id'] as String
          : matchResp['user1_id'] as String;
    }

    final bool iAmSender = currentUserId == senderId;
    final String peerKeyId = iAmSender ? recipientKeyId : senderKeyId;

    final peerKey = await fetchPeerPublicKey(peerKeyId);
    if (peerKey == null) return null;
    final peerPublicKeyBytes = base64Decode(peerKey.publicKeyBase64);

    final sharedSecret = await _crypto.x25519SharedSecretFromPrivateKey(
      myPrivateKey: currentUserPrivateKey,
      theirPublicKey: peerPublicKeyBytes,
    );

    final messageIdBytes = Uint8List.fromList(utf8.encode(messageId));
    final wrapKey = await _crypto.hkdfDeriveBytes(
      inputKeyMaterial: sharedSecret,
      salt: messageIdBytes,
      info: SecurityConstants.recipientWrapInfoLabel,
    );

    final wrapAad = _crypto.buildWrapAad(
      purpose: 'recipient',
      messageId: messageId,
      senderKeyId: senderKeyId,
      recipientOrSupabaseKeyId: recipientKeyId,
    );

    final recipientWrap = wrappedKeys['recipient'] as Map<String, dynamic>?;
    if (recipientWrap == null) return null;
    final wrapNonceBase64 = recipientWrap['nonce'] as String?;
    final wrapCiphertextBase64 = recipientWrap['ciphertext'] as String?;
    if (wrapNonceBase64 == null || wrapCiphertextBase64 == null) return null;

    final messageKey = await _crypto.unwrapMessageKey(
      wrappedKey: base64Decode(wrapCiphertextBase64),
      wrapKey: wrapKey,
      nonce: base64Decode(wrapNonceBase64),
      aad: wrapAad,
    );

    final decryptedBytes = await _crypto.decryptTranslated(
      ciphertext: base64Decode(contentTranslatedEncryptedBase64),
      messageKey: messageKey,
      nonce: base64Decode(contentTranslatedNonceBase64),
      messageId: messageId,
      matchId: matchId,
      senderId: senderId,
      recipientId: effectiveRecipientId,
      detectedSourceLanguage: detectedSourceLanguage,
      targetLanguage: targetLanguage,
      senderKeyId: senderKeyId,
      recipientKeyId: recipientKeyId,
    );

    return utf8.decode(decryptedBytes);
  }

  Future<UserChatKeyModel?> fetchPeerPublicKey(String keyId) async {
    if (_peerKeyCache.containsKey(keyId)) return _peerKeyCache[keyId];
    final supabase = Supabase.instance.client;
    final data = await supabase
        .from('user_chat_keys')
        .select('id, user_id, key_version, public_key, status, created_at, activated_at, retired_at')
        .eq('id', keyId)
        .maybeSingle();
    final key = data == null ? null : UserChatKeyModel.fromJson(data);
    _peerKeyCache[keyId] = key;
    return key;
  }

  void clearPeerKeyCache() => _peerKeyCache.clear();

  Future<UserChatKeyModel> setupEncryption({
    required String userId,
    String? password,
    String? existingKeyId,
  }) async {
    final keyPair = await _crypto.generateX25519KeyPair();
    final privateKeyBytes = await _crypto.privateKeyToBytes(keyPair);
    final publicKeyBytes = await _crypto.publicKeyToBytes(keyPair);
    final publicKeyBase64 = _crypto.publicKeyToBase64(publicKeyBytes);
    final crkBytes = await _crypto.generateRandomBytes(SecurityConstants.crkByteLength);
    final recoverySalt = _crypto.generateRandomBytesSync(SecurityConstants.pbkdf2SaltLength);
    final recoveryWrapKey = await _crypto.hkdfDeriveBytes(
      inputKeyMaterial: crkBytes,
      salt: recoverySalt,
      info: SecurityConstants.crkInfoLabel,
    );
    final recoveryNonce = _crypto.generateNonce();
    final recoveryAad = Uint8List.fromList(utf8.encode('chat-private-key-recovery'));
    final encryptedPrivateKeyByRecovery = await _crypto.aesGcmEncrypt(
      plaintext: privateKeyBytes,
      key: recoveryWrapKey,
      nonce: recoveryNonce,
      aad: recoveryAad,
    );

    final supabase = Supabase.instance.client;
    final String userChatKeyId;
    final int keyVersion;

    if (existingKeyId != null) {
      final keyResult = await supabase
          .from('user_chat_keys')
          .upsert({
            'id': existingKeyId,
            'user_id': userId,
            'key_version': 1,
            'public_key': publicKeyBase64,
            'status': 'active',
          }, onConflict: 'id')
          .select()
          .single();
      userChatKeyId = keyResult['id'] as String;
      keyVersion = keyResult['key_version'] as int;
      await supabase
          .from('user_chat_key_wrappers')
          .delete()
          .eq('user_chat_key_id', existingKeyId);
    } else {
      final maxVersionResult = await supabase
          .from('user_chat_keys')
          .select('key_version')
          .eq('user_id', userId)
          .order('key_version', ascending: false)
          .limit(1);
      final nextVersion = (maxVersionResult.isNotEmpty
          ? (maxVersionResult.first['key_version'] as int) + 1
          : 1);
      final keyResult = await supabase
          .from('user_chat_keys')
          .insert({
            'user_id': userId,
            'key_version': nextVersion,
            'public_key': publicKeyBase64,
            'status': 'active',
          })
          .select()
          .single();
      userChatKeyId = keyResult['id'] as String;
      keyVersion = nextVersion;
    }

    await supabase.from('user_chat_key_wrappers').insert({
      'user_chat_key_id': userChatKeyId,
      'user_id': userId,
      'wrapper_type': 'recovery_key',
      'kdf': 'HKDF-SHA256',
      'kdf_salt': base64Encode(recoverySalt),
      'wrap_alg': 'AES-256-GCM',
      'wrap_nonce': base64Encode(recoveryNonce),
      'encrypted_private_key': base64Encode(encryptedPrivateKeyByRecovery),
    });

    await storePrivateKeyBytes(userId, privateKeyBytes);
    await storeCrkBytes(userId, crkBytes);

    if (password != null && password.isNotEmpty) {
      await createPasswordWrapper(
        userId: userId,
        userChatKeyId: userChatKeyId,
        privateKeyBytes: privateKeyBytes,
        password: password,
      );
    }

    return UserChatKeyModel(
      id: userChatKeyId,
      userId: userId,
      keyVersion: keyVersion,
      publicKeyBase64: publicKeyBase64,
      status: 'active',
      createdAt: DateTime.now(),
      activatedAt: DateTime.now(),
    );
  }

  Future<void> createPasswordWrapper({
    required String userId,
    required String userChatKeyId,
    required Uint8List privateKeyBytes,
    required String password,
  }) async {
    final passwordBytes = Uint8List.fromList(utf8.encode(password));
    final salt = _crypto.generateRandomBytesSync(SecurityConstants.pbkdf2SaltLength);
    final passwordWrapKey = await _crypto.pbkdf2DeriveBytes(
      password: passwordBytes,
      salt: salt,
      iterations: SecurityConstants.pbkdf2Iterations,
    );
    final wrapNonce = _crypto.generateNonce();
    final aad = Uint8List.fromList(utf8.encode('chat-private-key-password'));
    final encryptedPrivateKey = await _crypto.aesGcmEncrypt(
      plaintext: privateKeyBytes,
      key: passwordWrapKey,
      nonce: wrapNonce,
      aad: aad,
    );

    final supabase = Supabase.instance.client;
    await supabase.rpc('create_or_replace_chat_key_wrapper', params: {
      'p_user_chat_key_id': userChatKeyId,
      'p_wrapper_type': 'password',
      'p_kdf': 'PBKDF2-HMAC-SHA256',
      'p_kdf_iterations': SecurityConstants.pbkdf2Iterations,
      'p_kdf_salt': base64Encode(salt),
      'p_wrap_alg': 'AES-256-GCM',
      'p_wrap_nonce': base64Encode(wrapNonce),
      'p_encrypted_private_key': base64Encode(encryptedPrivateKey),
    });
  }

  Future<Uint8List?> unlockWithPassword({
    required String userId,
    required String userChatKeyId,
    required String password,
  }) async {
    final wrapper = await fetchWrapperByType(userChatKeyId, 'password');
    if (wrapper == null) return null;

    final salt = base64Decode(wrapper.kdfSaltBase64);
    final passwordBytes = Uint8List.fromList(utf8.encode(password));
    final iterations = wrapper.kdfIterations ?? SecurityConstants.pbkdf2Iterations;
    final passwordWrapKey = await _crypto.pbkdf2DeriveBytes(
      password: passwordBytes,
      salt: salt,
      iterations: iterations,
    );

    final nonce = base64Decode(wrapper.wrapNonceBase64);
    final encryptedPrivateKey = base64Decode(wrapper.encryptedPrivateKeyBase64);
    final aad = Uint8List.fromList(utf8.encode('chat-private-key-password'));

    try {
      final privateKey = await _crypto.aesGcmDecrypt(
        ciphertext: encryptedPrivateKey,
        key: passwordWrapKey,
        nonce: nonce,
        aad: aad,
      );
      await storePrivateKeyBytes(userId, privateKey);
      return privateKey;
    } catch (_) {
      return null;
    }
  }

  Future<Uint8List?> unlockWithCrk({
    required String userId,
    required String userChatKeyId,
    required Uint8List crkBytes,
  }) async {
    final wrapper = await fetchWrapperByType(userChatKeyId, 'recovery_key');
    if (wrapper == null) return null;

    final salt = base64Decode(wrapper.kdfSaltBase64);
    final recoveryWrapKey = await _crypto.hkdfDeriveBytes(
      inputKeyMaterial: crkBytes,
      salt: salt,
      info: SecurityConstants.crkInfoLabel,
    );

    final nonce = base64Decode(wrapper.wrapNonceBase64);
    final encryptedPrivateKey = base64Decode(wrapper.encryptedPrivateKeyBase64);
    final aad = Uint8List.fromList(utf8.encode('chat-private-key-recovery'));

    try {
      final privateKey = await _crypto.aesGcmDecrypt(
        ciphertext: encryptedPrivateKey,
        key: recoveryWrapKey,
        nonce: nonce,
        aad: aad,
      );
      await storePrivateKeyBytes(userId, privateKey);
      await storeCrkBytes(userId, crkBytes);
      return privateKey;
    } catch (_) {
      return null;
    }
  }

  Future<Uint8List?> unlockAfterPasswordAuth(
      String userId, String password) async {
    final activeKey = await fetchActiveKey(userId);
    if (activeKey == null) return null;

    if (await hasPrivateKeyLocally(userId)) {
      return loadPrivateKeyBytes(userId);
    }

    return unlockWithPassword(
      userId: userId,
      userChatKeyId: activeKey.id,
      password: password,
    );
  }

  Future<Uint8List> ensurePrivateKeyUnlocked(String userId) async {
    final localKey = await loadPrivateKeyBytes(userId);
    if (localKey != null) return localKey;

    final activeKey = await fetchActiveKey(userId);
    if (activeKey == null) {
      throw Exception('No active chat key found');
    }

    throw Exception('Private key not unlocked locally');
  }

  Future<void> replaceRecoveryKey({
    required String userId,
    required String userChatKeyId,
    required Uint8List privateKeyBytes,
    required Uint8List newCrkBytes,
  }) async {
    final recoverySalt =
        _crypto.generateRandomBytesSync(SecurityConstants.pbkdf2SaltLength);
    final recoveryWrapKey = await _crypto.hkdfDeriveBytes(
      inputKeyMaterial: newCrkBytes,
      salt: recoverySalt,
      info: SecurityConstants.crkInfoLabel,
    );
    final recoveryNonce = _crypto.generateNonce();
    final aad = Uint8List.fromList(utf8.encode('chat-private-key-recovery'));
    final encryptedPrivateKey = await _crypto.aesGcmEncrypt(
      plaintext: privateKeyBytes,
      key: recoveryWrapKey,
      nonce: recoveryNonce,
      aad: aad,
    );

    final supabase = Supabase.instance.client;
    await supabase.rpc('create_or_replace_chat_key_wrapper', params: {
      'p_user_chat_key_id': userChatKeyId,
      'p_wrapper_type': 'recovery_key',
      'p_kdf': 'HKDF-SHA256',
      'p_kdf_salt': base64Encode(recoverySalt),
      'p_wrap_alg': 'AES-256-GCM',
      'p_wrap_nonce': base64Encode(recoveryNonce),
      'p_encrypted_private_key': base64Encode(encryptedPrivateKey),
    });

    await storeCrkBytes(userId, newCrkBytes);
  }

  Future<void> replacePasswordWrapper({
    required String userId,
    required String userChatKeyId,
    required Uint8List privateKeyBytes,
    required String newPassword,
  }) async {
    await createPasswordWrapper(
      userId: userId,
      userChatKeyId: userChatKeyId,
      privateKeyBytes: privateKeyBytes,
      password: newPassword,
    );
  }

  Future<UserChatKeyModel> replaceLostChatKey({
    required String userId,
    required String lostKeyId,
    required String reauthToken,
  }) async {
    final keyPair = await _crypto.generateX25519KeyPair();
    final privateKeyBytes = await _crypto.privateKeyToBytes(keyPair);
    final publicKeyBytes = await _crypto.publicKeyToBytes(keyPair);
    final publicKeyBase64 = _crypto.publicKeyToBase64(publicKeyBytes);
    final crkBytes = await _crypto.generateRandomBytes(SecurityConstants.crkByteLength);

    final supabase = Supabase.instance.client;
    final result = await supabase.rpc('replace_lost_chat_key', params: {
      'p_lost_key_id': lostKeyId,
      'p_new_public_key': publicKeyBase64,
      'p_reauth_token': reauthToken,
    });
    final newKeyId = result as String;

    final recoverySalt =
        _crypto.generateRandomBytesSync(SecurityConstants.pbkdf2SaltLength);
    final recoveryWrapKey = await _crypto.hkdfDeriveBytes(
      inputKeyMaterial: crkBytes,
      salt: recoverySalt,
      info: SecurityConstants.crkInfoLabel,
    );
    final recoveryNonce = _crypto.generateNonce();
    final aad = Uint8List.fromList(utf8.encode('chat-private-key-recovery'));
    final encryptedPrivateKey = await _crypto.aesGcmEncrypt(
      plaintext: privateKeyBytes,
      key: recoveryWrapKey,
      nonce: recoveryNonce,
      aad: aad,
    );

    await supabase.from('user_chat_key_wrappers').insert({
      'user_chat_key_id': newKeyId,
      'user_id': userId,
      'wrapper_type': 'recovery_key',
      'kdf': 'HKDF-SHA256',
      'kdf_salt': base64Encode(recoverySalt),
      'wrap_alg': 'AES-256-GCM',
      'wrap_nonce': base64Encode(recoveryNonce),
      'encrypted_private_key': base64Encode(encryptedPrivateKey),
    });

    await storePrivateKeyBytes(userId, privateKeyBytes);
    await storeCrkBytes(userId, crkBytes);

    return UserChatKeyModel(
      id: newKeyId,
      userId: userId,
      keyVersion: 0,
      publicKeyBase64: publicKeyBase64,
      status: 'active',
      createdAt: DateTime.now(),
      activatedAt: DateTime.now(),
    );
  }
}
