import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

class SensitiveActionReauthException implements Exception {
  const SensitiveActionReauthException({
    required this.code,
    required this.message,
    this.statusCode,
  });

  final String code;
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

class SensitiveActionEmailCodeRequestResult {
  const SensitiveActionEmailCodeRequestResult({
    required this.expiresAt,
    required this.sentFreshly,
  });

  final DateTime expiresAt;
  final bool sentFreshly;
}

class SensitiveActionReauthService {
  static const Duration _requestTimeout = Duration(seconds: 10);
  static const Duration _codeEntryWindow = Duration(minutes: 10);
  static DateTime? _activeEmailCodeExpiresAt;

  static DateTime? get activeEmailCodeExpiresAt {
    final expiresAt = _activeEmailCodeExpiresAt;
    if (expiresAt == null) return null;
    if (DateTime.now().isAfter(expiresAt)) {
      _activeEmailCodeExpiresAt = null;
      return null;
    }
    return expiresAt;
  }

  static Future<SensitiveActionEmailCodeRequestResult> requestEmailCode({
    bool forceResend = false,
    String? language,
  }) async {
    final activeWindow = activeEmailCodeExpiresAt;
    if (!forceResend && activeWindow != null) {
      return SensitiveActionEmailCodeRequestResult(
        expiresAt: activeWindow,
        sentFreshly: false,
      );
    }

    await sendEmailCode(language: language, forceResend: forceResend);
    final expiresAt = _markEmailCodeWindow();
    return SensitiveActionEmailCodeRequestResult(
      expiresAt: expiresAt,
      sentFreshly: true,
    );
  }

  static Future<void> sendEmailCode({String? language, bool forceResend = false}) async {
    final auth = Supabase.instance.client.auth;
    await _refreshSessionIfAvailable(auth);
    
    final currentUser = auth.currentUser;
    if (currentUser == null) {
      throw const SensitiveActionReauthException(
        code: 'not_authenticated',
        message: 'A signed-in user is required to send email code.',
      );
    }

    final email = currentUser.email?.trim().toLowerCase();
    if (email == null || email.isEmpty) {
      throw const SensitiveActionReauthException(
        code: 'missing_email',
        message: 'The current user does not have a confirmed email address.',
      );
    }

    try {
      if (forceResend) {
        // Resend existing code without generating a new one
        await _resendEmailCodeOnBackend(email: email, language: language);
      } else {
        // Generate code on backend
        await _generateEmailCodeOnBackend(email: email, language: language);
      }
      _markEmailCodeWindow();
    } on AuthException catch (error) {
      if (_shouldReuseExistingEmailCode(error)) {
        _markEmailCodeWindow();
        return;
      }
      if (await _tryRefreshSessionForAuthError(auth, error)) {
        try {
          if (forceResend) {
            await _resendEmailCodeOnBackend(email: email, language: language);
          } else {
            await _generateEmailCodeOnBackend(email: email, language: language);
          }
          _markEmailCodeWindow();
          return;
        } on AuthException catch (retryError) {
          if (_shouldReuseExistingEmailCode(retryError)) {
            _markEmailCodeWindow();
            return;
          }
          throw SensitiveActionReauthException(
            code: retryError.code ?? 'auth_error',
            message: retryError.message,
          );
        }
      }
      throw SensitiveActionReauthException(
        code: error.code ?? 'auth_error',
        message: error.message,
      );
    } on TimeoutException {
      throw const SensitiveActionReauthException(
        code: 'timeout',
        message: 'Email code request timed out.',
      );
    } catch (error) {
      if (error is SensitiveActionReauthException) {
        rethrow;
      }
      throw SensitiveActionReauthException(
        code: 'send_failed',
        message: error.toString(),
      );
    }
  }

  static Future<void> _generateEmailCodeOnBackend({
    required String email,
    String? language,
  }) async {
    final supabase = Supabase.instance.client;
    final session = supabase.auth.currentSession;

    if (session == null) {
      throw const SensitiveActionReauthException(
        code: 'not_authenticated',
        message: 'No active session for email code generation.',
      );
    }

    try {
      final response = await supabase.functions.invoke(
        'sensitive-action-email-code',
        body: {
          'action': 'generate',
          'email': email,
          'language': language ?? 'en',
        },
      ).timeout(_requestTimeout);

      // The response is a FunctionResponse object, get its data
      final result = response.data as Map<String, dynamic>? ?? {};
      
      if (result['success'] != true) {
        throw SensitiveActionReauthException(
          code: 'generation_failed',
          message: result['message'] ?? 'Failed to generate email code',
        );
      }
    } on TimeoutException {
      throw const SensitiveActionReauthException(
        code: 'timeout',
        message: 'Email code generation request timed out.',
      );
    } catch (error) {
      if (error is SensitiveActionReauthException) {
        rethrow;
      }
      print(
        '[SensitiveActionReauth] Backend generation error: $error',
      );
      throw SensitiveActionReauthException(
        code: 'generation_error',
        message: 'Failed to generate email code: $error',
      );
    }
  }

  static Future<void> _resendEmailCodeOnBackend({
    required String email,
    String? language,
  }) async {
    final supabase = Supabase.instance.client;
    final session = supabase.auth.currentSession;

    if (session == null) {
      throw const SensitiveActionReauthException(
        code: 'not_authenticated',
        message: 'No active session for email code resend.',
      );
    }

    try {
      final response = await supabase.functions.invoke(
        'sensitive-action-email-code',
        body: {
          'action': 'resend',
          'email': email,
          'language': language ?? 'en',
        },
      ).timeout(_requestTimeout);

      // The response is a FunctionResponse object, get its data
      final result = response.data as Map<String, dynamic>? ?? {};
      
      if (result['success'] != true) {
        throw SensitiveActionReauthException(
          code: 'resend_failed',
          message: result['message'] ?? 'Failed to resend email code',
        );
      }
    } on TimeoutException {
      throw const SensitiveActionReauthException(
        code: 'timeout',
        message: 'Email code resend request timed out.',
      );
    } catch (error) {
      if (error is SensitiveActionReauthException) {
        rethrow;
      }
      print(
        '[SensitiveActionReauth] Backend resend error: $error',
      );
      throw SensitiveActionReauthException(
        code: 'resend_error',
        message: 'Failed to resend email code: $error',
      );
    }
  }

  static Future<void> verifyEmailCode({
    required String email,
    required String token,
  }) async {
    final normalizedEmail = email.trim().toLowerCase();
    final normalizedToken = token.trim();
    if (normalizedEmail.isEmpty || normalizedToken.isEmpty) {
      throw const SensitiveActionReauthException(
        code: 'invalid_request',
        message: 'Email reauthentication requires both email and token.',
      );
    }

    final auth = Supabase.instance.client.auth;
    await _refreshSessionIfAvailable(auth);
    final currentUser = auth.currentUser;
    if (currentUser == null) {
      throw const SensitiveActionReauthException(
        code: 'not_authenticated',
        message: 'A signed-in user is required for email reauthentication.',
      );
    }

    final currentEmail = currentUser.email?.trim().toLowerCase();
    if (currentEmail == null || currentEmail.isEmpty) {
      throw const SensitiveActionReauthException(
        code: 'missing_email',
        message: 'The current user does not have a confirmed email address.',
      );
    }
    if (currentEmail != normalizedEmail) {
      throw const SensitiveActionReauthException(
        code: 'email_mismatch',
        message: 'The provided reauthentication email does not match the current user.',
      );
    }

    try {
      // Verify the email code against the backend
      final verifyResult = await _verifyEmailCodeWithBackend(
        email: normalizedEmail,
        code: normalizedToken,
      );

      if (!verifyResult['success']) {
        throw SensitiveActionReauthException(
          code: 'invalid_code',
          message: verifyResult['message'] ?? 'Invalid email code',
        );
      }

      // Code is valid, update user session
      await auth.updateUser(
        UserAttributes(
          data: _copyUserMetadata(currentUser.userMetadata),
          nonce: normalizedToken,
        ),
      );
      await auth.refreshSession().timeout(_requestTimeout);
      clearEmailCodeWindow();
    } on AuthException catch (error) {
      if (await _tryRefreshSessionForAuthError(auth, error)) {
        try {
          // Retry backend verification
          final verifyResult = await _verifyEmailCodeWithBackend(
            email: normalizedEmail,
            code: normalizedToken,
          );

          if (!verifyResult['success']) {
            throw SensitiveActionReauthException(
              code: 'invalid_code',
              message: verifyResult['message'] ?? 'Invalid email code',
            );
          }

          await auth.updateUser(
            UserAttributes(
              data: _copyUserMetadata(currentUser.userMetadata),
              nonce: normalizedToken,
            ),
          );
          await auth.refreshSession().timeout(_requestTimeout);
          clearEmailCodeWindow();
          return;
        } on AuthException catch (retryError) {
          throw SensitiveActionReauthException(
            code: retryError.code ?? 'auth_error',
            message: retryError.message,
          );
        }
      }
      throw SensitiveActionReauthException(
        code: error.code ?? 'auth_error',
        message: error.message,
      );
    } on TimeoutException {
      throw const SensitiveActionReauthException(
        code: 'timeout',
        message: 'Reauthentication request timed out.',
      );
    } catch (error) {
      if (error is SensitiveActionReauthException) {
        rethrow;
      }
      throw SensitiveActionReauthException(
        code: 'verification_failed',
        message: error.toString(),
      );
    }
  }

  static Future<Map<String, dynamic>> _verifyEmailCodeWithBackend({
    required String email,
    required String code,
  }) async {
    final supabase = Supabase.instance.client;
    final session = supabase.auth.currentSession;

    if (session == null) {
      throw const SensitiveActionReauthException(
        code: 'not_authenticated',
        message: 'No active session for email code verification.',
      );
    }

    try {
      final response = await supabase.functions.invoke(
        'sensitive-action-email-code',
        body: {
          'action': 'verify',
          'email': email,
          'code': code,
        },
      ).timeout(_requestTimeout);

      // The response is a FunctionResponse object, get its data
      final result = response.data as Map<String, dynamic>? ?? {};
      return result;
    } on TimeoutException {
      throw const SensitiveActionReauthException(
        code: 'timeout',
        message: 'Email code verification request timed out.',
      );
    } catch (error) {
      print(
        '[SensitiveActionReauth] Backend verification error: $error',
      );
      throw SensitiveActionReauthException(
        code: 'verification_error',
        message: 'Failed to verify email code: $error',
      );
    }
  }

  static void clearEmailCodeWindow() {
    _activeEmailCodeExpiresAt = null;
  }

  static Map<String, dynamic>? _copyUserMetadata(Map<String, dynamic>? source) {
    if (source == null || source.isEmpty) {
      return null;
    }
    return Map<String, dynamic>.from(source);
  }

  static bool _isLikelyNetworkError(Object error) {
    final msg = error.toString().toLowerCase();
    return msg.contains('socketexception') ||
        msg.contains('clientexception') ||
        msg.contains('failed host lookup') ||
        msg.contains('no address associated with hostname') ||
        msg.contains('network is unreachable') ||
        msg.contains('connection refused') ||
        msg.contains('connection reset') ||
        msg.contains('software caused connection abort') ||
        msg.contains('timed out') ||
        msg.contains('authretryablefetchexception');
  }

  static Future<void> _refreshSessionIfAvailable(GoTrueClient auth) async {
    final refreshToken = auth.currentSession?.refreshToken?.trim();
    if (refreshToken == null || refreshToken.isEmpty) {
      return;
    }

    try {
      await auth.refreshSession().timeout(_requestTimeout);
    } catch (error) {
      // Network errors are expected when offline - don't log as errors
      if (_isLikelyNetworkError(error)) {
        print(
          '[SensitiveActionReauth] Preflight refresh skipped (offline): $error',
        );
      } else {
        print(
          '[SensitiveActionReauth] Preflight refresh skipped: $error',
        );
      }
    }
  }

  static DateTime _markEmailCodeWindow() {
    final expiresAt = DateTime.now().add(_codeEntryWindow);
    _activeEmailCodeExpiresAt = expiresAt;
    return expiresAt;
  }

  static bool _shouldReuseExistingEmailCode(AuthException error) {
    final code = error.code?.trim().toLowerCase();
    return code == 'over_email_send_rate_limit' ||
        code == 'over_request_rate_limit';
  }

  static Future<bool> _tryRefreshSessionForAuthError(
    GoTrueClient auth,
    AuthException error,
  ) async {
    if (!_isLikelyInvalidSessionError(error)) {
      return false;
    }
    final refreshToken = auth.currentSession?.refreshToken?.trim();
    if (refreshToken == null || refreshToken.isEmpty) {
      return false;
    }

    try {
      print(
        '[SensitiveActionReauth] Refreshing session before retry: '
        '${error.code ?? 'auth_error'} ${error.message}',
      );
      await auth.refreshSession().timeout(_requestTimeout);
      return true;
    } catch (refreshError) {
      // Network errors are expected when offline - don't retry
      if (_isLikelyNetworkError(refreshError)) {
        print(
          '[SensitiveActionReauth] Session refresh failed during retry (offline): $refreshError',
        );
        return false;
      }
      print(
        '[SensitiveActionReauth] Session refresh failed during retry: $refreshError',
      );
      return false;
    }
  }

  static bool _isLikelyInvalidSessionError(Object error) {
    final message =
        error is AuthException ? error.message : error.toString();
    final lower = message.toLowerCase();
    return lower.contains('invalid jwt') ||
        lower.contains('jwt expired') ||
        lower.contains('token is expired') ||
        lower.contains('invalid refresh token') ||
        lower.contains('refresh_token_not_found') ||
        lower.contains('refresh token not found') ||
        lower.contains('refresh_token_already_used') ||
        lower.contains('already used') ||
        lower.contains('session expired') ||
        lower.contains('unauthorized') ||
        lower.contains('not authorized');
  }
}
