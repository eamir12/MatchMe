import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:matchme/services/chat_key_service.dart';
import 'package:matchme/services/crypto_service.dart';
import 'package:matchme/config/security_constants.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class EncryptedNotificationPreviewService {
  EncryptedNotificationPreviewService._();
  static final EncryptedNotificationPreviewService instance =
      EncryptedNotificationPreviewService._();

  static const _secureStorage = FlutterSecureStorage();
  static const _previewEnabledPrefix = 'notification_preview_enabled:';

  final ChatKeyService _chatKeyService = ChatKeyService.instance;
  final CryptoService _crypto = CryptoService.instance;

  Future<bool> isPreviewEnabled(String userId) async {
    final val =
        await _secureStorage.read(key: '$_previewEnabledPrefix$userId');
    return val == 'true';
  }

  Future<void> setPreviewEnabled(String userId, bool enabled) async {
    await _secureStorage.write(
        key: '$_previewEnabledPrefix$userId', value: enabled ? 'true' : 'false');
  }

  Future<String?> decryptPreview({
    required String messageId,
    required String matchId,
    required String senderId,
    required String recipientId,
    required String senderKeyId,
    required String recipientKeyId,
    required String contentOriginalEncryptedBase64,
    required String contentOriginalNonceBase64,
    required String wrappedKeysJson,
    String? translatedEncryptedBase64,
    String? translatedNonceBase64,
  }) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return null;

    final enabled = await isPreviewEnabled(userId);
    if (!enabled) return null;

    try {
      final privateKey = await _chatKeyService.loadPrivateKeyBytes(userId);
      if (privateKey == null) return null;

      final wrappedKeys =
          jsonDecode(wrappedKeysJson) as Map<String, dynamic>;
      final recipientWrap = wrappedKeys['recipient'];
      if (recipientWrap == null) return null;
      final recipientWrapMap = recipientWrap as Map<String, dynamic>;

      final senderKey = await _chatKeyService.fetchPeerPublicKey(senderKeyId);
      if (senderKey == null) return null;

      final senderPublicKey =
          _crypto.base64ToPublicKey(senderKey.publicKeyBase64);
      final sharedSecret = await _crypto.x25519SharedSecretFromPrivateKey(
        myPrivateKey: privateKey,
        theirPublicKey: senderPublicKey,
      );

      final messageIdBytes = Uint8List.fromList(utf8.encode(messageId));
      final wrapKey = await _crypto.hkdfDeriveBytes(
        inputKeyMaterial: sharedSecret,
        salt: messageIdBytes,
        info: SecurityConstants.recipientWrapInfoLabel,
      );

      final wrapNonce =
          base64Decode(recipientWrapMap['nonce'] as String);
      final wrapCiphertext =
          base64Decode(recipientWrapMap['ciphertext'] as String);
      final wrapAad = _crypto.buildWrapAad(
        purpose: 'recipient',
        messageId: messageId,
        senderKeyId: senderKeyId,
        recipientOrSupabaseKeyId: recipientKeyId,
      );

      final messageKey = await _crypto.unwrapMessageKey(
        wrappedKey: wrapCiphertext,
        wrapKey: wrapKey,
        nonce: wrapNonce,
        aad: wrapAad,
      );

      final contentNonce = base64Decode(contentOriginalNonceBase64);
      final contentCiphertext = base64Decode(contentOriginalEncryptedBase64);

      final plaintext = await _crypto.decryptOriginal(
        ciphertext: contentCiphertext,
        messageKey: messageKey,
        nonce: contentNonce,
        messageId: messageId,
        matchId: matchId,
        senderId: senderId,
        recipientId: recipientId,
        senderKeyId: senderKeyId,
        recipientKeyId: recipientKeyId,
      );

      return utf8.decode(plaintext);
    } catch (e) {
      debugPrint(
          '[EncryptedNotificationPreview] Decryption failed: $e');
      return null;
    }
  }
}
