import 'package:matchme/utils/offline_utils.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Coalesces [update_user_activity] RPC calls so heartbeat, navigation, and
/// connectivity handlers do not hammer the database.
class UserActivityService {
  UserActivityService._();

  static final UserActivityService instance = UserActivityService._();

  static const Duration _minInterval = Duration(seconds: 25);

  DateTime? _lastPingAt;
  String? _lastUserId;
  bool _inFlight = false;

  /// Ping user activity at most once per [_minInterval] per user.
  Future<void> pingIfDue(
    String userId, {
    bool force = false,
    String source = 'unknown',
  }) async {
    final uid = userId.trim();
    if (uid.isEmpty) return;
    if (shouldSkipSupabaseCalls()) return;

    final now = DateTime.now();
    if (!force &&
        _lastUserId == uid &&
        _lastPingAt != null &&
        now.difference(_lastPingAt!) < _minInterval) {
      return;
    }
    if (_inFlight) return;

    _inFlight = true;
    try {
      await Supabase.instance.client.rpc(
        'update_user_activity',
        params: {'p_user_id': uid},
      );
      _lastPingAt = now;
      _lastUserId = uid;
    } catch (e) {
      if (!isExpectedOfflineFailure(e)) {
        // ignore: avoid_print
        print('[UserActivity] ping failed ($source): $e');
      }
    } finally {
      _inFlight = false;
    }
  }

  void reset() {
    _lastPingAt = null;
    _lastUserId = null;
    _inFlight = false;
  }
}
