import 'dart:io' show Platform;

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart'
    show TargetPlatform, defaultTargetPlatform, kIsWeb;
import 'package:matchme/services/app_info_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';

class SecureSignUpException implements Exception {
  const SecureSignUpException({
    required this.code,
    required this.message,
  });

  final String code;
  final String message;

  @override
  String toString() => message;
}

class SecureSignupService {
  static const String _functionName = 'secure-sign-up';
  static const String _installIdPrefsKey = 'signup_install_id';
  static final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  static const Uuid _uuid = Uuid();

  static String _detectPlatform() {
    if (kIsWeb) return 'web';
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return 'android';
      case TargetPlatform.iOS:
        return 'ios';
      case TargetPlatform.macOS:
        return 'macos';
      case TargetPlatform.windows:
        return 'windows';
      case TargetPlatform.linux:
        return 'linux';
      default:
        return 'unknown';
    }
  }

  static Future<String> _getOrCreateInstallId() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_installIdPrefsKey)?.trim();
    if (existing != null && existing.isNotEmpty) {
      return existing;
    }

    final generated = _uuid.v4();
    await prefs.setString(_installIdPrefsKey, generated);
    return generated;
  }

  static Future<Map<String, dynamic>> _collectFingerprint() async {
    final appInfo = await AppInfoService.getAppInfo();
    final installId = await _getOrCreateInstallId();
    final platform = _detectPlatform();

    String? deviceId;
    String deviceModel = 'unknown';

    try {
      if (kIsWeb) {
        deviceModel = 'web';
      } else if (Platform.isAndroid) {
        final info = await _deviceInfo.androidInfo;
        deviceModel = info.model.trim().isEmpty ? 'android' : info.model.trim();
        final resolvedId = info.id.trim();
        if (resolvedId.isNotEmpty) {
          deviceId = resolvedId;
        }
      } else if (Platform.isIOS) {
        final info = await _deviceInfo.iosInfo;
        deviceModel =
            info.utsname.machine.trim().isEmpty ? 'ios' : info.utsname.machine.trim();
        final resolvedId = (info.identifierForVendor ?? '').trim();
        if (resolvedId.isNotEmpty) {
          deviceId = resolvedId;
        }
      } else if (Platform.isMacOS) {
        final info = await _deviceInfo.macOsInfo;
        deviceModel = info.model.trim().isEmpty ? 'macos' : info.model.trim();
      } else if (Platform.isWindows) {
        final info = await _deviceInfo.windowsInfo;
        deviceModel =
            info.computerName.trim().isEmpty ? 'windows' : info.computerName.trim();
      } else if (Platform.isLinux) {
        final info = await _deviceInfo.linuxInfo;
        deviceModel = info.name.trim().isEmpty ? 'linux' : info.name.trim();
      }
    } catch (_) {
      // Best-effort only.
    }

    return {
      'platform': platform,
      'installId': installId,
      'deviceId': deviceId,
      'deviceModel': deviceModel,
      'appName': appInfo.appName,
      'appVersion': appInfo.version,
      'buildNumber': appInfo.buildNumber,
    };
  }

  static SecureSignUpException _parseInvokeError(
    Object error, {
    String fallbackCode = 'unknown',
    String fallbackMessage = 'Sign up failed.',
  }) {
    if (error is SecureSignUpException) {
      return error;
    }

    // Check if this is a network error
    final errorStr = error.toString().toLowerCase();
    if (errorStr.contains('socketexception') ||
        errorStr.contains('clientexception') ||
        errorStr.contains('failed host lookup') ||
        errorStr.contains('no address associated with hostname') ||
        errorStr.contains('network is unreachable') ||
        errorStr.contains('connection refused') ||
        errorStr.contains('connection reset') ||
        errorStr.contains('timed out') ||
        errorStr.contains('timeout') ||
        errorStr.contains('handshake exception') ||
        errorStr.contains('certificate verification failed')) {
      return SecureSignUpException(
        code: 'network_error',
        message: 'Network error. Please check your internet connection.',
      );
    }

    if (error is FunctionException) {
      String code = fallbackCode;
      String message = fallbackMessage;
      final details = error.details;

      if (details is Map) {
        final rawCode = details['code'];
        if (rawCode != null && rawCode.toString().trim().isNotEmpty) {
          code = rawCode.toString().trim();
        }
        final rawMessage = details['message'] ?? details['error'];
        if (rawMessage != null && rawMessage.toString().trim().isNotEmpty) {
          message = rawMessage.toString().trim();
        }
      }

      if (message == fallbackMessage && error.reasonPhrase != null) {
        final phrase = error.reasonPhrase!.trim();
        if (phrase.isNotEmpty) {
          message = phrase;
        }
      }

      return SecureSignUpException(code: code, message: message);
    }

    return SecureSignUpException(
      code: fallbackCode,
      message: fallbackMessage,
    );
  }

  static Future<void> screenEmail({
    required String email,
  }) async {
    final trimmedEmail = email.trim();
    if (trimmedEmail.isEmpty) {
      throw const SecureSignUpException(
        code: 'bad_request',
        message: 'Email is required.',
      );
    }

    final fingerprint = await _collectFingerprint();

    try {
      final response = await Supabase.instance.client.functions.invoke(
        _functionName,
        body: {
          'action': 'screen_email',
          'email': trimmedEmail,
          'fingerprint': fingerprint,
        },
      );

      final ok = response.status >= 200 &&
          response.status < 300 &&
          response.data is Map &&
          (response.data as Map)['success'] == true;
      if (ok) {
        return;
      }

      throw _parseInvokeError(
        FunctionException(
          status: response.status,
          details: response.data,
          reasonPhrase: null,
        ),
        fallbackCode: 'screening_failed',
        fallbackMessage: 'Unable to validate email.',
      );
    } catch (error) {
      throw _parseInvokeError(
        error,
        fallbackCode: 'screening_failed',
        fallbackMessage: 'Unable to validate email.',
      );
    }
  }

  static Future<void> signUp({
    required String email,
    required String password,
    required String captchaToken,
    String? language,
  }) async {
    final trimmedEmail = email.trim();
    final trimmedPassword = password.trim();
    final trimmedCaptchaToken = captchaToken.trim();

    if (trimmedEmail.isEmpty ||
        trimmedPassword.isEmpty ||
        trimmedCaptchaToken.isEmpty) {
      throw const SecureSignUpException(
        code: 'bad_request',
        message: 'Sign up request is incomplete.',
      );
    }

    final fingerprint = await _collectFingerprint();
    try {
      final response = await Supabase.instance.client.functions.invoke(
        _functionName,
        body: {
          'email': trimmedEmail,
          'password': trimmedPassword,
          'captchaToken': trimmedCaptchaToken,
          'fingerprint': fingerprint,
          if (language != null && language.trim().isNotEmpty) 'language': language.trim(),
        },
      );

      final ok = response.status >= 200 &&
          response.status < 300 &&
          response.data is Map &&
          (response.data as Map)['success'] == true;
      if (ok) {
        // Extract refresh token from backend response for fallback recovery
        // The OTP verification will establish the full session
        final data = response.data as Map<String, dynamic>?;
        final refreshToken = data?['refreshToken'] as String?;
        if (refreshToken != null && refreshToken.isNotEmpty) {
          // Store for reference, but don't set session yet - OTP verification will do that
          final prefs = await SharedPreferences.getInstance();
          await prefs.setString('signup_refresh_token_pending', refreshToken);
        }
        return;
      }

      throw _parseInvokeError(
        FunctionException(
          status: response.status,
          details: response.data,
          reasonPhrase: null,
        ),
      );
    } catch (error) {
      throw _parseInvokeError(error);
    }
  }
}
