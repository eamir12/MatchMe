// lib/screens/home/home_screen.dart
import 'dart:async';
import 'dart:developer' as developer;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/models/sponsored_ad.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/providers/home_providers.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/providers/payment_provider.dart';
import 'package:matchme/providers/match_notification_provider.dart';
import 'package:matchme/providers/app_config_provider.dart';
import 'package:matchme/providers/external_ad_provider.dart';
import 'package:matchme/providers/theme_provider.dart';
import 'package:matchme/providers/user_preferences_provider.dart';
import 'package:matchme/services/app_config_service.dart';
import 'package:matchme/utils/greeting_utils.dart';
import 'package:matchme/utils/string_extensions.dart';
import 'package:matchme/utils/time_format_utils.dart';
import 'package:matchme/providers/profile_provider.dart';
import 'package:matchme/providers/visibility_provider.dart';
import 'package:matchme/screens/nearby/nearby_map_screen.dart';
import 'package:matchme/screens/paywall/paywall_screen.dart';
import 'package:matchme/widgets/ad_slot.dart';
import 'package:matchme/widgets/match_box.dart';
import 'package:matchme/widgets/chat_list_item.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

final supabase = Supabase.instance.client;

Widget _buildStatCard(
  BuildContext context,
  IconData icon,
  String value,
  String label, {
  String? subValue,
  VoidCallback? onTap,
}) {
  return Expanded(
    child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 30, color: Theme.of(context).colorScheme.secondary),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          if (subValue != null) ...[
            const SizedBox(height: 2),
            Text(
              subValue,
              style: const TextStyle(fontSize: 11, color: Colors.grey),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: Colors.grey),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});
  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

// Separate widget for subscription tier card to prevent entire home screen from rebuilding
// when subscription time updates (every minute)
class _SubscriptionTierCard extends ConsumerWidget {
  final UserProfile? profile;
  final String tierKey;
  final VoidCallback onTap;

  const _SubscriptionTierCard({
    required this.profile,
    required this.tierKey,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = ref.watch(localizationProvider);
    final remaining = ref.watch(subscriptionTimeRemainingProvider);
    
    final remainingText =
        (remaining != null && remaining > Duration.zero)
            ? '${l10n.getString('subscriptionTimeLeft')}: ${formatDurationWords(l10n, remaining)}'
            : null;
            
    return _buildStatCard(
      context,
      Icons.star_outline,
      l10n.getString(tierKey),
      l10n.getString('homeTier'),
      subValue: remainingText,
      onTap: onTap,
    );
  }
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  Timer? _userActivityTimer;

  @override
  void initState() {
    super.initState();
    developer.log('🏠 HomeScreen init', name: 'MatchMeTrace');
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        // Update user activity when home screen loads
        _updateUserActivity();
        // Schedule periodic activity updates to keep user online status fresh
        _schedulePeriodicActivityUpdates();
      }
    });
  }


  void _schedulePeriodicActivityUpdates() {
    _userActivityTimer?.cancel();
    // Update activity every 30 seconds to keep user visible online
    _userActivityTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        _updateUserActivity();
      }
    });
  }

  @override
  void dispose() {
    _userActivityTimer?.cancel();
    super.dispose();
  }

  Future<void> _updateUserActivity() async {
    final user = supabase.auth.currentUser;
    if (user != null) {
      // Only update activity if online to avoid unnecessary network calls
      final isOnline = ref.read(connectivityProvider).value ?? false;
      if (!isOnline) return;
      try {
        await supabase.rpc('update_user_activity', params: {'p_user_id': user.id});
      } catch (e) {
        // Silently fail - not critical
      }
    }
  }

  Widget _buildSectionTitle(
    BuildContext context,
    String title, {
    VoidCallback? onSeeAll,
  }) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16.0, 16.0, 8.0, 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: Theme.of(
              context,
            ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
          ),
          if (onSeeAll != null)
            TextButton(
              onPressed: onSeeAll,
              child: Text(
                ref.watch(localizationProvider).getString('homeSeeAll'),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildLoadingIndicator() =>
      const Center(heightFactor: 2, child: CircularProgressIndicator());
  Widget _buildErrorWidget(String error) => Center(
        heightFactor: 2,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            "Error:\n$error",
            style: const TextStyle(color: Colors.red),
            textAlign: TextAlign.center,
          ),
        ),
      );
  Widget _buildEmptyList(String message) => Center(
        heightFactor: 2,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            message,
            style: const TextStyle(color: Colors.grey),
            textAlign: TextAlign.center,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final l10n = ref.watch(localizationProvider);
    final isVisible = ref.watch(isVisibleProvider);
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) {
      return Scaffold(
        body: Center(child: Text(l10n.getString('generalError'))),
      );
    }

    // Use helper (not ref.watch) — helper itself will watch the connectivityProvider safely.
    final isOnline = connectivityProviderChecker(ref) ?? true;

    ref.watch(matchNotificationProvider);

    final profileState = ref.watch(userProfileProvider(userId));
    final dashboardStats = ref.watch(dashboardStatsProvider);
    final recentMatchesAsync = ref.watch(recentMatchesProvider(userId));
    final recentChatsAsync = ref.watch(recentChatsProvider(userId));

    return RefreshIndicator(
      onRefresh: () async {
        await appConfigService.refresh();
        ref.invalidate(appConfigProvider);
        ref.invalidate(externalAdsEnabledProvider);
        ref.invalidate(internalAdsEnabledProvider);
        ref.invalidate(externalAdServiceProvider);
        ref.invalidate(adMediationServiceProvider);
        ref.invalidate(dashboardStatsProvider);

        await Future.wait([
          ref.read(appConfigProvider.notifier).refresh(),
          ref
              .read(localizationProvider.notifier)
              .syncLanguageAfterLogin(),
          ref.read(themeModeProvider.notifier).refreshFromRemote(),
          ref.read(userPreferencesProvider.notifier).refresh(),
          ref.read(subscriptionProvider.notifier).refreshStatus(),
          ref.read(isVisibleProvider.notifier).refreshFromLocalAndRemote(),
          ref
              .read(profileSyncProvider)
              .syncProfile(userId, source: 'home-pull-to-refresh'),
        ]);

        ref.invalidate(userProfileProvider(userId));
        ref.invalidate(recentMatchesProvider(userId));
        ref.invalidate(recentChatsProvider(userId));
      },
      child: ListView(
        children: [
          Padding(
            padding: const EdgeInsets.only(
              left: 16.0,
              right: 16.0,
              bottom: 10.0,
            ),
            child: profileState.when(
              data: (profile) {
                final userName = profile?.name.split(' ').first ?? 'User';
                final String welcomeText;
                if (isUsersBirthdayToday(
                  dateOfBirth: profile?.dateOfBirth,
                  userTimezone: profile?.userTimezone,
                )) {
                  welcomeText = '${l10n.getString('happyBirthday')}, $userName!';
                } else {
                  final greeting = localizedGreeting(l10n, DateTime.now(), gender: profile?.gender);
                  welcomeText = '${greeting.replaceAll(RegExp(r'[!,]*$'), '').trim()}, $userName!';
                }
                return Text(
                  welcomeText,
                  style: Theme.of(context).textTheme.headlineSmall,
                );
              },
              loading: () => const SizedBox.shrink(),
              error: (e, s) => const SizedBox.shrink(),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 8.0,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                if (isOnline && isVisible)
                  dashboardStats.when(
                    data: (stats) => _buildStatCard(
                      context,
                      Icons.radar_outlined,
                      "${stats['nearby'] ?? 0}",
                      l10n.getString('homeNearby'),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const NearbyMapScreen()),
                        );
                      },
                    ),
                    loading: () => _buildStatCard(
                      context,
                      Icons.radar_outlined,
                      "...",
                      l10n.getString('homeNearby'),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const NearbyMapScreen()),
                        );
                      },
                    ),
                    error: (e, s) => _buildStatCard(
                      context,
                      Icons.radar_outlined,
                      "0",
                      l10n.getString('homeNearby'),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const NearbyMapScreen()),
                        );
                      },
                    ),
                  ),
                if (isOnline)
                  dashboardStats.when(
                    data: (stats) => _buildStatCard(
                      context,
                      Icons.people_outline,
                      "${stats['online'] ?? 0}",
                      l10n.getString('homeOnline'),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const OnlineWorldMapScreen()),
                        );
                      },
                    ),
                    loading: () => _buildStatCard(
                      context,
                      Icons.people_outline,
                      "...",
                      l10n.getString('homeOnline'),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const OnlineWorldMapScreen()),
                        );
                      },
                    ),
                    error: (e, s) => _buildStatCard(
                      context,
                      Icons.people_outline,
                      "0",
                      l10n.getString('homeOnline'),
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const OnlineWorldMapScreen()),
                        );
                      },
                    ),
                  ),
                profileState.when(
                  data: (p) {
                    final tierKey =
                        'tier${p?.subscriptionTier.capitalize() ?? 'Free'}';
                    return _SubscriptionTierCard(
                      profile: p,
                      tierKey: tierKey,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => const PaywallScreen()),
                        );
                      },
                    );
                  },
                  loading: () => _buildStatCard(
                    context,
                    Icons.star_border_outlined,
                    "...",
                    l10n.getString('homeTier'),
                  ),
                  error: (e, s) => _buildStatCard(
                    context,
                    Icons.error_outline,
                    "Error",
                    l10n.getString('homeTier'),
                  ),
                ),
              ],
            ),
          ),
          recentMatchesAsync.when(
            data: (matches) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildSectionTitle(
                    context,
                    l10n.getString('homeRecentMatches'),
                    onSeeAll: () {
                      ref.read(navigationIndexProvider.notifier).setIndex(1);
                    },
                  ),
                  if (matches.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20.0),
                      child: _buildEmptyList(l10n.getString('homeNoMatches')),
                    )
                  else
                    MatchBoxList(
                      matches: matches,
                      showTitle: false,
                    ),
                ],
              );
            },
            loading: _buildLoadingIndicator,
            error: (e, s) => _buildErrorWidget(e.toString()),
          ),
          _buildSectionTitle(
            context,
            l10n.getString('homeRecentChats'),
            onSeeAll: () {
              ref.read(navigationIndexProvider.notifier).setIndex(2);
            },
          ),
          recentChatsAsync.when(
            data: (chats) {
              if (chats.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20.0),
                  child: _buildEmptyList(l10n.getString('homeNoChats')),
                );
              }
              return Column(
                children: chats
                    .map(
                      (chat) => ChatListItem(
                        chat: chat,
                        showUnreadBorder: true,
                      ),
                    )
                    .toList(),
              );
            },
            loading: _buildLoadingIndicator,
            error: (e, s) => _buildErrorWidget(e.toString()),
          ),
          const SizedBox(height: 10),
          Builder(
            builder: (context) {
              return const AdSlot(placement: AdPlacement.homeInline);
            },
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

/// Helper to safely read connectivity provider value (used in build)
bool? connectivityProviderChecker(WidgetRef ref) {
  try {
    return ref.watch(connectivityProvider).value;
  } catch (_) {
    return true;
  }
}
