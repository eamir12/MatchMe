import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/chat_key_provider.dart';
import 'package:matchme/services/chat_key_service.dart';
import 'package:matchme/services/chat_recovery_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatRecoveryScreen extends ConsumerStatefulWidget {
  const ChatRecoveryScreen({super.key});

  @override
  ConsumerState<ChatRecoveryScreen> createState() => _ChatRecoveryScreenState();
}

class _ChatRecoveryScreenState extends ConsumerState<ChatRecoveryScreen> {
  final ChatRecoveryService _recoveryService = ChatRecoveryService.instance;
  final ChatKeyService _chatKeyService = ChatKeyService.instance;

  String? _recoveryCode;
  bool _isLoading = false;
  bool _showConfirmation = false;
  final _confirmationController = TextEditingController();
  String? _confirmationError;

  @override
  void dispose() {
    _confirmationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chatKeyState = ref.watch(chatKeyProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat Recovery Key'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (_recoveryCode != null) ...[
              _buildRecoveryCodeSection(),
            ] else if (chatKeyState.hasRecoveryKey) ...[
              _buildExistingKeyInfo(),
            ] else ...[
              _buildNoKeyInfo(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildRecoveryCodeSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Your Chat Recovery Key',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 8),
        Text(
          'Save this key somewhere safe. You will need it to access your '
          'encrypted messages on a new device or after resetting your password.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey.shade700,
              ),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.grey.shade100,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey.shade300),
          ),
          child: SelectableText(
            _recoveryCode!,
            style: const TextStyle(
              fontFamily: 'monospace',
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _copyToClipboard,
                icon: const Icon(Icons.copy),
                label: const Text('Copy'),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _shareCode,
                icon: const Icon(Icons.share),
                label: const Text('Share'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        if (_showConfirmation) ...[
          Text(
            'Confirm your recovery key',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 8),
          Text(
            'Enter the last 8 characters of your recovery key to confirm you saved it.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Colors.grey.shade600,
                ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _confirmationController,
            decoration: InputDecoration(
              hintText: 'Last 8 characters',
              border: const OutlineInputBorder(),
              errorText: _confirmationError,
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: _isLoading ? null : _confirmRecoveryKey,
            child: _isLoading
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('Confirm'),
          ),
        ] else ...[
          ElevatedButton(
            onPressed: () => setState(() => _showConfirmation = true),
            child: const Text('I have saved my recovery key'),
          ),
        ],
      ],
    );
  }

  Widget _buildExistingKeyInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Recovery Key Status',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.green, size: 20),
            const SizedBox(width: 8),
            const Text('Your recovery key is saved on this device.'),
          ],
        ),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _showExistingRecoveryKey,
          child: const Text('Show Recovery Key'),
        ),
      ],
    );
  }

  Widget _buildNoKeyInfo() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'No Recovery Key',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 8),
        Text(
          'You do not have a chat recovery key yet. Set up encrypted chat '
          'to generate one.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey.shade700,
              ),
        ),
      ],
    );
  }

  void _copyToClipboard() {
    if (_recoveryCode != null) {
      Clipboard.setData(ClipboardData(text: _recoveryCode!));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Recovery key copied to clipboard')),
      );
    }
  }

  void _shareCode() {
    if (_recoveryCode != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Share not implemented yet')),
      );
    }
  }

  Future<void> _confirmRecoveryKey() async {
    final input = _confirmationController.text.trim().replaceAll('-', '');
    if (_recoveryCode == null) return;

    final expected = _recoveryCode!
        .replaceAll('MMRK1-', '')
        .replaceAll('-', '');
    final last8 = expected.substring(expected.length - 8);

    if (!input.endsWith(last8) && input != last8) {
      setState(() => _confirmationError = 'Incorrect. Please try again.');
      return;
    }

    setState(() {
      _isLoading = true;
      _confirmationError = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser!.id;
      await _chatKeyService.setRecoveryConfirmed(userId, true);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Recovery key confirmed'),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _confirmationError = 'Failed to confirm. Try again.');
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _showExistingRecoveryKey() async {
    setState(() => _isLoading = true);
    try {
      final userId = Supabase.instance.client.auth.currentUser!.id;
      final crkBytes = await _chatKeyService.loadCrkBytes(userId);
      if (crkBytes != null) {
        setState(() {
          _recoveryCode = _recoveryService.generateRecoveryCode(crkBytes);
          _showConfirmation = false;
        });
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('No recovery key found on this device')),
          );
        }
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }
}
