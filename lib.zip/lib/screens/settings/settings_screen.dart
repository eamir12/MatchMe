// lib/screens/settings/settings_screen.dart
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/currency_provider.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/providers/visibility_provider.dart';
import 'package:matchme/providers/profile_provider.dart';
import 'package:matchme/services/app_config_service.dart';
import 'package:matchme/services/session_service.dart';
import '../../providers/main_intents_provider.dart';
import '../../providers/translation_version_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/providers/unit_provider.dart';
import 'package:matchme/utils/unit_utils.dart';
import 'dart:ui' as ui;
import 'package:matchme/services/local_db_service.dart';
import 'package:matchme/screens/settings/invisibility_rules_screen.dart';
import 'package:matchme/screens/settings/gender_age_preferences_screen.dart';
import 'package:matchme/screens/settings/email_change_screen.dart';
import 'package:matchme/screens/settings/sensitive_action_verification.dart';
import 'package:matchme/screens/paywall/paywall_screen.dart';
import 'package:matchme/screens/referral/invite_friends_screen.dart';
import 'package:matchme/screens/profile/verification_screen.dart';
import 'package:matchme/screens/subscription/billing_screen.dart';
import 'package:matchme/providers/user_preferences_provider.dart';
import 'package:matchme/utils/permission_coordinator.dart';
import 'package:matchme/providers/theme_provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:matchme/services/error_localization_service.dart';
import 'package:matchme/utils/resume_route_restore.dart';
import 'package:matchme/utils/offline_utils.dart';
import 'package:matchme/widgets/currency_picker_bottom_sheet.dart';
import 'package:matchme/screens/settings/chat_recovery_screen.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key, this.scrollToInvisibilityRules = false});

  final bool scrollToInvisibilityRules;

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> with WidgetsBindingObserver {
  static const Duration _mfaStatusTimeout = Duration(seconds: 8);
  late String _currentUserId;
  final ScrollController _scrollController = ScrollController();
  final GlobalKey _invisibilityRulesKey = GlobalKey();
  Future<_MfaStatus>? _mfaStatusRequest;
  _MfaStatus _lastKnownMfaStatus = const _MfaStatus(
    hasVerifiedTotp: false,
    currentSessionVerified: false,
    primaryFactorId: null,
    recoveryCodesRemaining: 0,
  );
  StreamSubscription<AuthState>? _authSubscription;
  bool? _lastKnownOnlineState;
  OverlayEntry? _mfaProgressOverlay;

  bool _passwordHasMinLength(String value) => value.length >= 8;
  bool _passwordHasUppercase(String value) => value.contains(RegExp(r'[A-Z]'));
  bool _passwordHasLowercase(String value) => value.contains(RegExp(r'[a-z]'));
  bool _passwordHasNumber(String value) => value.contains(RegExp(r'\d'));
  bool _passwordHasSpecialCharacter(String value) =>
      value.contains(RegExp(r'[@$!%*?&]'));

  bool _isValidNewPassword(String value) =>
      _passwordHasMinLength(value) &&
      _passwordHasUppercase(value) &&
      _passwordHasLowercase(value) &&
      _passwordHasNumber(value) &&
      _passwordHasSpecialCharacter(value);

  Widget _buildPasswordRequirementRow(
    BuildContext context, {
    required bool met,
    required String label,
  }) {
    final theme = Theme.of(context);
    final color = met ? Colors.green.shade700 : Colors.grey.shade600;
    return Row(
      children: [
        Icon(
          met ? Icons.check_circle : Icons.radio_button_unchecked,
          size: 18,
          color: color,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(color: color),
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _currentUserId = Supabase.instance.client.auth.currentUser!.id;
    
    // Validate High Accuracy Mode permission when settings screen is opened
    if (!kIsWeb && Platform.isAndroid) {
      Future.microtask(() async {
        try {
          await ref
              .read(userPreferencesProvider.notifier)
              .syncHighAccuracyModePermissionState();
        } catch (e) {
          print('Failed to validate High Accuracy Mode permission: $e');
        }
      });
    }
    
    _authSubscription = Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      switch (data.event) {
        case AuthChangeEvent.signedIn:
        case AuthChangeEvent.userUpdated:
        case AuthChangeEvent.mfaChallengeVerified:
          if (mounted) {
            _refreshMfaStatus();
          }
          break;
        default:
          break;
      }
    });
    Future.microtask(() async {
      await ref.read(profileEditProvider(_currentUserId).notifier).loadInitialProfile();
      if (widget.scrollToInvisibilityRules) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          final context = _invisibilityRulesKey.currentContext;
          if (context != null) {
            Scrollable.ensureVisible(context, duration: const Duration(milliseconds: 500), alignment: 0.1);
          }
        });
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _authSubscription?.cancel();
    _hideMfaProgressOverlay();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    // Validate permission when app resumes from background
    if (state == AppLifecycleState.resumed && !kIsWeb && Platform.isAndroid) {
      Future.microtask(() async {
        try {
          await ref
              .read(userPreferencesProvider.notifier)
              .syncHighAccuracyModePermissionState();
        } catch (e) {
          print('Failed to validate High Accuracy Mode permission: $e');
        }
      });
    }
  }

  void _showSnackBar(String message, {required bool isError}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red : Colors.green,
      ),
    );
  }

  void _showMfaProgressOverlay(LocalizationState l10n) {
    if (!mounted || _mfaProgressOverlay != null) return;
    final overlayState = Overlay.of(context, rootOverlay: true);

    _mfaProgressOverlay = OverlayEntry(
      builder: (context) {
        final theme = Theme.of(context);
        final colors = theme.colorScheme;
        return Stack(
          children: [
            ModalBarrier(
              dismissible: false,
              color: Colors.black.withValues(alpha: 0.35),
            ),
            Center(
              child: Material(
                color: Colors.transparent,
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 320),
                  margin: const EdgeInsets.symmetric(horizontal: 24),
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: colors.surface,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: theme.shadowColor.withValues(alpha: 0.18),
                        blurRadius: 20,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 16),
                      Text(
                        l10n.getString('settingsMfaVerifySensitiveAction'),
                        textAlign: TextAlign.center,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: colors.onSurface,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        l10n.getString('generalLoadingDots'),
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colors.onSurface.withValues(alpha: 0.74),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );

    overlayState.insert(_mfaProgressOverlay!);
  }

  void _hideMfaProgressOverlay() {
    _mfaProgressOverlay?.remove();
    _mfaProgressOverlay = null;
  }

  void _refreshMfaStatus() {
    // Re-load MFA status when needed (e.g., after password change)
    _mfaStatusRequest = null;
  }

  void _refreshPasskeyEnrollmentState() {
    // Refresh passkey state when needed
  }

  _MfaStatus _fallbackMfaStatus() {
    return _MfaStatus(
      hasVerifiedTotp: _lastKnownMfaStatus.hasVerifiedTotp,
      currentSessionVerified: _readAccessTokenClaim('aal') == 'aal2',
      primaryFactorId: _lastKnownMfaStatus.primaryFactorId,
      recoveryCodesRemaining: _lastKnownMfaStatus.recoveryCodesRemaining,
    );
  }

  void _refreshPasskeyStateAfterReconnect() {
    unawaited(() async {
      try {
        await appConfigService.refresh();
      } catch (error) {
        print(
          '⚠️ [Settings] Failed to refresh app config after reconnect: $error',
        );
      }

      if (!mounted) return;
      _refreshPasskeyEnrollmentState();
    }());
  }

  String _readAccessTokenClaim(String claim) {
    try {
      final token = Supabase.instance.client.auth.currentSession?.accessToken;
      if (token == null || token.isEmpty) return '';
      final parts = token.split('.');
      if (parts.length != 3) return '';
      final normalized = base64Url.normalize(parts[1]);
      final payload = jsonDecode(utf8.decode(base64Url.decode(normalized)));
      if (payload is! Map<String, dynamic>) return '';
      final value = payload[claim];
      return value?.toString().trim() ?? '';
    } catch (_) {
      return '';
    }
  }

  String _normalizeFactorStatus(dynamic status) {
    return status?.toString().split('.').last.toLowerCase().trim() ?? '';
  }

  int _readRecoveryCodeCount(dynamic value) {
    if (value is num) return value.toInt();
    if (value is String) return int.tryParse(value.trim()) ?? 0;
    return 0;
  }

  String? _currentUserEmail() {
    final email = Supabase.instance.client.auth.currentUser?.email?.trim();
    if (email == null || email.isEmpty) return null;
    return email;
  }

  Future<_MfaStatus> _loadMfaStatus({bool forceRefresh = false}) {
    if (!forceRefresh && _mfaStatusRequest != null) {
      return _mfaStatusRequest!;
    }

    final request = () async {
      try {
        final factors = await Supabase.instance.client.auth.mfa
            .listFactors()
            .timeout(_mfaStatusTimeout);
        Object? recoveryStatus;
        try {
          recoveryStatus = await Supabase.instance.client
              .rpc('get_mfa_recovery_code_status')
              .timeout(_mfaStatusTimeout);
        } catch (error) {
          print('Settings MFA recovery status refresh skipped: $error');
        }
        final verifiedTotp = factors.totp.where((factor) {
          return _normalizeFactorStatus((factor as dynamic).status) == 'verified';
        }).toList(growable: false);
        final primaryFactor = verifiedTotp.isNotEmpty ? verifiedTotp.first as dynamic : null;
        final primaryFactorId = primaryFactor?.id?.toString().trim();
        final recoveryCodesRemaining = recoveryStatus is Map
            ? _readRecoveryCodeCount(recoveryStatus['available_count'])
            : 0;

        final status = _MfaStatus(
          hasVerifiedTotp: verifiedTotp.isNotEmpty,
          currentSessionVerified: _readAccessTokenClaim('aal') == 'aal2',
          primaryFactorId: primaryFactorId != null && primaryFactorId.isNotEmpty ? primaryFactorId : null,
          recoveryCodesRemaining: recoveryCodesRemaining,
        );
        _lastKnownMfaStatus = status;
        return status;
      } catch (error) {
        print('Settings MFA status refresh skipped: $error');
        return _fallbackMfaStatus();
      }
    }();

    _mfaStatusRequest = request.whenComplete(() {
      if (identical(_mfaStatusRequest, request)) {
        _mfaStatusRequest = null;
      }
    });
    return _mfaStatusRequest!;
  }

  Future<bool> _ensureMfaVerifiedForSensitiveAction(LocalizationState l10n) async {
    return ensureSensitiveActionVerified(
      context: context,
      l10n: l10n,
      isMounted: () => mounted,
      getCurrentUserEmail: _currentUserEmail,
      loadStatus: () async {
        final status = await _loadMfaStatus(forceRefresh: true);
        return SensitiveActionVerificationStatus(
          primaryFactorId: status.primaryFactorId,
          hasVerifiedTotp: status.hasVerifiedTotp,
        );
      },
      showProgressOverlay: () => _showMfaProgressOverlay(l10n),
      hideProgressOverlay: _hideMfaProgressOverlay,
      refreshStatus: _refreshMfaStatus,
      showSnackBar: _showSnackBar,
      logDebug: (message) => print(message),
    );
  }

  Future<bool> _ensureOnlineForAccountAction(LocalizationState l10n) async {
    final isOnline = ref.read(connectivityProvider).value ?? true;
    if (isOnline) return true;

    await showOfflineFeatureDialog(
      context,
      title: '',
      message: l10n.getString('offlineSensitiveActionsRequireInternet'),
      ref: ref,
    );
    return false;
  }

  Future<void> _showChangePasswordDialog(LocalizationState l10n) async {
    final isOnline = await _ensureOnlineForAccountAction(l10n);
    if (!isOnline || !mounted) return;
    final canProceed = await _ensureMfaVerifiedForSensitiveAction(l10n);
    if (!canProceed || !mounted) return;
    final newPasswordController = TextEditingController();
    final confirmPasswordController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool isLoading = false;
    bool obscureNew = true;
    bool obscureConfirm = true;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setState) {
            return Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minWidth: MediaQuery.of(context).size.width * 0.6,
                  maxWidth: MediaQuery.of(context).size.width * 0.95,
                ),
                child: AlertDialog(
                  title: Text(l10n.getString('settingsChangePassword')),
                  content: SingleChildScrollView(
                    child: ConstrainedBox(
                      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.75),
                      child: Form(
                        key: formKey,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              l10n.getString('settingsPasswordReauthBody'),
                              style: Theme.of(context).textTheme.bodyMedium,
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: newPasswordController,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontFeatures: const []),
                              decoration: InputDecoration(
                                label: Text(l10n.getString('settingsNewPassword')),
                                suffixIcon: IconButton(
                                  icon: Icon(obscureNew ? Icons.visibility_off : Icons.visibility),
                                  onPressed: () => setState(() => obscureNew = !obscureNew),
                                ),
                              ),
                              onChanged: (_) => setState(() {}),
                              obscureText: obscureNew,
                              validator: (v) {
                                if (v == null || v.isEmpty) return l10n.getString('authPasswordRequired');
                                if (!_isValidNewPassword(v)) {
                                  return l10n.getString('authPasswordRequirementsTitle');
                                }
                                return null;
                              },
                            ),
                            const SizedBox(height: 12),
                            DecoratedBox(
                              decoration: BoxDecoration(
                                color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: Theme.of(context).dividerColor,
                                ),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      l10n.getString('authPasswordRequirementsTitle'),
                                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                            fontWeight: FontWeight.w600,
                                          ),
                                    ),
                                    const SizedBox(height: 10),
                                    _buildPasswordRequirementRow(
                                      context,
                                      met: _passwordHasMinLength(newPasswordController.text),
                                      label: l10n.getString('authPasswordRuleMinLength'),
                                    ),
                                    const SizedBox(height: 6),
                                    _buildPasswordRequirementRow(
                                      context,
                                      met: _passwordHasUppercase(newPasswordController.text),
                                      label: l10n.getString('authPasswordRuleUppercase'),
                                    ),
                                    const SizedBox(height: 6),
                                    _buildPasswordRequirementRow(
                                      context,
                                      met: _passwordHasLowercase(newPasswordController.text),
                                      label: l10n.getString('authPasswordRuleLowercase'),
                                    ),
                                    const SizedBox(height: 6),
                                    _buildPasswordRequirementRow(
                                      context,
                                      met: _passwordHasNumber(newPasswordController.text),
                                      label: l10n.getString('authPasswordRuleNumber'),
                                    ),
                                    const SizedBox(height: 6),
                                    _buildPasswordRequirementRow(
                                      context,
                                      met: _passwordHasSpecialCharacter(newPasswordController.text),
                                      label: l10n.getString('authPasswordRuleSpecial'),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            TextFormField(
                              controller: confirmPasswordController,
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontFeatures: const []),
                              decoration: InputDecoration(
                                label: Text(l10n.getString('settingsConfirmNewPassword')),
                                suffixIcon: IconButton(
                                  icon: Icon(obscureConfirm ? Icons.visibility_off : Icons.visibility),
                                  onPressed: () => setState(() => obscureConfirm = !obscureConfirm),
                                ),
                              ),
                              obscureText: obscureConfirm,
                              validator: (v) {
                                if (v != newPasswordController.text) return l10n.getString('settingsPasswordMismatch');
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(dialogContext),
                      child: Text(l10n.getString('generalCancel')),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                      onPressed: isLoading
                          ? null
                          : () async {
                              if (!formKey.currentState!.validate()) return;
                              setState(() => isLoading = true);
                              try {
                                await Supabase.instance.client.auth.updateUser(
                                  UserAttributes(
                                    password: newPasswordController.text,
                                  ),
                                );
                                if (!mounted) return;
                                Navigator.of(this.context).pop();
                                ScaffoldMessenger.of(this.context).showSnackBar(
                                  SnackBar(
                                    content: Text(l10n.getString('settingsPasswordChanged')),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                              } catch (_) {
                                if (!mounted) return;
                                ScaffoldMessenger.of(this.context).showSnackBar(
                                  SnackBar(
                                    content: Text(
                                      l10n.getString('settingsPasswordChangeFailed'),
                                    ),
                                    backgroundColor: Colors.red,
                                  ),
                                );
                              } finally {
                                if (mounted) setState(() => isLoading = false);
                              }
                            },
                      child: isLoading
                          ? const CircularProgressIndicator()
                          : Text(l10n.getString('generalSave')),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _showDeleteAccountDialog(LocalizationState l10n) async {
    final isOnline = await _ensureOnlineForAccountAction(l10n);
    if (!isOnline || !mounted) return;
    final canProceed = await _ensureMfaVerifiedForSensitiveAction(l10n);
    if (!canProceed || !mounted) return;
    showDialog(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(l10n.getString('settingsDeleteAccount')),
          content: Text(l10n.getString('settingsDeleteAccountConfirm')),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(l10n.getString('generalCancel')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                final currentContext = context;
                final currentL10n = l10n;
                Navigator.pop(dialogContext);
                
                // Check if user is authenticated
                final currentUser = Supabase.instance.client.auth.currentUser;
                if (currentUser == null) {
                  if (mounted) {
                    ScaffoldMessenger.of(currentContext).showSnackBar(
                      SnackBar(content: Text(currentL10n.getString('settingsDeleteAccountFailed')), backgroundColor: Colors.red),
                    );
                  }
                  return;
                }

                // Get the current session token
                final session = Supabase.instance.client.auth.currentSession;
                if (session == null || session.accessToken.isEmpty) {
                  if (mounted) {
                    ScaffoldMessenger.of(currentContext).showSnackBar(
                      SnackBar(content: Text(currentL10n.getString('settingsDeleteAccountFailed')), backgroundColor: Colors.red),
                    );
                  }
                  return;
                }

                try {
                  // Call the delete-account Supabase function with explicit headers
                  final response = await Supabase.instance.client.functions.invoke(
                    'delete-account',
                    headers: {
                      'Authorization': 'Bearer ${session.accessToken}',
                    },
                  );

                  if (response.status == 200 || response.status == 404) {
                    // Success: either account deleted (200) or user already doesn't exist (404)
                    // Clear local storage and sign out
                    try {
                      // Sign out from Supabase (this will clear the session)
                      // Note: This might fail with 403 if user was already deleted from auth
                      await Supabase.instance.client.auth.signOut().catchError((error) {
                        // Continue anyway - the session will be cleared when app restarts
                      });
                      
                      // Clear all local database (Hive boxes)
                      final localDb = await LocalDbService.instance;
                      await localDb.clearDatabase();

                      // Try to revoke sessions before sign out (best-effort)
                      try {
                        final user = Supabase.instance.client.auth.currentUser;
                        if (user != null) {
                          await Supabase.instance.client.rpc('revoke_all_user_sessions', params: {'p_user_id': user.id});
                        }
                      } catch (e) {
                        print('revoke_all_user_sessions failed: $e');
                      }

                      // Clear other cached data if needed
                      // Note: Riverpod providers will be reset when the app restarts

                    } catch (clearError) {
                      // Continue anyway - the account is deleted from server or user doesn't exist
                    }
                    
                    if (mounted) {
                      final message = response.status == 200 
                        ? l10n.getString('settingsAccountDeleted')
                        : l10n.getString('settingsAccountAlreadyDeleted');
                      ScaffoldMessenger.of(currentContext).showSnackBar( // ignore: use_build_context_synchronously
                        SnackBar(
                          content: Text(message),
                          backgroundColor: Colors.green,
                        ),
                      );
                      // Pop all routes to return to the root screen
                      // The auth state will automatically show the login screen when session is cleared
                      Navigator.of(currentContext).popUntil((route) => route.isFirst); // ignore: use_build_context_synchronously
                    }
                  } else {
                    final errorMessage = response.data?['error'] ?? 'Unknown error (status: ${response.status})';
                    throw Exception(errorMessage);
                  }
                } catch (e) {
                  if (mounted) {
                    final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
                    ScaffoldMessenger.of(currentContext).showSnackBar( // ignore: use_build_context_synchronously
                      SnackBar(content: Text('${currentL10n.getString('settingsDeleteAccountFailed')}: ${currentL10n.getString(errorKey)}'), backgroundColor: Colors.red),
                    );
                  }
                }
              },
              child: Text(l10n.getString('settingsDeleteAccount')),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = ref.watch(localizationProvider);
    final profileEditState = ref.watch(profileEditProvider(_currentUserId));
    // Ensure language options are watched so the dropdown renders and stays stable
    final languageOptionsAsync = ref.watch(languageOptionsProvider);
    final isOnline = ref.watch(connectivityProvider.select((state) => state.value ?? true));
    final useImperialAsync = ref.watch(unitSystemProvider);
    final prefs = ref.watch(userPreferencesProvider);
    final preferredCurrencyAsync = ref.watch(effectiveUserCurrencyProvider.select((state) => state.asData?.value ?? 'USD'));
    final preferredCurrency = preferredCurrencyAsync;
    final prioritizedCurrenciesAsync = ref.watch(prioritizedCurrencyCodesProvider.select((state) => state.asData?.value ?? const <String>[]));
    final prioritizedCurrencies = prioritizedCurrenciesAsync;
    final allCurrencyOptions = ref.watch(allCurrencyOptionsProvider);

    final hasConnectivityChanged = _lastKnownOnlineState != isOnline;
    final cameBackOnline = _lastKnownOnlineState == false && isOnline;
    if (hasConnectivityChanged) {
      _lastKnownOnlineState = isOnline;
      if (cameBackOnline) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          _refreshPasskeyStateAfterReconnect();
        });
      }
    }

    // Compute an immediate, synchronous value to avoid UI flicker while the
    // async provider resolves (useful when switching to System preference).
    final effectiveUseImperial = useImperialAsync.maybeWhen(
      data: (v) => v,
      orElse: () {
        final unitPref = prefs.unitSystem;
        if (unitPref == UnitSystemPreference.imperial) return true;
        if (unitPref == UnitSystemPreference.metric) return false;
        // System: derive from device locale immediately when possible.
        final deviceCountry = ui.PlatformDispatcher.instance.locale.countryCode ?? '';
        if (deviceCountry.isNotEmpty) return usesImperialUnitsByCountry(deviceCountry);
        return false;
      },
    );

    // Theme-aware helpers
    final theme = Theme.of(context);
    final colors = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.getString('settingsTitle')),
        actions: [
          if (!isOnline)
            Container(
              margin: const EdgeInsets.only(right: 8.0),
              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
              decoration: BoxDecoration(
                color: colors.primaryContainer,
                borderRadius: BorderRadius.circular(8.0),
              ),
              child: Row(
                children: [
                  Icon(Icons.wifi_off, size: 14, color: colors.onPrimaryContainer),
                  const SizedBox(width: 4),
                  Text(
                    l10n.getString('generalOffline'),
                    style: TextStyle(color: colors.onPrimaryContainer, fontSize: 12),
                  ),
                ],
              ),
            ),
        ],
      ),
      body: SafeArea(child: profileEditState.when(
        data: (profile) {
          if (profile == null) return Center(child: Text(l10n.getString('generalErrorLoadingProfile')));

          return ListView(
            controller: _scrollController,
            padding: const EdgeInsets.all(16.0),
            children: [
              // App Display Section
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: theme.shadowColor.withValues(alpha: 0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: colors.primary.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.settings_display, color: colors.primary, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          l10n.getString('settingsAppDisplay'),
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: colors.onSurface,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    languageOptionsAsync.when(
                      data: (languages) {
                        // Build dropdown items with disabled state for non-cached languages
                        final items = <DropdownMenuItem<String>>[];
                        
                        for (final lang in languages) {
                          final langCode = lang['code'] as String;
                          final display = lang['display'] as String;
                          final isCached = (lang['cached'] as bool?) ?? true; // Default to cached
                          final isAvailableOffline =
                              (lang['availableOffline'] as bool?) ?? isCached;
                          final isOffline = (lang['offline'] as bool?) ?? false;
                          
                          final canUseNow = !isOffline || isAvailableOffline;
                          
                          items.add(
                            DropdownMenuItem<String>(
                              value: langCode,
                              child: Row(
                                children: [
                                  Text(
                                    display,
                                    style: TextStyle(
                                      color: canUseNow ? null : Colors.grey.shade400,
                                      fontWeight: !canUseNow ? FontWeight.normal : null,
                                    ),
                                  ),
                                  if (!canUseNow)
                                    Padding(
                                      padding: const EdgeInsets.only(left: 8.0),
                                      child: Icon(Icons.lock_outline, size: 16, color: Colors.grey.shade400),
                                    ),
                                ],
                              ),
                            ),
                          );
                        }
                        
                        return DropdownButtonFormField<String>(
                          key: ValueKey(l10n.currentLocale.languageCode),
                          initialValue: l10n.currentLocale.languageCode,
                          decoration: InputDecoration(
                            labelText: l10n.getString('profileAppLanguage'),
                            prefixIcon: Icon(Icons.language_outlined, color: colors.primary),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: theme.dividerColor),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: theme.dividerColor),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: colors.primary, width: 2),
                            ),
                            filled: true,
                            fillColor: colors.surface,
                          ),
                          items: items,
                          onChanged: (value) async {
                            if (value == null) return;
                            
                            // Check if this language is not cached and we're offline
                            final selectedLang = languages.firstWhere((l) => l['code'] == value);
                            final isCached = (selectedLang['cached'] as bool?) ?? true;
                            final isAvailableOffline =
                                (selectedLang['availableOffline'] as bool?) ?? isCached;
                            final isOffline = (selectedLang['offline'] as bool?) ?? false;
                            
                            if (!isAvailableOffline && isOffline && mounted) {
                              // Show dialog explaining why this language can't be selected
                              await showDialog<void>(
                                context: context,
                                builder: (BuildContext ctx) => AlertDialog(
                                  icon: const Icon(Icons.cloud_off_rounded, size: 32, color: Colors.orange),
                                  title: Text(l10n.getString('offlineLanguageUnavailableTitle')),
                                  content: Text(l10n.getString('offlineLanguageUnavailableMessage')),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.of(ctx).pop(),
                                      child: Text(l10n.getString('offlineOkButton')),
                                    ),
                                  ],
                                ),
                              );
                              return;
                            }

                            final localizationNotifier =
                                ref.read(localizationProvider.notifier);

                            await localizationNotifier.setLocale(value);
                            if (!mounted) return;

                            // Persist the user's preferred language on their
                            // profile when we can reach Supabase.
                            if (!isOffline) {
                              try {
                                ref
                                    .read(
                                      profileEditProvider(
                                        _currentUserId,
                                      ).notifier,
                                    )
                                    .updatePreferredLanguage(value);
                              } catch (_) {}
                            }
                            if (!mounted) return;

                            // Force per-message translation providers to re-run.
                            ref
                                .read(translationVersionProvider.notifier)
                                .increment();
                          },
                        );
                      },
                      loading: () => const LinearProgressIndicator(),
                      error: (e,s) => Text(l10n.getString('generalError')),
                    ),

                    const SizedBox(height: 16),

                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () async {
                        final picked = await showCurrencyPickerBottomSheet(
                          context: context,
                          l10n: l10n,
                          selectedCurrency: preferredCurrency,
                          recentCurrencyCodes: prefs.recentCurrencies,
                          prioritizedCurrencyCodes: prioritizedCurrencies,
                          allCurrencyOptions: allCurrencyOptions,
                        );
                        if (picked == null || !context.mounted) return;
                        await ref
                            .read(userPreferencesProvider.notifier)
                            .setPreferredCurrency(picked);
                      },
                      child: InputDecorator(
                        decoration: InputDecoration(
                          labelText: l10n.getString('settingsCurrencyPreference'),
                          prefixIcon: Icon(
                            Icons.currency_exchange_outlined,
                            color: colors.primary,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: theme.dividerColor),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: theme.dividerColor),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                            borderSide: BorderSide(color: colors.primary, width: 2),
                          ),
                          filled: true,
                          fillColor: colors.surface,
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    currencySelectedLabel(
                                      preferredCurrency,
                                      localeCode: l10n.currentLocale.languageCode,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Icon(
                              Icons.arrow_drop_down,
                              color: colors.onSurfaceVariant,
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Units preference (system/metric/imperial)
                    DropdownButtonFormField<UnitSystemPreference>(
                      key: ValueKey(prefs.unitSystem),
                      initialValue: prefs.unitSystem,
                      decoration: InputDecoration(
                        labelText: l10n.getString('settingsUnits'),
                        prefixIcon: Icon(Icons.straighten_outlined, color: colors.primary),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: theme.dividerColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: theme.dividerColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: colors.primary, width: 2),
                        ),
                        filled: true,
                        fillColor: colors.surface,
                      ),
                      items: [
                        DropdownMenuItem(
                          value: UnitSystemPreference.system,
                          child: Text(l10n.getString('settingsUnitsSystem')),
                        ),
                        DropdownMenuItem(
                          value: UnitSystemPreference.metric,
                          child: Text(l10n.getString('settingsUnitsMetric')),
                        ),
                        DropdownMenuItem(
                          value: UnitSystemPreference.imperial,
                          child: Text(l10n.getString('settingsUnitsImperial')),
                        ),
                      ],
                      onChanged: (value) {
                        if (value == null) return;
                        ref.read(userPreferencesProvider.notifier).setUnitSystem(value);
                      },
                    ),

                    const SizedBox(height: 16),

                    // Time format preference (system/24h/12h)
                    DropdownButtonFormField<TimeFormatPreference>(
                      key: ValueKey(prefs.timeFormat),
                      initialValue: prefs.timeFormat,
                      decoration: InputDecoration(
                        labelText: l10n.getString('settingsTimeFormat'),
                        prefixIcon: Icon(Icons.schedule_outlined, color: colors.primary),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: theme.dividerColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: theme.dividerColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: colors.primary, width: 2),
                        ),
                        filled: true,
                        fillColor: colors.surface,
                      ),
                      items: [
                        DropdownMenuItem(
                          value: TimeFormatPreference.system,
                          child: Text(l10n.getString('settingsTimeFormatSystem')),
                        ),
                        DropdownMenuItem(
                          value: TimeFormatPreference.h24,
                          child: Text(l10n.getString('settingsTimeFormat24')),
                        ),
                        DropdownMenuItem(
                          value: TimeFormatPreference.h12,
                          child: Text(l10n.getString('settingsTimeFormat12')),
                        ),
                      ],
                      onChanged: (value) {
                        if (value == null) return;
                        ref.read(userPreferencesProvider.notifier).setTimeFormat(value);
                      },
                    ),

                    const SizedBox(height: 16),

                    // Theme mode (System / Light / Dark)
                    DropdownButtonFormField<ThemeMode>(
                      key: ValueKey(ref.watch(themeModeProvider)),
                      initialValue: ref.watch(themeModeProvider),
                      decoration: InputDecoration(
                        labelText: l10n.getString('settingsThemeMode'),
                        prefixIcon: Icon(Icons.dark_mode_outlined, color: colors.primary),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: theme.dividerColor),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: theme.dividerColor),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: colors.primary, width: 2),
                        ),
                        filled: true,
                        fillColor: colors.surface,
                      ),
                      items: [
                        DropdownMenuItem(value: ThemeMode.system, child: Text(l10n.getString('settingsThemeModeSystem'))),
                        DropdownMenuItem(value: ThemeMode.light, child: Text(l10n.getString('settingsThemeModeLight'))),
                        DropdownMenuItem(value: ThemeMode.dark, child: Text(l10n.getString('settingsThemeModeDark'))),
                      ],
                      onChanged: (mode) {
                        if (mode == null) return;
                        ref.read(themeModeProvider.notifier).setThemeMode(mode);
                      },
                    ),
                  ],
                ),
              ),

              // Matching Section
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: theme.shadowColor.withValues(alpha: 0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: colors.secondary.withValues(alpha: 0.08),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.favorite_border, color: colors.secondary, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          l10n.getString('settingsMatching'),
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: colors.onSurface,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    FutureBuilder<List<int>>(
                      future: appConfigService.getIntList(
                        'profile.match_radius_options_km',
                        defaultValue: [5, 10, 20, 100]
                      ),
                      builder: (context, snapshot) {
                        final allowedRadii = snapshot.data ?? [5, 10, 20, 100];
                        final currentRadius = profile.matchRadiusDefault;
                        final radii = Set<int>.from(allowedRadii)..add(currentRadius);
                        final sortedRadii = radii.toList()..sort();
                        return DropdownButtonFormField<int>(
                          key: ValueKey(currentRadius),
                          initialValue: currentRadius,
                          decoration: InputDecoration(
                            labelText: l10n.getString('settingsRadius'),
                            prefixIcon: Icon(Icons.radar_outlined, color: colors.secondary),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: theme.dividerColor),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: theme.dividerColor),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: colors.secondary, width: 2),
                            ),
                            filled: true,
                            fillColor: colors.surface,
                          ),
                          items: sortedRadii.map((radius) => DropdownMenuItem(
                            value: radius,
                            child: Text(formatDistanceWithImperial(radius.toDouble(), effectiveUseImperial, l10n)),
                          )).toList(),
                          onChanged: (value) async {
                            if (value != null && allowedRadii.contains(value)) {
                              try {
                                await ref.read(profileEditProvider(_currentUserId).notifier).updateRadius(value);
                              } catch (e) {
                                if (!mounted) return;
                                final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
                                ScaffoldMessenger.of(this.context).showSnackBar(
                                  SnackBar(content: Text('${l10n.getString('settingsRadiusUpdateFailed')}: ${l10n.getString(errorKey)}'), backgroundColor: Colors.red),
                                );
                              }
                            }
                          },
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    FutureBuilder<List<int>>(
                      future: appConfigService.getIntList(
                        'gps.interval_options_seconds',
                        defaultValue: [5, 10, 20, 30, 60]
                      ),
                      builder: (context, snapshot) {
                        final allowedRates = snapshot.data ?? [5, 10, 20, 30, 60];
                        final currentRate = profile.gpsIntervalDefault;
                        final rates = Set<int>.from(allowedRates)..add(currentRate);
                        final sortedRates = rates.toList()..sort();
                        return DropdownButtonFormField<int>(
                          key: ValueKey(currentRate),
                          initialValue: currentRate,
                          decoration: InputDecoration(
                            labelText: l10n.getString('settingsGpsRate'),
                            prefixIcon: Icon(Icons.timer_outlined, color: colors.tertiary),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: theme.dividerColor),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: theme.dividerColor),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide(color: colors.tertiary, width: 2),
                            ),
                            filled: true,
                            fillColor: colors.surface,
                          ),
                          items: sortedRates.map((rate) => DropdownMenuItem(
                            value: rate,
                            child: Text('${rate.toString()} ${l10n.getString('settingsGpsRateUnit')}'),
                          )).toList(),
                          onChanged: (value) async {
                             if (value != null && allowedRates.contains(value)) {
                               try {
                                 await ref.read(profileEditProvider(_currentUserId).notifier).updateGpsRate(value);
                                 // updateGpsRate() already directly notifies VisibilityNotifier and triggers immediate location update
                                 if (!mounted) return;
                                 // ignore: use_build_context_synchronously
                                 ScaffoldMessenger.of(this.context).showSnackBar(
                                     SnackBar(content: Text(l10n.getString('settingsGpsRateUpdated')), backgroundColor: Colors.green),
                                   );
                               } catch (e) {
                                 if (!mounted) return;
                                 final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
                                 // ignore: use_build_context_synchronously
                                 ScaffoldMessenger.of(this.context).showSnackBar(
                                     SnackBar(content: Text('${l10n.getString('settingsGpsRateUpdateFailed')}: ${l10n.getString(errorKey)}'), backgroundColor: Colors.red),
                                   );
                               }
                             }
                           },
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            l10n.getString('settingsHighAccuracyMode'),
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: colors.onSurface,
                            ),
                          ),
                        ),
                        Switch(
                          value: prefs.highAccuracyMode,
                          onChanged: (value) async {
                            // On Android 14+, High Accuracy Mode requires background location permission
                            if (value && !kIsWeb && Platform.isAndroid) {
                              if (!context.mounted) return;
                              final hasBackgroundLocation = await PermissionCoordinator.hasBackgroundLocationPermission();
                              if (!hasBackgroundLocation && context.mounted) {
                                // Request background location permission
                                final granted = await PermissionCoordinator.requestBackgroundLocationPermission(context, ref);
                                if (!granted) {
                                  // Permission not granted, don't enable High Accuracy Mode
                                  return;
                                }
                              }
                            }
                            if (context.mounted) {
                              await ref.read(userPreferencesProvider.notifier).setHighAccuracyMode(value);
                            }
                          },
                          activeThumbColor: Theme.of(context).colorScheme.tertiary,
                          activeTrackColor: Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.3),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.only(left: 4.0, right: 8.0),
                      child: Text(
                        kIsWeb
                            ? l10n.getString('settingsHighAccuracyModeDesc_web')
                            : (defaultTargetPlatform == TargetPlatform.android
                                ? l10n.getString('settingsHighAccuracyModeDesc_android')
                                : (defaultTargetPlatform == TargetPlatform.iOS
                                    ? l10n.getString('settingsHighAccuracyModeDesc_ios')
                                    : l10n.getString('settingsHighAccuracyModeDesc'))),
                        style: TextStyle(fontSize: 12, color: colors.onSurface.withAlpha((0.6 * 255).round())),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            l10n.getString('settingsSmartGpsThrottling'),
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: colors.onSurface,
                            ),
                          ),
                        ),
                        Switch(
                          value: profile.smartGpsThrottlingEnabled,
                          onChanged: (value) async {
                            try {
                              await ref.read(profileEditProvider(_currentUserId).notifier).updateSmartGpsThrottling(value);
                              // Update the location stream interval to apply throttling changes immediately
                              await ref.read(isVisibleProvider.notifier).updateLocationStreamInterval();
                              if (!mounted) return;
                              ScaffoldMessenger.of(this.context).showSnackBar(
                                SnackBar(content: Text(l10n.getString('settingsSmartGpsThrottlingUpdated')), backgroundColor: Theme.of(this.context).colorScheme.primary),
                              );
                            } catch (e) {
                              if (!mounted) return;
                              final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
                              ScaffoldMessenger.of(this.context).showSnackBar(
                                SnackBar(content: Text('${l10n.getString('settingsSmartGpsThrottlingUpdateFailed')}: ${l10n.getString(errorKey)}'), backgroundColor: Colors.red),
                              );
                            }
                          },
                          activeThumbColor: Theme.of(context).colorScheme.tertiary,
                          activeTrackColor: Theme.of(context).colorScheme.tertiary.withValues(alpha:0.3),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Padding(
                      padding: const EdgeInsets.only(left: 4.0, right: 8.0),
                      child: Text(
                        l10n.getString('settingsSmartGpsThrottlingDesc'),
                        style: TextStyle(fontSize: 12, color: colors.onSurface.withAlpha((0.6 * 255).round())),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            l10n.getString('settingsSharedEventMatching'),
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: colors.onSurface,
                            ),
                          ),
                        ),
                        Switch(
                          value: profile.sharedEventMatchingEnabled,
                          onChanged: (value) async {
                            try {
                              await ref.read(profileEditProvider(_currentUserId).notifier).updateSharedEventMatching(value);
                              if (!mounted) return;
                              ScaffoldMessenger.of(this.context).showSnackBar(
                                SnackBar(content: Text(l10n.getString('settingsSharedEventMatchingUpdated')), backgroundColor: Colors.green),
                              );
                            } catch (e) {
                              if (!mounted) return;
                              final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
                              ScaffoldMessenger.of(this.context).showSnackBar(
                                SnackBar(content: Text('${l10n.getString('settingsSharedEventMatchingUpdateFailed')}: ${l10n.getString(errorKey)}'), backgroundColor: Theme.of(this.context).colorScheme.error),
                              );
                            }
                          },
                          activeThumbColor: Theme.of(context).colorScheme.secondary,
                          activeTrackColor: Theme.of(context).colorScheme.secondary.withValues(alpha:0.3),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            l10n.getString('settingsSharedMovementMatching'),
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: colors.onSurface,
                            ),
                          ),
                        ),
                        Switch(
                          value: profile.sharedMovementMatchingEnabled,
                          onChanged: (value) async {
                            try {
                              await ref.read(profileEditProvider(_currentUserId).notifier).updateSharedMovementMatching(value);
                              if (!mounted) return;
                              ScaffoldMessenger.of(this.context).showSnackBar(
                                SnackBar(content: Text(l10n.getString('settingsSharedMovementMatchingUpdated')), backgroundColor: Colors.green),
                              );
                            } catch (e) {
                              if (!mounted) return;
                              final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
                              ScaffoldMessenger.of(this.context).showSnackBar(
                                SnackBar(content: Text('${l10n.getString('settingsSharedMovementMatchingUpdateFailed')}: ${l10n.getString(errorKey)}'), backgroundColor: Theme.of(this.context).colorScheme.error),
                              );
                            }
                          },
                          activeThumbColor: Theme.of(context).colorScheme.secondary,
                          activeTrackColor: Theme.of(context).colorScheme.secondary.withValues(alpha:0.3),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // Gender and Age Preferences Section - Navigate to dedicated screen
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const GenderAgePreferencesScreen()),
                    );
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.05),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Theme.of(context).colorScheme.primary.withValues(alpha:0.2)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.people_alt_outlined, color: Theme.of(context).colorScheme.primary, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n.getString('settingsGenderAgePreferences'),
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                l10n.getString('settingsGenderAgePreferencesDesc'),
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha:0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(Icons.arrow_forward_ios, color: Theme.of(context).colorScheme.primary, size: 16),
                      ],
                    ),
                  ),
                ),
              ),

              // Invisibility Rules Section - Navigate to dedicated screen
              Container(
                key: _invisibilityRulesKey,
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const InvisibilityRulesScreen()),
                    );
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.05),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Theme.of(context).colorScheme.primary.withValues(alpha:0.2)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.visibility_off, color: Theme.of(context).colorScheme.primary, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n.getString('settingsInvisibilityRules'),
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                l10n.getString('settingsInvisibilityRulesDesc'),
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha:0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Theme.of(context).colorScheme.primary,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Notifications Settings Section - Navigate to dedicated screen
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    Navigator.of(
                      context,
                    ).pushNamed(ResumeRouteRestore.notificationsSettingsRoute);
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.05),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Theme.of(context).colorScheme.primary.withValues(alpha:0.2)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.notifications_outlined, color: Theme.of(context).colorScheme.primary, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n.getString('settingsNotifications'),
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                l10n.getString('settingsNotificationsSettingsDesc'),
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha:0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Theme.of(context).colorScheme.primary,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              FutureBuilder<List<bool>>(
                future: Future.wait([
                  appConfigService.isSubscriptionEnabled(),
                  appConfigService.isInviteFriendsEnabled(),
                ]),
                builder: (context, snapshot) {
                  final showSubscription = snapshot.data?[0] ?? true;
                  final showInviteFriends = snapshot.data?[1] ?? true;

                  return Column(
                    children: [
                      if (showSubscription)
                        Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const PaywallScreen()),
                              );
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.12),
                                    Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.06),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.25)),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).colorScheme.tertiary.withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(
                                      Icons.workspace_premium_outlined,
                                      color: Theme.of(context).colorScheme.tertiary,
                                      size: 28,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          l10n.getString('paywallTitle'),
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Theme.of(context).colorScheme.tertiary,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          l10n.getString('paywallFeaturesTitle'),
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    color: Theme.of(context).colorScheme.tertiary,
                                    size: 20,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      if (showSubscription)
                        Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => const BillingScreen(),
                                ),
                              );
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Theme.of(context).colorScheme.secondary.withValues(alpha: 0.12),
                                    Theme.of(context).colorScheme.secondary.withValues(alpha: 0.06),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Theme.of(context).colorScheme.secondary.withValues(alpha: 0.25)),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).colorScheme.secondary.withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(
                                      Icons.receipt_long_outlined,
                                      color: Theme.of(context).colorScheme.secondary,
                                      size: 28,
                                    ),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          l10n.getString('billingTitle'),
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Theme.of(context).colorScheme.secondary,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          l10n.getString('billingSettingsDescription'),
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    color: Theme.of(context).colorScheme.secondary,
                                    size: 20,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      if (showInviteFriends)
                        Container(
                          margin: const EdgeInsets.only(bottom: 8),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => const InviteFriendsScreen()),
                              );
                            },
                            borderRadius: BorderRadius.circular(16),
                            child: Container(
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
                                    Theme.of(context).colorScheme.primary.withValues(alpha: 0.05),
                                  ],
                                ),
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.2)),
                              ),
                              child: Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.1),
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(Icons.card_giftcard, color: Theme.of(context).colorScheme.primary, size: 28),
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          l10n.getString('inviteFriendsTitle'),
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            color: Theme.of(context).colorScheme.primary,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          l10n.getString('inviteFriendsDescription'),
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Icon(
                                    Icons.arrow_forward_ios,
                                    color: Theme.of(context).colorScheme.primary,
                                    size: 20,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),

              Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap:
                      profile.isVerified
                          ? null
                          : () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => const VerificationScreen()),
                            );
                          },
                  borderRadius: BorderRadius.circular(16),
                  child: Opacity(
                    opacity: profile.isVerified ? 0.8 : 1,
                    child: Builder(
                      builder: (context) {
                        final status =
                            profile.isVerified ? 'approved' : profile.verificationStatus;

                        Color accentColor;
                        IconData leadingIcon;
                        String title;
                        String subtitle;

                        switch (status) {
                          case 'approved':
                            accentColor = Colors.green;
                            leadingIcon = Icons.verified;
                            title = l10n.getString('verified');
                            subtitle = l10n.getString('verifiedDescription');
                            break;
                          case 'pending':
                            accentColor = Colors.orange;
                            leadingIcon = Icons.pending;
                            title = l10n.getString('underReview');
                            subtitle = l10n.getString('underReviewDescription');
                            break;
                          case 'analyzing':
                            accentColor = Colors.blue;
                            leadingIcon = Icons.hourglass_top;
                            title = l10n.getString('analyzingPhotos');
                            subtitle = l10n.getString('analyzingPhotosDescription');
                            break;
                          case 'rejected':
                            accentColor = colors.error;
                            leadingIcon = Icons.error;
                            title = l10n.getString('verificationRejected');
                            subtitle = l10n.getString('verificationNotApproved');
                            break;
                          default:
                            accentColor = Theme.of(context).colorScheme.primary;
                            leadingIcon = Icons.verified_outlined;
                            title = l10n.getString('profileVerification');
                            subtitle =
                                profile.verificationSubmittedAt == null
                                    ? l10n.getString('getVerifiedToBuildTrust')
                                    : l10n.getString('notVerifiedDescription');
                        }

                        return Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                accentColor.withValues(alpha: 0.1),
                                accentColor.withValues(alpha: 0.05),
                              ],
                            ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: accentColor.withValues(alpha: 0.2),
                            ),
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: accentColor.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(
                                  leadingIcon,
                                  color: accentColor,
                                  size: 28,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      title,
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: accentColor,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      subtitle,
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 12),
                              Icon(
                                profile.isVerified ? Icons.check_circle : Icons.arrow_forward_ios,
                                color: accentColor,
                                size: 20,
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),

              // Security & Sign-In Hub Button
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    Navigator.of(
                      context,
                    ).pushNamed(ResumeRouteRestore.securityCenterRoute);
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                          Theme.of(context).colorScheme.primary.withValues(alpha:0.05),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Theme.of(context).colorScheme.primary.withValues(alpha:0.2)),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.security, color: Theme.of(context).colorScheme.primary, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                l10n.getString('securitySignInHubTitle'),
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                l10n.getString('securitySignInHubDescription'),
                                style: TextStyle(
                                  fontSize: 13,
                                  color: Theme.of(context).colorScheme.onSurface.withValues(alpha:0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Theme.of(context).colorScheme.primary,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Chat Encryption
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const ChatRecoveryScreen(),
                      ),
                    );
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: colors.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: theme.dividerColor),
                    ),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primary.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.lock_outline, color: Theme.of(context).colorScheme.primary, size: 28),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Chat Encryption',
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: colors.onSurface,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Secure your messages with end-to-end encryption',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: colors.onSurface.withValues(alpha:0.7),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 12),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: colors.onSurface.withValues(alpha:0.7),
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),

              // Account Management (Change Password + Delete Account)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: colors.surface,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: theme.shadowColor.withValues(alpha: 0.05),
                      blurRadius: 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Colors.red.withValues(alpha:0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(Icons.person, color: colors.error, size: 20),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          l10n.getString('settingsAccountManagement'),
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: colors.onSurface,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: isOnline
                            ? () => _showChangePasswordDialog(l10n)
                            : null,
                        icon: const Icon(Icons.edit),
                        label: Text(l10n.getString('settingsChangePassword')),
                        style: ElevatedButton.styleFrom(
                          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Theme.of(context).colorScheme.onPrimary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: isOnline
                            ? () async {
                                final navigator = Navigator.of(context);
                                final isOnline =
                                    await _ensureOnlineForAccountAction(l10n);
                                if (!isOnline || !mounted) return;
                                final canProceed =
                                    await _ensureMfaVerifiedForSensitiveAction(
                                      l10n,
                                    );
                                if (!canProceed || !mounted) return;
                                await navigator.push(
                                  MaterialPageRoute(
                                    builder: (context) =>
                                        const EmailChangeScreen(),
                                  ),
                                );
                              }
                            : null,
                        icon: const Icon(Icons.email),
                        label: Text(l10n.getString('settingsChangeEmailTitle')),
                        style: ElevatedButton.styleFrom(
                          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Theme.of(context).colorScheme.onPrimary,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: isOnline
                            ? () => _showDeleteAccountDialog(l10n)
                            : null,
                        icon: const Icon(Icons.delete_forever),
                        label: Text(l10n.getString('settingsDeleteAccount')),
                        style: ElevatedButton.styleFrom(
                          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          backgroundColor: Theme.of(context).colorScheme.error,
                          foregroundColor: Theme.of(context).colorScheme.onError,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                    ),
                    if (!isOnline) ...[
                      const SizedBox(height: 12),
                      SensitiveActionsOfflineNotice(
                        message: l10n.getString(
                          'offlineSensitiveActionsRequireInternet',
                        ),
                      ),
                    ],

                  ],
                ),
              ),

            ],
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, s) => Center(child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('${l10n.getString('generalError')}: ${l10n.getString(ErrorLocalizationService.getErrorTranslationKey(e))}', textAlign: TextAlign.center),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                onPressed: () => ref.read(profileEditProvider(_currentUserId).notifier).loadInitialProfile(),
                child: Text(l10n.getString('generalRetry')),
              )
            ],
          ),
        )),
      )),
    );
  }
}

class _MfaStatus {
  const _MfaStatus({
    required this.hasVerifiedTotp,
    required this.currentSessionVerified,
    required this.primaryFactorId,
    required this.recoveryCodesRemaining,
  });

  final bool hasVerifiedTotp;
  final bool currentSessionVerified;
  final String? primaryFactorId;
  final int recoveryCodesRemaining;
}

class _MfaEnrollDialog extends StatefulWidget {
  const _MfaEnrollDialog({required this.l10n});

  final LocalizationState l10n;

  @override
  State<_MfaEnrollDialog> createState() => _MfaEnrollDialogState();
}

class _MfaEnrollDialogState extends State<_MfaEnrollDialog> {
  final TextEditingController _codeController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isInitializing = true;
  bool _isSubmitting = false;
  bool _completed = false;
  String? _factorId;
  String? _secret;
  String? _qrCodeSvg;
  String? _errorText;

  String get _accountLabel {
    final user = Supabase.instance.client.auth.currentUser;
    final email = user?.email?.trim();
    if (email != null && email.isNotEmpty) {
      return email.replaceAll(':', ' ');
    }
    final phone = user?.phone?.trim();
    if (phone != null && phone.isNotEmpty) {
      return phone.replaceAll(':', ' ');
    }
    return (user?.id ?? 'user').replaceAll(':', ' ');
  }

  String? get _otpauthUri {
    final secret = _secret?.trim();
    if (secret == null || secret.isEmpty) return null;
    final issuer = Uri.encodeQueryComponent('MatchMe');
    final label = Uri.encodeComponent('MatchMe:$_accountLabel');
    final normalizedSecret = secret.replaceAll(' ', '');
    return 'otpauth://totp/$label?secret=$normalizedSecret&issuer=$issuer&algorithm=SHA1&digits=6&period=30';
  }

  @override
  void initState() {
    super.initState();
    Future.microtask(_startEnrollment);
  }

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  Future<void> _startEnrollment() async {
    try {
      final response = await Supabase.instance.client.auth.mfa.enroll(
        factorType: FactorType.totp,
        issuer: 'MatchMe',
        friendlyName: 'MatchMe',
      );
      if (!mounted) return;
      final secret = response.totp?.secret;
      if (secret == null || secret.isEmpty) {
        throw StateError('Missing TOTP secret');
      }
      setState(() {
        _factorId = response.id;
        _secret = secret;
        _qrCodeSvg = response.totp?.qrCode;
        _isInitializing = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorText = widget.l10n.getString('settingsMfaEnrollmentFailed');
        _isInitializing = false;
      });
    }
  }

  Future<void> _cancel() async {
    final factorId = _factorId;
    if (!_completed && factorId != null && factorId.isNotEmpty) {
      try {
        await Supabase.instance.client.auth.mfa.unenroll(factorId);
      } catch (_) {
      }
    }
    if (!mounted) return;
    Navigator.of(context).pop(false);
  }

  Future<void> _copySecret() async {
    final secret = _secret;
    if (secret == null || secret.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: secret));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(widget.l10n.getString('settingsMfaCopied'))),
    );
  }

  Future<void> _openAuthenticatorApp() async {
    final otpauthUri = _otpauthUri;
    if (otpauthUri == null || otpauthUri.isEmpty) return;
    try {
      final launched = await launchUrl(
        Uri.parse(otpauthUri),
        mode: LaunchMode.externalApplication,
      );
      if (launched || !mounted) return;
    } catch (_) {
      if (!mounted) return;
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          widget.l10n.getString('settingsMfaOpenAuthenticatorFailed'),
        ),
      ),
    );
  }

  Future<void> _verify() async {
    if (!_formKey.currentState!.validate()) return;
    final factorId = _factorId;
    if (factorId == null || factorId.isEmpty) {
      setState(() {
        _errorText = widget.l10n.getString('settingsMfaEnrollmentFailed');
      });
      return;
    }

    setState(() {
      _isSubmitting = true;
      _errorText = null;
    });

    try {
      await Supabase.instance.client.auth.mfa.challengeAndVerify(
        factorId: factorId,
        code: _codeController.text.trim(),
      );
      _completed = true;
      await SessionService.syncCurrentSessionMfaVerified(forceValue: true);
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorText = widget.l10n.getString('settingsMfaVerificationFailed');
      });
    } finally {
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final showDirectOpenButton = !kIsWeb;

    return AlertDialog(
      title: Text(widget.l10n.getString('settingsMfaSetupTitle')),
      content: SizedBox(
        width: 420,
        child: _isInitializing
            ? const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              )
            : SingleChildScrollView(
                child: Form(
                  key: _formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(widget.l10n.getString('settingsMfaSetupBody')),
                      if (showDirectOpenButton) ...[
                        const SizedBox(height: 16),
                        FilledButton.tonalIcon(
                          onPressed: _openAuthenticatorApp,
                          icon: const Icon(Icons.open_in_new),
                          label: Text(
                            widget.l10n.getString(
                              'settingsMfaOpenAuthenticator',
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.l10n.getString(
                            'settingsMfaOpenAuthenticatorBody',
                          ),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                      if ((_qrCodeSvg ?? '').isNotEmpty) ...[
                        const SizedBox(height: 20),
                        Text(
                          widget.l10n.getString('settingsMfaQrTitle'),
                          style: theme.textTheme.titleSmall?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            border: Border.all(color: theme.dividerColor),
                            borderRadius: BorderRadius.circular(16),
                            color: theme.colorScheme.surfaceContainerHighest
                                .withValues(alpha: 0.35),
                          ),
                          child: Center(
                            child: SvgPicture.string(
                              _qrCodeSvg!,
                              width: 180,
                              height: 180,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          widget.l10n.getString('settingsMfaQrBody'),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                      const SizedBox(height: 20),
                      Text(
                        widget.l10n.getString('settingsMfaManualEntryTitle'),
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        widget.l10n.getString('settingsMfaManualEntryBody'),
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        widget.l10n.getString('settingsMfaSecret'),
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          border: Border.all(color: theme.dividerColor),
                          borderRadius: BorderRadius.circular(12),
                          color: theme.colorScheme.surfaceContainerHighest
                              .withValues(alpha: 0.5),
                        ),
                        child: SelectableText(_secret ?? ''),
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton.icon(
                        onPressed: _copySecret,
                        icon: const Icon(Icons.copy),
                        label: Text(
                          widget.l10n.getString('settingsMfaCopySecret'),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _codeController,
                        keyboardType: TextInputType.number,
                        autofillHints: const [AutofillHints.oneTimeCode],
                        decoration: InputDecoration(
                          label: Text(widget.l10n.getString('settingsMfaCode')),
                          errorText: _errorText,
                        ),
                        validator: (value) {
                          final code = value?.trim() ?? '';
                          if (!RegExp(r'^\d{6}$').hasMatch(code)) {
                            return widget.l10n.getString('settingsMfaEnterCode');
                          }
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
      ),
      actions: [
        TextButton(
          onPressed: _isSubmitting ? null : _cancel,
          child: Text(widget.l10n.getString('generalCancel')),
        ),
        ElevatedButton(
          onPressed: _isInitializing || _isSubmitting ? null : _verify,
          child: _isSubmitting
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : Text(widget.l10n.getString('generalContinue')),
        ),
      ],
    );
  }
}
