// lib/screens/profile/profile_screen.dart
// Complete ProfileScreen updated to show ordered photo thumbnails (tap to preview full-screen),
// bio, languages, and all previous functionality preserved.

import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'dart:ui' as ui;
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/providers/profile_provider.dart';
import 'package:matchme/screens/profile/profile_wizard_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/providers/new_options_provider.dart';
import 'package:matchme/providers/main_intents_provider.dart';
import 'package:matchme/widgets/signed_image.dart';
import 'package:extended_image/extended_image.dart';
import 'package:matchme/services/storage_helper.dart';
import 'package:matchme/utils/string_extensions.dart';
import 'package:matchme/widgets/verified_badge.dart';
import 'package:matchme/widgets/new_user_badge.dart';
import 'package:matchme/providers/match_rating_provider.dart';
import 'package:matchme/services/match_rating_service.dart';
import 'package:matchme/widgets/ad_slot.dart';
import 'package:matchme/models/sponsored_ad.dart';

final supabase = Supabase.instance.client;

String _normalizeKey(String s) {
  final trimmed = s.trim().toLowerCase();
  final replaced = trimmed.replaceAll(RegExp(r'[^a-z0-9]+'), '_');
  final collapsed = replaced.replaceAll(RegExp(r'_+'), '_');
  return collapsed.replaceAll(RegExp(r'^_|_$'), '');
}

/// MatchMe4 - Profile Screen
/// Shows user's own profile with photos, bio, interests, etc.
class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {

  // Cache for resolved display labels to avoid repeated computations
  static final Map<String, String> _displayLabelCache = {};

  // Cache for new user badge check to avoid repeated computations
  bool? _isNewUserCached;

  String? _resolveLookupTranslationKey(
    Map<String, String>? lookup,
    String rawKey,
  ) {
    if (lookup == null || rawKey.trim().isEmpty) return null;
    for (final candidate in _translationLookupCandidates(rawKey)) {
      final match = lookup[candidate];
      if (match != null && match.trim().isNotEmpty) {
        return match;
      }
    }
    return null;
  }

  Iterable<String> _translationLookupCandidates(String rawKey) sync* {
    final seen = <String>{};

    void emit(String value) {
      final normalized = _normalizeKey(value);
      if (normalized.isNotEmpty && seen.add(normalized)) {
        // no-op: seen.add above ensures uniqueness while preserving insertion order
      }
    }

    void emitTokenVariants(List<String> tokens) {
      if (tokens.isEmpty) return;
      emit(tokens.join('_'));
      for (var i = 1; i < tokens.length; i++) {
        emit(tokens.sublist(i).join('_'));
      }
    }

    List<String> singularizeTokens(List<String> tokens) {
      String singularize(String token) {
        if (token.endsWith('ies') && token.length > 3) {
          return '${token.substring(0, token.length - 3)}y';
        }
        if (token.endsWith('ing') && token.length > 5) {
          final stem = token.substring(0, token.length - 3);
          if (stem.endsWith('v')) return '${stem}e';
          return stem;
        }
        if (token.endsWith('s') && token.length > 3) {
          return token.substring(0, token.length - 1);
        }
        return token;
      }

      return tokens.map(singularize).toList(growable: false);
    }

    emit(rawKey);
    if (rawKey.contains('::')) {
      final parts = rawKey.split('::');
      if (parts.length >= 2) {
        emit(parts.last);
      }
    }

    final normalized = _normalizeKey(rawKey);
    final parts = normalized
        .split(RegExp(r'[_.]'))
        .where((p) => p.isNotEmpty)
        .toList(growable: false);
    emitTokenVariants(parts);

    final tokensWithoutFillers = parts
        .where((token) => token != 'and' && token != 'with')
        .toList(growable: false);
    emitTokenVariants(tokensWithoutFillers);

    final singularTokens = singularizeTokens(parts);
    emitTokenVariants(singularTokens);

    final singularWithoutFillers = singularTokens
        .where((token) => token != 'and' && token != 'with')
        .toList(growable: false);
    emitTokenVariants(singularWithoutFillers);

    if (normalized == 'gym_buddies') {
      emit('gym');
      emit('fitness_gym');
      emit('interest.friendship.fitness.gym');
    } else if (normalized == 'hiking_trails') {
      emit('hiking');
      emit('outdoors_hiking');
      emit('interest.activity.outdoors.hiking');
      emit('interest.romantic.outdoors.hiking');
    } else if (normalized == 'traveling') {
      emit('travel');
      emit('interest.friendship.travel');
    } else if (normalized == 'dates') {
      emit('dating');
      emit('date');
    } else if (normalized == 'walks') {
      emit('walking');
      emit('walk');
    } else if (normalized == 'music_and_art') {
      emit('music_art');
      emit('arts_music');
      emit('art_music');
    } else if (normalized == 'study_and_learning') {
      emit('study_learning');
      emit('learning');
      emit('study');
    } else if (normalized == 'startup_founders') {
      emit('startups_founders');
      emit('founders');
      emit('interest.business.entrepreneurship.startups');
    } else if (normalized == 'skill_sharing') {
      emit('sharing_skills');
      emit('skills_sharing');
    }

    for (final value in seen) {
      yield value;
    }
  }

  Map<String, String> _buildTranslationLookup(
    Map<String, String> source,
  ) {
    final lookup = <String, String>{};
    for (final entry in source.entries) {
      final translationKey = entry.value.trim();
      if (translationKey.isEmpty) continue;
      for (final alias in _translationLookupCandidates(entry.key)) {
        lookup.putIfAbsent(alias, () => translationKey);
      }
      for (final alias in _translationLookupCandidates(translationKey)) {
        lookup.putIfAbsent(alias, () => translationKey);
      }
    }
    return lookup;
  }

  // Humanize a key as a last-resort fallback for display:
  String _humanizeKey(String key) {
    var s = key;
    s = s.replaceAll(RegExp(r'^(interest_category_|interest_|category_|subIntent|intent|profileEdit)'), '');
    s = s.replaceAll('_', ' ');
    s = s.replaceAllMapped(RegExp(r'([a-z])([A-Z])'), (m) => '${m[1]} ${m[2]}');
    final words = s.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    final human = words.map((w) {
      if (w.length <= 1) return w.toUpperCase();
      return w[0].toUpperCase() + w.substring(1);
    }).join(' ');

    final result = human.isEmpty ? key : human;
    return result;
  }

  bool _looksLikeTranslationKey(String value) {
    final normalized = value.trim();
    if (normalized.isEmpty) return false;
    return RegExp(r'^[A-Za-z0-9._-]+$').hasMatch(normalized);
  }

  // Safe wrapper for l10n.getString: returns null when translation not found
  String? _tryGetString(LocalizationState l10n, String key) {
    if (!_looksLikeTranslationKey(key)) {
      return null;
    }
    try {
      final val = l10n.getString(key);
      // Check if translation is missing (returns 'key...' format)
      if (val.trim().isEmpty || val == key || val.endsWith('...')) {
        return null;
      }
      return val;
    } catch (_) {
      return null;
    }
  }

  // Extract language code from localization provider currentLocale value
  String _extractLangCode(dynamic cur) {
    try {
      if (cur == null) return 'en';
      if (cur is Locale) return cur.languageCode;
      if (cur is String) return (cur.split(RegExp('[-_]')).first);
      return cur.toString().split(RegExp('[-_]')).first;
    } catch (_) {
      return 'en';
    }
  }

  // Format a DateTime using localization provider:
  String _formatDateWithL10n(DateTime date, LocalizationState l10n) {
    try {
      final cur = l10n.currentLocale;
      final langCode = _extractLangCode(cur).toLowerCase();

      if (langCode.startsWith('he')) {
        try {
          final df = DateFormat('EEEE, d MMMM y', 'he');
          return df.format(date);
        } catch (_) {}
      }

      final enMonthLower = DateFormat.MMMM('en_US').format(date).toLowerCase();
      final monthKey = 'month_$enMonthLower';
      final translatedMonth = _tryGetString(l10n, monthKey);
      if (translatedMonth != null) {
        return '$translatedMonth ${date.day}, ${date.year}';
      }

      try {
        final localeTag = cur.toLanguageTag();
        final df = localeTag.isNotEmpty ? DateFormat.yMMMMd(localeTag) : DateFormat.yMMMMd();
        return df.format(date);
      } catch (_) {}

      return DateFormat('MMMM d, yyyy').format(date);
    } catch (_) {
      return DateFormat('MMMM d, yyyy').format(date);
    }
  }

  // Calculate age from date of birth
  int _calculateAge(DateTime birthDate) {
    final now = DateTime.now();
    int age = now.year - birthDate.year;
    if (now.month < birthDate.month || (now.month == birthDate.month && now.day < birthDate.day)) {
      age--;
    }
    return age;
  }

  // Get age label for localization (same as profile wizard)
  String _ageLabelFor(LocalizationState l10n) {
    const ageKey = 'profileYourAge';
    try {
      final s = l10n.getString(ageKey);
      if (s.trim().isNotEmpty && s != ageKey && !s.startsWith('profile')) {
        return s;
      }
    } catch (_) {}
    final lang = _extractLangCode(l10n.currentLocale);
    if (lang.toLowerCase().startsWith('he')) return 'גילך';
    return 'Your age';
  }

  // Check if current language is RTL
  bool _isRtl(LocalizationState l10n) {
    final langCode = _extractLangCode(l10n.currentLocale);
    return ['ar', 'he'].contains(langCode.toLowerCase());
  }

  String _normalizeGenderDisplayKey(String raw) {
    final normalized = raw.trim().toLowerCase().replaceAll('-', '_');
    if (normalized.isEmpty) return normalized;
    if (normalized.startsWith('gender_')) return normalized;
    if (normalized == 'male' ||
        normalized == 'female' ||
        normalized == 'non_binary' ||
        normalized == 'nonbinary') {
      return normalized == 'nonbinary' ? 'gender_non_binary' : 'gender_$normalized';
    }
    return raw.trim();
  }

  // Resolve display label for a key or composite key into a user-friendly string.
  String _resolveDisplayLabel(
    LocalizationState l10n,
    String keyOrDisplay, {
    Map<String, String>? interestKeyToDisplayKey,
    Map<String, String>? categoryKeyToDisplayKey,
    Map<String, String>? allIntentsMap, // For sub-intents
  }) {
    // Create cache key from inputs
    final cacheKey = '$keyOrDisplay|${l10n.currentLocale.languageCode}|${l10n.translationSource}|${l10n.strings.length}|${interestKeyToDisplayKey?.length ?? 0}|${categoryKeyToDisplayKey?.length ?? 0}|${allIntentsMap?.length ?? 0}';
    if (_displayLabelCache.containsKey(cacheKey)) {
      return _displayLabelCache[cacheKey]!;
    }

    // Special case for invalid key "0"
    if (keyOrDisplay == '0') {
      final result = 'Unknown Intent';
      return result;
    }

    if (keyOrDisplay.trim().isEmpty) {
      return '';
    }

    if (keyOrDisplay.contains('::')) {
      final parts = keyOrDisplay.split('::');
      if (parts.length >= 2) {
        final left = parts[0];
        final right = parts.sublist(1).join('::'); // keep any extra separators

        final leftLocalized = _tryGetString(l10n, allIntentsMap?[left] ?? left) ?? _humanizeKey(left);
        String? rightLocalized;

        if (interestKeyToDisplayKey != null) {
          final mapped = interestKeyToDisplayKey[right];
          if (mapped != null && mapped.isNotEmpty) {
            rightLocalized = _tryGetString(l10n, mapped) ?? _humanizeKey(right);
          }
        }
        if ((rightLocalized == null || rightLocalized.trim().isEmpty) && categoryKeyToDisplayKey != null) {
          final mappedCat = categoryKeyToDisplayKey[right];
          if (mappedCat != null && mappedCat.isNotEmpty) {
            rightLocalized = _tryGetString(l10n, mappedCat) ?? _humanizeKey(right);
          }
        }

        rightLocalized = rightLocalized ?? _humanizeKey(right);
        final result = '$leftLocalized — $rightLocalized';
        _displayLabelCache[cacheKey] = result;
        return result;
      }
    }

    final resolvedIntentTranslationKey = _resolveLookupTranslationKey(
      allIntentsMap,
      keyOrDisplay,
    );
    if (resolvedIntentTranslationKey != null) {
      final mapped = resolvedIntentTranslationKey;
      final mappedLoc = _tryGetString(l10n, mapped);
      if (mappedLoc != null) {
        _displayLabelCache[cacheKey] = mappedLoc;
        return mappedLoc;
      }
      return _humanizeKey(keyOrDisplay);
    }

    final resolvedInterestTranslationKey = _resolveLookupTranslationKey(
      interestKeyToDisplayKey,
      keyOrDisplay,
    );
    if (resolvedInterestTranslationKey != null) {
      final mapped = resolvedInterestTranslationKey;
      final mappedLoc = _tryGetString(l10n, mapped);
      if (mappedLoc != null) {
        _displayLabelCache[cacheKey] = mappedLoc;
        return mappedLoc;
      }
      return _humanizeKey(keyOrDisplay);
    }

    final resolvedCategoryTranslationKey = _resolveLookupTranslationKey(
      categoryKeyToDisplayKey,
      keyOrDisplay,
    );
    if (resolvedCategoryTranslationKey != null) {
      final mapped = resolvedCategoryTranslationKey;
      final mappedLoc = _tryGetString(l10n, mapped);
      if (mappedLoc != null) {
        _displayLabelCache[cacheKey] = mappedLoc;
        return mappedLoc;
      }
      return _humanizeKey(keyOrDisplay);
    }

    final direct = _tryGetString(l10n, keyOrDisplay);
    if (direct != null) {
      _displayLabelCache[cacheKey] = direct;
      return direct;
    }

    return _humanizeKey(keyOrDisplay);
  }

  // Open a full-screen preview of the image source (objectPath or url)
  void _openPhotoPreview(BuildContext context, String source, LocalizationState l10n) async {
    ResolvedImageRequest? request;
    try {
      request = await StorageHelper.resolveImageRequest(
        source,
        ttlSeconds: 3600,
      );
    } catch (_) {
      request = ResolvedImageRequest(url: source);
    }

    final displayUrl = request?.url;
    if (displayUrl == null || displayUrl.isEmpty) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.getString('generalImageLoadFailed'))));
      }
      return;
    }

    if (context.mounted) {
      showDialog(
        context: context,
        builder: (_) => Dialog(
          insetPadding: const EdgeInsets.all(8.0),
          backgroundColor: Colors.black,
          child: SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: Stack(
              children: [
                if (kIsWeb)
                  Center(
                    child: Image.network(
                      displayUrl,
                      headers: null,
                      fit: BoxFit.contain,
                      webHtmlElementStrategy: WebHtmlElementStrategy.prefer,
                      loadingBuilder: (context, child, loadingProgress) {
                        if (loadingProgress == null) return child;
                        return const Center(
                          child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
                        );
                      },
                      errorBuilder: (context, error, stackTrace) {
                        return Center(
                          child: Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              l10n.getString('generalImageLoadFailed'),
                              style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        );
                      },
                    ),
                  )
                else
                  ExtendedImage.network(
                    displayUrl,
                    headers: request?.headers,
                    cache: true,
                    cacheKey: StorageHelper.cacheKeyForSource(source),
                    mode: ExtendedImageMode.gesture,
                    fit: BoxFit.contain,
                    initGestureConfigHandler: (_) => GestureConfig(
                      minScale: 1.0,
                      maxScale: 5.0,
                      animationMinScale: 0.8,
                      animationMaxScale: 6.0,
                      speed: 1.0,
                      inertialSpeed: 100.0,
                      initialScale: 1.0,
                      inPageView: false,
                    ),
                    loadStateChanged: (state) {
                      switch (state.extendedImageLoadState) {
                        case LoadState.loading:
                          return const Center(
                            child: SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2)),
                          );
                        case LoadState.completed:
                          return ExtendedRawImage(
                            image: state.extendedImageInfo?.image,
                            fit: BoxFit.contain,
                            width: double.infinity,
                            height: double.infinity,
                          );
                        case LoadState.failed:
                          return Center(
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Text(
                                l10n.getString('generalImageLoadFailed'),
                                style: TextStyle(color: Theme.of(context).colorScheme.onSurface),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          );
                      }
                    },
                  ),
                Positioned(
                  top: 24,
                  right: 8,
                  child: IconButton(
                    icon: Icon(Icons.close, color: Theme.of(context).colorScheme.onSurface),
                    onPressed: () => Navigator.of(context).maybePop(),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    print('[ProfileScreen] Build method called');
    final l10n = ref.watch(localizationProvider);
    final user = supabase.auth.currentUser;
    if (user == null) {
      return Scaffold(body: Center(child: Text(_t(l10n, 'generalError'))));
    }
    final userId = user.id;
    print('[ProfileScreen] User ID: $userId');

    final profileAsyncValue = ref.watch(userProfileProvider(userId));
    print('[ProfileScreen] Profile async value: $profileAsyncValue');
    if (profileAsyncValue.asData?.value != null) {
      print('[ProfileScreen] Profile createdAt: ${profileAsyncValue.asData!.value!.createdAt}');
      print('[ProfileScreen] Profile gender: ${profileAsyncValue.asData!.value!.gender}');
    }
    final allIntentsAsync = ref.watch(allIntentsProvider);
    final mainIntents = ref.watch(mainIntentsProvider);
    // Use the new provider to get only relevant interests for the selected intents
    final allIntents = allIntentsAsync.asData?.value ?? [];
    final allInterests = ref.watch(allInterestsProvider).asData?.value ?? [];
    final intentDisplayMap = _buildTranslationLookup({
      for (final intent in allIntents) intent.key: intent.translationKey,
    });
    final interestDisplayMap = _buildTranslationLookup({
      for (final interest in allInterests) interest.key: interest.translationKey,
    });
    final categoryDisplayMap = _buildTranslationLookup({
      for (final category in allInterests.where((i) => i.parentId == null || i.parentId == 0))
        category.key: category.translationKey,
    });
    return Scaffold(
      floatingActionButton: Builder(
        builder: (context) => FloatingActionButton.extended(
          heroTag: 'profile_edit_fab',
          onPressed: () {
            final currentUser = supabase.auth.currentUser;
            if (currentUser == null) {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_t(l10n, 'generalError'))));
              return;
            }
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ProfileWizardScreen(user: currentUser, isEditing: true),
              ),
            );
          },
          tooltip: _t(l10n, 'generalEdit'),
          backgroundColor: Theme.of(context).colorScheme.primary,
          foregroundColor: Theme.of(context).colorScheme.onPrimary,
          elevation: 6,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          icon: const Icon(Icons.edit_outlined),
          label: Text(_t(l10n, 'generalEdit')),
        ),
      ),
      body: Builder(
        builder: (context) => profileAsyncValue.when(
          data: (profile) {
            if (profile == null) {
              return Center(
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(l10n.getString('generalErrorLoadingProfile')),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: () => ref
                        .read(profileSyncProvider)
                        .syncProfile(userId, source: 'profile-screen-retry-empty'),
                    child: Text(_t(l10n, 'generalRetry')),
                  ),
                ]),
              );
            }

            return RefreshIndicator(
              onRefresh: () async => ref
                  .read(profileSyncProvider)
                  .syncProfile(userId, source: 'profile-screen-pull-to-refresh'),
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                children: [
                  // Photos: show thumbnails in order. If none, show placeholder.
                  if (profile.photos.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: SizedBox(
                        height: 140,
                        child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: profile.photos.length,
                        separatorBuilder: (_, _) => const SizedBox(width: 8),
                        itemBuilder: (ctx, i) {
                          final source = profile.photos[i];
                          return GestureDetector(
                            onTap: () => _openPhotoPreview(context, source, l10n),
                            child: Stack(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: SignedImage(
                                    source: source,
                                    width: 140,
                                    height: 140,
                                    fit: BoxFit.cover,
                                    placeholder: Container(
                                      width: 140,
                                      height: 140,
                                      color: Colors.grey.shade100,
                                    ),
                                    errorWidget: Container(
                                      width: 140,
                                      height: 140,
                                      color: Colors.grey.shade200,
                                      child: const Icon(
                                        Icons.broken_image,
                                        size: 36,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ),
                                ),
                                if (i == 0)
                                  Positioned(
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    child: Container(
                                      color: Colors.black54,
                                      padding: const EdgeInsets.symmetric(vertical: 2),
                                      child: Text(
                                        l10n.getString('profileWizardPrimaryPhotoBadge'),
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ),
                          );
                        },
                        ),
                      ),
                    )
                  else
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: SizedBox(
                        height: 140,
                        child: Center(child: Text(_t(l10n, 'profileNoPhotos'))),
                      ),
                    ),
                  
                  const SizedBox(height: 16),

                  // Name
                  (() {
                    final displayName = profile.name.trim();
                    final badges = <Widget>[];
                    if (profile.isVerified) {
                      // Use gender-specific translation key based on user's gender
                      final normalizedGender = profile.gender?.trim().toLowerCase();
                      final translationKey = normalizedGender == 'female'
                          ? 'profileVerifiedBadgeFemale'
                          : (normalizedGender == 'non_binary' || normalizedGender == 'nonbinary')
                              ? 'profileVerifiedBadgeNeutral'
                              : 'profileVerifiedBadge';
                      badges.add(VerifiedBadge(
                        size: 20,
                        showText: true,
                        text: _t(l10n, translationKey),
                      ));
                    }
                    // Check if user is new (under 1 week) - cache the result to avoid repeated computations
                    if (_isNewUserCached == null && profile.createdAt != null) {
                      final now = DateTime.now();
                      final difference = now.difference(profile.createdAt!);
                      _isNewUserCached = difference.inDays < 7;
                      print('[ProfileScreen] Account age: ${difference.inDays} days, isNewUser: $_isNewUserCached');
                    }

                    if (_isNewUserCached == true) {
                      badges.add(const SizedBox(width: 8));
                      // Use gender-specific translation key based on user's gender
                      final normalizedGender = profile.gender?.trim().toLowerCase();
                      final translationKey = normalizedGender == 'female'
                          ? 'profileNewUserBadgeFemale'
                          : (normalizedGender == 'non_binary' || normalizedGender == 'nonbinary')
                              ? 'profileNewUserBadgeNeutral'
                              : 'profileNewUserBadge';
                      print('[ProfileScreen] Adding new user badge with key: $translationKey');
                      badges.add(NewUserBadge(
                        size: 20,
                        showText: true,
                        text: _t(l10n, translationKey),
                        gender: profile.gender,
                      ));
                    }
                    return _buildProfileItem(
                      context,
                      Icons.person_outline_rounded,
                      _t(l10n, 'profileName'),
                      displayName,
                      textDirection: RegExp(r'[a-zA-Z]').hasMatch(displayName) ? ui.TextDirection.ltr : (displayName.isRtl() ? ui.TextDirection.rtl : ui.TextDirection.ltr),
                      trailing: badges.isNotEmpty ? Row(mainAxisSize: MainAxisSize.min, children: badges) : null,
                    );
                  })(),
                  (() {
                    final displayName = profile.name.trim();
                    final parts = displayName.split(RegExp(r'\s+')).where((p) => p.trim().isNotEmpty).toList(growable: false);
                    final hasLastName = parts.length >= 2;
                    if (!hasLastName) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsetsDirectional.only(start: 16, end: 16, top: 2, bottom: 12),
                      child: Text(
                        _t(l10n, 'profileLastNameNotDisplayed'),
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.grey.shade600),
                      ),
                    );
                  })(),

                  // Birthday
                  _buildProfileItem(
                    context,
                    Icons.cake_outlined,
                    _t(l10n, 'profileBirthday'),
                    profile.dateOfBirth != null ? _formatDateWithL10n(profile.dateOfBirth!, l10n) : _t(l10n, 'profileNotSet'),
                  ),

                  // Age (displayed separately like in profile wizard)
                  if (profile.dateOfBirth != null) ...[
                    Padding(
                      padding: const EdgeInsetsDirectional.only(start: 12.0 + 56.0 + 8.0, top: 8.0),
                      child: Align(
                        alignment: _isRtl(l10n) ? Alignment.centerRight : Alignment.centerLeft,
                        child: Text(
                          '${_ageLabelFor(l10n)}: ${_calculateAge(profile.dateOfBirth!)}',
                          style: TextStyle(color: Colors.green.shade700),
                        ),
                      ),
                    ),
                  ],

                  // Gender
                  Consumer(builder: (ctx, ref, _) {
                    final genderOptionsAsync = ref.watch(genderOptionsProvider);
                    return genderOptionsAsync.when(
                      data: (options) {
                        final genderKey = profile.gender ?? '';
                        String genderDisplay;
                        try {
                          final Map<String, String> found = options.firstWhere(
                            (o) => (o['key'] ?? '').trim().toLowerCase() == genderKey.trim().toLowerCase(),
                            orElse: () => <String, String>{},
                          );
                          
                          if (found.isNotEmpty) {
                            final displayKey = found['displayKey'] ?? '';
                            final translated =
                                _tryGetString(
                                  l10n,
                                  _normalizeGenderDisplayKey(displayKey),
                                ) ??
                                _tryGetString(
                                  l10n,
                                  _normalizeGenderDisplayKey(genderKey),
                                );

                            genderDisplay =
                                translated ??
                                (genderKey.trim().isEmpty
                                    ? _t(l10n, 'profileNotSet')
                                    : _humanizeKey(genderKey));
                          } else {
                            if (genderKey.trim().isEmpty) {
                              genderDisplay = _t(l10n, 'profileNotSet');
                            } else {
                              genderDisplay = _humanizeKey(genderKey);
                            }
                          }
                        } catch (e) {
                          if (genderKey.trim().isEmpty) {
                            genderDisplay = _t(l10n, 'profileNotSet');
                          } else {
                            genderDisplay = _humanizeKey(genderKey);
                          }
                        }
                        return _buildProfileItem(ctx, Icons.wc_outlined, _t(l10n, 'profileGender'), genderDisplay);
                      },
                      loading: () => _buildProfileItem(ctx, Icons.wc_outlined, _t(l10n, 'profileGender'), _t(l10n, 'generalLoading')),
                      error: (e, s) => _buildProfileItem(ctx, Icons.wc_outlined, _t(l10n, 'profileGender'), _t(l10n, 'generalError')),
                    );
                  }),

                  // Bio display (if present)
                  if ((profile.bio ?? '').trim().isNotEmpty) ...[
                    const SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_t(l10n, 'profileAbout'), style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 8),
                          Card(
                            elevation: 0,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Text(
                                profile.bio ?? '',
                                textDirection: RegExp(r'[a-zA-Z]').hasMatch(profile.bio ?? '') ? ui.TextDirection.ltr : ui.TextDirection.rtl,
                                textAlign: (profile.bio ?? '').isRtl() ? TextAlign.right : TextAlign.left,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  const Divider(height: 30),

                  // Intents
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l10n.getString('profileEditIntentsTitle'), style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 10),
                        if (profile.activeModes.isEmpty)
                          Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                              child: Text(
                              l10n.getString('profileWizardNoIntents'),
                              style: const TextStyle(color: Colors.grey),
                            ),
                          ),
                        allIntentsAsync.when(
                    data: (allIntents) {
                      final Map<String, String> mainIntentNormalizedLookup = {};
                      for (var opt in mainIntents) {
                        mainIntentNormalizedLookup[_normalizeKey(opt.key)] = opt.translationKey;
                      }

                      final validMainModes = profile.activeModes.where((modeKey) {
                        final nm = _normalizeKey(modeKey);
                        return modeKey != '0' && modeKey.isNotEmpty && mainIntentNormalizedLookup.containsKey(nm);
                      }).toList();

                      final intentOrder = ['romantic', 'friendship', 'activity_partner', 'business_networking'];
                      final sortedValidModes = validMainModes..sort((a, b) {
                        final aNorm = _normalizeKey(a);
                        final bNorm = _normalizeKey(b);
                        final aIndex = intentOrder.indexOf(aNorm);
                        final bIndex = intentOrder.indexOf(bNorm);
                        if (aIndex == -1) return 1;
                        if (bIndex == -1) return -1;
                        return aIndex.compareTo(bIndex);
                      });

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: sortedValidModes.map((modeKey) {
                          final norm = _normalizeKey(modeKey);
                          final displayKey = mainIntentNormalizedLookup[norm] ?? modeKey;
                          final chipLabel = _resolveDisplayLabel(l10n, displayKey);

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 8.0),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Chip(label: Text(chipLabel), backgroundColor: Theme.of(context).colorScheme.primaryContainer),
                              if (profile.subIntents[modeKey]?.isNotEmpty ?? false)
                                Padding(
                                  padding: const EdgeInsets.only(left: 16.0, top: 4.0),
                                  child: Wrap(
                                    spacing: 6.0,
                                    runSpacing: 0.0,
                                    children: profile.subIntents[modeKey]!.where((subKey) => subKey != '0' && subKey.isNotEmpty).map((subKey) {
                                      final subDisplayKey = subKey.contains('::') ? subKey.split('::').last : subKey;
                                      final translationKey = _resolveLookupTranslationKey(intentDisplayMap, subDisplayKey);
                                      final subLabel =
                                          (translationKey != null
                                                  ? _tryGetString(l10n, translationKey)
                                                  : null) ??
                                              _tryGetString(l10n, subKey) ??
                                              _tryGetString(l10n, subDisplayKey) ??
                                              _humanizeKey(subDisplayKey);
                                      return Chip(
                                        label: Text(subLabel, style: const TextStyle(fontSize: 12)),
                                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                        backgroundColor: Theme.of(context).colorScheme.secondaryContainer.withValues(alpha:0.5),
                                      );
                                    }).toList(),
                                  ),
                                ),
                            ]), // end column
                          );
                        }).toList(),
                      );
                    },
                    loading: () => const Center(child: CircularProgressIndicator()),
                    error: (e, s) => Text(_t(l10n, 'generalError'), style: const TextStyle(color: Colors.red)),
                  ),
                      ],
                    ),
                  ),

                  const Divider(height: 30),

                  // Interests
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l10n.getString('profileInterests'), style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 10),
                        if (profile.interests.isEmpty)
                          Padding(padding: const EdgeInsets.only(left: 8.0), child: Text(_t(l10n, 'profileNoInterests'), style: const TextStyle(color: Colors.grey))),

                        // Display interests separated by intent type (personal vs business/networking)
                        (() {
                    final Set<String> allUniqueInterestKeys = {};
                    final Map<String, Set<String>> interestToIntents = {};
                    final Map<String, Set<String>> businessInterests = {};
                    final Map<String, Set<String>> personalInterests = {};

                    // Parse the prefixed keys to collect all unique interests and their associated intents
                    profile.interests.forEach((prefixedKey, interestKeys) {
                      if (prefixedKey.contains('::')) {
                        final parts = prefixedKey.split('::');
                        if (parts.length >= 2) {
                          final intentKey = parts[0];
                          final isBusinessNetworking = _normalizeKey(intentKey) == 'business_networking';
                          
                          for (final interestKey in interestKeys.where((key) => key != '0' && key.isNotEmpty)) {
                            allUniqueInterestKeys.add(interestKey);
                            if (!interestToIntents.containsKey(interestKey)) {
                              interestToIntents[interestKey] = {};
                            }
                            interestToIntents[interestKey]!.add(intentKey);
                            
                            // Categorize interests by intent type
                            if (isBusinessNetworking) {
                              if (!businessInterests.containsKey(interestKey)) {
                                businessInterests[interestKey] = {};
                              }
                              businessInterests[interestKey]!.add(intentKey);
                            } else {
                              if (!personalInterests.containsKey(interestKey)) {
                                personalInterests[interestKey] = {};
                              }
                              personalInterests[interestKey]!.add(intentKey);
                            }
                          }
                        }
                      }
                    });

                    // Helper function to create interest widgets for a category
                    Widget createInterestSection(String title, IconData icon, Map<String, Set<String>> interestCategory, Color? chipColor) {
                      if (interestCategory.isEmpty) {
                        return const SizedBox.shrink();
                      }

                      final categoryInterestKeys = interestCategory.keys.toList(growable: false);

                      // Sort interests alphabetically for consistent display
                      final sortedInterestKeys = categoryInterestKeys.toList()
                        ..sort((a, b) {
                        final aInterestKey = a.contains('::') ? a.split('::').last : a;
                        final aDisplayName = _resolveDisplayLabel(
                          l10n,
                          aInterestKey,
                          interestKeyToDisplayKey: interestDisplayMap,
                          categoryKeyToDisplayKey: categoryDisplayMap,
                        ).toLowerCase();

                        final bInterestKey = b.contains('::') ? b.split('::').last : b;
                        final bDisplayName = _resolveDisplayLabel(
                          l10n,
                          bInterestKey,
                          interestKeyToDisplayKey: interestDisplayMap,
                          categoryKeyToDisplayKey: categoryDisplayMap,
                        ).toLowerCase();

                        return aDisplayName.compareTo(bDisplayName);
                      });

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 20.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(icon, size: 20, color: Theme.of(context).colorScheme.primary),
                                const SizedBox(width: 8),
                                Text(
                                  title,
                                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: Theme.of(context).colorScheme.primary,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Padding(
                              padding: const EdgeInsets.only(left: 8.0),
                              child: Wrap(
                                spacing: 6.0,
                                runSpacing: 4.0,
                                children: sortedInterestKeys.map((rawInterestKey) {
                                  final interestKey = rawInterestKey.contains('::') ? rawInterestKey.split('::').last : rawInterestKey;
                                  final displayName = _resolveDisplayLabel(
                                    l10n,
                                    interestKey,
                                    interestKeyToDisplayKey: interestDisplayMap,
                                    categoryKeyToDisplayKey: categoryDisplayMap,
                                  );
                                  return Chip(
                                    label: Text(displayName, style: const TextStyle(fontSize: 12)),
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    backgroundColor: chipColor ?? Theme.of(context).colorScheme.tertiaryContainer.withValues(alpha:0.5),
                                  );
                                }).toList(),
                              ),
                            ),
                          ],
                        ),
                      );
                    }

                    // Create sections for personal and business interests
                    final List<Widget> sections = [];
                    
                    // Personal interests section (romantic, friendship, activity partner)
                    sections.add(createInterestSection(
                      l10n.getString('profilePersonalInterests'),
                      Icons.favorite_outline,
                      personalInterests,
                      Theme.of(context).colorScheme.tertiaryContainer.withValues(alpha:0.5),
                    ));

                    // Business/Networking interests section
                    sections.add(createInterestSection(
                      l10n.getString('profileBusinessInterests'),
                      Icons.business_center_outlined,
                      businessInterests,
                      Theme.of(context).colorScheme.secondaryContainer.withValues(alpha:0.5),
                    ));

                    // If no interests at all, show the original empty state
                    if (personalInterests.isEmpty && businessInterests.isEmpty) {
                      return Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Text(
                          l10n.getString('profileNoInterests'),
                          style: const TextStyle(color: Colors.grey),
                        ),
                      );
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: sections,
                    );
                  })(),
                      ],
                    ),
                  ),

                  const Divider(height: 30),

                  // Languages Known
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(l10n.getString('profileLanguagesKnown'), style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 10),
                        Consumer(builder: (ctx, ref, _) {
                          final languageOptionsAsync = ref.watch(languageOptionsProvider);
                          return languageOptionsAsync.when(
                      data: (allLanguages) {
                        final Map<String, String> allLangsMap = {
                          for (var v in allLanguages) v['code']!: l10n.getString('lang_${v['code']}')
                        };
                        if (profile.languagesKnown.isEmpty) {
                          return Padding(padding: const EdgeInsets.only(left: 8.0), child: Text(l10n.getString('profileNotSet'), style: const TextStyle(color: Colors.grey)));
                        }
                        final filteredEntries = <MapEntry<String, List<String>>>[];
                        final langs = profile.languagesKnown['languages'] ?? [];
                        for (final lang in langs) {
                          if (lang == 'languages') continue;
                          final skills = profile.languagesKnown[lang] ?? [];
                          filteredEntries.add(MapEntry(lang, skills));
                        }
                        if (filteredEntries.isEmpty) {
                          return Padding(padding: const EdgeInsets.only(left: 8.0), child: Text(l10n.getString('profileNotSet'), style: const TextStyle(color: Colors.grey)));
                        }
                        return Padding(
                          padding: const EdgeInsets.only(left: 8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: filteredEntries.map((entry) {
                              final langCode = entry.key;
                              final langName = allLangsMap[langCode] ?? l10n.getString('lang_$langCode');
                              final skills = entry.value;
                              // Format skills with capitalization
                              final skillsText = skills.map((skillKey) {
                                final skillName = l10n.getString(skillKey);
                                return skillName;
                              }).join(', ');
                              
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 6.0),
                                child: RichText(
                                  text: TextSpan(
                                    style: TextStyle(fontSize: 15, color: Theme.of(context).colorScheme.onSurface),
                                    children: [
                                      TextSpan(
                                        text: '$langName: ',
                                        style: const TextStyle(fontWeight: FontWeight.w600),
                                      ),
                                      TextSpan(text: skillsText),
                                    ],
                                  ),
                                ),
                              );
                            }).toList(),
                          ),
                        );
                      },
                      loading: () => const CircularProgressIndicator(),
                      error: (e, s) => Text(_t(l10n, 'generalError'), style: const TextStyle(color: Colors.red)),
                    );
                        }),
                      ],
                    ),
                  ),

                  Consumer(builder: (ctx, ref, _) {
                    final ratingSummaryAsync = ref.watch(userRatingSummaryProvider(userId));
                    final ratingQuestionsAsync = ref.watch(ratingQuestionsProvider);
                    return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0),
                    child: ratingSummaryAsync.when(
                      data: (summary) {
                        if (summary.overallAvg == null) {
                          return const SizedBox.shrink();
                        }
                        return ratingQuestionsAsync.when(
                          data: (questions) {
                            final firstFive = questions.take(5).toList();
                            final questionAverages = <double?>[
                              summary.q1Avg,
                              summary.q2Avg,
                              summary.q3Avg,
                              summary.q4Avg,
                              summary.q5Avg,
                            ];

                          Future<void> showQuestion(String headerKey, String questionKey) async {
                            final header = l10n.getString(headerKey);
                            final question = l10n.getString(questionKey);
                            await showDialog<void>(
                              context: ctx,
                              builder: (dlgCtx) => AlertDialog(
                                title: Text(header),
                                content: Text(question),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.of(dlgCtx).pop(),
                                    child: Text(l10n.getString('generalCancel')),
                                  ),
                                ],
                              ),
                            );
                          }

                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Divider(height: 30),
                              Text(
                                l10n.getString('ratingSectionTitle'),
                                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 10),
                              Card(
                                elevation: 2,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      for (var i = 0; i < firstFive.length && i < questionAverages.length; i++)
                                        if (questionAverages[i] != null)
                                          Padding(
                                            padding: const EdgeInsets.only(bottom: 10.0),
                                            child: Row(
                                              children: [
                                                Expanded(
                                                  child: Row(
                                                    children: [
                                                      Flexible(
                                                        child: Text(
                                                          l10n.getString(_headerKeyForQuestion(firstFive[i])),
                                                          style: Theme.of(context).textTheme.bodyMedium,
                                                          overflow: TextOverflow.ellipsis,
                                                        ),
                                                      ),
                                                      IconButton(
                                                        visualDensity: VisualDensity.compact,
                                                        padding: EdgeInsets.zero,
                                                        icon: const Icon(Icons.info_outline, size: 18),
                                                        onPressed: () => showQuestion(
                                                          _headerKeyForQuestion(firstFive[i]),
                                                          firstFive[i].translationKey,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Text(
                                                  _formatScore(questionAverages[i]!, decimals: 1),
                                                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                                                ),
                                              ],
                                            ),
                                          ),
                                      const Divider(height: 18),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              l10n.getString('ratingOverall'),
                                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                                            ),
                                          ),
                                          Text(
                                            _formatScore(summary.overallAvg!, decimals: 2),
                                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                        loading: () => const SizedBox.shrink(),
                        error: (e, s) => const SizedBox.shrink(),
                      );
                    },
                    loading: () => const SizedBox.shrink(),
                    error: (e, s) => const SizedBox.shrink(),
                  ),
                    );
                  }),

                  // Ad slot at bottom of profile
                  const AdSlot(placement: AdPlacement.profileInline),
                  const SizedBox(height: 60),
                ],
              ),
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (err, stack) => Center(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(l10n.getString('generalErrorLoadingProfile'), textAlign: TextAlign.center),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => ref
                      .read(profileSyncProvider)
                      .syncProfile(userId, source: 'profile-screen-retry-error'),
                  child: Text(_t(l10n, 'generalRetry')),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileItem(BuildContext context, IconData icon, String label, String value, {ui.TextDirection? textDirection, Widget? trailing}) {
    final theme = Theme.of(context);
    final colors = theme.colorScheme;

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: theme.shadowColor.withValues(alpha: 0.05),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: colors.primary.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: colors.primary, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Text(
                      label,
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: colors.onSurface.withValues(alpha: 0.7),
                        letterSpacing: 0.5,
                      ),
                    ),
                    if (trailing != null) ...[
                      const SizedBox(width: 8),
                      trailing,
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  textDirection: textDirection,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                    color: colors.onSurface,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatScore(double value, {int decimals = 1}) {
    final s = value.toStringAsFixed(decimals);
    return s.replaceFirst(RegExp(r'\.?0+$'), '');
  }

  String _headerKeyForQuestion(RatingQuestion q) {
    switch (q.id) {
      case 'communication':
        return 'ratingHeaderCommunication';
      case 'reliability':
        return 'ratingHeaderReliability';
      case 'respect':
        return 'ratingHeaderRespect';
      case 'safety':
        return 'ratingHeaderSafety';
      case 'profile_accuracy':
        return 'ratingHeaderAccuracy';
      default:
        return q.translationKey;
    }
  }

  String _t(LocalizationState l10n, String key) => l10n.getString(key);
}
