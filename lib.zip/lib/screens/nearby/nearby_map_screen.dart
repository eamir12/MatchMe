import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:proj4dart/proj4dart.dart' as proj4;
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/providers/current_location_provider.dart';
import 'package:matchme/providers/home_providers.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/providers/profile_provider.dart';
import 'package:matchme/services/error_localization_service.dart';
import 'package:matchme/services/session_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

String _ts() => DateTime.now().toIso8601String();

bool _isNetworkMapError(Object error) {
  final key = ErrorLocalizationService.getErrorTranslationKey(error);
  return key.startsWith('networkError');
}

final Crs _noWrap3857Crs = () {
  final max = pi * SphericalMercator.r;
  const tileSize = 256.0;
  final scaleFactor = 0.5 / (pi * SphericalMercator.r);
  final scales = List<double>.generate(
    19,
    (z) => tileSize * pow(2, z).toDouble() * scaleFactor,
    growable: false,
  );

  return Proj4Crs.fromFactory(
    code: 'EPSG:3857',
    proj4Projection: proj4.Projection.GOOGLE,
    origins: [Point<double>(-max, max)],
    bounds: Rect.fromLTRB(-max, -max, max, max),
    scales: scales,
  );
}();

class NearbyMapCell {
  final double lat;
  final double lng;
  final int count;

  const NearbyMapCell({
    required this.lat,
    required this.lng,
    required this.count,
  });
}

class NearbyMapScreen extends ConsumerStatefulWidget {
  const NearbyMapScreen({super.key});

  @override
  ConsumerState<NearbyMapScreen> createState() => _NearbyMapScreenState();
}

class _NearbyMapScreenState extends ConsumerState<NearbyMapScreen> {
  static final LatLngBounds _worldBounds = LatLngBounds(
    const LatLng(-85, -180),
    const LatLng(85, 180),
  );

  static const InteractionOptions _interaction = InteractionOptions(
    flags: InteractiveFlag.drag |
        InteractiveFlag.pinchMove |
        InteractiveFlag.pinchZoom |
        InteractiveFlag.doubleTapZoom |
        InteractiveFlag.scrollWheelZoom,
  );

  final MapController _mapController = MapController();
  final Distance _distance = const Distance();
  Timer? _debounce;
  Timer? _pollTimer;
  ProviderSubscription<AsyncValue<bool>>? _connectivitySub;
  RealtimeChannel? _activityChannel;
  RealtimeChannel? _locationChannel;
  LatLng? _lastUserCenter;
  double? _lastDefaultRadiusKm;
  LatLng? _lastCameraCenter;

  bool _loading = false;
  String? _error;
  List<NearbyMapCell> _cells = const [];
  NearbyMapCell? _selectedCell;
  DateTime? _lastActivityCommitTimestamp;

  bool _dedupActivityEvent(DateTime? commitTimestamp) {
    if (commitTimestamp == null || commitTimestamp == _lastActivityCommitTimestamp) {
      return true;
    }
    _lastActivityCommitTimestamp = commitTimestamp;
    return false;
  }

  @override
  void initState() {
    super.initState();
    print('[${_ts()}] 🗺️ NearbyMapScreen: initState');
    Future.microtask(() async {
      print('[${_ts()}] 🗺️ NearbyMapScreen: refreshLocation start');
      await ref.read(currentLocationProvider.notifier).refreshLocation();
      print('[${_ts()}] 🗺️ NearbyMapScreen: refreshLocation done');
    });

    _connectivitySub = ref.listenManual<AsyncValue<bool>>(connectivityProvider, (previous, next) {
      final isOnline = next.value ?? false;
      if (!isOnline) return;
      final center = _lastUserCenter;
      final radiusKm = _lastDefaultRadiusKm;
      if (center == null || radiusKm == null) return;
      _scheduleFetch(userCenter: center, defaultRadiusKm: radiusKm);
    });

    // Setup realtime subscriptions for immediate updates
    _setupRealtimeSubscriptions();
  }

  void _setupRealtimeSubscriptions() {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    // Subscribe to user_activity table for online status changes
    _activityChannel = Supabase.instance.client
        .channel('nearby_map_activity_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.insert,
          schema: 'public',
          table: 'user_activity',
          callback: (payload) {
            // Dedup by commit timestamp (handles duplicate events from Postgres)
            if (_dedupActivityEvent(payload.commitTimestamp)) return;

            final newRecord = payload.newRecord as Map<String, dynamic>?;
            final changedUserId = newRecord?['user_id'] as String?;
            if (changedUserId == null || changedUserId == userId) return;

            // Refresh on any user_activity change (online/offline)
            print('[${_ts()}] 🗺️ NearbyMapScreen: User activity changed, refreshing nearby cells');
            _triggerRefresh();
          },
        )
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'user_activity',
          callback: (payload) {
            // Dedup by commit timestamp (handles duplicate events from Postgres)
            if (_dedupActivityEvent(payload.commitTimestamp)) return;

            final newRecord = payload.newRecord as Map<String, dynamic>?;
            final oldRecord = payload.oldRecord as Map<String, dynamic>?;
            final changedUserId = (newRecord?['user_id'] ?? oldRecord?['user_id']) as String?;
            if (changedUserId == null || changedUserId == userId) return;

            // Refresh on any user_activity UPDATE (online/offline changes)
            print('[${_ts()}] 🗺️ NearbyMapScreen: User activity updated, refreshing nearby cells');
            _triggerRefresh();
          },
        )
        .subscribe((status, err) {
          print('[${_ts()}] 🗺️ NearbyMapScreen: Activity channel status: $status, error: $err');
        });

    // Subscribe to user_locations table for location changes
    _locationChannel = Supabase.instance.client
        .channel('nearby_map_location_$userId')
        .onPostgresChanges(
          event: PostgresChangeEvent.update,
          schema: 'public',
          table: 'user_locations',
          callback: (payload) {
            final newRecord = payload.newRecord as Map<String, dynamic>?;
            final oldRecord = payload.oldRecord as Map<String, dynamic>?;
            final changedUserId = (newRecord?['user_id'] ?? oldRecord?['user_id']) as String?;
            if (changedUserId == null || changedUserId == userId) return;

            print('[${_ts()}] 🗺️ NearbyMapScreen: User location changed, refreshing nearby cells');
            _triggerRefresh();
          },
        )
        .subscribe((status, err) {
          print('[${_ts()}] 🗺️ NearbyMapScreen: Location channel status: $status, error: $err');
        });
  }

  void _triggerRefresh() {
    if (!mounted) return;
    final isOnline = ref.read(connectivityProvider).value ?? false;
    if (!isOnline) return;
    final center = _lastUserCenter;
    final radiusKm = _lastDefaultRadiusKm;
    if (center == null || radiusKm == null) return;
    _scheduleFetch(userCenter: center, defaultRadiusKm: radiusKm);
  }

  @override
  void dispose() {
    print('[${_ts()}] 🗺️ NearbyMapScreen: dispose');
    _debounce?.cancel();
    _pollTimer?.cancel();
    _connectivitySub?.close();
    _activityChannel?.unsubscribe();
    _locationChannel?.unsubscribe();
    super.dispose();
  }

  int _cellMetersForRadiusKm(double radiusKm) {
    // Use a fixed cell size (1500 meters) regardless of zoom level
    // This prevents markers from moving when zooming because the cell grid remains stable
    return 1500;
  }

  double _initialZoomForRadiusKm(double radiusKm) {
    if (radiusKm <= 1) return 14;
    if (radiusKm <= 3) return 13;
    if (radiusKm <= 8) return 12;
    if (radiusKm <= 20) return 11;
    if (radiusKm <= 50) return 10;
    if (radiusKm <= 120) return 9;
    return 3;
  }

  double _currentViewRadiusKm({required double fallbackKm}) {
    try {
      final camera = _mapController.camera;
      final bounds = camera.visibleBounds;
      final center = camera.center;
      final northPoint = LatLng(bounds.north, center.longitude);
      final meters = _distance(center, northPoint);
      if (meters.isFinite && meters > 0) return meters / 1000.0;
      return fallbackKm;
    } catch (_) {
      return fallbackKm;
    }
  }

  void _scheduleFetch({required LatLng userCenter, required double defaultRadiusKm}) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      unawaited(_fetchCells(userCenter: userCenter, defaultRadiusKm: defaultRadiusKm));
    });
  }

  void _ensurePolling({required LatLng userCenter, required double defaultRadiusKm}) {
    _lastUserCenter = userCenter;
    _lastDefaultRadiusKm = defaultRadiusKm;

    _pollTimer ??= Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted) return;
      if (_loading) return;
      final isOnline = ref.read(connectivityProvider).value ?? false;
      if (!isOnline) return;
      final center = _lastUserCenter;
      final radiusKm = _lastDefaultRadiusKm;
      if (center == null || radiusKm == null) return;
      unawaited(_fetchCells(userCenter: center, defaultRadiusKm: radiusKm));
    });
  }

  int _stableHash32(String input) {
    final bytes = utf8.encode(input);
    var hash = 0x811c9dc5;
    for (final b in bytes) {
      hash ^= b;
      hash = (hash * 0x01000193) & 0xffffffff;
    }
    return hash & 0x7fffffff;
  }

  LatLng _jitteredCellPoint(String requestingUserId, NearbyMapCell cell) {
    final seed = _stableHash32(
      'cell|$requestingUserId|${cell.lat.toStringAsFixed(6)}|${cell.lng.toStringAsFixed(6)}',
    );
    final rng = Random(seed);

    // Use a completely fixed jitter radius (30 meters) to ensure markers don't move when zooming
    // This is independent of cell size and zoom level
    const maxMeters = 30.0;
    final r = rng.nextDouble() * maxMeters;
    final theta = rng.nextDouble() * pi * 2;
    final dNorth = cos(theta) * r;
    final dEast = sin(theta) * r;

    final lat = cell.lat + (dNorth / 111000.0);
    final cosLat = cos(cell.lat * pi / 180.0).abs();
    final lon = cell.lng + (dEast / (111000.0 * max(cosLat, 0.15)));

    return LatLng(lat, lon);
  }

  Color _cellColor(String requestingUserId, NearbyMapCell cell) {
    // Use a single color (deepPurple) to match the legend
    // Previously used a palette of different colors which was inconsistent with the legend
    return Colors.deepPurple.withValues(alpha: 0.78);
  }

  Future<void> _fetchCells({required LatLng userCenter, required double defaultRadiusKm}) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null || userId.isEmpty) return;

    final viewRadiusKm = _currentViewRadiusKm(fallbackKm: defaultRadiusKm);

    LatLng queryCenter = userCenter;
    double queryRadiusKm = defaultRadiusKm;
    if (viewRadiusKm > defaultRadiusKm) {
      try {
        queryCenter = _mapController.camera.center;
        queryRadiusKm = viewRadiusKm;
      } catch (_) {
        queryCenter = userCenter;
        queryRadiusKm = defaultRadiusKm;
      }
    }

    final cellMeters = _cellMetersForRadiusKm(queryRadiusKm);

    print(
      '[${_ts()}] 🗺️ NearbyMapScreen: _fetchCells start '
      '(viewRadiusKm=${viewRadiusKm.toStringAsFixed(2)}, defaultRadiusKm=${defaultRadiusKm.toStringAsFixed(2)}, '
      'queryCenter=${queryCenter.latitude.toStringAsFixed(6)},${queryCenter.longitude.toStringAsFixed(6)}, '
      'queryRadiusKm=${queryRadiusKm.toStringAsFixed(2)}, cellMeters=$cellMeters)',
    );

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final result = await Supabase.instance.client.rpc(
        'get_visible_online_user_map_cells',
        params: <String, dynamic>{
          'p_requesting_user_id': userId,
          'p_center_lat': queryCenter.latitude,
          'p_center_lng': queryCenter.longitude,
          'p_radius_km': queryRadiusKm,
          'p_cell_meters': cellMeters,
          'p_recent_minutes': 30,
        },
      );

      final rows = (result as List<dynamic>?) ?? const [];
      final parsed = <NearbyMapCell>[];
      for (final row in rows) {
        if (row is! Map) continue;
        final lat = (row['cell_center_lat'] as num?)?.toDouble();
        final lng = (row['cell_center_lng'] as num?)?.toDouble();
        final count = (row['user_count'] as num?)?.toInt();
        if (lat == null || lng == null || count == null) continue;
        if (count <= 0) continue;
        parsed.add(NearbyMapCell(lat: lat, lng: lng, count: count));
      }

      var totalUsers = 0;
      for (final c in parsed) {
        totalUsers += c.count;
      }
      print('[${_ts()}] 🗺️ NearbyMapScreen: _fetchCells rpc ok (rows=${rows.length}, cells=${parsed.length}, totalUsers=$totalUsers)');

      if (!mounted) return;
      setState(() {
        _cells = parsed;
        if (_selectedCell != null) {
          final stillExists = parsed.any((c) => c.lat == _selectedCell!.lat && c.lng == _selectedCell!.lng);
          if (!stillExists) _selectedCell = null;
        }
      });
    } catch (e) {
      print('[${_ts()}] 🗺️ NearbyMapScreen: _fetchCells error: $e');
      if (!mounted) return;
      final isNetworkError = _isNetworkMapError(e);
      setState(() {
        _error = isNetworkError ? null : e.toString();
        if (!isNetworkError) {
          _cells = const [];
          _selectedCell = null;
        }
      });
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
      }
      print('[${_ts()}] 🗺️ NearbyMapScreen: _fetchCells done');
    }
  }

  List<Marker> _buildCellMarkers(
    BuildContext context, {
    required String requestingUserId,
  }) {
    final markers = <Marker>[];
    for (final c in _cells) {
      final isSelected = _selectedCell != null && _selectedCell!.lat == c.lat && _selectedCell!.lng == c.lng;
      final size = (18.0 + (log(c.count + 1) / ln2) * 4.0).clamp(16.0, 44.0);
      final label = c.count >= 100 ? '99+' : c.count.toString();
      final point = _jitteredCellPoint(requestingUserId, c);
      final baseColor = _cellColor(requestingUserId, c);

      markers.add(
        Marker(
          point: point,
          width: size + 10,
          height: size + 10,
          child: Center(
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedCell = c;
                });
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                width: size,
                height: size,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: (isSelected ? Colors.orange : baseColor).withValues(alpha: 0.78),
                  border: Border.all(
                    width: isSelected ? 3 : 2,
                    color: Colors.white.withValues(alpha: 0.95),
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.25),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                alignment: Alignment.center,
                child: c.count == 1
                    ? Container(
                        width: max(5.0, size * 0.26),
                        height: max(5.0, size * 0.26),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.95),
                          shape: BoxShape.circle,
                        ),
                      )
                    : Text(
                        label,
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                        textAlign: TextAlign.center,
                      ),
              ),
            ),
          ),
        ),
      );
    }
    return markers;
  }

  Marker _buildUserMarker(LatLng userLatLng) {
    return Marker(
      point: userLatLng,
      width: 54,
      height: 54,
      child: Center(
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.blueAccent.withValues(alpha: 0.18),
              ),
            ),
            Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.blueAccent,
                border: Border.all(width: 3, color: Colors.white),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.25),
                    blurRadius: 10,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _legend(BuildContext context, LocalizationState l10n) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(12),
      color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.92),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: DefaultTextStyle(
          style: Theme.of(context).textTheme.labelMedium ?? const TextStyle(),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.blueAccent,
                      border: Border.all(width: 2, color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(l10n.getString('mapLegendYou')),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 12,
                    height: 12,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.deepPurple.withValues(alpha: 0.78),
                      border: Border.all(width: 2, color: Colors.white),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(l10n.getString('mapLegendOnlineUsersApprox')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l10n = ref.watch(localizationProvider);
    final userId = Supabase.instance.client.auth.currentUser?.id;
    final isOnline = ref.watch(connectivityProvider).value ?? true;
    final displayedOnlineCount = _cells.fold<int>(0, (sum, cell) => sum + cell.count);

    if (userId == null) {
      return Scaffold(body: Center(child: Text(l10n.getString('generalError'))));
    }

    final profileAsync = ref.watch(userProfileProvider(userId));
    final position = ref.watch(currentLocationProvider);

    return profileAsync.when(
      data: (profile) {
        final defaultRadiusMeters = (profile?.matchRadiusDefault ?? 5000).toDouble();
        final defaultRadiusKm = max(defaultRadiusMeters / 1000.0, 0.5);

        final userLatLng = position != null
            ? LatLng(position.latitude, position.longitude)
            : null;
        if (userLatLng != null) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            _ensurePolling(userCenter: userLatLng, defaultRadiusKm: defaultRadiusKm);
          });
        }

        return Scaffold(
          appBar: AppBar(
            title: Text(l10n.getString('homeNearby')),
          ),
          body: userLatLng == null
              ? const Center(child: CircularProgressIndicator())
              : Stack(
                  children: [
                    FlutterMap(
                      mapController: _mapController,
                      options: MapOptions(
                        crs: _noWrap3857Crs,
                        initialCenter: userLatLng,
                        initialZoom: _initialZoomForRadiusKm(defaultRadiusKm),
                        minZoom: 1,
                        maxZoom: 18,
                        cameraConstraint: CameraConstraint.contain(bounds: _worldBounds),
                        interactionOptions: _interaction,
                        onPositionChanged: (camera, hasGesture) {
                          if (!hasGesture) return;
                          // Only refetch when the center position changes significantly (panning), not when just zooming
                          // This prevents markers from disappearing/reappearing when zooming
                          final currentCenter = camera.center;
                          final lastCenter = _lastCameraCenter;
                          if (lastCenter != null) {
                            final distance = _distance(lastCenter, currentCenter);
                            // Only refetch if panned more than 100 meters
                            if (distance < 100) return;
                          }
                          _lastCameraCenter = currentCenter;
                          _scheduleFetch(userCenter: userLatLng, defaultRadiusKm: defaultRadiusKm);
                        },
                        onMapReady: () {
                          _scheduleFetch(userCenter: userLatLng, defaultRadiusKm: defaultRadiusKm);
                        },
                        onTap: (tapPosition, point) {
                          if (_selectedCell == null) return;
                          setState(() {
                            _selectedCell = null;
                          });
                        },
                      ),
                      children: [
                        if (isOnline)
                          TileLayer(
                            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                            userAgentPackageName: 'matchme.app',
                            tileBounds: _worldBounds,
                          ),
                        CircleLayer(
                          circles: [
                            CircleMarker(
                              point: userLatLng,
                              radius: defaultRadiusKm * 1000.0,
                              useRadiusInMeter: true,
                              color: Colors.blueAccent.withValues(alpha: 0.12),
                              borderColor: Colors.blueAccent.withValues(alpha: 0.35),
                              borderStrokeWidth: 2,
                            ),
                          ],
                        ),
                        MarkerLayer(
                          markers: _buildCellMarkers(
                            context,
                            requestingUserId: userId,
                          ),
                        ),
                        MarkerLayer(markers: [_buildUserMarker(userLatLng)]),
                      ],
                    ),
                    Positioned(
                      right: 12,
                      bottom: 110,
                      child: FloatingActionButton.small(
                        heroTag: null,
                        onPressed: () {
                          _mapController.move(
                            userLatLng,
                            _initialZoomForRadiusKm(defaultRadiusKm),
                          );
                          _scheduleFetch(userCenter: userLatLng, defaultRadiusKm: defaultRadiusKm);
                        },
                        child: const Icon(Icons.my_location),
                      ),
                    ),
                    Positioned(
                      right: 12,
                      bottom: 12,
                      child: _MapZoomControls(
                        controller: _mapController,
                        minZoom: 1,
                        maxZoom: 18,
                      ),
                    ),
                    if (_loading)
                      const Positioned(
                        top: 12,
                        left: 12,
                        child: SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        ),
                      ),
                    Positioned(
                      top: 12,
                      right: 12,
                      child: _legend(context, l10n),
                    ),
                    Positioned(
                      top: 12,
                      left: 44,
                      child: Material(
                        elevation: 0,
                        borderRadius: BorderRadius.circular(999),
                        color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.92),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                          child: Text(
                            l10n.getString(
                              'mapShowingApproxUsers',
                              params: {'count': displayedOnlineCount.toString()},
                            ),
                            style: Theme.of(context).textTheme.labelMedium,
                          ),
                        ),
                      ),
                    ),
                    if (_selectedCell != null)
                      Positioned(
                        bottom: 12,
                        left: 12,
                        right: 12,
                        child: Material(
                          elevation: 2,
                          borderRadius: BorderRadius.circular(12),
                          color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.95),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  l10n.getString(
                                    'mapApproxUsersHere',
                                    params: {'count': _selectedCell!.count.toString()},
                                  ),
                                  style: Theme.of(context).textTheme.titleSmall,
                                ),
                                TextButton(
                                  onPressed: () {
                                    setState(() {
                                      _selectedCell = null;
                                    });
                                  },
                                  child: Text(l10n.getString('generalClose')),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    if (!isOnline)
                      Positioned(
                        top: 12,
                        left: 12,
                        right: 12,
                        child: Material(
                          color: Theme.of(context).colorScheme.surfaceContainerHighest,
                          borderRadius: BorderRadius.circular(8),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            child: Text(
                              l10n.getString('generalOffline'),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    if (_error != null)
                      Positioned(
                        bottom: 12,
                        left: 12,
                        right: 12,
                        child: Material(
                          color: Theme.of(context).colorScheme.errorContainer,
                          borderRadius: BorderRadius.circular(8),
                          child: Padding(
                            padding: const EdgeInsets.all(12),
                            child: Text(
                              _error!,
                              style: TextStyle(
                                color: Theme.of(context).colorScheme.onErrorContainer,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
        );
      },
      loading: () => const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, s) => Scaffold(body: Center(child: Text(e.toString()))),
    );
  }
}

class OnlineWorldMapScreen extends ConsumerStatefulWidget {
  const OnlineWorldMapScreen({super.key});

  @override
  ConsumerState<OnlineWorldMapScreen> createState() =>
      _OnlineWorldMapScreenState();
}

class _OnlineWorldMapScreenState extends ConsumerState<OnlineWorldMapScreen>
    with WidgetsBindingObserver {
  static const Color _mapBackgroundColor = Color(0xFFD4EBF4);
  static final LatLngBounds _worldBounds = LatLngBounds(
    const LatLng(-85, -180),
    const LatLng(85, 180),
  );
  static final CameraFit _initialWorldCameraFit = CameraFit.insideBounds(
    bounds: _worldBounds,
    minZoom: 1,
    maxZoom: 18,
  );

  static const InteractionOptions _interaction = InteractionOptions(
    flags: InteractiveFlag.drag |
        InteractiveFlag.flingAnimation |
        InteractiveFlag.pinchMove |
        InteractiveFlag.pinchZoom |
        InteractiveFlag.doubleTapZoom |
        InteractiveFlag.scrollWheelZoom,
  );

  final MapController _mapController = MapController();

  bool _loading = false;
  String? _error;
  List<_CountryCount> _counts = const [];
  final Map<String, LatLng> _countryCenters = {};
  final Map<String, String> _countryNames = {};
  String? _lastLanguageCode; // Track last used language to detect changes
  Timer? _refreshTimer;
  int? _lastOnlineCount;
  RealtimeChannel? _sessionChannel;

  _OnlineWorldMapScreenState() {
    print('[CRITICAL] 🗺️ _OnlineWorldMapScreenState constructor called');
  }

  @override
  void initState() {
    super.initState();
    print(
      '[CRITICAL] 🗺️ OnlineWorldMapScreen.initState() called - screen is being created',
    );
    print('[${_ts()}] 🗺️ OnlineWorldMapScreen: initState called');
    WidgetsBinding.instance.addObserver(this);
    // Call _refresh immediately instead of in a microtask to avoid delay
    _refresh();
    // Set up periodic refresh to keep country breakdown current while screen is open
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted && !_loading) {
        unawaited(_refresh());
      }
    });
    // Subscribe to user_session changes so the map refreshes as soon as
    // any user's session (and thus country) is registered/updated.
    // This catches the case where registerSession completes slightly after
    // update_user_activity fires the realtime event to other users.
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId != null) {
      _sessionChannel = Supabase.instance.client
          .channel('online_map_session_$userId')
          .onPostgresChanges(
            event: PostgresChangeEvent.all,
            schema: 'public',
            table: 'user_session',
            callback: (payload) {
              if (!mounted || _loading) return;
              unawaited(_refresh());
            },
          )
          .subscribe((status, err) {
            if (err != null) {
              print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Session channel status: $status, error: $err');
            }
          });
    }
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    if (_sessionChannel != null) {
      Supabase.instance.client.removeChannel(_sessionChannel!);
      _sessionChannel = null;
    }
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted && !_loading) {
      final isOnline = ref.read(connectivityProvider).value ?? true;
      if (isOnline) {
        unawaited(_refresh());
      }
    }
  }

  Future<void> _refreshPresence() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null || userId.isEmpty) {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refreshPresence - no user ID');
      return;
    }

    final platformText = kIsWeb
        ? 'web'
        : defaultTargetPlatform == TargetPlatform.android
            ? 'android'
            : defaultTargetPlatform == TargetPlatform.iOS
                ? 'ios'
                : defaultTargetPlatform == TargetPlatform.macOS
                    ? 'macos'
                    : defaultTargetPlatform == TargetPlatform.windows
                        ? 'windows'
                        : defaultTargetPlatform == TargetPlatform.linux
                            ? 'linux'
                            : 'unknown';

    print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refreshPresence start for user=$userId platform=$platformText');

    // Refresh location
    try {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Refreshing location...');
      await ref.read(currentLocationProvider.notifier).refreshLocation();
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Location refreshed successfully');
    } catch (e) {
      print('[${_ts()}] ⚠️ OnlineWorldMapScreen: Location refresh failed: $e');
    }

    final position = ref.read(currentLocationProvider);
    print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Current position: ${position != null ? '${position.latitude},${position.longitude}' : 'null'}');

    // Update location if available
    if (position != null) {
      try {
        print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Updating user location...');
        await Supabase.instance.client.rpc(
          'update_user_location',
          params: <String, dynamic>{
            'p_user_id': userId,
            'p_latitude': position.latitude,
            'p_longitude': position.longitude,
            'p_speed': position.speed,
            'p_heading': position.heading,
          },
        );
        print('[${_ts()}] ✅ OnlineWorldMapScreen: User location updated successfully');
      } catch (e) {
        print('[${_ts()}] ❌ OnlineWorldMapScreen: Failed to update user location: $e');
      }
    } else {
      print('[${_ts()}] ⚠️ OnlineWorldMapScreen: No position available, skipping location update');
    }

    // Register session FIRST so country is set before marking as online.
    // This prevents a race where other users see this user as "online" (from user_activity)
    // but the map's get_online_user_counts_by_country RPC can't find them because
    // their country is not yet set in user_session.
    try {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Registering session...');
      await SessionService.registerSession(
        userId,
        platform: platformText,
        latitude: position?.latitude,
        longitude: position?.longitude,
      );
      print('[${_ts()}] ✅ OnlineWorldMapScreen: Session registered successfully');
    } catch (e) {
      print('[${_ts()}] ⚠️ OnlineWorldMapScreen: Failed to register session: $e');
    }

    // Update user activity (CRITICAL - this marks user as online)
    // Run AFTER registerSession so country is already in user_session
    // when the realtime notification fires to other users.
    try {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Updating user activity (marking as online)...');
      await Supabase.instance.client.rpc(
        'update_user_activity',
        params: <String, dynamic>{'p_user_id': userId},
      );
      print('[${_ts()}] ✅ OnlineWorldMapScreen: User activity updated - user marked as ONLINE');
    } catch (e) {
      print('[${_ts()}] ❌ OnlineWorldMapScreen: CRITICAL - Failed to update user activity: $e');
      print('[${_ts()}] ❌ This is why you don\'t appear online on the map!');
    }

    print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refreshPresence complete');
  }

  Future<void> _moveToUserCountry() async {
    if (!mounted) return;
    
    final isOnline = ref.read(connectivityProvider).value ?? true;
    if (!isOnline) {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _moveToUserCountry - offline, skipping');
      return;
    }
    
    setState(() => _loading = true);
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null || !mounted) return;

      final res = await Supabase.instance.client
          .from('user_session')
          .select('country')
          .eq('user_id', userId)
          .order('last_active_at', ascending: false)
          .limit(1)
          .maybeSingle();

      if (res == null) return;
      final countryCode = (res['country'] as String?)?.toUpperCase();
      if (countryCode == null || countryCode.isEmpty) return;

      if (!_countryCenters.containsKey(countryCode)) {
        final l10n = ref.read(localizationProvider);
        await _ensureCountryCenters([countryCode], l10n.currentLocale.languageCode);
      }

      final center = _countryCenters[countryCode];
      if (center != null) {
        _mapController.move(center, 5.0);
      }
    } catch (e) {
      print('Error moving to user country: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refresh() async {
    print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() called');
    if (!mounted) {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - widget not mounted, returning');
      return;
    }
    
    final isOnline = ref.read(connectivityProvider).value ?? true;
    if (!isOnline) {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - offline, skipping network call');
      return;
    }
    
    print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - setting loading state');
    setState(() {
      _loading = true;
      _error = null;
    });

    final l10n = ref.read(localizationProvider);
    final languageCode = l10n.currentLocale.languageCode;

    // Clear cache if language changed to get localized country names
    if (_lastLanguageCode != null && _lastLanguageCode != languageCode) {
      _countryCenters.clear();
      _countryNames.clear();
    }
    _lastLanguageCode = languageCode;

    try {
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - calling get_online_user_counts_by_country RPC immediately');
      
      // Fetch online user counts immediately (don't wait for presence updates)
      final rpcResult = await Supabase.instance.client.rpc(
        'get_online_user_counts_by_country',
        params: <String, dynamic>{},
      );
      
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - RPC completed');

      final rows = rpcResult;
      final list = (rows as List<dynamic>?) ?? const [];
      final parsed = <_CountryCount>[];
      for (final row in list) {
        if (row is! Map) continue;
        final code = (row['country'] ?? '').toString().trim().toUpperCase();
        final count = (row['user_count'] as num?)?.toInt();
        if (code.isEmpty || count == null || count <= 0) continue;
        parsed.add(_CountryCount(countryCode: code, count: count));
      }

      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - parsed ${parsed.length} countries with online users');
      final codes = parsed.map((e) => e.countryCode).toSet().toList(growable: false);
      await _ensureCountryCenters(codes, l10n.currentLocale.languageCode);

      if (!mounted) return;
      setState(() {
        _counts = parsed;
      });
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - success, updated UI with ${parsed.length} countries');
      
      // Now update presence in the background (non-blocking)
      print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - calling _refreshPresence() in background');
      unawaited(_refreshPresence());
      
    } catch (e) {
      print('[${_ts()}] ❌ OnlineWorldMapScreen: _refresh() - ERROR: $e');
      if (!mounted) return;
      final isNetworkError = _isNetworkMapError(e);
      setState(() {
        _error = isNetworkError ? null : e.toString();
        if (!isNetworkError) {
          _counts = const [];
        }
      });
    } finally {
      if (mounted) {
        setState(() {
          _loading = false;
        });
        print('[${_ts()}] 🗺️ OnlineWorldMapScreen: _refresh() - complete');
      }
    }
  }

  // Map of ISO country codes to English names for Nominatim API
  // This is needed because Nominatim interprets ambiguous codes (like CO = Colombia vs Colorado)
  static const _countryCodeToName = {
    'CO': 'Colombia',
    'US': 'United States',
    'GB': 'United Kingdom',
    'AE': 'United Arab Emirates',
    // Add other common codes that might be ambiguous
  };

  String _getCountryNameForCode(String countryCode) {
    return _countryCodeToName[countryCode.toUpperCase()] ?? countryCode;
  }

  // Supported languages by Nominatim API (OpenStreetMap)
  // Nominatim supports all common languages including Hebrew
  static const _supportedLanguages = {'en', 'es', 'he', 'fr', 'de', 'ar', 'zh'};

  String _getSupportedLanguageCode(String languageCode) {
    // Return the requested language if supported, otherwise fall back to English
    return _supportedLanguages.contains(languageCode) ? languageCode : 'en';
  }

  Future<void> _ensureCountryCenters(List<String> codes, String languageCode) async {
    final supportedLangCode = _getSupportedLanguageCode(languageCode);
    final missing = codes.where((c) => !_countryCenters.containsKey(c)).toList(growable: false);
    if (missing.isEmpty) return;

    for (final code in missing) {
      try {
        // Use Nominatim (OpenStreetMap) API for geocoding with language support
        // This API supports Hebrew, English, Spanish and many other languages
        // Use country name instead of code to avoid ambiguity (e.g., CO = Colombia vs Colorado)
        final countryName = _getCountryNameForCode(code);
        final uri = Uri.https(
          'nominatim.openstreetmap.org',
          '/search',
          <String, String>{
            'q': countryName,
            'format': 'json',
            'accept-language': supportedLangCode,
            'limit': '1',
            'addressdetails': '0',
            'countrycodes': code.toLowerCase(), // Use country code filter to ensure we get the right country
          },
        );

        final resp = await http.get(uri, headers: {'User-Agent': 'MatchMe/1.0'}).timeout(const Duration(seconds: 8));
        if (resp.statusCode < 200 || resp.statusCode >= 300) continue;
        
        final decoded = jsonDecode(resp.body);
        if (decoded is! List || decoded.isEmpty) continue;
        
        final first = decoded[0];
        if (first is! Map) continue;
        
        final lat = double.tryParse(first['lat'] as String? ?? '');
        final lon = double.tryParse(first['lon'] as String? ?? '');
        final name = first['name'] as String?;
        
        if (lat == null || lon == null) continue;
        
        _countryCenters[code] = LatLng(lat, lon);
        if (name != null) _countryNames[code] = name;
      } catch (_) {}
    }
  }

  String _formatCount(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 10000) return '${(n / 1000).toStringAsFixed(0)}k';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}k';
    return n.toString();
  }

  List<Marker> _buildMarkers(BuildContext context) {
    final markers = <Marker>[];
    for (final entry in _counts) {
      final center = _countryCenters[entry.countryCode];
      if (center == null) continue;
      
      final name = _countryNames[entry.countryCode] ?? entry.countryCode;

      markers.add(
        Marker(
          point: center,
          width: 140,
          height: 60,
          child: IgnorePointer(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.5),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    name,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                    ),
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 2),
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: Colors.deepPurple.withValues(alpha: 0.88),
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: Colors.white.withValues(alpha: 0.9), width: 1),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: Text(
                      _formatCount(entry.count),
                      style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
    return markers;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = ref.watch(localizationProvider);
    final isOnline = ref.watch(connectivityProvider).value ?? true;
    // Use dashboardStatsProvider for real-time total (same as home screen)
    // while _counts provides the per-country breakdown for map markers
    final dashboardStats = ref.watch(dashboardStatsProvider);

    // Listen to online count changes to refresh country markers in real-time
    ref.listen(
      dashboardStatsProvider,
      (previous, next) {
        next.when(
          data: (stats) {
            final currentOnline = stats['online'] ?? 0;
            if (_lastOnlineCount != null && _lastOnlineCount != currentOnline) {
              print('[${_ts()}] 🗺️ OnlineWorldMapScreen: Online count changed ($_lastOnlineCount -> $currentOnline), refreshing country breakdown');
              if (mounted && !_loading && (ref.read(connectivityProvider).value ?? true)) {
                unawaited(_refresh());
              }
            }
            _lastOnlineCount = currentOnline;
          },
          loading: () {},
          error: (_, e) {},
        );
      },
    );

    final displayedOnlineCount = dashboardStats.when(
      data: (stats) => stats['online'] ?? 0,
      loading: () => _counts.fold<int>(0, (sum, e) => sum + e.count),
      error: (_, e) => _counts.fold<int>(0, (sum, c) => sum + c.count),
    );

    return Scaffold(
      backgroundColor: _mapBackgroundColor,
      appBar: AppBar(
        title: Text(l10n.getString('homeOnline')),
        elevation: 0,
        scrolledUnderElevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Center(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.9),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  child: ConstrainedBox(
                    constraints: BoxConstraints(
                      maxWidth: MediaQuery.of(context).size.width * 0.34,
                    ),
                    child: Text(
                      l10n.getString(
                        'onlineMapTotalOnline',
                        params: {'count': displayedOnlineCount.toString()},
                      ),
                      style: Theme.of(context).textTheme.labelLarge,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          const ColoredBox(color: _mapBackgroundColor),
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: const LatLng(20, 0),
              initialZoom: 1.6,
              initialCameraFit: _initialWorldCameraFit,
              minZoom: 1,
              maxZoom: 18,
              backgroundColor: _mapBackgroundColor,
              cameraConstraint: const CameraConstraint.containLatitude(85, -85),
              interactionOptions: _interaction,
            ),
            children: [
              if (isOnline)
                TileLayer(
                  urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                  userAgentPackageName: 'matchme.app',
                ),
              MarkerLayer(markers: _buildMarkers(context)),
            ],
          ),
          Positioned(
            right: 12,
            bottom: 110,
            child: FloatingActionButton.small(
              heroTag: null,
              onPressed: _loading ? null : _moveToUserCountry,
              child: const Icon(Icons.my_location),
            ),
          ),
          Positioned(
            right: 12,
            bottom: 12,
            child: _MapZoomControls(
              controller: _mapController,
              minZoom: 1,
              maxZoom: 18,
            ),
          ),
          if (!isOnline)
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Material(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  child: Text(
                    l10n.getString('generalOffline'),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          if (_error != null)
            Positioned(
              bottom: 12,
              left: 12,
              right: 12,
              child: Material(
                color: Theme.of(context).colorScheme.errorContainer,
                borderRadius: BorderRadius.circular(8),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Text(
                    _error!,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.onErrorContainer,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _CountryCount {
  final String countryCode;
  final int count;

  const _CountryCount({required this.countryCode, required this.count});
}

class _MapZoomControls extends StatelessWidget {
  final MapController controller;
  final double minZoom;
  final double maxZoom;

  const _MapZoomControls({
    required this.controller,
    required this.minZoom,
    required this.maxZoom,
  });

  void _zoom(double delta) {
    final camera = controller.camera;
    final nextZoom = (camera.zoom + delta).clamp(minZoom, maxZoom);
    controller.move(camera.center, nextZoom);
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FloatingActionButton.small(
            heroTag: null,
            onPressed: () => _zoom(1),
            child: const Icon(Icons.add),
          ),
          const SizedBox(height: 8),
          FloatingActionButton.small(
            heroTag: null,
            onPressed: () => _zoom(-1),
            child: const Icon(Icons.remove),
          ),
        ],
      ),
    );
  }
}
