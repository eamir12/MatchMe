// lib/screens/auth/profile_check_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/profile_provider.dart';
import 'package:matchme/providers/event_provider.dart';
import 'package:matchme/screens/auth/auth_screen.dart';
import 'package:matchme/screens/main_navigation_screen.dart';
import 'package:matchme/screens/profile/profile_wizard_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:matchme/services/background_service.dart';
import 'package:matchme/utils/permission_coordinator.dart';
import 'package:matchme/utils/app_shortcuts.dart';
import 'package:matchme/providers/home_providers.dart';
import 'package:matchme/services/local_db_service.dart';
import 'package:matchme/widgets/startup_loader.dart';

class ProfileCheckScreen extends ConsumerStatefulWidget {
  final User user;
  const ProfileCheckScreen({super.key, required this.user});

  @override
  ConsumerState<ProfileCheckScreen> createState() => _ProfileCheckScreenState();
}

enum _PcsScreen { loading, mainNavigation, wizard }

class _ProfileCheckScreenState extends ConsumerState<ProfileCheckScreen> {
  bool _notificationChecked = false;
  bool _didRunPermissionGate = false;
  Future<UserProfile?>? _cachedProfileFuture;
  bool _userDeletedCheckPerformed = false;
  bool _startupSyncScheduled = false;
  final _mainScreenKey = GlobalKey();
  Widget? _mainScreen;
  _PcsScreen _screen = _PcsScreen.loading;

  @override
  void initState() {
    super.initState();
    _cachedProfileFuture = _loadCachedProfile();
    _checkPendingNotification();
    Future.delayed(Duration.zero, () {
      if (!mounted) return;
      _scheduleDeferredStartupSync(widget.user.id);
      PermissionCoordinator.syncNativePermissionStrings(ref);
      PermissionCoordinator.handleOnResume(context, ref);
    });
  }

  @override
  Widget build(BuildContext context) {
    print('👤👤👤 ProfileCheckScreen build for user: ${widget.user.id}');

    ref.listen<AsyncValue<UserProfile?>>(
      userProfileProvider(widget.user.id),
      (prev, next) => _onProfileChanged(next),
    );

    if (_screen == _PcsScreen.loading) {
      final current = ref.read(userProfileProvider(widget.user.id));
      current.whenData((profile) {
        if (profile != null) {
          _screen = profile.isProfileComplete
              ? _PcsScreen.mainNavigation
              : _PcsScreen.wizard;
        }
      });
    }

    switch (_screen) {
      case _PcsScreen.mainNavigation:
        if (!_didRunPermissionGate) {
          _didRunPermissionGate = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            PermissionCoordinator.handleOnResume(context, ref);
          });
        }
        _mainScreen ??= MainNavigationScreen(key: _mainScreenKey);
        return _mainScreen!;
      case _PcsScreen.wizard:
        return ProfileWizardScreen(user: widget.user, isEditing: false);
      case _PcsScreen.loading:
        return _buildCachedProfileFallback();
    }
  }

  _PcsScreen _evaluateScreen(UserProfile? profile) {
    if (profile != null && profile.isProfileComplete) {
      return _PcsScreen.mainNavigation;
    } else if (profile != null && !profile.isProfileComplete) {
      return _PcsScreen.wizard;
    }
    return _PcsScreen.loading;
  }

  void _onProfileChanged(AsyncValue<UserProfile?> profileAsync) {
    profileAsync.whenData((profile) {
      if (profile == null) {
        if (!_userDeletedCheckPerformed) {
          _userDeletedCheckPerformed = true;
          _verifyUserStillExists();
        }
        return;
      }
      final newScreen = _evaluateScreen(profile);
      if (_screen != newScreen) {
        setState(() => _screen = newScreen);
      }
    });
  }

  Widget _buildCachedProfileFallback() {
    return FutureBuilder<UserProfile?>(
      future: _cachedProfileFuture,
      builder: (context, snapshot) {
        final cachedProfile = snapshot.data;
        if (cachedProfile != null) {
          if (cachedProfile.isProfileComplete) {
            return MainNavigationScreen();
          }
          return ProfileWizardScreen(user: widget.user, isEditing: false);
        }
        return const StartupLoaderScaffold();
      },
    );
  }

  Future<UserProfile?> _loadCachedProfile() async {
    try {
      final localDb = ref.read(localDbProvider);
      final raw = await localDb.getLocalProfile(widget.user.id);
      if (raw == null) return null;
      return UserProfile.fromMap(raw);
    } catch (_) {
      return null;
    }
  }

  Future<void> _checkPendingNotification() async {
    if (_notificationChecked) return;
    _notificationChecked = true;

    final initialRoute = await BackgroundService.getInitialRoute();
    if (initialRoute != null && initialRoute['route'] != null) {
      final route = initialRoute['route'] as String;
      if (route.startsWith('/chat/')) {
        final matchId = (initialRoute['matchId'] as String?)?.trim();
        if (matchId != null && matchId.isNotEmpty && mounted) {
          // Use deep-link route so we don't depend on argument maps.
          Navigator.of(context).pushNamed('/chat/$matchId');
        }
      }
    }

    // Static shortcuts may deliver a requested tab index.
    final rawTabIndex = initialRoute?['tabIndex'];
    final parsedTabIndex = rawTabIndex is int
        ? rawTabIndex
        : rawTabIndex is String
            ? int.tryParse(rawTabIndex.trim())
            : null;
    if (parsedTabIndex != null && parsedTabIndex >= 0 && parsedTabIndex <= 4) {
      AppShortcuts.setPendingTabIndex(parsedTabIndex);
      // Also set the provider immediately so if MainNavigationScreen has already been built,
      // it will still land on the right tab.
      try {
        ref.read(navigationIndexProvider.notifier).setIndex(parsedTabIndex);
      } catch (_) {}
    }

    final sharedText = (initialRoute?['sharedText'] as String?)?.trim();
    final sharedFilePath = (initialRoute?['sharedFilePath'] as String?)?.trim();
    if ((sharedText != null && sharedText.isNotEmpty) ||
        (sharedFilePath != null && sharedFilePath.isNotEmpty)) {
      final payload = <String, dynamic>{
        if (sharedText != null && sharedText.isNotEmpty) 'sharedText': sharedText,
        if (sharedFilePath != null && sharedFilePath.isNotEmpty) 'sharedFilePath': sharedFilePath,
      };
      try {
        ref.read(pendingAddEventShareProvider.notifier).setPayload(payload);
      } catch (_) {}
      AppShortcuts.setPendingTabIndex(3);
      try {
        ref.read(navigationIndexProvider.notifier).setIndex(3);
      } catch (_) {}
    }
  }

  void _startBackgroundSync(String userId) {
    // Start sync in background without waiting for it
    ref
        .read(profileSyncProvider)
        .syncProfile(userId, source: 'profile-check-startup')
        .then((_) {
      print('[ProfileCheckScreen] Background sync completed for user $userId');
    }).catchError((e) {
      // Log error but don't crash the app
      print('Background profile sync failed: $e');
    });
  }

  void _scheduleDeferredStartupSync(String userId) {
    if (_startupSyncScheduled) return;
    _startupSyncScheduled = true;
    print(
      '[ProfileCheckScreen] Scheduling deferred startup sync for user $userId',
    );
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (!mounted) return;
      _startBackgroundSync(userId);
    });
  }

  Future<void> _verifyUserStillExists() async {
    if (!mounted) return;
    
    try {
      final supabase = Supabase.instance.client;
      final userId = widget.user.id;
      
      // Check if user still exists in the database
      final userExists = await supabase
          .from('users')
          .select('id')
          .eq('id', userId)
          .maybeSingle();
      
      if (!mounted) return;
      
      if (userExists == null) {
        // User was deleted from database - sign out and redirect to signup
        print('[ProfileCheckScreen] User $userId not found in database - redirecting to signup');
        await _handleUserDeleted();
      }
    } catch (e) {
      print('[ProfileCheckScreen] Error verifying user existence: $e');
      // Don't redirect on error, just log it and let the profile provider handle it
    }
  }

  Future<void> _handleUserDeleted() async {
    if (!mounted) return;
    
    try {
      // Clear local data
      try {
        final prefs = await SharedPreferences.getInstance();
        await prefs.remove('was_logged_in');
        await prefs.remove('user_id');
      } catch (_) {}
      
      try {
        final localDb = await LocalDbService.instance;
        await localDb.clearDatabase();
      } catch (_) {}
      
      // Sign out from Supabase
      try {
        await Supabase.instance.client.auth.signOut(scope: SignOutScope.local);
      } catch (_) {}
    } catch (e) {
      print('[ProfileCheckScreen] Error during user deleted cleanup: $e');
    }
    
    // Redirect to auth screen
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const AuthScreen()),
      (route) => false,
    );
  }
}
