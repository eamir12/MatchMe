// lib/screens/auth/auth_screen.dart
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/auth_provider.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/providers/main_intents_provider.dart';
import 'package:matchme/screens/auth/signup_email_code_screen.dart';
import 'package:matchme/services/secure_signup_service.dart';
import 'package:matchme/services/turnstile_service.dart';
import 'package:matchme/services/error_localization_service.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;
import 'package:matchme/services/session_service.dart';
import 'package:matchme/services/passkey_auth_service.dart';
import 'package:matchme/services/passkey_client_service.dart';
import 'package:matchme/services/passkey_client_exception.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:matchme/services/web_calendar_service.dart';

final supabase = Supabase.instance.client;

class AuthScreen extends ConsumerStatefulWidget {
  const AuthScreen({super.key});
  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final _scrollController = ScrollController();
  final _passwordRequirementsKey = GlobalKey();
  bool _isLoading = false;
  String? _errorMessage;
  bool _isSignUp = false;
  bool _authSucceeded = false;

  final FocusNode _emailFocusNode = FocusNode();
  final FocusNode _passwordFocusNode = FocusNode();

  // NEW: control whether the password is obscured
  bool _obscurePassword = true;
  
  // NEW: Track if password field is focused (to show/hide requirements)
  bool _isPasswordFieldFocused = false;
  bool _isCheckingSignupEmail = false;
  String? _emailFieldErrorMessage;
  bool _hasApprovedSignupEmail = false;
  Timer? _signupEmailValidationTimer;
  int _signupEmailValidationGeneration = 0;
  String _lastScreenedSignupEmail = '';

  bool _authUiMessageListenerRegistered = false;

  // Passkey availability tracking
  bool _hasPasskeyForEmail = false;
  bool _isCheckingPasskey = false;
  String _lastCheckedPasskeyEmail = '';
  String _lastServerCheckedPasskeyEmail = '';
  Set<String> _knownPasskeyEmails = <String>{};
  Timer? _passKeyCheckDebounceTimer;
  int _passkeyCheckGeneration = 0;

  static const double _oauthProviderIconSize = 20;
  static const double _oauthButtonHeight = 48;

  int _failedPasswordAttempts = 0;
  String _failedPasswordAttemptsEmail = '';

  bool _passwordHasMinLength(String value) => value.length >= 8;
  bool _passwordHasUppercase(String value) => value.contains(RegExp(r'[A-Z]'));
  bool _passwordHasLowercase(String value) => value.contains(RegExp(r'[a-z]'));
  bool _passwordHasNumber(String value) => value.contains(RegExp(r'\d'));
  bool _passwordHasSpecialCharacter(String value) =>
      value.contains(RegExp(r'[@$!%*?&]'));

  bool _isSignupPasswordValid(String value) =>
      _passwordHasMinLength(value) &&
      _passwordHasUppercase(value) &&
      _passwordHasLowercase(value) &&
      _passwordHasNumber(value) &&
      _passwordHasSpecialCharacter(value);

  bool get _isSignupEmailApproved =>
      !_isSignUp ||
      (_isValidEmail(_normalizeEmail(_emailController.text)) &&
          _hasApprovedSignupEmail &&
          _emailFieldErrorMessage == null &&
          !_isCheckingSignupEmail);

  String _mapPasswordAuthError(AuthException e, LocalizationState l10n) {
    final errorKey = ErrorLocalizationService.getErrorTranslationKey(e, isSignUp: false);
    return l10n.getString(errorKey);
  }

  String _mapOAuthAuthError(AuthException e, LocalizationState l10n) {
    final errorKey = ErrorLocalizationService.getErrorTranslationKey(e, isSignUp: false);
    return l10n.getString(errorKey);
  }

  String _mapSecureSignupError(
    SecureSignUpException e,
    LocalizationState l10n,
  ) {
    switch (e.code) {
      case 'network_error':
        return l10n.getString('networkErrorNoInternet');
      case 'already_registered':
        return l10n.getString('authEmailAlreadyRegistered');
      case 'disposable_email_blocked':
        return l10n.getString('authDisposableEmailBlocked');
      case 'email_recent_abuse_blocked':
      case 'email_high_risk_blocked':
      case 'invalid_email_blocked':
      case 'screening_failed':
        return l10n.getString('authEmailRejected');
      case 'fraud_blocked':
      case 'device_reuse_blocked':
      case 'device_reuse_same_network_blocked':
      case 'install_reuse_blocked':
      case 'install_reuse_same_network_blocked':
      case 'existing_device_session_blocked':
        return l10n.getString('authSignUpBlocked');
      case 'turnstile_verification_failed':
      case 'captcha_failed':
        return l10n.getString('authCaptchaVerificationFailed');
      case 'config_missing':
        return l10n.getString('authCaptchaMissingConfig');
      case 'bad_request':
      case 'exception':
        return l10n.getString('authUnexpectedError');
      default:
        return e.message.trim().isNotEmpty
            ? e.message.trim()
            : l10n.getString('authUnexpectedError');
    }
  }

  String? _mapSecureSignupEmailFieldError(
    SecureSignUpException e,
    LocalizationState l10n,
  ) {
    switch (e.code) {
      case 'already_registered':
        return l10n.getString('authEmailAlreadyRegistered');
      case 'disposable_email_blocked':
        return l10n.getString('authDisposableEmailBlocked');
      case 'email_recent_abuse_blocked':
      case 'email_high_risk_blocked':
      case 'invalid_email_blocked':
      case 'screening_failed':
        return l10n.getString('authEmailRejected');
      default:
        return null;
    }
  }

  Widget _buildPasswordRequirementRow(
    BuildContext context, {
    required bool met,
    required String label,
  }) {
    final theme = Theme.of(context);
    final color = met ? Colors.green.shade700 : Colors.grey.shade600;
    return Row(
      children: [
        Icon(
          met ? Icons.check_circle : Icons.radio_button_unchecked,
          size: 18,
          color: color,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            label,
            style: theme.textTheme.bodySmall?.copyWith(color: color),
          ),
        ),
      ],
    );
  }

  String _normalizeEmail(String raw) => raw.trim().toLowerCase();
  
  // NEW: Check if email is in valid format
  bool _isValidEmail(String email) {
    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
    return emailRegex.hasMatch(email.trim());
  }

  bool get _shouldShowPasskeySuggestion {
    if (_isSignUp || !_hasPasskeyForEmail) {
      return false;
    }
    final normalizedEmail = _normalizeEmail(_emailController.text);
    return normalizedEmail.isNotEmpty &&
        normalizedEmail == _lastCheckedPasskeyEmail;
  }

  Future<void> _loadKnownPasskeyEmails() async {
    final knownEmails = await PasskeyAuthService.getKnownPasskeyEnabledEmails();
    if (!mounted) return;

    final normalizedEmail = _normalizeEmail(_emailController.text);
    final shouldShowForCurrentEmail =
        !_isSignUp &&
        _isValidEmail(normalizedEmail) &&
        knownEmails.contains(normalizedEmail);

    setState(() {
      _knownPasskeyEmails = knownEmails;
      if (shouldShowForCurrentEmail) {
        _hasPasskeyForEmail = true;
        _lastCheckedPasskeyEmail = normalizedEmail;
      }
    });
  }

  Future<void> _updateKnownPasskeyEmail(
    String email, {
    required bool hasPasskey,
  }) async {
    final knownEmails = await PasskeyAuthService.cachePasskeyAvailabilityForEmail(
      email,
      hasPasskey,
    );
    if (!mounted) return;

    setState(() {
      _knownPasskeyEmails = knownEmails;
    });
  }

  void _applyCachedPasskeyAvailability(String normalizedEmail) {
    final hasLocalPasskey = _knownPasskeyEmails.contains(normalizedEmail);
    if (hasLocalPasskey) {
      if (!_hasPasskeyForEmail || _lastCheckedPasskeyEmail != normalizedEmail) {
        setState(() {
          _hasPasskeyForEmail = true;
          _lastCheckedPasskeyEmail = normalizedEmail;
        });
      }
      return;
    }

    if (_hasPasskeyForEmail || _lastCheckedPasskeyEmail.isNotEmpty) {
      setState(() {
        _hasPasskeyForEmail = false;
        _lastCheckedPasskeyEmail = '';
      });
    }
  }

  void _resetPasskeyAvailabilityState() {
    _passKeyCheckDebounceTimer?.cancel();
    _passkeyCheckGeneration++;
    _lastServerCheckedPasskeyEmail = '';
    if (!_hasPasskeyForEmail &&
        !_isCheckingPasskey &&
        _lastCheckedPasskeyEmail.isEmpty) {
      return;
    }
    setState(() {
      _hasPasskeyForEmail = false;
      _isCheckingPasskey = false;
      _lastCheckedPasskeyEmail = '';
    });
  }

  Widget _buildPasskeySuggestionCard(String Function(String key) getString) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            colorScheme.primaryContainer.withValues(alpha: 0.92),
            colorScheme.surface.withValues(alpha: 0.98),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: colorScheme.primary.withValues(alpha: 0.22),
        ),
        boxShadow: [
          BoxShadow(
            color: colorScheme.primary.withValues(alpha: 0.10),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: colorScheme.primary.withValues(alpha: 0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(
                    Icons.fingerprint_rounded,
                    color: colorScheme.primary,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        getString('authPasskeyInlineHintTitle'),
                        style: theme.textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w700,
                          color: colorScheme.onSurface,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        getString('authPasskeyInlineHintBody'),
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: colorScheme.onSurfaceVariant,
                          height: 1.35,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _isLoading ? null : _signInWithPasskey,
                icon: const Icon(Icons.verified_user_rounded),
                label: Text(getString('authUsePasskeyNow')),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(50),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  // NEW: Sign in with passkey (for now, placeholder that could call Supabase passkey auth)
  Future<void> _signInWithPasskey() async {
    if (!mounted) return;
    
    final normalizedEmail = _normalizeEmail(_emailController.text);
    
    if (!_isValidEmail(normalizedEmail)) {
      final l10n = ref.read(localizationProvider);
      setState(() {
        _errorMessage = l10n.getString('authEmailInvalid');
      });
      return;
    }

    final l10n = ref.read(localizationProvider);
    
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      // Check if passkey authentication is supported
      if (!await PasskeyClientService.isAuthenticationSupported()) {
        if (!mounted) return;
        setState(() {
          _errorMessage = l10n.getString('authPasskeyNotSupported');
          _isLoading = false;
        });
        return;
      }

      // Start authentication with the server
      final startResult = await PasskeyAuthService.startAuthentication(
        email: normalizedEmail,
      );

      if (!startResult.hasPublicKeyOptions) {
        if (!mounted) return;
        setState(() {
          _errorMessage = l10n.getString('authPasskeyNotAvailable');
          _isLoading = false;
        });
        return;
      }

      // Get assertion from the device
      final assertion = await PasskeyClientService.getAuthenticationAssertion(
        publicKeyOptions: startResult.publicKeyOptions!,
      );

      // Finish authentication and apply session
      await PasskeyAuthService.finishAuthenticationAndApplySession(
        assertion: assertion,
        email: normalizedEmail,
        requestId: startResult.requestId,
      );
      await _updateKnownPasskeyEmail(normalizedEmail, hasPasskey: true);

      if (!mounted) return;
      // Session is now applied, auth state listener will handle navigation
      setState(() {
        _isLoading = false;
        _errorMessage = l10n.getString('authPasskeySignInSuccess');
      });
    } catch (error) {
      if (!mounted) return;
      
      String errorMessage = l10n.getString('authPasskeySignInFailed');
      
      if (error is PasskeyClientException) {
        final errorKey = ErrorLocalizationService.getErrorTranslationKey(error);
        errorMessage = l10n.getString(errorKey);
      } else if (error is PasskeyAuthException) {
        final errorKey = ErrorLocalizationService.getErrorTranslationKey(error);
        errorMessage = l10n.getString(errorKey);
      } else {
        final errorKey = ErrorLocalizationService.getErrorTranslationKey(error);
        errorMessage = l10n.getString(errorKey);
      }
      
      setState(() {
        _errorMessage = errorMessage;
        _isLoading = false;
      });
    }
  }

  bool _isPasswordLoginCaptchaRequired() =>
      !_isSignUp && _failedPasswordAttempts >= 3;

  bool _requiresCaptchaForCurrentAction() =>
      _isSignUp || _isPasswordLoginCaptchaRequired();

  bool _isInvalidPasswordAttempt(AuthException e) {
    final lower = e.message.toLowerCase();
    return lower.contains('invalid login credentials') ||
        lower.contains('invalid credentials') ||
        (lower.contains('invalid') && lower.contains('credential'));
  }

  int _incrementFailedPasswordAttempts(String email) {
    if (email.isEmpty) return _failedPasswordAttempts;
    final sameEmail = _failedPasswordAttemptsEmail == email;
    final next = sameEmail ? _failedPasswordAttempts + 1 : 1;
    if (mounted) {
      setState(() {
        _failedPasswordAttemptsEmail = email;
        _failedPasswordAttempts = next;
      });
    } else {
      _failedPasswordAttemptsEmail = email;
      _failedPasswordAttempts = next;
    }
    return next;
  }

  Future<void> _resetFailedPasswordAttempts(String email) async {
    if (email.isEmpty) return;
    if (_failedPasswordAttemptsEmail != email && _failedPasswordAttempts == 0) {
      return;
    }
    if (mounted) {
      setState(() {
        _failedPasswordAttemptsEmail = '';
        _failedPasswordAttempts = 0;
      });
    } else {
      _failedPasswordAttemptsEmail = '';
      _failedPasswordAttempts = 0;
    }
  }

  void _syncFailedAttemptsWithCurrentEmail() {
    final email = _normalizeEmail(_emailController.text);
    if (email.isEmpty) {
      if (_failedPasswordAttempts != 0 || _failedPasswordAttemptsEmail.isNotEmpty) {
        setState(() {
          _failedPasswordAttempts = 0;
          _failedPasswordAttemptsEmail = '';
        });
      }
      return;
    }

    if (_failedPasswordAttemptsEmail.isNotEmpty &&
        _failedPasswordAttemptsEmail != email &&
        _failedPasswordAttempts != 0) {
      setState(() {
        _failedPasswordAttempts = 0;
        _failedPasswordAttemptsEmail = '';
      });
    }
  }

  void _switchAuthMode(bool signUp) {
    if (_isSignUp == signUp) return;
    setState(() {
      _isSignUp = signUp;
      _errorMessage = null;
    });
    _syncFailedAttemptsWithCurrentEmail();
    _checkPasskeyAvailabilityDebounced();
  }

  void _scrollPasswordGuidanceIntoView() {
    if (!_isSignUp || !mounted) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final targetContext = _passwordRequirementsKey.currentContext;
      if (targetContext == null) return;
      Scrollable.ensureVisible(
        targetContext,
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeOutCubic,
        alignment: 0.35,
      );
    });
  }

  void _handlePasswordFocusChange() {
    setState(() {
      _isPasswordFieldFocused = _passwordFocusNode.hasFocus;
    });
    if (_passwordFocusNode.hasFocus) {
      _scrollPasswordGuidanceIntoView();
    }
  }

  Future<void> _handleEmailFocusChange() async {
    if (!mounted) return;

    if (_emailFocusNode.hasFocus) {
      if (_emailFieldErrorMessage != null) {
        setState(() {
          _emailFieldErrorMessage = null;
        });
      }
      if (_hasApprovedSignupEmail) {
        setState(() {
          _hasApprovedSignupEmail = false;
        });
      }
      return;
    }

    if (!_isSignUp || _isLoading) return;

    await _validateSignupEmail(
      forceShowInvalidFormat: true,
      requestGeneration: ++_signupEmailValidationGeneration,
    );
  }

  void _scheduleSignupEmailValidation() {
    _signupEmailValidationTimer?.cancel();
    if (!_isSignUp) return;

    final normalizedEmail = _normalizeEmail(_emailController.text);
    if (normalizedEmail.isEmpty || !_isValidEmail(normalizedEmail)) {
      return;
    }

    final requestGeneration = ++_signupEmailValidationGeneration;
    _signupEmailValidationTimer = Timer(
      const Duration(milliseconds: 500),
      () => _validateSignupEmail(
        forceShowInvalidFormat: false,
        requestGeneration: requestGeneration,
      ),
    );
  }

  Future<void> _validateSignupEmail({
    required bool forceShowInvalidFormat,
    required int requestGeneration,
  }) async {
    if (!mounted || !_isSignUp || _isLoading) return;

    final normalizedEmail = _normalizeEmail(_emailController.text);
    if (normalizedEmail.isEmpty) return;
    if (!_isValidEmail(normalizedEmail)) {
      if (!forceShowInvalidFormat) return;
      setState(() {
        _hasApprovedSignupEmail = false;
        _emailFieldErrorMessage =
            ref.read(localizationProvider).getString('authEmailInvalid');
      });
      return;
    }

    if (_lastScreenedSignupEmail == normalizedEmail &&
        (_hasApprovedSignupEmail || _emailFieldErrorMessage != null)) {
      return;
    }

    setState(() {
      _isCheckingSignupEmail = true;
      _hasApprovedSignupEmail = false;
      _emailFieldErrorMessage = null;
    });

    try {
      await SecureSignupService.screenEmail(email: normalizedEmail);
      if (!mounted || requestGeneration != _signupEmailValidationGeneration) {
        return;
      }
      if (_normalizeEmail(_emailController.text) != normalizedEmail) {
        return;
      }
      setState(() {
        _lastScreenedSignupEmail = normalizedEmail;
        _hasApprovedSignupEmail = true;
        _emailFieldErrorMessage = null;
      });
    } on SecureSignUpException catch (error) {
      if (!mounted || requestGeneration != _signupEmailValidationGeneration) {
        return;
      }
      if (_normalizeEmail(_emailController.text) != normalizedEmail) {
        return;
      }
      setState(() {
        _lastScreenedSignupEmail = normalizedEmail;
        _hasApprovedSignupEmail = false;
        _emailFieldErrorMessage = _mapSecureSignupEmailFieldError(
              error,
              ref.read(localizationProvider),
            ) ??
            _mapSecureSignupError(error, ref.read(localizationProvider));
      });
    } finally {
      if (mounted && requestGeneration == _signupEmailValidationGeneration) {
        setState(() {
          _isCheckingSignupEmail = false;
        });
      }
    }
  }

  Future<String?> _prepareCaptchaTokenIfNeeded(LocalizationState l10n) async {
    if (!_requiresCaptchaForCurrentAction()) {
      return '';
    }

    final action = _isSignUp
        ? TurnstileAuthAction.signUp
        : TurnstileAuthAction.passwordLogin;
    final normalizedEmail = _normalizeEmail(_emailController.text);

    try {
      final token = await TurnstileService.requestToken(
        context: context,
        l10n: l10n,
        action: action,
      );
      if (token == null || token.isEmpty) {
        if (mounted) {
          setState(() {
            _errorMessage = l10n.getString('authCaptchaCancelled');
          });
        }
        return null;
      }
      if (action == TurnstileAuthAction.signUp) {
        return token;
      }
      await TurnstileService.verifyToken(
        token: token,
        action: action,
        l10n: l10n,
      );
      if (action == TurnstileAuthAction.passwordLogin) {
        await _resetFailedPasswordAttempts(normalizedEmail);
      }
      return token;
    } catch (e) {
      if (mounted) {
        final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
        setState(() {
          _errorMessage = l10n.getString(errorKey);
        });
      }
      return null;
    }
  }

  Widget _buildOAuthButton({
    required OAuthProvider provider,
    required String label,
    required String assetPath,
  }) {
    final icon = SizedBox(
      width: _oauthProviderIconSize,
      height: _oauthProviderIconSize,
      child: Image.asset(
        assetPath,
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          return const SizedBox.shrink();
        },
      ),
    );
    final text = Text(label);
    final spacer = const SizedBox(width: 12);

    return OutlinedButton(
      onPressed: _isLoading ? null : () => _signInWithOAuth(provider),
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(_oauthButtonHeight),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [text, spacer, icon],
      ),
    );
  }

  Future<void> _signInWithOAuth(OAuthProvider provider) async {
    if (!mounted) return;

    // Use native Google Sign-In (popup on web, native SDK on mobile) +
    // signInWithIdToken instead of redirect-based OAuth which opens Chrome.
    if (provider == OAuthProvider.google) {
      print('🔵 [GoogleSignIn] Delegating to _signInWithGoogle (platform=${defaultTargetPlatform.name}, isWeb=$kIsWeb)');
      await _signInWithGoogle();
      print('🔵 [GoogleSignIn] _signInWithGoogle returned');
      return;
    }

    _authSucceeded = false;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      const mobileRedirectTo = 'com.example.matchme://login-callback';
      final redirectTo = kIsWeb ? '${Uri.base.origin}/auth/callback' : mobileRedirectTo;
      final scopes = switch (provider) {
        OAuthProvider.google =>
          'openid email profile '
              'https://www.googleapis.com/auth/calendar.readonly '
              'https://www.googleapis.com/auth/calendar.events.readonly',
        OAuthProvider.azure =>
          'openid email profile offline_access User.Read Calendars.Read',
        OAuthProvider.apple => 'name email',
        OAuthProvider.facebook => 'email public_profile',
        _ => null,
      };

      await supabase.auth.signInWithOAuth(
        provider,
        redirectTo: redirectTo,
        scopes: scopes,
        authScreenLaunchMode: LaunchMode.platformDefault,
      );

      // Redirect initiated successfully — keep spinner until onAuthStateChange navigates away
      _authSucceeded = true;
    } on AuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = _mapOAuthAuthError(e, ref.read(localizationProvider));
      });
    } catch (e) {
      if (!mounted) return;
      final l10n = ref.read(localizationProvider);
      final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
      setState(() {
        _errorMessage = l10n.getString(errorKey);
      });
    } finally {
      if (mounted && !_authSucceeded) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  /// Signs in with Google using the native SDK (popup on web, native UI on mobile).
  /// No Chrome window is opened — the credential is exchanged with Supabase via
  /// signInWithIdToken directly.
  Future<void> _signInWithGoogle() async {
    if (!mounted) return;
    print('🔵 [GoogleSignIn] _signInWithGoogle started');
    _authSucceeded = false;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // Resolve platform-appropriate client IDs.
      // Web: just the web client ID.
      // Android: Android client ID + web client ID as serverClientId.
      // iOS: iOS client ID + web client ID as serverClientId.
      final envWebId =
          const String.fromEnvironment('GOOGLE_CLIENT_ID', defaultValue: '').trim();
      final envAndroidId =
          const String.fromEnvironment('GOOGLE_ANDROID_CLIENT_ID', defaultValue: '').trim();
      final envIosId =
          const String.fromEnvironment('GOOGLE_IOS_CLIENT_ID', defaultValue: '').trim();
      final dotWebId = (dotenv.env['GOOGLE_CLIENT_ID'] ?? '').trim();
      final dotAndroidId = (dotenv.env['GOOGLE_ANDROID_CLIENT_ID'] ?? '').trim();
      final dotIosId = (dotenv.env['GOOGLE_IOS_CLIENT_ID'] ?? '').trim();

      final webClientId = envWebId.isNotEmpty ? envWebId : dotWebId;
      final androidClientId = envAndroidId.isNotEmpty ? envAndroidId : dotAndroidId;
      final iosClientId = envIosId.isNotEmpty ? envIosId : dotIosId;

      String clientId;
      String? serverClientId;

      if (kIsWeb) {
        clientId = webClientId;
        serverClientId = null;
      } else if (defaultTargetPlatform == TargetPlatform.android) {
        clientId = androidClientId.isNotEmpty ? androidClientId : webClientId;
        serverClientId = webClientId.isNotEmpty ? webClientId : null;
      } else if (defaultTargetPlatform == TargetPlatform.iOS) {
        clientId = iosClientId.isNotEmpty ? iosClientId : webClientId;
        serverClientId = webClientId.isNotEmpty ? webClientId : null;
      } else {
        clientId = webClientId;
        serverClientId = null;
      }

      if (clientId.isEmpty) {
        throw Exception('Google Client ID not configured for this platform');
      }

      await WebCalendarService.ensureGoogleSignInInitialized(
        clientId: clientId,
        serverClientId: serverClientId,
      );

      // Open native Google sign-in (popup on web, system UI on mobile).
      // The native UI auto-closes after account selection — no Chrome tab.
      print('🔵 [GoogleSignIn] Calling authenticate()...');
      final googleUser = await GoogleSignIn.instance.authenticate();
      print('🔵 [GoogleSignIn] authenticate() returned: ${googleUser.email}');

      final googleAuth = googleUser.authentication;
      final idToken = googleAuth.idToken;
      print('🔵 [GoogleSignIn] idToken received: ${idToken != null}, length=${idToken?.length}');

      if (idToken == null) {
        throw Exception('No ID token received from Google');
      }

      // Obtain access token via authorization client (separate step in v7.x API).
      // Must pass at least one scope — Android throws "requestedScopes cannot be
      // null or empty" for an empty list. 'openid' is always available.
      final authClient = googleUser.authorizationClient;
      final authorization = await authClient.authorizationForScopes(['openid']);
      final accessToken = authorization?.accessToken;
      print('🔵 [GoogleSignIn] accessToken received: ${accessToken != null}, length=${accessToken?.length}');

      print('🔵 [GoogleSignIn] Calling signInWithIdToken...');
      final authResponse = await supabase.auth.signInWithIdToken(
        provider: OAuthProvider.google,
        idToken: idToken,
        accessToken: accessToken,
      );
      print('🔵 [GoogleSignIn] signInWithIdToken succeeded. User: ${authResponse.user?.id}, Session: ${authResponse.session != null}');

      // Auth succeeded — leave the spinner visible so the login form doesn't
      // flash before onAuthStateChange triggers navigation.
      _authSucceeded = true;
    } on GoogleSignInException catch (e) {
      // Only treat explicit cancellation as non-error.
      // unknownError (e.g. "requestedScopes cannot be null or empty") is a real bug.
      if (e.code == GoogleSignInExceptionCode.canceled) {
        print('🟡 [GoogleSignIn] User canceled');
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
        return;
      }
      print('🔴 [GoogleSignIn] GoogleSignInException (${e.code}): $e');
      if (!mounted) return;
      setState(() {
        _errorMessage = e.toString();
      });
    } on AuthException catch (e) {
      print('🔴 [GoogleSignIn] AuthException: ${e.message}');
      if (!mounted) return;
      final l10n = ref.read(localizationProvider);
      final mapped = _mapOAuthAuthError(e, l10n);
      setState(() {
        _errorMessage = mapped.isNotEmpty ? mapped : '${l10n.getString('authOAuthFailed')}: ${e.message}';
      });
    } catch (e, st) {
      print('🔴 [GoogleSignIn] Unexpected error: $e\n$st');
      if (!mounted) return;
      final l10n = ref.read(localizationProvider);
      final errorKey = ErrorLocalizationService.getErrorTranslationKey(e);
      final translated = l10n.getString(errorKey);
      setState(() {
        _errorMessage = translated.isNotEmpty ? translated : e.toString();
      });
    } finally {
      // If auth succeeded, keep the spinner visible — onAuthStateChange will
      // navigate away momentarily. Only reset loading on error/cancel.
      if (mounted && !_authSucceeded) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _performAuth() async {
    if (!_formKey.currentState!.validate()) return;
    if (!mounted) return;

    final l10n = ref.read(localizationProvider);
    final normalizedEmail = _normalizeEmail(_emailController.text);
    final captchaToken = await _prepareCaptchaTokenIfNeeded(l10n);
    if (_requiresCaptchaForCurrentAction() &&
        (captchaToken == null || captchaToken.isEmpty)) {
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    try {
      // Get the localization provider reference BEFORE async operations
      // (ref becomes unsafe after widget unmounts due to navigation)
      final localizationNotifier = ref.read(localizationProvider.notifier);
      
      if (_isSignUp) {
        await SecureSignupService.signUp(
          email: normalizedEmail,
          password: _passwordController.text.trim(),
          captchaToken: captchaToken ?? '',
          language: l10n.currentLocale.languageCode,
        );
        if (!mounted) return;
        _passwordController.clear();
        await Navigator.of(context).push(
          MaterialPageRoute<void>(
            builder: (_) => SignupEmailCodeScreen(email: normalizedEmail),
          ),
        );
      } else {
        await supabase.auth.signInWithPassword(
          email: _emailController.text.trim(),
          password: _passwordController.text.trim(),
        );

        await _resetFailedPasswordAttempts(normalizedEmail);

        // Register session on the server with retry logic
        final user = supabase.auth.currentUser;
        if (user != null) {
          final platformText = _detectPlatform();
          
          // Wait a moment for JWT token to be fully available
          await Future.delayed(const Duration(milliseconds: 500));
          
          // Try to register session with retry logic
          bool sessionRegistered = false;
          int retryCount = 0;
          const maxRetries = 3;
          
          while (!sessionRegistered && retryCount < maxRetries) {
            try {
              await SessionService.registerSession(user.id, platform: platformText);
              sessionRegistered = true;
              print('✅ Session registration successful (attempt ${retryCount + 1})');
            } catch (e) {
              retryCount++;
              if (retryCount < maxRetries) {
                print(
                  '⚠️ Session registration failed, retrying ($retryCount/$maxRetries): $e',
                );
                await Future.delayed(const Duration(milliseconds: 1000));
              } else {
                print('❌ Session registration failed after $maxRetries attempts: $e');
                // Log the error but don't block login
              }
            }
          }

          // Update user activity to mark as online immediately
          // This is called regardless of session registration status to ensure user appears online immediately
          try {
            await supabase.rpc('update_user_activity', params: {'p_user_id': user.id});
            print('✅ User activity updated successfully');
          } catch (e) {
            print('⚠️ update_user_activity failed: $e');
            // Non-critical, background heartbeat will handle it
          }

          // Sync language preference to database after login
          // This ensures the language selected on login screen is persisted to DB
          // Note: We got the notifier reference before login to avoid ref issues after navigation
          try {
            await localizationNotifier.syncLanguageAfterLogin();
          } catch (e) {
            print('syncLanguageAfterLogin failed: $e');
          }

          _passwordController.clear();
        }
      }
    } on SecureSignUpException catch (e) {
      if (!mounted) return;
      final emailFieldMessage = _mapSecureSignupEmailFieldError(
        e,
        ref.read(localizationProvider),
      );
      setState(() {
        if (emailFieldMessage != null) {
          _emailFieldErrorMessage = emailFieldMessage;
          _errorMessage = null;
        } else {
          _errorMessage = _mapSecureSignupError(
            e,
            ref.read(localizationProvider),
          );
        }
      });
    } on AuthException catch (e) {
      if (!mounted) return;
      var message = _mapPasswordAuthError(e, ref.read(localizationProvider));
      if (!_isSignUp && _isInvalidPasswordAttempt(e)) {
        _incrementFailedPasswordAttempts(normalizedEmail);
        if (!mounted) return;
      }
      setState(() {
        _errorMessage = message;
      });
    } catch (e) {
      if (!mounted) return;
      final l10n = ref.read(localizationProvider);
      final errorKey = ErrorLocalizationService.getErrorTranslationKey(e, isSignUp: _isSignUp);
      setState(() {
        _errorMessage = l10n.getString(errorKey);
      });
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    _scrollController.dispose();
    _emailFocusNode.dispose();
    _passwordFocusNode.dispose();
    _passKeyCheckDebounceTimer?.cancel();
    _signupEmailValidationTimer?.cancel();
    super.dispose();
  }

  String _detectPlatform() {
    if (kIsWeb) return 'web';
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return 'android';
      case TargetPlatform.iOS:
        return 'ios';
      case TargetPlatform.macOS:
        return 'macos';
      case TargetPlatform.windows:
        return 'windows';
      case TargetPlatform.linux:
        return 'linux';
      default:
        return 'unknown';
    }
  }

  @override
  void initState() {
    super.initState();
    _loadKnownPasskeyEmails();
    _emailController.addListener(_onEmailChanged);
    _passwordController.addListener(_onPasswordChanged);
    _emailFocusNode.addListener(_handleEmailFocusChange);
    _passwordFocusNode.addListener(_handlePasswordFocusChange);
    // Request focus after first frame so the view is "served" and keyboard shows correctly (avoids showSoftInput ignored)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && _emailFocusNode.canRequestFocus) {
        _emailFocusNode.requestFocus();
      }
      _checkPasskeyAvailabilityDebounced();
    });
    // Clear error message when user starts typing
    _emailController.addListener(() {
      if (_errorMessage != null && _emailController.text.isNotEmpty) {
        setState(() {
          _errorMessage = null;
        });
      }
    });
    
    _passwordController.addListener(() {
      if (_errorMessage != null && _passwordController.text.isNotEmpty) {
        setState(() {
          _errorMessage = null;
        });
      }
    });
  }

  void _onEmailChanged() {
    _signupEmailValidationTimer?.cancel();

    // Clear error message when user starts typing
    if (_errorMessage != null) {
      setState(() {
        _errorMessage = null;
      });
    }
    if (_emailFieldErrorMessage != null) {
      setState(() {
        _emailFieldErrorMessage = null;
      });
    }
    if (_hasApprovedSignupEmail) {
      setState(() {
        _hasApprovedSignupEmail = false;
      });
    }
    if (_isCheckingSignupEmail) {
      setState(() {
        _isCheckingSignupEmail = false;
      });
    }
    _lastScreenedSignupEmail = '';
    _syncFailedAttemptsWithCurrentEmail();
    _checkPasskeyAvailabilityDebounced();
    _scheduleSignupEmailValidation();
  }

  void _checkPasskeyAvailabilityDebounced() {
    // Cancel previous debounce timer
    _passKeyCheckDebounceTimer?.cancel();

    final normalizedEmail = _normalizeEmail(_emailController.text);

    // If email is empty or invalid, reset passkey state
    if (_isSignUp || normalizedEmail.isEmpty || !_isValidEmail(normalizedEmail)) {
      _resetPasskeyAvailabilityState();
      return;
    }

    _applyCachedPasskeyAvailability(normalizedEmail);

    // If this email was already confirmed with the server during this screen
    // session, keep the current UI and skip another lookup.
    if (_lastServerCheckedPasskeyEmail == normalizedEmail &&
        !_isCheckingPasskey) {
      return;
    }

    final requestGeneration = ++_passkeyCheckGeneration;

    // Set a debounce timer to check passkey availability after 500ms of inactivity
    _passKeyCheckDebounceTimer = Timer(
      const Duration(milliseconds: 500),
      () => _checkPasskeyAvailability(
        email: normalizedEmail,
        requestGeneration: requestGeneration,
      ),
    );
  }

  Future<void> _checkPasskeyAvailability({
    required String email,
    required int requestGeneration,
  }) async {
    if (!mounted || email.isEmpty || _isSignUp) return;

    setState(() {
      _isCheckingPasskey = true;
    });

    try {
      // Try to start authentication - if a passkey exists, we get public key options
      final result = await PasskeyAuthService.startAuthentication(email: email)
          .timeout(const Duration(seconds: 5));

      if (!mounted || requestGeneration != _passkeyCheckGeneration) {
        return;
      }
      final currentEmail = _normalizeEmail(_emailController.text);
      if (currentEmail != email || _isSignUp) {
        _resetPasskeyAvailabilityState();
        return;
      }
      await _updateKnownPasskeyEmail(email, hasPasskey: result.hasPublicKeyOptions);
      if (!mounted || requestGeneration != _passkeyCheckGeneration) {
        return;
      }
      if (mounted) {
        setState(() {
          _hasPasskeyForEmail = result.hasPublicKeyOptions;
          _lastCheckedPasskeyEmail = email;
          _lastServerCheckedPasskeyEmail = email;
          _isCheckingPasskey = false;
        });
      }
    } catch (e) {
      // Only show the suggestion when the current email is positively verified.
      if (!mounted || requestGeneration != _passkeyCheckGeneration) {
        return;
      }
      _lastServerCheckedPasskeyEmail = '';
      if (mounted) {
        setState(() {
          _isCheckingPasskey = false;
        });
      }
    }
  }

  void _onPasswordChanged() {
    if (_isSignUp) {
      setState(() {});
      return;
    }

    // Clear error message when user starts typing
    if (_errorMessage != null) {
      setState(() {
        _errorMessage = null;
      });
    }
  }

  Future<void> _showOfflineLanguageUnavailableDialog() async {
    final l10n = ref.read(localizationProvider);
    await showDialog<void>(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        icon: const Icon(Icons.cloud_off_rounded, size: 32, color: Colors.orange),
        title: Text(l10n.getString('offlineLanguageUnavailableTitle')),
        content: Text(l10n.getString('offlineLanguageUnavailableMessage')),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text(l10n.getString('offlineOkButton')),
          ),
        ],
      ),
    );
  }

  List<AppLanguage> _fallbackPickerLanguages(List<AppLanguage> supportedLanguages) {
    if (supportedLanguages.isNotEmpty) {
      return supportedLanguages;
    }

    return [
      AppLanguage(code: 'en', displayName: 'English'),
      AppLanguage(code: 'es', displayName: 'Español'),
      AppLanguage(code: 'fr', displayName: 'Français'),
      AppLanguage(code: 'de', displayName: 'Deutsch'),
      AppLanguage(code: 'it', displayName: 'Italiano'),
      AppLanguage(code: 'pt', displayName: 'Português'),
      AppLanguage(code: 'ru', displayName: 'Русский'),
      AppLanguage(code: 'ja', displayName: '日本語'),
      AppLanguage(code: 'ko', displayName: '한국어'),
      AppLanguage(code: 'zh', displayName: '中文'),
      AppLanguage(code: 'ar', displayName: 'العربية', direction: TextDirection.rtl),
      AppLanguage(code: 'he', displayName: 'עברית', direction: TextDirection.rtl),
      AppLanguage(code: 'hi', displayName: 'हिन्दी'),
      AppLanguage(code: 'tr', displayName: 'Türkçe'),
      AppLanguage(code: 'nl', displayName: 'Nederlands'),
      AppLanguage(code: 'pl', displayName: 'Polski'),
    ];
  }

  void _showLanguagePicker(BuildContext context, List<AppLanguage> supportedLanguages) {
    showDialog(
      context: context,
      builder: (dialogContext) {
        final l10n = ref.watch(localizationProvider);
        final languageOptionsAsync = ref.watch(languageOptionsProvider);
        final isOffline = !(ref.watch(connectivityProvider).value ?? true);
        final fallbackLanguages = _fallbackPickerLanguages(supportedLanguages);

        Widget buildFallbackList() {
          final currentLanguageCode = l10n.currentLocale.languageCode.toLowerCase();
          return ListView.builder(
            shrinkWrap: true,
            itemCount: fallbackLanguages.length,
            itemBuilder: (context, index) {
              final lang = fallbackLanguages[index];
              final canUseNow =
                  !isOffline ||
                  lang.code == currentLanguageCode ||
                  lang.code == 'en';
              final textColor = canUseNow ? null : Colors.grey.shade400;

              return ListTile(
                leading: Icon(
                  canUseNow ? Icons.language : Icons.lock_outline,
                  color: textColor,
                ),
                title: Text(
                  lang.displayName,
                  style: TextStyle(color: textColor),
                ),
                onTap: () async {
                  if (!canUseNow) {
                    Navigator.of(dialogContext).pop();
                    if (mounted) {
                      await _showOfflineLanguageUnavailableDialog();
                    }
                    return;
                  }

                  Navigator.of(dialogContext).pop();
                  await ref
                      .read(localizationProvider.notifier)
                      .setLocale(lang.code, fallbackLanguages);
                },
              );
            },
          );
        }

        return AlertDialog(
          title: Text(l10n.getString('authSelectLanguage')),
          content: SizedBox(
            width: double.maxFinite,
            child: languageOptionsAsync.when(
              data: (languages) => ListView.builder(
                shrinkWrap: true,
                itemCount: languages.length,
                itemBuilder: (context, index) {
                  final lang = languages[index];
                  final langCode = lang['code'] as String;
                  final display = lang['display'] as String;
                  final isCached = (lang['cached'] as bool?) ?? true;
                  final isAvailableOffline =
                      (lang['availableOffline'] as bool?) ?? isCached;
                  final isOffline = (lang['offline'] as bool?) ?? false;
                  final canUseNow = !isOffline || isAvailableOffline;
                  final textColor = canUseNow ? null : Colors.grey.shade400;

                  return ListTile(
                    leading: Icon(
                      canUseNow ? Icons.language : Icons.lock_outline,
                      color: textColor,
                    ),
                    title: Text(
                      display,
                      style: TextStyle(color: textColor),
                    ),
                    onTap: () async {
                      if (!canUseNow) {
                        Navigator.of(dialogContext).pop();
                        if (mounted) {
                          await _showOfflineLanguageUnavailableDialog();
                        }
                        return;
                      }

                      final selectedLanguage = supportedLanguages.firstWhere(
                        (language) => language.code == langCode,
                        orElse: () => supportedLanguages.firstWhere(
                          (language) => language.code == l10n.currentLocale.languageCode,
                          orElse: () => supportedLanguages.first,
                        ),
                      );

                      Navigator.of(dialogContext).pop();
                      await ref
                          .read(localizationProvider.notifier)
                          .setLocale(selectedLanguage.code, supportedLanguages);
                    },
                  );
                },
              ),
              loading: buildFallbackList,
              error: (_, stackTrace) => buildFallbackList(),
            ),
          ),
        );
      },
    );
  }

  void _showForgotPasswordDialog() {
    final emailController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool isLoading = false;

    showDialog(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setState) {
            final l10n = ref.watch(localizationProvider);
            String getString(String key) => l10n.getString(key);

            return AlertDialog(
              title: Text(getString('authResetPasswordTitle')),
              content: Form(
                key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(getString('authResetPasswordMessage')),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: emailController,
                      decoration: InputDecoration(labelText: getString('authEmail')),
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        if (v == null || v.isEmpty) return getString('authEmailRequired');
                        final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
                        if (!emailRegex.hasMatch(v.trim())) return getString('authEmailInvalid');
                        return null;
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: Text(getString('generalCancel')),
                ),
                ElevatedButton(
                  onPressed: isLoading
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          setState(() => isLoading = true);
                          
                          // Capture everything we need before any async operations
                          final navigator = Navigator.of(dialogContext);
                          final scaffoldMessenger = ScaffoldMessenger.of(dialogContext);
                          final successMessage = getString('authResetPasswordSent');
                          final errorMessage = getString('authResetPasswordFailed');
                          
                          // Perform async operation
                          bool success = false;
                          try {
                            await supabase.auth.resetPasswordForEmail(emailController.text.trim());
                            success = true;
                          } catch (e) {
                            success = false;
                          }
                          
                          // Close dialog using captured navigator
                          navigator.pop();
                          
                          // Handle UI updates using captured scaffoldMessenger
                          if (mounted) {
                            scaffoldMessenger.showSnackBar(
                              SnackBar(
                                content: Text(success ? successMessage : errorMessage),
                                backgroundColor: success ? Colors.green : Colors.red,
                              ),
                            );
                            setState(() => isLoading = false);
                          }
                        },
                  child: isLoading ? const CircularProgressIndicator() : Text(getString('authSendResetPassword')),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    print('🔐🔐🔐 AuthScreen build');
    final l10n = ref.watch(localizationProvider);
    String getString(String key) => l10n.getString(key);
    final showIncorrectPasswordState =
        !_isSignUp && _errorMessage == getString('authIncorrectPassword');
    final incorrectPasswordBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(
        color: Colors.red.shade400,
        width: 1.6,
      ),
    );

    if (!_authUiMessageListenerRegistered) {
      ref.listen<String?>(authUiMessageProvider, (previous, next) {
        if (next == null || next.trim().isEmpty) return;
        if (!mounted) return;
        setState(() {
          _errorMessage = next;
        });
        ref.read(authUiMessageProvider.notifier).clear();
      });
      _authUiMessageListenerRegistered = true;
    }

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leadingWidth: 120,
        leading: Consumer(
          builder: (context, ref, child) {
            // Use the interpreted connectivity status so the auth badge follows
            // the same resume/reconnect grace logic as the rest of the app.
            final healthAsync = ref.watch(connectivityHealthProvider);

            final isOffline = healthAsync.when(
              data: (health) => health.status == ConnectivityHealthStatus.offline,
              loading: () => false,
              error: (e, st) => false,
            );

            if (!isOffline) {
              return const SizedBox.shrink();
            }

            final l10n = ref.watch(localizationProvider);
            final color = Theme.of(context).colorScheme.error;

            return Padding(
              padding: const EdgeInsets.only(left: 8.0, right: 4.0),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
                  decoration: BoxDecoration(
                    color: color.withAlpha((0.1 * 255).round()),
                    borderRadius: BorderRadius.circular(16.0),
                    border: Border.all(
                      color: color.withAlpha((0.2 * 255).round()),
                      width: 1,
                    ),
                  ),
                  clipBehavior: Clip.hardEdge,
                  child: Text(
                    l10n.getString('youAreOffline'),
                    style: TextStyle(
                      color: color,
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            );
          },
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            tooltip: getString('authSelectLanguage'),
            onPressed: () => _showLanguagePicker(context, l10n.supportedLanguages),
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset('assets/images/logo.png', height: 100),
                  const SizedBox(height: 24),
                  const CircularProgressIndicator(),
                ],
              ),
            )
          : Center(
              child: SingleChildScrollView(
                controller: _scrollController,
                padding: const EdgeInsets.all(24.0),
                child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Image.asset(
                  'assets/images/logo.png',
                  height: 100,
                  width: 100,
                  fit: BoxFit.contain,
                ),
                const SizedBox(height: 40),
                Text(
                  _isSignUp ? getString('authSignUp') : getString('authLogin'),
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.6),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: Theme.of(context).dividerColor,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: _isLoading ? null : () => _switchAuthMode(false),
                            style: FilledButton.styleFrom(
                              backgroundColor: _isSignUp
                                  ? Colors.transparent
                                  : Theme.of(context).colorScheme.primary,
                              foregroundColor: _isSignUp
                                  ? Theme.of(context).colorScheme.onSurface
                                  : Theme.of(context).colorScheme.onPrimary,
                              elevation: _isSignUp ? 0 : null,
                            ),
                            child: Text(getString('authLogin')),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: FilledButton(
                            onPressed: _isLoading ? null : () => _switchAuthMode(true),
                            style: FilledButton.styleFrom(
                              backgroundColor: _isSignUp
                                  ? Theme.of(context).colorScheme.primary
                                  : Colors.transparent,
                              foregroundColor: _isSignUp
                                  ? Theme.of(context).colorScheme.onPrimary
                                  : Theme.of(context).colorScheme.onSurface,
                              elevation: _isSignUp ? null : 0,
                            ),
                            child: Text(getString('authSignUp')),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                DecoratedBox(
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.08),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: Theme.of(context).colorScheme.primary.withValues(alpha: 0.18),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(
                          _isSignUp ? Icons.login_rounded : Icons.person_add_alt_1_rounded,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            _isSignUp
                                ? getString('authAlreadyHaveAccountPrompt')
                                : getString('authNewHerePrompt'),
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                        ),
                        const SizedBox(width: 10),
                        TextButton(
                          onPressed: _isLoading ? null : () => _switchAuthMode(!_isSignUp),
                          child: Text(
                            _isSignUp
                                ? getString('authLogin')
                                : getString('authSignUp'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 30),
                TextFormField(
                  controller: _emailController,
                  focusNode: _emailFocusNode,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontFeatures: const []),
                  decoration: InputDecoration(
                    labelText: getString('authEmail'),
                    prefixIcon: const Icon(Icons.email),
                    suffixIcon: _isSignUp && _isCheckingSignupEmail
                        ? const Padding(
                            padding: EdgeInsets.all(12),
                            child: SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            ),
                          )
                        : null,
                  ),
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  onFieldSubmitted: (_) {
                    if (_isSignUp && !_isSignupEmailApproved) {
                      FocusScope.of(context).unfocus();
                      return;
                    }
                    FocusScope.of(context).requestFocus(_passwordFocusNode);
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) return getString('authEmailRequired');
                    final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+$');
                    if (!emailRegex.hasMatch(v.trim())) return getString('authEmailInvalid');
                    return null;
                  },
                ),
                if (_isSignUp && _emailFieldErrorMessage != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    _emailFieldErrorMessage!,
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.error,
                          height: 1.35,
                        ),
                  ),
                ],
                if (_shouldShowPasskeySuggestion) ...[
                  const SizedBox(height: 16),
                  _buildPasskeySuggestionCard(getString),
                ],
                const SizedBox(height: 16),
                TextFormField(
                  controller: _passwordController,
                  focusNode: _passwordFocusNode,
                  readOnly: _isSignUp && !_isSignupEmailApproved,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontFeatures: const []),
                  decoration: InputDecoration(
                    labelText: getString('authPassword'),
                    prefixIcon: const Icon(Icons.lock),
                    helperText: _isSignUp && !_isSignupEmailApproved
                        ? getString('authPasswordLockedUntilEmailApproved')
                        : null,
                    filled: showIncorrectPasswordState,
                    fillColor: showIncorrectPasswordState
                        ? Colors.red.shade50
                        : null,
                    enabledBorder: showIncorrectPasswordState
                        ? incorrectPasswordBorder
                        : null,
                    focusedBorder: showIncorrectPasswordState
                        ? incorrectPasswordBorder.copyWith(
                            borderSide: BorderSide(
                              color: Colors.red.shade600,
                              width: 2,
                            ),
                          )
                        : null,
                    // suffix icon toggles password visibility
                    suffixIcon: IconButton(
                      icon: Icon(_obscurePassword ? Icons.visibility : Icons.visibility_off),
                      onPressed: () {
                        setState(() {
                          _obscurePassword = !_obscurePassword;
                        });
                      },
                      tooltip: _obscurePassword ? getString('authShowPassword') : getString('authHidePassword'),
                    ),
                  ),
                  obscureText: _obscurePassword,
                  onTap: () {
                    if (_isSignUp && !_isSignupEmailApproved) {
                      FocusScope.of(context).unfocus();
                      return;
                    }
                    _scrollPasswordGuidanceIntoView();
                  },
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) {
                    // validate first; if valid, unfocus and submit
                    if (_isLoading) return;
                    final isValid = _formKey.currentState?.validate() ?? false;
                    if (isValid) {
                      FocusScope.of(context).unfocus();
                      _performAuth();
                    } else {
                      // keep focus on password so user can correct it
                      FocusScope.of(context).requestFocus(_passwordFocusNode);
                    }
                  },
                  validator: (v) {
                    if (v == null || v.isEmpty) return getString('authPasswordRequired');
                    if (_isSignUp && !_isSignupPasswordValid(v)) {
                      return getString('authPasswordRequirementsTitle');
                    }
                    return null;
                  },
                ),
                if (_isSignUp && _isPasswordFieldFocused && _hasApprovedSignupEmail && _emailFieldErrorMessage == null) ...[
                  const SizedBox(height: 12),
                  DecoratedBox(
                    key: _passwordRequirementsKey,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: Theme.of(context).dividerColor,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            getString('authPasswordRequirementsTitle'),
                            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                  fontWeight: FontWeight.w600,
                                ),
                          ),
                          const SizedBox(height: 10),
                          _buildPasswordRequirementRow(
                            context,
                            met: _passwordHasMinLength(_passwordController.text),
                            label: getString('authPasswordRuleMinLength'),
                          ),
                          const SizedBox(height: 6),
                          _buildPasswordRequirementRow(
                            context,
                            met: _passwordHasUppercase(_passwordController.text),
                            label: getString('authPasswordRuleUppercase'),
                          ),
                          const SizedBox(height: 6),
                          _buildPasswordRequirementRow(
                            context,
                            met: _passwordHasLowercase(_passwordController.text),
                            label: getString('authPasswordRuleLowercase'),
                          ),
                          const SizedBox(height: 6),
                          _buildPasswordRequirementRow(
                            context,
                            met: _passwordHasNumber(_passwordController.text),
                            label: getString('authPasswordRuleNumber'),
                          ),
                          const SizedBox(height: 6),
                          _buildPasswordRequirementRow(
                            context,
                            met: _passwordHasSpecialCharacter(_passwordController.text),
                            label: getString('authPasswordRuleSpecial'),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 30),
                ElevatedButton(
                  onPressed: _isSignUp && !_isSignupEmailApproved
                      ? null
                      : () => _performAuth(),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    textStyle: const TextStyle(inherit: false),
                  ),
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 200),
                    child: Text(
                      _isSignUp ? getString('authSignUp') : getString('authLogin'),
                      key: ValueKey(_isSignUp),
                      style: const TextStyle(inherit: false),
                    ),
                  ),
                ),
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 16.0),
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.red.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.red.shade200),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.red.shade100.withValues(alpha: 0.6),
                            blurRadius: 18,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(Icons.error_outline, color: Colors.red.shade700),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                _errorMessage!,
                                style: TextStyle(
                                  color: Colors.red.shade800,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    const Expanded(child: Divider()),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12.0),
                      child: Text(getString('authOr')),
                    ),
                    const Expanded(child: Divider()),
                  ],
                ),
                const SizedBox(height: 16),
                _buildOAuthButton(
                  provider: OAuthProvider.google,
                  label: getString('authContinueWithGoogle'),
                  assetPath: 'assets/images/providers/google.png',
                ),
                const SizedBox(height: 12),
                _buildOAuthButton(
                  provider: OAuthProvider.azure,
                  label: getString('authContinueWithMicrosoft'),
                  assetPath: 'assets/images/providers/microsoft.png',
                ),
                const SizedBox(height: 12),
                _buildOAuthButton(
                  provider: OAuthProvider.apple,
                  label: getString('authContinueWithApple'),
                  assetPath: 'assets/images/providers/apple.png',
                ),
                const SizedBox(height: 12),
                _buildOAuthButton(
                  provider: OAuthProvider.facebook,
                  label: getString('authContinueWithFacebook'),
                  assetPath: 'assets/images/providers/facebook.png',
                ),
                const SizedBox(height: 20),
                TextButton(
                  onPressed: _isLoading
                      ? null
                      : () => _switchAuthMode(!_isSignUp),
                  child: Text(_isSignUp ? getString('authToggleToSignIn') : getString('authToggleToSignUp')),
                ),
                const SizedBox(height: 10),
                TextButton(
                  onPressed: _isLoading ? null : _showForgotPasswordDialog,
                  child: Text(getString('authForgotPassword')),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
