// lib/screens/main_navigation_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:matchme/providers/locale_provider.dart';
import 'package:matchme/theme/semantic_colors.dart';
import 'package:matchme/providers/visibility_provider.dart';
import 'package:matchme/providers/home_providers.dart';
import 'package:matchme/providers/match_notification_provider.dart';
import 'package:matchme/providers/invisibility_rules_provider.dart';
import 'package:matchme/providers/connectivity_provider.dart';
import 'package:matchme/services/global_sync_manager.dart';
import 'package:matchme/screens/home/home_screen.dart';
import 'package:matchme/screens/chats/chats_screen.dart';
import 'package:matchme/screens/matches/matches_screen.dart';
import 'package:matchme/screens/profile/profile_screen.dart';
import 'package:matchme/screens/events/events_screen.dart';
import 'package:matchme/widgets/match_notification_overlay.dart';
import 'package:matchme/widgets/custom_app_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:matchme/services/user_activity_service.dart';
import 'package:matchme/providers/current_location_provider.dart';
import 'package:matchme/screens/settings/invisibility_rules_screen.dart';
import 'package:matchme/services/background_service.dart';
import 'package:matchme/utils/resume_route_restore.dart';
import 'package:shared_preferences/shared_preferences.dart';

final supabase = Supabase.instance.client;

/// Subscribes to cached location updates without forcing [MainNavigationScreen] to rebuild.
class _KeepCurrentLocationAlive extends ConsumerWidget {
  const _KeepCurrentLocationAlive();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    ref.watch(currentLocationProvider);
    return const SizedBox.shrink();
  }
}

/// App-bar center strip: connectivity, visibility, invisibility rules — isolated rebuild scope.
class _MainNavAppBarCenter extends ConsumerWidget {
  final bool isVerySmallScreen;
  final bool isSmallScreen;

  const _MainNavAppBarCenter({
    required this.isVerySmallScreen,
    required this.isSmallScreen,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = ref.watch(localizationProvider);
    final isOnline = ref.watch(connectivityProvider).value ?? false;
    final isVisible = ref.watch(isVisibleProvider);
    final rules = ref.watch(invisibilityRulesProvider);
    final isLoaded = rules.isLoaded;
    final currentInvisibilityReasons = ref.watch(currentInvisibilityReasonsProvider);
    final currentInvisibilityReason = ref.watch(currentInvisibilityReasonProvider);
    final hasActiveRules = currentInvisibilityReasons.isNotEmpty;

    if (!isLoaded) {
      return _mainNavVisibilityDetailWidget(
        context,
        l10n,
        hasActiveRules,
        currentInvisibilityReason,
        isOnline,
        isVisible,
        isLoaded,
        null,
        null,
        isVerySmallScreen,
        isSmallScreen,
      );
    }

    if (hasActiveRules) {
      return _mainNavVisibilityDetailWidget(
        context,
        l10n,
        hasActiveRules,
        currentInvisibilityReason,
        isOnline,
        isVisible,
        isLoaded,
        () {
          final activeRuleIds = ref.read(activeRuleIdsProvider);
          final firstActiveRuleId =
              activeRuleIds.keys.isNotEmpty ? activeRuleIds.keys.first : null;
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => InvisibilityRulesScreen(
                highlightRuleId: firstActiveRuleId,
              ),
            ),
          );
        },
        null,
        isVerySmallScreen,
        isSmallScreen,
      );
    }

    String text;
    Color color;
    Widget? switchWidget;

    if (!isOnline) {
      text = isVerySmallScreen
          ? l10n.getString('generalOffShort')
          : (isSmallScreen
              ? l10n.getString('generalOffline')
              : l10n.getString('youAreOffline'));
      color = Theme.of(context).colorScheme.error;
      switchWidget = null;
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 4.0),
        decoration: BoxDecoration(
          color: color.withAlpha((0.1 * 255).round()),
          borderRadius: BorderRadius.circular(16.0),
          border: Border.all(
            color: color.withAlpha((0.2 * 255).round()),
            width: 1,
          ),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: FontWeight.w500,
          ),
        ),
      );
    }

    if (isVisible) {
      text = isVerySmallScreen
          ? l10n.getString('generalOnShort')
          : l10n.getString('youAreCurrentlyOnlineAndVisible');
      final semantic = Theme.of(context).extension<SemanticColors>();
      final Color c = semantic?.success ?? const Color(0xFF10B981);
      final Color bg = semantic?.successContainer ?? const Color(0xFFDCFCE7);
      switchWidget = Transform.scale(
        scale: isSmallScreen ? 0.8 : 0.88,
        child: Switch(
          value: isVisible,
          onChanged: (value) {
            ref.read(isVisibleProvider.notifier).setVisibility(value);
          },
          activeThumbColor: c,
          inactiveThumbColor: Theme.of(context).colorScheme.error,
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
      );
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16.0),
          border: Border.all(
            color: c.withAlpha((0.2 * 255).round()),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Text(
                text,
                maxLines: 2,
                overflow: TextOverflow.visible,
                softWrap: true,
                style: TextStyle(
                  color: c,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(width: 4),
            switchWidget,
          ],
        ),
      );
    }

    text = isVerySmallScreen
        ? l10n.getString('generalOnInvisibleShort')
        : '${l10n.getString('youAreCurrentlyOnline').trimRight()} ${l10n.getString('andInvisible').trimLeft()}';
    color = Theme.of(context).colorScheme.error;
    switchWidget = Transform.scale(
      scale: isSmallScreen ? 0.8 : 0.88,
      child: Switch(
        value: isVisible,
        onChanged: (value) {
          ref.read(isVisibleProvider.notifier).setVisibility(value);
        },
        activeThumbColor: Theme.of(context).colorScheme.secondary,
        inactiveThumbColor: Theme.of(context).colorScheme.error,
        materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      ),
    );
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
      decoration: BoxDecoration(
        color: color.withAlpha((0.1 * 255).round()),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: color.withAlpha((0.2 * 255).round()),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Flexible(
            child: Text(
              text,
              maxLines: 2,
              overflow: TextOverflow.visible,
              softWrap: true,
              style: TextStyle(
                color: color,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          const SizedBox(width: 4),
          switchWidget,
        ],
      ),
    );
  }
}

Widget _mainNavVisibilityDetailWidget(
  BuildContext context,
  LocalizationState l10n,
  bool hasActiveRules,
  String? currentInvisibilityReason,
  bool isOnline,
  bool isVisible,
  bool isLoaded,
  VoidCallback? onTap,
  ValueChanged<bool>? onVisibilityChanged,
  bool isVerySmallScreen,
  bool isSmallScreen,
) {
  if (!isLoaded) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
      decoration: BoxDecoration(
        color: Colors.grey.withAlpha((0.1 * 255).round()),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: Colors.grey.withAlpha((0.2 * 255).round()),
          width: 1,
        ),
      ),
      clipBehavior: Clip.hardEdge,
      child: Text(
        l10n.getString('generalLoadingDots'),
        style: TextStyle(
          color: Colors.grey,
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget child;
  if (!isOnline) {
    final color = Theme.of(context).colorScheme.error;
    child = Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
      decoration: BoxDecoration(
        color: color.withAlpha((0.1 * 255).round()),
        borderRadius: BorderRadius.circular(16.0),
        border: Border.all(
          color: color.withAlpha((0.2 * 255).round()),
          width: 1,
        ),
      ),
      clipBehavior: Clip.hardEdge,
      child: Text(
        l10n.getString('youAreOffline'),
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  } else if (hasActiveRules) {
    final color = Theme.of(context).colorScheme.tertiary;
    final reasonText = currentInvisibilityReason!.replaceFirst(
      l10n.getString('youAreInvisibleDueTo'),
      l10n.getString('invisibleDueTo'),
    );
    child = InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
        decoration: BoxDecoration(
          color: color.withAlpha((0.1 * 255).round()),
          borderRadius: BorderRadius.circular(16.0),
          border: Border.all(
            color: color.withAlpha((0.2 * 255).round()),
            width: 1,
          ),
        ),
        clipBehavior: Clip.hardEdge,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.visibility_off,
              size: 14,
              color: color,
            ),
            const SizedBox(width: 4),
            Flexible(
              child: Text(
                l10n
                    .getString('youAreCurrentlyOnlineAnd')
                    .replaceAll('{reason}', reasonText),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  } else {
    if (isVisible) {
      final semantic = Theme.of(context).extension<SemanticColors>();
      final Color color = semantic?.success ?? const Color(0xFF10B981);
      final Color bg = semantic?.successContainer ?? const Color(0xFFDCFCE7);
      child = Container(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16.0),
          border: Border.all(
            color: color.withAlpha((0.2 * 255).round()),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: Text(
                l10n.getString('youAreCurrentlyOnlineAndVisible'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
                style: TextStyle(
                  color: color,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            Transform.scale(
              scale: isSmallScreen ? 0.8 : 0.88,
              child: Switch(
                value: isVisible,
                onChanged: onVisibilityChanged,
                activeThumbColor: color,
                inactiveTrackColor: Colors.grey.shade300,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ),
          ],
        ),
      );
    } else {
      final semantic = Theme.of(context).extension<SemanticColors>();
      final Color onlineColor =
          semantic?.success ?? Theme.of(context).colorScheme.secondary;
      final Color onlineBg = semantic?.successContainer ??
          onlineColor.withAlpha((0.1 * 255).round());
      child = Container(
        padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 2.0),
        decoration: BoxDecoration(
          color: onlineBg,
          borderRadius: BorderRadius.circular(16.0),
          border: Border.all(
            color: onlineColor.withAlpha((0.2 * 255).round()),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: l10n.getString('youAreCurrentlyOnline').trimRight(),
                      style: TextStyle(
                        color: onlineColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const TextSpan(text: ' '),
                    TextSpan(
                      text: l10n.getString('andInvisible').trimLeft(),
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                        fontSize: 11,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Transform.scale(
              scale: isSmallScreen ? 0.8 : 0.88,
              child: Switch(
                value: isVisible,
                onChanged: onVisibilityChanged,
                activeThumbColor: onlineColor,
                inactiveTrackColor: Colors.grey.shade300,
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
              ),
            ),
          ],
        ),
      );
    }
  }

  return child;
}

class MainNavigationScreen extends ConsumerStatefulWidget {
  final int initialIndex;
  const MainNavigationScreen({super.key, this.initialIndex = 0});
  @override
  ConsumerState<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends ConsumerState<MainNavigationScreen> with WidgetsBindingObserver {
  Timer? _activityTimer;
  final GlobalKey<NavigatorState> _eventsNavigatorKey = GlobalKey<NavigatorState>();
  bool _didAttemptPendingRouteRestore = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _updateUserActivity();
        unawaited(_restoreNavigationContext());

        // Start background service for authenticated user
        final currentUserId = supabase.auth.currentUser?.id;
        if (currentUserId != null) {
          _saveLoginState(currentUserId);
          BackgroundService.start();
        }
      }
    });
  }

  Future<void> _restoreNavigationContext() async {
    // Always start at Home screen (index 0) on app startup
    // Do not restore the last tab index
    if (!mounted) return;

    ref.read(navigationIndexProvider.notifier).setIndex(widget.initialIndex);

    if (_didAttemptPendingRouteRestore) return;
    _didAttemptPendingRouteRestore = true;

    final initialRoute = await BackgroundService.getInitialRoute();
    final hasExternalLaunchIntent =
        initialRoute?['route'] != null ||
        initialRoute?['sharedText'] != null ||
        initialRoute?['sharedFilePath'] != null ||
        initialRoute?['tabIndex'] != null;

    if (hasExternalLaunchIntent) {
      await ResumeRouteRestore.clearPendingRoute();
      return;
    }

    final pendingRouteName = await ResumeRouteRestore.consumePendingRouteName();
    if (!mounted || pendingRouteName == null || pendingRouteName == '/') return;

    switch (pendingRouteName) {
      case ResumeRouteRestore.settingsRoute:
      case ResumeRouteRestore.notificationsSettingsRoute:
      case ResumeRouteRestore.securityCenterRoute:
        Navigator.of(context).pushNamed(pendingRouteName);
        break;
      default:
        break;
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _activityTimer?.cancel();
    super.dispose();
  }

  Future<void> _updateUserActivity() async {
    final user = supabase.auth.currentUser;
    if (user != null) {
      await UserActivityService.instance.pingIfDue(
        user.id,
        source: 'main-navigation',
      );
    }
  }

  Future<void> _saveLoginState(String userId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('was_logged_in', true);
      await prefs.setString('user_id', userId);
      // Store Supabase config for background service
      // These are set during app initialization in main.dart
      final supabaseUrl = prefs.getString('supabase_url') ?? 'https://your-project.supabase.co';
      final supabaseKey = prefs.getString('supabase_key') ?? 'your-anon-key';
      await prefs.setString('stored_supabase_url', supabaseUrl);
      await prefs.setString('stored_supabase_key', supabaseKey);
    } catch (e) {
      print('Error saving login state: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentIndex = ref.watch(navigationIndexProvider);
    final userId = supabase.auth.currentUser?.id;

    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 400;
    final isVerySmallScreen = screenWidth < 350;

    final List<Widget> screens = [
      const HomeScreen(),
      const MatchesScreen(),
      const ChatsScreen(),
      EventsTab(navigatorKey: _eventsNavigatorKey),
      const ProfileScreen(),
    ];

    final List<String> appBarTitleKeys = ['navHome', 'navMatches', 'navChats', 'navEvents', 'navProfile'];
    final safeIndex = currentIndex < 0 ? 0 : (currentIndex >= appBarTitleKeys.length ? appBarTitleKeys.length - 1 : currentIndex);

    return Stack(
      children: [
        Scaffold(
          appBar: _MainNavAppBar(
            safeIndex: safeIndex,
            appBarTitleKeys: appBarTitleKeys,
            isSmallScreen: isSmallScreen,
            isVerySmallScreen: isVerySmallScreen,
            userId: userId,
          ),
          body: Column(
            children: [
              Expanded(
                child: IndexedStack(
                  index: safeIndex,
                  children: screens,
                ),
              ),
            ],
          ),
          bottomNavigationBar: _MainNavBottomBar(
            safeIndex: safeIndex,
          ),
        ),
        const MatchNotificationOverlay(),
        const _KeepCurrentLocationAlive(),
      ],
    );
  }

}

class _MainNavAppBar extends ConsumerWidget implements PreferredSizeWidget {
  final int safeIndex;
  final List<String> appBarTitleKeys;
  final bool isSmallScreen;
  final bool isVerySmallScreen;
  final String? userId;

  const _MainNavAppBar({
    required this.safeIndex,
    required this.appBarTitleKeys,
    required this.isSmallScreen,
    required this.isVerySmallScreen,
    required this.userId,
  });

  /// Must match [buildCustomAppBar] bottom [PreferredSize] height (56).
  static const double _centerStripHeight = 56;

  @override
  Size get preferredSize =>
      const Size.fromHeight(kToolbarHeight + _centerStripHeight);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = ref.watch(localizationProvider);
    final screenName = l10n.getString(appBarTitleKeys[safeIndex]);
    final iconPadding = isSmallScreen ? 6.0 : 8.0;

    final List<Widget> actions = [
      IconButton(
        icon: Container(
          padding: EdgeInsets.all(iconPadding),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(Icons.settings_outlined,
              color: Theme.of(context).colorScheme.onSurface.withValues(alpha: 0.7)),
        ),
        tooltip: l10n.getString('settingsTitle'),
        onPressed: () {
          if (userId == null) return;
          Navigator.of(context).pushNamed(ResumeRouteRestore.settingsRoute);
        },
      ),
      IconButton(
        icon: Container(
          padding: EdgeInsets.all(iconPadding),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.error.withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Transform(
            alignment: Alignment.center,
            transform: Matrix4.diagonal3Values(
              l10n.textDirection == TextDirection.rtl ? -1.0 : 1.0,
              1.0,
              1.0,
            ),
            child: Icon(Icons.logout_rounded,
                color: Theme.of(context).colorScheme.error),
          ),
        ),
        tooltip: l10n.getString('authLogout'),
        onPressed: () async {
          Future<void> clearLoginState() async {
            try {
              final prefs = await SharedPreferences.getInstance();
              await prefs.remove('was_logged_in');
              await prefs.remove('user_id');
              await prefs.remove('supabase_url');
              await prefs.remove('supabase_key');
            } catch (_) {}
          }

          try {
            ref.read(globalSyncManagerProvider).dispose();
            await clearLoginState();
            try {
              final user = supabase.auth.currentUser;
              if (user != null) {
                await supabase.rpc('revoke_all_user_sessions',
                    params: {'p_user_id': user.id});
              }
            } catch (e) {
              print('revoke_all_user_sessions failed: $e');
            }
            await supabase.auth.signOut();
          } catch (e) {
            print('Logout error: $e');
            ref.read(globalSyncManagerProvider).dispose();
            await BackgroundService.stop();
            await clearLoginState();
          }
        },
      ),
    ];

    return buildCustomAppBar(
      context,
      ref,
      l10n,
      screenName,
      actions,
      centerWidget: _MainNavAppBarCenter(
        isVerySmallScreen: isVerySmallScreen,
        isSmallScreen: isSmallScreen,
      ),
    );
  }
}

class _MainNavBottomBar extends ConsumerWidget {
  final int safeIndex;

  const _MainNavBottomBar({required this.safeIndex});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = ref.watch(localizationProvider);

    return BottomNavigationBar(
      currentIndex: safeIndex,
      onTap: (index) {
        ref.read(navigationIndexProvider.notifier).setIndex(index);
        unawaited(ResumeRouteRestore.saveLastMainTabIndex(index));
      },
      type: BottomNavigationBarType.fixed,
      selectedItemColor: Theme.of(context).colorScheme.primary,
      unselectedItemColor: Colors.grey,
      showUnselectedLabels: true,
      items: [
        BottomNavigationBarItem(
          icon: const Icon(Icons.home_outlined),
          activeIcon: const Icon(Icons.home),
          label: l10n.getString('navHome'),
        ),
        BottomNavigationBarItem(
          icon: const _UnreadMatchesNavIcon(icon: Icons.favorite_border),
          activeIcon: const _UnreadMatchesNavIcon(icon: Icons.favorite),
          label: l10n.getString('navMatches'),
        ),
        BottomNavigationBarItem(
          icon: const _UnreadChatsNavIcon(icon: Icons.chat_bubble_outline),
          activeIcon: const _UnreadChatsNavIcon(icon: Icons.chat_bubble),
          label: l10n.getString('navChats'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.calendar_today_outlined),
          activeIcon: const Icon(Icons.calendar_today),
          label: l10n.getString('navEvents'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.person_outline),
          activeIcon: const Icon(Icons.person),
          label: l10n.getString('navProfile'),
        ),
      ],
    );
  }
}

class _UnreadMatchesNavIcon extends ConsumerWidget {
  final IconData icon;
  const _UnreadMatchesNavIcon({required this.icon});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final count = ref.watch(unreadMatchCountProvider);
    return _NavBadgeIcon(icon: icon, count: count);
  }
}

class _UnreadChatsNavIcon extends ConsumerWidget {
  final IconData icon;
  const _UnreadChatsNavIcon({required this.icon});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final count = ref.watch(totalUnreadChatCountProvider);
    return _NavBadgeIcon(icon: icon, count: count);
  }
}

class _NavBadgeIcon extends StatelessWidget {
  final IconData icon;
  final int count;
  const _NavBadgeIcon({required this.icon, required this.count});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Icon(icon),
        if (count > 0)
          Positioned(
            right: 0,
            top: 0,
            child: Container(
              padding: const EdgeInsets.all(2),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.error,
                borderRadius: BorderRadius.circular(10),
              ),
              constraints: const BoxConstraints(
                minWidth: 16,
                minHeight: 16,
              ),
              child: Text(
                count > 99 ? '99+' : count.toString(),
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onError,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ),
      ],
    );
  }
}
